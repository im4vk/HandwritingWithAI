# 🌍 Live DDoS Attack Map Demo

## 🎯 What This Demo Shows

This demonstration provides a **real-time visualization** of simulated DDoS attacks happening around the world. It's designed to showcase:

### Real-Time Visualization Features
- **Interactive World Map**: Global view with animated attack flows
- **Live Attack Animations**: Watch attacks travel from source to target countries
- **Attack Statistics**: Real-time counters and metrics
- **Attack Type Distribution**: Pie chart showing different DDoS attack types
- **Recent Attacks Feed**: Scrolling list of latest detected attacks

### Attack Data Simulation
- **Geographic Realism**: Attacks originate from and target realistic country locations
- **Attack Variety**: Multiple types including Volumetric, Protocol, Application Layer, etc.
- **Intensity Levels**: Color-coded severity from 1-10 scale
- **Traffic Metrics**: Realistic bandwidth usage and packet rates

## 🚀 Quick Start

### Option 1: Using the Start Script
```bash
./start_demo.sh
```

### Option 2: Manual Start
```bash
# Install dependencies
pip install -r requirements.txt

# Run the demo
python app.py
```

### Option 3: Using the Python Runner
```bash
python run_demo.py
```

## 🎮 How to Use the Demo

1. **Open your browser** and go to: `http://localhost:5000`

2. **Watch the Map**: 
   - Attacks appear as animated lines between countries
   - Markers show attack sources (red) and targets (larger markers)
   - Colors indicate intensity: Green (low), Yellow (medium), Red (high)

3. **Explore the Interface**:
   - **Left Panel**: Live statistics and recent attacks feed
   - **Map Controls**: Global view, clear map, pause/resume buttons
   - **Attack Details**: Click on any marker or feed item for details

4. **Interactive Features**:
   - Click attack markers for detailed popup information
   - Use keyboard shortcuts (Spacebar to pause, G for global view)
   - Hover over elements for additional information

## 📊 What You'll See

### Attack Statistics
- **Total Attacks**: Running count of all detected attacks
- **Attacks Per Minute**: Current attack rate
- **Countries Affected**: Number of unique countries involved
- **Average Intensity**: Mean severity level

### Attack Types Visualized
- **Volumetric**: High-bandwidth consumption attacks
- **Protocol**: TCP/UDP protocol exploitation
- **Application Layer**: HTTP/HTTPS application attacks
- **Reflection/Amplification**: DNS/NTP amplification attacks
- **Botnet**: Distributed zombie network attacks

### Geographic Patterns
- **Common Sources**: China, Russia, Eastern Europe, compromised networks
- **Common Targets**: US, Europe, major business centers
- **Attack Flows**: Realistic country-to-country attack patterns

## 🎨 Visual Elements

### Color Coding
- **🟢 Green (1-3)**: Low intensity attacks
- **🟡 Yellow (4-6)**: Medium intensity attacks  
- **🔴 Red (7-10)**: High intensity attacks

### Animation Effects
- **Attack Lines**: Animated paths showing attack direction
- **Marker Pulses**: Intensity-based pulsing effects
- **Real-time Updates**: Smooth transitions and updates

## 🔧 Technical Details

### Technologies Used
- **Backend**: Python Flask + SocketIO for real-time communication
- **Frontend**: Leaflet.js for interactive mapping
- **Charts**: Chart.js for statistics visualization
- **UI Framework**: Bootstrap 5 with custom dark theme
- **Real-time**: WebSocket connections for live updates

### Simulated Data Sources
- **IP Geolocation**: Mock geographic data (GeoLite2 database optional)
- **Attack Patterns**: Realistic timing and frequency simulation
- **Traffic Metrics**: Authentic bandwidth and packet rate calculations
- **Geographic Distribution**: Real-world attack source/target patterns

## 🎯 Demo Scenarios

### Typical Demo Flow
1. **Initial View**: Global map with scattered attack activity
2. **Intensity Variations**: Watch attacks of different severities
3. **Geographic Hotspots**: Notice attacks concentrated in certain regions
4. **Statistics Evolution**: Observe counters and charts updating
5. **Attack Details**: Click on attacks to see detailed information

### Key Demonstration Points
- **Real-time Nature**: Attacks appear continuously and automatically
- **Global Scope**: Attacks span multiple continents
- **Variety**: Different attack types, intensities, and durations
- **Professional Interface**: Enterprise-quality visualization tools

## 🛡️ Educational Value

### Cybersecurity Awareness
- **Attack Scale**: Demonstrates the global nature of DDoS threats
- **Attack Variety**: Shows different types of DDoS attacks
- **Geographic Patterns**: Illustrates common attack origins and targets
- **Impact Visualization**: Makes abstract network attacks tangible

### Technical Learning
- **Network Security**: Understanding DDoS attack mechanics
- **Threat Intelligence**: Visualizing security data
- **Real-time Monitoring**: Importance of continuous security monitoring
- **Global Perspective**: Cybersecurity as a worldwide concern

## 🎪 Perfect for Demonstrations

### Suitable Audiences
- **Security Teams**: Network operations centers (NOCs)
- **Executive Presentations**: High-level security briefings
- **Educational Settings**: Cybersecurity training and workshops
- **Trade Shows**: Conference demonstrations and exhibits
- **Sales Presentations**: Security product showcases

### Presentation Tips
- Start with global view to show overall activity
- Click on attacks to show detailed information capabilities
- Highlight real-time nature and continuous monitoring
- Discuss geographic patterns and threat landscapes
- Demonstrate pause/resume for controlled viewing

---

**🚨 Important**: This is a simulation for demonstration purposes. No real attacks are detected or displayed. All data is generated for educational and showcase purposes.
