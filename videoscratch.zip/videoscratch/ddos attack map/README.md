# Live DDoS Attack Map 🌍⚡

A real-time visualization system that showcases global DDoS attacks happening around the world. This demo provides an interactive map with animated attack flows, statistics, and threat intelligence data.

## 🎯 Features

### Real-time Visualization
- **Interactive World Map**: Live global view of DDoS attacks with country-to-country attack flows
- **Animated Attack Lines**: Visual representation of attack paths with intensity-based coloring
- **Attack Markers**: Source and target indicators with detailed information popups
- **Real-time Statistics**: Live counters for total attacks, attack rates, and geographic distribution

### Dashboard Components
- **Attack Types Chart**: Pie chart showing distribution of different DDoS attack types
- **Recent Attacks Feed**: Live scrolling feed of the latest detected attacks
- **Intensity Mapping**: Color-coded visualization based on attack severity (1-10 scale)
- **Geographic Statistics**: Real-time tracking of affected countries and regions

### Advanced Features
- **WebSocket Integration**: Real-time data streaming for instant updates
- **Attack Simulation**: Intelligent attack generation with realistic geographic and temporal patterns
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Keyboard Shortcuts**: Quick navigation and control options
- **Attack Details Modal**: Comprehensive information about individual attacks

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip (Python package manager)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Installation

1. **Clone or navigate to the project directory:**
   ```bash
   cd "/ddos attack map"
   ```

2. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

4. **Open your browser and navigate to:**
   ```
   http://localhost:5000
   ```

### Alternative Installation with Virtual Environment

1. **Create virtual environment:**
   ```bash
   python -m venv ddos_env
   source ddos_env/bin/activate  # On Windows: ddos_env\\Scripts\\activate
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application:**
   ```bash
   python app.py
   ```

## 🎮 Usage Guide

### Main Interface

#### Map Controls
- **Global View Button** (🌍): Reset map to global view
- **Heatmap Toggle** (🔥): Switch between marker and heatmap views
- **Clear Map** (🗑️): Remove all current attack visualizations
- **Pause/Resume**: Control real-time attack monitoring

#### Statistics Panel
- **Total Attacks**: Cumulative count of detected attacks
- **Attacks Per Minute**: Real-time attack rate
- **Countries Affected**: Number of unique countries involved
- **Average Intensity**: Mean attack severity level

#### Recent Attacks Feed
- Click on any attack in the feed to view detailed information
- Automatically updates with new attacks
- Shows source → target country flows
- Color-coded by attack type and intensity

### Keyboard Shortcuts
- **Spacebar**: Pause/Resume monitoring
- **G**: Global view
- **Ctrl+C**: Clear map
- **ESC**: Close modals and popups

### Attack Information
Click on any attack marker or feed item to view:
- Source and target IP addresses
- Geographic coordinates
- Attack type and intensity
- Traffic metrics (packets/sec, bandwidth)
- Risk assessment and threat level

## 🏗️ Architecture

### Backend Components

#### Flask Application (`app.py`)
- **Attack Monitor**: Core monitoring system that generates and manages attack data
- **GeoIP Manager**: Handles IP geolocation using MaxMind GeoLite2 database
- **Threat Intelligence**: Simulates realistic DDoS attack patterns
- **WebSocket Server**: Real-time data streaming via Flask-SocketIO

#### Data Models
```python
@dataclass
class DDoSAttack:
    source_ip: str
    target_ip: str
    source_country: str
    target_country: str
    source_coords: Tuple[float, float]
    target_coords: Tuple[float, float]
    attack_type: str
    intensity: int  # 1-10 scale
    timestamp: str
    duration: int  # seconds
    packets_per_second: int
    bandwidth_mbps: float
```

### Frontend Components

#### Interactive Map (`static/js/app.js`)
- **Leaflet.js**: Open-source mapping library with dark theme
- **Real-time Markers**: Dynamic attack source/target visualization
- **Animated Attack Lines**: SVG-based attack flow animations
- **Chart.js Integration**: Statistical visualization components

#### Responsive UI (`templates/index.html`)
- **Bootstrap 5**: Modern responsive framework
- **Font Awesome Icons**: Professional iconography
- **Custom CSS**: Dark theme with cybersecurity aesthetics
- **WebSocket Client**: Real-time data synchronization

## 🔧 Configuration

### Environment Variables
Create a `.env` file in the project root:
```bash
# Server Configuration
FLASK_PORT=5000
FLASK_HOST=0.0.0.0
DEBUG_MODE=False

# Attack Generation
ATTACK_FREQUENCY_MIN=2  # Minimum seconds between attacks
ATTACK_FREQUENCY_MAX=5  # Maximum seconds between attacks
MAX_STORED_ATTACKS=1000

# GeoIP Database
GEOIP_DATABASE_PATH=./data/GeoLite2-City.mmdb
```

### Attack Types Configuration
The system simulates various DDoS attack types:
- **Volumetric Attacks**: High-bandwidth consumption
- **Protocol Attacks**: Exploit protocol vulnerabilities
- **Application Layer**: Target specific applications
- **Reflection/Amplification**: Use third-party servers
- **Botnet Attacks**: Distributed zombie networks

## 📊 Data Sources

### Simulated Intelligence Feeds
The demo generates realistic attack data based on:
- **Geographic Patterns**: Real-world attack source/target distributions
- **Temporal Patterns**: Realistic timing and frequency variations
- **Attack Characteristics**: Authentic traffic metrics and attack types
- **IP Ranges**: Public IP address generation avoiding private ranges

### Optional Real Data Integration
For production use, the system can integrate with:
- **Honeypot Networks**: Real attack detection sensors
- **Threat Intelligence APIs**: Commercial and open-source feeds
- **SIEM Systems**: Enterprise security information platforms
- **Network Monitoring**: Actual traffic analysis tools

## 🛠️ Customization

### Adding Custom Attack Types
Edit the `ThreatIntelligence` class in `app.py`:
```python
self.attack_types = [
    "Volumetric", "Protocol", "Application Layer",
    "Custom_Attack_Type"  # Add your custom type
]
```

### Modifying Map Appearance
Update the tile layer in `static/js/app.js`:
```javascript
L.tileLayer('https://your-custom-tiles/{z}/{x}/{y}.png', {
    attribution: 'Your attribution',
    // ... other options
}).addTo(this.map);
```

### Custom Statistics
Add new metrics in the `updateStats()` method:
```javascript
// Calculate custom statistic
const customStat = this.attacks.filter(/* your condition */).length;
document.getElementById('custom-stat').textContent = customStat;
```

## 🔒 Security Considerations

### Demo Mode
- All attack data is **simulated** - no real attacks are detected
- IP addresses are randomly generated for demonstration
- No actual network traffic is analyzed
- Geographic data uses mock locations when GeoIP database unavailable

### Production Deployment
For real-world deployment:
- Implement proper authentication and authorization
- Use HTTPS/WSS for encrypted communication
- Sanitize and validate all input data
- Implement rate limiting and DoS protection
- Add proper logging and audit trails

## 📈 Performance

### Optimization Features
- **Memory Management**: Automatic cleanup of old attack data
- **Marker Limiting**: Prevents excessive map markers
- **Efficient Updates**: Selective DOM updates for better performance
- **Background Processing**: Non-blocking attack generation

### System Requirements
- **RAM**: Minimum 512MB available
- **CPU**: Any modern processor
- **Network**: Minimal bandwidth for local demo
- **Browser**: Modern browser with WebSocket support

## 🐛 Troubleshooting

### Common Issues

#### "Module not found" errors
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

#### Port already in use
```bash
# Change port in app.py or kill existing process
lsof -ti:5000 | xargs kill
```

#### Map not loading
- Check browser console for JavaScript errors
- Ensure internet connection for map tiles
- Verify all CSS/JS files are accessible

#### No attacks appearing
- Check browser WebSocket support
- Verify server is running without errors
- Check firewall/proxy settings

### Debug Mode
Run the application in debug mode:
```bash
python app.py --debug
```

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create feature branch: `git checkout -b feature-name`
3. Make changes and test thoroughly
4. Submit pull request with detailed description

### Code Style
- Follow PEP 8 for Python code
- Use meaningful variable and function names
- Add comments for complex logic
- Write unit tests for new features

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **Leaflet.js**: Open-source mapping library
- **Chart.js**: Beautiful chart visualizations
- **Bootstrap**: Responsive web framework
- **Font Awesome**: Icon library
- **MaxMind GeoLite2**: IP geolocation database
- **Flask-SocketIO**: Real-time web applications

## 📞 Support

For questions, issues, or feature requests:
- Create an issue in the project repository
- Check existing documentation and troubleshooting guides
- Review the code comments for implementation details

---

**⚠️ Disclaimer**: This is a demonstration system that generates simulated DDoS attack data for educational and showcase purposes. It does not perform actual network monitoring or detect real attacks.
