#!/usr/bin/env python3
"""
Live DDoS Attack Visualization Demo
Real-time global DDoS attack monitoring and visualization system
"""

import os
import sys
import json
import time
import random
import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import requests
import geoip2.database
import geoip2.errors
from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import schedule
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
import ipaddress

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ddos_demo.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'ddos-demo-secret-key-2024'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

@dataclass
class DDoSAttack:
    """Represents a DDoS attack event"""
    source_ip: str
    target_ip: str
    source_country: str
    target_country: str
    source_coords: Tuple[float, float]
    target_coords: Tuple[float, float]
    attack_type: str
    intensity: int  # 1-10 scale
    timestamp: str
    duration: int  # seconds
    packets_per_second: int
    bandwidth_mbps: float

class GeoIPManager:
    """Manages GeoIP database for IP geolocation"""
    
    def __init__(self):
        self.reader = None
        self._init_geoip_db()
    
    def _init_geoip_db(self):
        """Initialize GeoIP database"""
        try:
            # Try to use GeoLite2 database if available
            db_paths = [
                'GeoLite2-City.mmdb',
                '/usr/share/GeoIP/GeoLite2-City.mmdb',
                './data/GeoLite2-City.mmdb'
            ]
            
            for db_path in db_paths:
                if os.path.exists(db_path):
                    self.reader = geoip2.database.Reader(db_path)
                    logger.info(f"GeoIP database loaded from {db_path}")
                    return
            
            logger.warning("GeoIP database not found, using mock data")
            
        except Exception as e:
            logger.error(f"Failed to initialize GeoIP database: {e}")
    
    def get_location(self, ip: str) -> Tuple[Optional[str], Optional[Tuple[float, float]]]:
        """Get country and coordinates for an IP address"""
        try:
            if self.reader:
                response = self.reader.city(ip)
                country = response.country.name or "Unknown"
                coords = (float(response.location.latitude or 0), 
                         float(response.location.longitude or 0))
                return country, coords
            else:
                # Mock data for demonstration
                return self._get_mock_location()
                
        except (geoip2.errors.AddressNotFoundError, ValueError):
            return self._get_mock_location()
        except Exception as e:
            logger.error(f"Error getting location for {ip}: {e}")
            return self._get_mock_location()
    
    def _get_mock_location(self) -> Tuple[str, Tuple[float, float]]:
        """Generate mock location data for demo purposes"""
        countries = [
            ("United States", (39.8283, -98.5795)),
            ("China", (35.8617, 104.1954)),
            ("Russia", (61.5240, 105.3188)),
            ("Germany", (51.1657, 10.4515)),
            ("United Kingdom", (55.3781, -3.4360)),
            ("France", (46.2276, 2.2137)),
            ("Brazil", (-14.2350, -51.9253)),
            ("India", (20.5937, 78.9629)),
            ("Japan", (36.2048, 138.2529)),
            ("South Korea", (35.9078, 127.7669)),
            ("Australia", (-25.2744, 133.7751)),
            ("Canada", (56.1304, -106.3468)),
            ("Netherlands", (52.1326, 5.2913)),
            ("Sweden", (60.1282, 18.6435)),
            ("Ukraine", (48.3794, 31.1656))
        ]
        return random.choice(countries)

class ThreatIntelligence:
    """Simulates threat intelligence feeds for DDoS attacks"""
    
    def __init__(self, geo_manager: GeoIPManager):
        self.geo_manager = geo_manager
        self.attack_types = [
            "Volumetric", "Protocol", "Application Layer", 
            "Reflection", "Amplification", "Botnet", 
            "SYN Flood", "UDP Flood", "HTTP Flood", "DNS Amplification"
        ]
        
    def generate_attack(self) -> DDoSAttack:
        """Generate a simulated DDoS attack"""
        # Generate random source and target IPs
        source_ip = self._generate_random_ip()
        target_ip = self._generate_random_ip()
        
        # Get geolocation data
        source_country, source_coords = self.geo_manager.get_location(source_ip)
        target_country, target_coords = self.geo_manager.get_location(target_ip)
        
        # Generate attack characteristics
        attack_type = random.choice(self.attack_types)
        intensity = random.randint(1, 10)
        packets_per_second = random.randint(1000, 1000000) * intensity
        bandwidth_mbps = round(random.uniform(10, 10000) * (intensity / 10), 2)
        duration = random.randint(30, 3600)  # 30 seconds to 1 hour
        
        return DDoSAttack(
            source_ip=source_ip,
            target_ip=target_ip,
            source_country=source_country or "Unknown",
            target_country=target_country or "Unknown",
            source_coords=source_coords or (0, 0),
            target_coords=target_coords or (0, 0),
            attack_type=attack_type,
            intensity=intensity,
            timestamp=datetime.now().isoformat(),
            duration=duration,
            packets_per_second=packets_per_second,
            bandwidth_mbps=bandwidth_mbps
        )
    
    def _generate_random_ip(self) -> str:
        """Generate a random public IP address"""
        # Avoid private IP ranges
        while True:
            ip = f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"
            try:
                ip_obj = ipaddress.ip_address(ip)
                if ip_obj.is_global:
                    return ip
            except ValueError:
                continue

class AttackMonitor:
    """Monitors and manages DDoS attack data"""
    
    def __init__(self):
        self.geo_manager = GeoIPManager()
        self.threat_intel = ThreatIntelligence(self.geo_manager)
        self.active_attacks = deque(maxlen=1000)  # Keep last 1000 attacks
        self.attack_stats = defaultdict(int)
        self.country_stats = defaultdict(int)
        self.running = False
        
    def start_monitoring(self):
        """Start the attack monitoring system"""
        self.running = True
        logger.info("Starting DDoS attack monitoring...")
        
        # Schedule regular attack generation
        schedule.every(2).to(5).seconds.do(self._generate_new_attack)
        
        # Run scheduler in background thread
        threading.Thread(target=self._run_scheduler, daemon=True).start()
        
        # Emit periodic updates
        threading.Thread(target=self._emit_updates, daemon=True).start()
    
    def stop_monitoring(self):
        """Stop the attack monitoring system"""
        self.running = False
        logger.info("Stopping DDoS attack monitoring...")
    
    def _run_scheduler(self):
        """Run the attack generation scheduler"""
        while self.running:
            schedule.run_pending()
            time.sleep(1)
    
    def _generate_new_attack(self):
        """Generate and process a new attack"""
        try:
            attack = self.threat_intel.generate_attack()
            self.active_attacks.append(attack)
            
            # Update statistics
            self.attack_stats[attack.attack_type] += 1
            self.attack_stats['total'] += 1
            self.country_stats[f"{attack.source_country} -> {attack.target_country}"] += 1
            
            logger.info(f"New attack detected: {attack.source_country} -> {attack.target_country} "
                       f"({attack.attack_type}, Intensity: {attack.intensity})")
            
        except Exception as e:
            logger.error(f"Error generating attack: {e}")
    
    def _emit_updates(self):
        """Emit real-time updates via WebSocket"""
        while self.running:
            try:
                if self.active_attacks:
                    latest_attack = self.active_attacks[-1]
                    socketio.emit('new_attack', asdict(latest_attack))
                    
                # Emit statistics update every 10 seconds
                if int(time.time()) % 10 == 0:
                    socketio.emit('stats_update', {
                        'attack_stats': dict(self.attack_stats),
                        'country_stats': dict(self.country_stats),
                        'total_attacks': len(self.active_attacks)
                    })
                    
                time.sleep(1)
            except Exception as e:
                logger.error(f"Error emitting updates: {e}")
                time.sleep(5)
    
    def get_recent_attacks(self, limit: int = 100) -> List[Dict]:
        """Get recent attacks as dictionaries"""
        return [asdict(attack) for attack in list(self.active_attacks)[-limit:]]
    
    def get_statistics(self) -> Dict:
        """Get current attack statistics"""
        return {
            'attack_types': dict(self.attack_stats),
            'country_flows': dict(self.country_stats),
            'total_attacks': len(self.active_attacks),
            'attacks_last_hour': len([a for a in self.active_attacks 
                                    if datetime.fromisoformat(a.timestamp) > 
                                    datetime.now() - timedelta(hours=1)])
        }

# Global attack monitor instance
attack_monitor = AttackMonitor()

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html')

@app.route('/api/attacks')
def get_attacks():
    """API endpoint to get recent attacks"""
    limit = request.args.get('limit', 100, type=int)
    return jsonify(attack_monitor.get_recent_attacks(limit))

@app.route('/api/stats')
def get_stats():
    """API endpoint to get attack statistics"""
    return jsonify(attack_monitor.get_statistics())

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    logger.info(f"Client connected: {request.sid}")
    emit('connected', {'status': 'Connected to DDoS Monitor'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    logger.info(f"Client disconnected: {request.sid}")

@socketio.on('request_recent_attacks')
def handle_recent_attacks(data):
    """Handle request for recent attacks"""
    limit = data.get('limit', 50)
    attacks = attack_monitor.get_recent_attacks(limit)
    emit('recent_attacks', attacks)

if __name__ == '__main__':
    try:
        logger.info("Starting DDoS Attack Visualization Demo")
        
        # Start attack monitoring
        attack_monitor.start_monitoring()
        
        # Run Flask-SocketIO app
        socketio.run(app, host='0.0.0.0', port=5000, debug=False)
        
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        attack_monitor.stop_monitoring()
    except Exception as e:
        logger.error(f"Application error: {e}")
        attack_monitor.stop_monitoring()
