#!/usr/bin/env python3
"""
Configuration settings for DDoS Attack Map Demo
Centralized configuration management
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Base configuration class"""
    
    # Server Configuration
    FLASK_HOST = os.getenv('FLASK_HOST', '0.0.0.0')
    FLASK_PORT = int(os.getenv('FLASK_PORT', 5000))
    DEBUG_MODE = os.getenv('DEBUG_MODE', 'False').lower() == 'true'
    SECRET_KEY = os.getenv('SECRET_KEY', 'ddos-demo-secret-key-2024')
    
    # Attack Generation Settings
    ATTACK_FREQUENCY_MIN = int(os.getenv('ATTACK_FREQUENCY_MIN', 2))
    ATTACK_FREQUENCY_MAX = int(os.getenv('ATTACK_FREQUENCY_MAX', 5))
    MAX_STORED_ATTACKS = int(os.getenv('MAX_STORED_ATTACKS', 1000))
    MAX_MARKERS_ON_MAP = int(os.getenv('MAX_MARKERS_ON_MAP', 200))
    
    # GeoIP Configuration
    GEOIP_DATABASE_PATH = os.getenv('GEOIP_DATABASE_PATH', './data/GeoLite2-City.mmdb')
    USE_MOCK_LOCATIONS = os.getenv('USE_MOCK_LOCATIONS', 'True').lower() == 'true'
    
    # WebSocket Settings
    WEBSOCKET_CORS_ORIGINS = os.getenv('WEBSOCKET_CORS_ORIGINS', '*')
    WEBSOCKET_ASYNC_MODE = os.getenv('WEBSOCKET_ASYNC_MODE', 'threading')
    
    # Logging Configuration
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'ddos_demo.log')
    ENABLE_PERFORMANCE_LOGGING = os.getenv('ENABLE_PERFORMANCE_LOGGING', 'True').lower() == 'true'
    
    # Demo Mode Settings
    DEMO_MODE = os.getenv('DEMO_MODE', 'True').lower() == 'true'
    SIMULATE_REALISTIC_PATTERNS = os.getenv('SIMULATE_REALISTIC_PATTERNS', 'True').lower() == 'true'
    ENABLE_GEOGRAPHIC_CLUSTERING = os.getenv('ENABLE_GEOGRAPHIC_CLUSTERING', 'True').lower() == 'true'
    
    # Attack Types Configuration
    ATTACK_TYPES = [
        "Volumetric", "Protocol", "Application Layer", 
        "Reflection", "Amplification", "Botnet", 
        "SYN Flood", "UDP Flood", "HTTP Flood", "DNS Amplification"
    ]
    
    # Geographic Regions for Realistic Attack Patterns
    HIGH_RISK_COUNTRIES = [
        "China", "Russia", "United States", "Brazil", "India",
        "Iran", "Ukraine", "North Korea", "Romania", "Turkey"
    ]
    
    # Common Target Countries
    TARGET_COUNTRIES = [
        "United States", "United Kingdom", "Germany", "France",
        "Japan", "South Korea", "Australia", "Canada", "Netherlands"
    ]
    
    @classmethod
    def validate_config(cls):
        """Validate configuration settings"""
        errors = []
        
        # Validate port range
        if not (1024 <= cls.FLASK_PORT <= 65535):
            errors.append(f"Invalid port number: {cls.FLASK_PORT}")
        
        # Validate frequency settings
        if cls.ATTACK_FREQUENCY_MIN >= cls.ATTACK_FREQUENCY_MAX:
            errors.append("ATTACK_FREQUENCY_MIN must be less than ATTACK_FREQUENCY_MAX")
        
        # Validate paths
        log_dir = Path(cls.LOG_FILE).parent
        if not log_dir.exists():
            log_dir.mkdir(parents=True, exist_ok=True)
        
        geoip_dir = Path(cls.GEOIP_DATABASE_PATH).parent
        if not geoip_dir.exists():
            geoip_dir.mkdir(parents=True, exist_ok=True)
        
        return errors

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG_MODE = True
    LOG_LEVEL = 'DEBUG'
    ATTACK_FREQUENCY_MIN = 1
    ATTACK_FREQUENCY_MAX = 3

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG_MODE = False
    LOG_LEVEL = 'WARNING'
    SECRET_KEY = os.getenv('SECRET_KEY') or 'change-this-in-production'

class TestingConfig(Config):
    """Testing configuration"""
    DEBUG_MODE = True
    LOG_LEVEL = 'DEBUG'
    DEMO_MODE = True
    MAX_STORED_ATTACKS = 100

# Configuration mapping
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': Config
}

def get_config(config_name=None):
    """Get configuration based on environment"""
    if config_name is None:
        config_name = os.getenv('FLASK_ENV', 'default')
    
    return config.get(config_name, Config)
