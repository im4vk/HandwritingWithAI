#!/usr/bin/env python3
"""
DDoS Attack Map Demo Runner
Convenient script to launch the demonstration with proper setup
"""

import os
import sys
import subprocess
import platform
import webbrowser
import time
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Error: Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True

def check_dependencies():
    """Check if required packages are installed"""
    required_packages = [
        'flask', 'flask-socketio', 'requests', 'geoip2', 'pandas'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"❌ Missing packages: {', '.join(missing_packages)}")
        print("Installing missing packages...")
        try:
            subprocess.check_call([
                sys.executable, '-m', 'pip', 'install'
            ] + missing_packages)
            print("✅ Dependencies installed successfully")
        except subprocess.CalledProcessError:
            print("❌ Failed to install dependencies")
            return False
    else:
        print("✅ All dependencies are installed")
    
    return True

def setup_directories():
    """Create necessary directories"""
    directories = ['data', 'logs', 'static/css', 'static/js', 'templates']
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
    
    print("✅ Directory structure verified")

def download_geoip_db():
    """Download GeoLite2 database if not present"""
    geoip_path = Path('data/GeoLite2-City.mmdb')
    
    if geoip_path.exists():
        print("✅ GeoIP database found")
        return True
    
    print("⚠️ GeoIP database not found")
    print("Demo will use mock geographic data")
    print("For real GeoIP data, download GeoLite2-City.mmdb from MaxMind")
    return True

def check_port_availability(port=5000):
    """Check if the port is available"""
    import socket
    
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            result = sock.connect_ex(('localhost', port))
            if result == 0:
                print(f"⚠️ Port {port} is already in use")
                return False
            else:
                print(f"✅ Port {port} is available")
                return True
    except Exception as e:
        print(f"❌ Error checking port: {e}")
        return False

def launch_application():
    """Launch the DDoS Attack Map application"""
    print("\n🚀 Starting DDoS Attack Map Demo...")
    print("=" * 50)
    
    try:
        # Import and run the application
        from app import app, socketio, attack_monitor
        
        print("✅ Application modules loaded")
        
        # Start the attack monitoring system
        attack_monitor.start_monitoring()
        print("✅ Attack monitoring started")
        
        # Open browser after a short delay
        def open_browser():
            time.sleep(2)
            url = "http://localhost:5000"
            print(f"🌐 Opening browser: {url}")
            webbrowser.open(url)
        
        import threading
        threading.Thread(target=open_browser, daemon=True).start()
        
        print("\n📊 DDoS Attack Map is running!")
        print("🌐 URL: http://localhost:5000")
        print("⌨️ Press Ctrl+C to stop")
        print("=" * 50)
        
        # Run the Flask-SocketIO application
        socketio.run(app, host='0.0.0.0', port=5000, debug=False)
        
    except KeyboardInterrupt:
        print("\n\n🛑 Shutting down DDoS Attack Map...")
        attack_monitor.stop_monitoring()
        print("✅ Application stopped successfully")
    except Exception as e:
        print(f"❌ Error starting application: {e}")
        return False
    
    return True

def show_banner():
    """Show application banner"""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                    DDoS Attack Map Demo                      ║
║                 Live Global Threat Visualization             ║
╠══════════════════════════════════════════════════════════════╣
║  Features:                                                   ║
║  • Real-time global DDoS attack visualization               ║
║  • Interactive world map with attack animations             ║
║  • Live statistics and threat intelligence                  ║
║  • Modern responsive web interface                          ║
║  • WebSocket-based real-time updates                        ║
╚══════════════════════════════════════════════════════════════╝
"""
    print(banner)

def main():
    """Main demo runner function"""
    show_banner()
    
    print("🔍 Performing system checks...")
    
    # Check Python version
    if not check_python_version():
        return 1
    
    # Check dependencies
    if not check_dependencies():
        return 1
    
    # Setup directories
    setup_directories()
    
    # Check GeoIP database
    download_geoip_db()
    
    # Check port availability
    if not check_port_availability():
        print("💡 Try stopping other applications using port 5000")
        return 1
    
    print("\n✅ All system checks passed!")
    input("Press Enter to launch the demo...")
    
    # Launch application
    if not launch_application():
        return 1
    
    return 0

if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n👋 Demo cancelled by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)
