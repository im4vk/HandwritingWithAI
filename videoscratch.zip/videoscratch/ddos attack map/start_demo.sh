#!/bin/bash

# Live DDoS Attack Map Demo Launcher
# Quick start script for the demonstration

echo "🌍 Starting Live DDoS Attack Map Demo..."
echo "=========================================="

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo "✅ Virtual environment activated"
else
    echo "⚠️  Running without virtual environment"
fi

# Install dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Check if app.py exists
if [ ! -f "app.py" ]; then
    echo "❌ app.py not found!"
    exit 1
fi

echo ""
echo "🚀 Launching DDoS Attack Map Demo..."
echo "🌐 URL: http://localhost:5000"
echo "⌨️  Press Ctrl+C to stop"
echo "=========================================="
echo ""

# Start the application
python app.py
