/**
 * Live DDoS Attack Map - Main Application JavaScript
 * Real-time visualization of global DDoS attacks
 */

class DDoSAttackMap {
    constructor() {
        this.map = null;
        this.socket = null;
        this.attacks = [];
        this.attackMarkers = [];
        this.attackLines = [];
        this.stats = {
            total: 0,
            perMinute: 0,
            countries: new Set(),
            avgIntensity: 0
        };
        this.charts = {};
        this.isMonitoring = true;
        this.lastMinuteAttacks = [];
        
        this.init();
    }
    
    init() {
        this.initMap();
        this.initSocket();
        this.initCharts();
        this.initEventListeners();
        this.startStatsUpdater();
        
        console.log('DDoS Attack Map initialized');
    }
    
    initMap() {
        // Initialize Leaflet map with dark theme
        this.map = L.map('map', {
            center: [20, 0],
            zoom: 2,
            zoomControl: false,
            attributionControl: false
        });
        
        // Add dark tile layer
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://carto.com/">CARTO</a>',
            subdomains: 'abcd',
            maxZoom: 19
        }).addTo(this.map);
        
        // Add custom zoom control
        L.control.zoom({
            position: 'bottomright'
        }).addTo(this.map);
        
        // Add scale control
        L.control.scale({
            position: 'bottomleft',
            imperial: false
        }).addTo(this.map);
        
        console.log('Map initialized');
    }
    
    initSocket() {
        this.socket = io();
        
        this.socket.on('connect', () => {
            console.log('Connected to server');
            this.updateConnectionStatus(true);
            this.socket.emit('request_recent_attacks', { limit: 50 });
        });
        
        this.socket.on('disconnect', () => {
            console.log('Disconnected from server');
            this.updateConnectionStatus(false);
        });
        
        this.socket.on('new_attack', (attack) => {
            if (this.isMonitoring) {
                this.addAttack(attack);
            }
        });
        
        this.socket.on('recent_attacks', (attacks) => {
            console.log(`Received ${attacks.length} recent attacks`);
            attacks.forEach(attack => this.addAttack(attack, false));
        });
        
        this.socket.on('stats_update', (stats) => {
            this.updateGlobalStats(stats);
        });
        
        this.socket.on('connected', (data) => {
            console.log('Server connection confirmed:', data.status);
        });
    }
    
    initCharts() {
        // Attack Types Pie Chart
        const ctx = document.getElementById('attackTypesChart').getContext('2d');
        this.charts.attackTypes = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        '#dc3545', '#ffc107', '#28a745', '#17a2b8',
                        '#6f42c1', '#fd7e14', '#20c997', '#6c757d',
                        '#007bff', '#e83e8c'
                    ],
                    borderColor: '#333',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#fff',
                            font: { size: 10 },
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }
    
    initEventListeners() {
        // Map click handler
        this.map.on('click', () => {
            this.closeAllPopups();
        });
        
        // Window resize handler
        window.addEventListener('resize', () => {
            this.map.invalidateSize();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            switch(e.key) {
                case ' ': // Spacebar to pause/resume
                    e.preventDefault();
                    this.toggleMonitoring();
                    break;
                case 'c': // Clear map
                    if (e.ctrlKey) {
                        e.preventDefault();
                        this.clearMap();
                    }
                    break;
                case 'g': // Global view
                    this.zoomToGlobal();
                    break;
            }
        });
    }
    
    addAttack(attack, animate = true) {
        this.attacks.push(attack);
        this.lastMinuteAttacks.push({
            ...attack,
            addedAt: Date.now()
        });
        
        // Update statistics
        this.updateStats();
        this.updateRecentAttacksFeed(attack);
        
        if (animate) {
            this.animateAttack(attack);
        } else {
            this.addAttackMarker(attack);
        }
        
        // Limit stored attacks to prevent memory issues
        if (this.attacks.length > 1000) {
            this.attacks = this.attacks.slice(-500);
        }
        
        // Clean up old markers periodically
        if (this.attackMarkers.length > 200) {
            this.cleanupOldMarkers();
        }
    }
    
    animateAttack(attack) {
        const sourceCoords = attack.source_coords;
        const targetCoords = attack.target_coords;
        
        if (!sourceCoords || !targetCoords || 
            sourceCoords[0] === 0 || targetCoords[0] === 0) {
            return;
        }
        
        // Create attack line animation
        const line = L.polyline([sourceCoords, targetCoords], {
            color: this.getIntensityColor(attack.intensity),
            weight: Math.max(2, attack.intensity / 2),
            opacity: 0.8,
            dashArray: '10, 10',
            className: 'attack-line'
        }).addTo(this.map);
        
        this.attackLines.push(line);
        
        // Animate line appearance
        this.animateLine(line, sourceCoords, targetCoords);
        
        // Add source marker
        setTimeout(() => {
            this.addAttackMarker(attack, 'source');
        }, 500);
        
        // Add target marker
        setTimeout(() => {
            this.addAttackMarker(attack, 'target');
        }, 1000);
        
        // Remove line after animation
        setTimeout(() => {
            if (this.map.hasLayer(line)) {
                this.map.removeLayer(line);
            }
            const index = this.attackLines.indexOf(line);
            if (index > -1) {
                this.attackLines.splice(index, 1);
            }
        }, 3000);
    }
    
    animateLine(line, start, end) {
        let progress = 0;
        const duration = 1500; // ms
        const startTime = Date.now();
        
        const animate = () => {
            const elapsed = Date.now() - startTime;
            progress = Math.min(elapsed / duration, 1);
            
            // Calculate intermediate point
            const lat = start[0] + (end[0] - start[0]) * progress;
            const lng = start[1] + (end[1] - start[1]) * progress;
            
            line.setLatLngs([start, [lat, lng]]);
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };
        
        animate();
    }
    
    addAttackMarker(attack, type = 'both') {
        const sourceCoords = attack.source_coords;
        const targetCoords = attack.target_coords;
        
        if (!sourceCoords || !targetCoords) return;
        
        const intensityColor = this.getIntensityColor(attack.intensity);
        const markerSize = Math.max(8, attack.intensity * 2);
        
        if (type === 'both' || type === 'source') {
            const sourceMarker = L.circleMarker(sourceCoords, {
                radius: markerSize,
                fillColor: intensityColor,
                color: '#fff',
                weight: 1,
                opacity: 0.8,
                fillOpacity: 0.6
            }).addTo(this.map);
            
            sourceMarker.bindPopup(this.createAttackPopup(attack, 'source'));
            sourceMarker.on('click', () => this.showAttackDetails(attack));
            
            this.attackMarkers.push({
                marker: sourceMarker,
                timestamp: Date.now(),
                attack: attack
            });
        }
        
        if (type === 'both' || type === 'target') {
            const targetMarker = L.circleMarker(targetCoords, {
                radius: markerSize,
                fillColor: intensityColor,
                color: '#fff',
                weight: 2,
                opacity: 0.9,
                fillOpacity: 0.8
            }).addTo(this.map);
            
            targetMarker.bindPopup(this.createAttackPopup(attack, 'target'));
            targetMarker.on('click', () => this.showAttackDetails(attack));
            
            this.attackMarkers.push({
                marker: targetMarker,
                timestamp: Date.now(),
                attack: attack
            });
        }
    }
    
    createAttackPopup(attack, type) {
        const isSource = type === 'source';
        const country = isSource ? attack.source_country : attack.target_country;
        const ip = isSource ? attack.source_ip : attack.target_ip;
        const role = isSource ? 'Attacker' : 'Target';
        
        return `
            <div class="attack-popup">
                <h6 class="mb-2">${role}: ${country}</h6>
                <p class="mb-1"><strong>IP:</strong> ${ip}</p>
                <p class="mb-1"><strong>Type:</strong> ${attack.attack_type}</p>
                <p class="mb-1"><strong>Intensity:</strong> 
                    <span class="badge bg-${this.getIntensityClass(attack.intensity)}">${attack.intensity}/10</span>
                </p>
                <p class="mb-1"><strong>Bandwidth:</strong> ${attack.bandwidth_mbps} Mbps</p>
                <p class="mb-0"><strong>Time:</strong> ${moment(attack.timestamp).format('HH:mm:ss')}</p>
            </div>
        `;
    }
    
    showAttackDetails(attack) {
        const modalBody = document.getElementById('attack-details');
        modalBody.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-danger">Source</h6>
                    <p><strong>Country:</strong> ${attack.source_country}</p>
                    <p><strong>IP Address:</strong> <code>${attack.source_ip}</code></p>
                    <p><strong>Coordinates:</strong> ${attack.source_coords[0].toFixed(4)}, ${attack.source_coords[1].toFixed(4)}</p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-info">Target</h6>
                    <p><strong>Country:</strong> ${attack.target_country}</p>
                    <p><strong>IP Address:</strong> <code>${attack.target_ip}</code></p>
                    <p><strong>Coordinates:</strong> ${attack.target_coords[0].toFixed(4)}, ${attack.target_coords[1].toFixed(4)}</p>
                </div>
            </div>
            <hr class="border-secondary">
            <div class="row">
                <div class="col-md-4">
                    <h6>Attack Details</h6>
                    <p><strong>Type:</strong> ${attack.attack_type}</p>
                    <p><strong>Intensity:</strong> <span class="badge bg-${this.getIntensityClass(attack.intensity)}">${attack.intensity}/10</span></p>
                    <p><strong>Duration:</strong> ${attack.duration} seconds</p>
                </div>
                <div class="col-md-4">
                    <h6>Traffic Metrics</h6>
                    <p><strong>Packets/sec:</strong> ${attack.packets_per_second.toLocaleString()}</p>
                    <p><strong>Bandwidth:</strong> ${attack.bandwidth_mbps} Mbps</p>
                    <p><strong>Timestamp:</strong> ${moment(attack.timestamp).format('YYYY-MM-DD HH:mm:ss')}</p>
                </div>
                <div class="col-md-4">
                    <h6>Risk Assessment</h6>
                    <p><strong>Threat Level:</strong> <span class="text-${this.getIntensityClass(attack.intensity)}">${this.getThreatLevel(attack.intensity)}</span></p>
                    <p><strong>Attack Vector:</strong> ${this.getAttackVector(attack.attack_type)}</p>
                </div>
            </div>
        `;
        
        const modal = new bootstrap.Modal(document.getElementById('attackModal'));
        modal.show();
    }
    
    updateStats() {
        this.stats.total = this.attacks.length;
        
        // Calculate attacks per minute
        const oneMinuteAgo = Date.now() - 60000;
        this.lastMinuteAttacks = this.lastMinuteAttacks.filter(a => a.addedAt > oneMinuteAgo);
        this.stats.perMinute = this.lastMinuteAttacks.length;
        
        // Update countries
        this.stats.countries.clear();
        this.attacks.forEach(attack => {
            this.stats.countries.add(attack.source_country);
            this.stats.countries.add(attack.target_country);
        });
        
        // Calculate average intensity
        if (this.attacks.length > 0) {
            const totalIntensity = this.attacks.reduce((sum, attack) => sum + attack.intensity, 0);
            this.stats.avgIntensity = (totalIntensity / this.attacks.length).toFixed(1);
        }
        
        // Update DOM
        document.getElementById('total-attacks').textContent = this.stats.total.toLocaleString();
        document.getElementById('attacks-per-minute').textContent = this.stats.perMinute;
        document.getElementById('countries-affected').textContent = this.stats.countries.size;
        document.getElementById('avg-intensity').textContent = this.stats.avgIntensity;
    }
    
    updateRecentAttacksFeed(attack) {
        const feed = document.getElementById('recent-attacks');
        const attackItem = document.createElement('div');
        attackItem.className = 'attack-item fade-in-up';
        attackItem.onclick = () => this.showAttackDetails(attack);
        
        attackItem.innerHTML = `
            <div class="time">${moment(attack.timestamp).format('HH:mm:ss')}</div>
            <div class="countries">${attack.source_country} → ${attack.target_country}</div>
            <div class="details">
                <span class="badge bg-${this.getIntensityClass(attack.intensity)} me-1">${attack.attack_type}</span>
                <small class="text-muted">${attack.bandwidth_mbps} Mbps</small>
            </div>
        `;
        
        feed.insertBefore(attackItem, feed.firstChild);
        
        // Keep only last 20 items
        while (feed.children.length > 20) {
            feed.removeChild(feed.lastChild);
        }
    }
    
    updateGlobalStats(stats) {
        // Update attack types chart
        if (stats.attack_stats && Object.keys(stats.attack_stats).length > 0) {
            const labels = Object.keys(stats.attack_stats).filter(key => key !== 'total');
            const data = labels.map(label => stats.attack_stats[label]);
            
            this.charts.attackTypes.data.labels = labels;
            this.charts.attackTypes.data.datasets[0].data = data;
            this.charts.attackTypes.update('none');
        }
    }
    
    updateConnectionStatus(connected) {
        const statusElement = document.getElementById('connection-status');
        if (connected) {
            statusElement.innerHTML = '<i class="fas fa-circle text-success"></i> <small>Connected</small>';
        } else {
            statusElement.innerHTML = '<i class="fas fa-circle text-danger"></i> <small>Disconnected</small>';
        }
    }
    
    getIntensityColor(intensity) {
        if (intensity <= 3) return '#28a745'; // Green
        if (intensity <= 6) return '#ffc107'; // Yellow
        return '#dc3545'; // Red
    }
    
    getIntensityClass(intensity) {
        if (intensity <= 3) return 'success';
        if (intensity <= 6) return 'warning';
        return 'danger';
    }
    
    getThreatLevel(intensity) {
        if (intensity <= 3) return 'Low';
        if (intensity <= 6) return 'Medium';
        if (intensity <= 8) return 'High';
        return 'Critical';
    }
    
    getAttackVector(type) {
        const vectors = {
            'Volumetric': 'Network Layer',
            'Protocol': 'Transport Layer',
            'Application Layer': 'Application Layer',
            'Reflection': 'Network Amplification',
            'Amplification': 'Protocol Amplification',
            'Botnet': 'Distributed Sources',
            'SYN Flood': 'TCP Protocol',
            'UDP Flood': 'UDP Protocol',
            'HTTP Flood': 'HTTP Application',
            'DNS Amplification': 'DNS Protocol'
        };
        return vectors[type] || 'Unknown';
    }
    
    cleanupOldMarkers() {
        const cutoffTime = Date.now() - (5 * 60 * 1000); // 5 minutes
        
        this.attackMarkers = this.attackMarkers.filter(item => {
            if (item.timestamp < cutoffTime) {
                this.map.removeLayer(item.marker);
                return false;
            }
            return true;
        });
    }
    
    closeAllPopups() {
        this.map.closePopup();
    }
    
    startStatsUpdater() {
        setInterval(() => {
            this.updateStats();
        }, 1000);
    }
    
    // Public methods for UI controls
    toggleMonitoring() {
        this.isMonitoring = !this.isMonitoring;
        const badge = document.getElementById('status-badge');
        const toggleBtn = document.getElementById('toggle-text');
        const toggleIcon = document.getElementById('toggle-icon');
        
        if (this.isMonitoring) {
            badge.textContent = 'MONITORING';
            badge.className = 'badge bg-danger ms-2';
            toggleBtn.textContent = 'Pause';
            toggleIcon.className = 'fas fa-pause';
        } else {
            badge.textContent = 'PAUSED';
            badge.className = 'badge bg-warning ms-2';
            toggleBtn.textContent = 'Resume';
            toggleIcon.className = 'fas fa-play';
        }
    }
    
    zoomToGlobal() {
        this.map.setView([20, 0], 2);
    }
    
    toggleHeatmap() {
        // Placeholder for heatmap functionality
        console.log('Heatmap toggle not implemented yet');
    }
    
    clearMap() {
        // Remove all markers
        this.attackMarkers.forEach(item => {
            this.map.removeLayer(item.marker);
        });
        this.attackMarkers = [];
        
        // Remove all lines
        this.attackLines.forEach(line => {
            this.map.removeLayer(line);
        });
        this.attackLines = [];
        
        // Clear attacks data
        this.attacks = [];
        this.lastMinuteAttacks = [];
        
        // Clear recent attacks feed
        document.getElementById('recent-attacks').innerHTML = '';
        
        // Reset stats
        this.updateStats();
        
        console.log('Map cleared');
    }
}

// Global functions for UI controls
let ddosMap;

function toggleMonitoring() {
    if (ddosMap) ddosMap.toggleMonitoring();
}

function zoomToGlobal() {
    if (ddosMap) ddosMap.zoomToGlobal();
}

function toggleHeatmap() {
    if (ddosMap) ddosMap.toggleHeatmap();
}

function clearMap() {
    if (ddosMap) ddosMap.clearMap();
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    ddosMap = new DDoSAttackMap();
});

// Handle page visibility change
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        console.log('Page hidden, reducing updates');
    } else {
        console.log('Page visible, resuming normal updates');
    }
});
