# Deepfake Detector Configuration Guide

The deepfake detector includes a comprehensive configuration management system that allows you to customize every aspect of the detection process, from algorithm parameters to logging settings and performance optimizations.

## Quick Start

### Basic Usage (Default Configuration)
```bash
python -m deepfake_detector.detect --input video.mp4
```

### Using Configuration Profiles
```bash
# Fast processing profile (3 algorithms, optimized for speed)
python -m deepfake_detector.detect --input video.mp4 --profile fast

# Production profile (enterprise settings)
python -m deepfake_detector.detect --input video.mp4 --profile production

# Accuracy profile (all algorithms enabled, high quality)
python -m deepfake_detector.detect --input video.mp4 --profile accuracy
```

### Using Configuration Files
```bash
# Load from custom configuration file
python -m deepfake_detector.detect --input video.mp4 --config my_config.json

# Save current configuration for reuse
python -m deepfake_detector.detect --input video.mp4 --save-config my_settings.json
```

## Configuration Architecture

The configuration system is organized into six main sections:

### 1. Processing Configuration
Controls video/image processing parameters:

```json
{
  "processing": {
    "target_fps": 15,
    "max_frames": null,
    "face_crop_size": 224,
    "face_detection_confidence": 0.5,
    "face_detection_method": "auto",
    "enable_face_tracking": true,
    "tracking_max_distance": 50.0,
    "min_face_size": [30, 30],
    "max_face_size": [300, 300]
  }
}
```

**Key Parameters:**
- `target_fps`: Frame rate for video processing (1-120)
- `max_frames`: Maximum frames to process (null = no limit)
- `face_detection_method`: "auto", "mediapipe", "haar", or "both"
- `face_crop_size`: Size of face crops for analysis (typically 224)

### 2. Algorithm Configuration
Controls detection algorithms and their weights:

```json
{
  "algorithms": {
    "enable_frequency_analysis": true,
    "frequency_analysis_weight": 1.0,
    "enable_rppg_analysis": true,
    "rppg_analysis_weight": 1.0,
    "enable_avsync_analysis": true,
    "avsync_analysis_weight": 1.0,
    "enable_geometry_analysis": true,
    "geometry_analysis_weight": 1.0,
    "enable_cnn_analysis": true,
    "cnn_analysis_weight": 1.0,
    "cnn_model_url": null
  }
}
```

**Algorithm Types:**
- **Frequency Analysis**: Detects compression artifacts in frequency domain
- **rPPG Analysis**: Remote photoplethysmography for pulse detection
- **Audio-Visual Sync**: Lip-sync consistency analysis
- **Geometry Analysis**: Facial landmark temporal consistency
- **CNN Analysis**: Deep learning-based detection

### 3. Logging Configuration
Controls logging behavior and output:

```json
{
  "logging": {
    "log_level": "INFO",
    "log_dir": null,
    "console_output": true,
    "file_output": false,
    "structured_logs": false,
    "performance_monitoring": true,
    "max_file_size": 10485760,
    "backup_count": 5,
    "quiet_mode": false
  }
}
```

### 4. Performance Configuration
Controls optimization and resource usage:

```json
{
  "performance": {
    "enable_caching": true,
    "cache_size": 100,
    "cache_ttl": 3600,
    "enable_multiprocessing": false,
    "num_workers": null,
    "chunk_size": 10,
    "memory_limit": null,
    "gpu_acceleration": false,
    "gpu_device_id": 0
  }
}
```

### 5. Output Configuration
Controls result formatting and additional outputs:

```json
{
  "output": {
    "output_format": "json",
    "include_intermediate_scores": true,
    "include_confidence_intervals": false,
    "include_processing_metadata": true,
    "overlay_output": false,
    "save_face_crops": false,
    "save_debug_images": false
  }
}
```

### 6. Global Settings
Environment and general configuration:

```json
{
  "environment": "development",
  "debug_mode": false,
  "strict_validation": true,
  "config_version": "1.0"
}
```

## Predefined Profiles

### Development Profile
Default settings for development and testing:
- All algorithms enabled with equal weights
- Debug logging with console output
- No performance optimizations
- Detailed output with metadata

### Production Profile
Enterprise-ready settings:
- All algorithms enabled with optimized weights
- Structured JSON logging to files
- Multiprocessing and GPU acceleration enabled
- Minimal console output
- Performance monitoring enabled

### Fast Profile
Optimized for speed:
- Only 3 algorithms enabled (frequency, geometry, CNN)
- Lower frame rate and frame limits
- GPU acceleration enabled
- Minimal logging
- Reduced processing quality for speed

### Accuracy Profile
Optimized for detection quality:
- All algorithms enabled
- Higher frame rates and quality settings
- MediaPipe face detection (more accurate)
- Detailed logging for analysis

## Command Line Options

### Configuration Sources
| Option | Description | Example |
|--------|-------------|---------|
| `--config PATH` | Load configuration from file | `--config settings.json` |
| `--profile NAME` | Use predefined profile | `--profile production` |
| `--save-config PATH` | Save current config to file | `--save-config backup.json` |

### Processing Overrides
| Option | Description | Overrides |
|--------|-------------|-----------|
| `--target-fps N` | Set frame rate | `processing.target_fps` |
| `--max-frames N` | Limit frame count | `processing.max_frames` |
| `--overlay-out PATH` | Generate overlay video | N/A |

### Algorithm Controls
| Option | Description | Effect |
|--------|-------------|--------|
| `--no-cnn` | Disable CNN detection | `algorithms.enable_cnn_analysis = false` |
| `--disable-frequency` | Disable frequency analysis | `algorithms.enable_frequency_analysis = false` |
| `--disable-rppg` | Disable rPPG analysis | `algorithms.enable_rppg_analysis = false` |
| `--disable-avsync` | Disable audio-visual sync | `algorithms.enable_avsync_analysis = false` |
| `--disable-geometry` | Disable geometry analysis | `algorithms.enable_geometry_analysis = false` |

### Environment and Performance
| Option | Description | Effect |
|--------|-------------|--------|
| `--environment ENV` | Set deployment environment | `environment = ENV` |
| `--debug` | Enable debug mode | `debug_mode = true`, `log_level = DEBUG` |
| `--gpu` | Enable GPU acceleration | `performance.gpu_acceleration = true` |

### Logging Controls
| Option | Description | Effect |
|--------|-------------|--------|
| `--log-level LEVEL` | Set logging level | `logging.log_level = LEVEL` |
| `--log-dir PATH` | Set log directory | `logging.log_dir = PATH` |
| `--structured-logs` | Use JSON logging | `logging.structured_logs = true` |
| `--quiet` | Minimal output | `logging.quiet_mode = true` |

## Configuration Files

### Supported Formats
- **JSON**: Human-readable, widely supported
- **YAML**: More readable for complex configurations (requires PyYAML)
- **TOML**: Modern configuration format (requires tomli)

### File Locations
The system looks for configuration files in this order:
1. Path specified with `--config`
2. Environment variable `DEEPFAKE_CONFIG_FILE`
3. `./config/default.json` (if it exists)
4. Built-in defaults

### Example JSON Configuration
```json
{
  "processing": {
    "target_fps": 20,
    "face_detection_method": "mediapipe",
    "face_detection_confidence": 0.7
  },
  "algorithms": {
    "enable_rppg_analysis": false,
    "cnn_analysis_weight": 1.5
  },
  "logging": {
    "log_level": "DEBUG",
    "log_dir": "./logs",
    "structured_logs": true
  },
  "performance": {
    "enable_multiprocessing": true,
    "num_workers": 4,
    "gpu_acceleration": true
  },
  "environment": "production"
}
```

### Example YAML Configuration
```yaml
processing:
  target_fps: 20
  face_detection_method: mediapipe
  face_detection_confidence: 0.7

algorithms:
  enable_rppg_analysis: false
  cnn_analysis_weight: 1.5

logging:
  log_level: DEBUG
  log_dir: ./logs
  structured_logs: true

performance:
  enable_multiprocessing: true
  num_workers: 4
  gpu_acceleration: true

environment: production
```

## Environment Variables

Override any configuration setting using environment variables with the `DEEPFAKE_` prefix:

### Processing Settings
```bash
export DEEPFAKE_TARGET_FPS=25
export DEEPFAKE_MAX_FRAMES=100
export DEEPFAKE_FACE_DETECTION_METHOD=mediapipe
```

### Algorithm Settings
```bash
export DEEPFAKE_ENABLE_CNN=true
export DEEPFAKE_CNN_MODEL_URL=https://example.com/model.onnx
export DEEPFAKE_CNN_BATCH_SIZE=64
```

### Logging Settings
```bash
export DEEPFAKE_LOG_LEVEL=DEBUG
export DEEPFAKE_LOG_DIR=/var/log/deepfake-detector
export DEEPFAKE_STRUCTURED_LOGS=true
```

### Performance Settings
```bash
export DEEPFAKE_ENABLE_CACHING=true
export DEEPFAKE_NUM_WORKERS=8
export DEEPFAKE_GPU_ACCELERATION=true
```

### Global Settings
```bash
export DEEPFAKE_ENVIRONMENT=production
export DEEPFAKE_DEBUG_MODE=false
```

## Configuration Precedence

Settings are applied in this order (later sources override earlier ones):

1. **Built-in defaults**
2. **Configuration file** (specified with `--config` or `--profile`)
3. **Environment variables** (with `DEEPFAKE_` prefix)
4. **Command line arguments** (highest priority)

## Programmatic Usage

### Basic Configuration
```python
from deepfake_detector.config import DeepfakeDetectorConfig, get_config

# Create default configuration
config = DeepfakeDetectorConfig()

# Modify settings
config.processing.target_fps = 25
config.algorithms.enable_rppg_analysis = False
config.logging.log_level = LogLevel.DEBUG

# Use in analysis
from deepfake_detector.detect import analyze_video
report = analyze_video("video.mp4", config=config)
```

### Loading from File
```python
from deepfake_detector.config import load_config

# Load from file with environment overrides
config = load_config("my_config.json")

# Load profile
profiles = create_profile_configs()
config = profiles["production"]
```

### Saving Configuration
```python
# Save current configuration
config.save("backup.json")

# Save as YAML (requires PyYAML)
config.save("config.yaml", format="yaml")
```

### Configuration Validation
```python
# Validate configuration
issues = config.validate()
if issues:
    print("Configuration issues:")
    for issue in issues:
        print(f"  - {issue}")

# Get configuration summary
summary = config.get_summary()
print(f"Enabled algorithms: {summary['enabled_algorithms']}")
print(f"GPU acceleration: {summary['gpu_acceleration']}")
```

## Performance Tuning

### For Speed (Minimal Quality Impact)
```json
{
  "processing": {
    "target_fps": 10,
    "max_frames": 60,
    "face_detection_method": "haar"
  },
  "algorithms": {
    "enable_rppg_analysis": false,
    "enable_avsync_analysis": false
  },
  "performance": {
    "enable_multiprocessing": true,
    "gpu_acceleration": true
  }
}
```

### For Accuracy (Maximum Quality)
```json
{
  "processing": {
    "target_fps": 25,
    "face_detection_method": "mediapipe",
    "face_detection_confidence": 0.7
  },
  "algorithms": {
    "enable_frequency_analysis": true,
    "enable_rppg_analysis": true,
    "enable_avsync_analysis": true,
    "enable_geometry_analysis": true,
    "enable_cnn_analysis": true
  }
}
```

### For Large-Scale Processing
```json
{
  "performance": {
    "enable_multiprocessing": true,
    "num_workers": 8,
    "chunk_size": 20,
    "enable_caching": true,
    "cache_size": 1000,
    "gpu_acceleration": true
  },
  "logging": {
    "log_level": "WARNING",
    "console_output": false,
    "file_output": true,
    "structured_logs": true
  }
}
```

## Troubleshooting

### Common Configuration Issues

1. **Algorithm Weights Sum to Zero**
   ```
   Error: At least one algorithm weight must be positive
   ```
   **Solution**: Ensure at least one algorithm is enabled with weight > 0

2. **Invalid Parameter Ranges**
   ```
   Error: target_fps must be between 1 and 120
   ```
   **Solution**: Check parameter constraints in the configuration reference

3. **Missing Dependencies**
   ```
   Error: PyYAML not installed. Install with: pip install PyYAML
   ```
   **Solution**: Install required packages for YAML/TOML support

4. **Permission Issues**
   ```
   Error: Permission denied writing to /var/log/deepfake-detector
   ```
   **Solution**: Ensure log directory is writable or use a different path

### Validation Warnings

The system provides helpful warnings for suboptimal configurations:

- **Performance**: When multiprocessing is enabled without specifying workers
- **GPU**: When GPU acceleration is enabled but CNN is disabled
- **Storage**: When saving debug outputs without specifying a log directory

### Debug Configuration

For maximum diagnostic information:

```bash
python -m deepfake_detector.detect \
    --input video.mp4 \
    --debug \
    --log-dir ./debug-logs \
    --structured-logs \
    --save-config debug_session.json
```

This will:
- Enable debug logging
- Create detailed log files
- Use structured JSON format
- Save the exact configuration used

## Migration Guide

### From Version 1.0 to 1.1
- No breaking changes
- New optional parameters use sensible defaults
- Existing configuration files remain compatible

### Upgrading Legacy Scripts
If you have scripts using the old API:

**Old way:**
```python
from deepfake_detector.detect import analyze_video
report = analyze_video("video.mp4", target_fps=20, use_cnn=False)
```

**New way:**
```python
from deepfake_detector.config import DeepfakeDetectorConfig
from deepfake_detector.detect import analyze_video

config = DeepfakeDetectorConfig()
config.processing.target_fps = 20
config.algorithms.enable_cnn_analysis = False

report = analyze_video("video.mp4", config=config)
```

The old API still works for backward compatibility, but the new configuration system provides much more flexibility and control.

## Best Practices

### Development
- Use the `development` profile or environment
- Enable debug logging and performance monitoring
- Save configurations for reproducible experiments
- Use `--save-config` to capture working settings

### Testing
- Create dedicated test configurations with limited resources
- Use the `fast` profile for quick iteration
- Enable structured logging for automated analysis
- Set memory limits to prevent resource exhaustion

### Production
- Use the `production` profile as a starting point
- Enable structured logging with proper log rotation
- Set up environment variables for sensitive settings
- Monitor performance metrics and adjust as needed
- Use configuration validation to catch issues early

### CI/CD Integration
```bash
# Validate configuration before deployment
python -c "
from deepfake_detector.config import load_config
config = load_config('production.json')
issues = config.validate()
if issues:
    print('Configuration validation failed')
    exit(1)
print('Configuration valid')
"
```

The configuration system provides the flexibility to adapt the deepfake detector to any environment while maintaining consistency and reliability across deployments.
