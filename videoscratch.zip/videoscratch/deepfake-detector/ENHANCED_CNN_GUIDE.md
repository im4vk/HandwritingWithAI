# Enhanced CNN Detection Guide

The deepfake detector includes a sophisticated CNN-based detection system with advanced model management, multiple architectures, ensemble capabilities, and comprehensive optimization features.

## Quick Start

### Basic Usage
```python
from deepfake_detector.enhanced_cnn import EnhancedCNNDetector, create_model_config

# Create model configuration
config = create_model_config("xception", batch_size=16)

# Initialize detector
detector = EnhancedCNNDetector(config)

# Predict on face crops
face_crops = [...]  # List of face crop images (BGR format)
probability = detector.predict(face_crops)
print(f"Deepfake probability: {probability:.3f}")
```

### CLI Tools
```bash
# List available models
python -m deepfake_detector.cnn_cli list

# Benchmark model performance
python -m deepfake_detector.cnn_cli benchmark --model xception --samples 100

# Compare multiple models
python -m deepfake_detector.cnn_cli compare --models xception efficientnet_b0 resnet50

# Validate model integrity
python -m deepfake_detector.cnn_cli validate --model xception
```

## Model Architecture Support

### Available Architectures

The system supports multiple state-of-the-art CNN architectures:

| Architecture | Input Size | Accuracy | Speed (ms) | Use Case |
|-------------|-----------|----------|------------|----------|
| **Xception** | 224×224 | 89.2% | 45.2 | Balanced accuracy/speed |
| **EfficientNet-B0** | 224×224 | 87.6% | 28.7 | Fast inference |
| **EfficientNet-B4** | 380×380 | 92.3% | 89.3 | High accuracy |
| **ResNet-50** | 224×224 | 86.4% | 35.1 | Robust baseline |
| **MobileNet-V3** | 224×224 | 84.7% | 12.4 | Mobile/edge devices |

### Model Selection

```python
from deepfake_detector.enhanced_cnn import ModelArchitecture, list_available_models

# List all available models
models = list_available_models()
print(f"Available models: {models['total_models']}")

# Model-specific configurations
architectures = {
    "speed_optimized": ModelArchitecture.MOBILENET_V3,    # Fastest
    "accuracy_focused": ModelArchitecture.EFFICIENTNET_B4, # Most accurate
    "balanced": ModelArchitecture.XCEPTION,              # Best balance
    "production": ModelArchitecture.EFFICIENTNET_B0      # Production ready
}
```

## Advanced Model Configuration

### Comprehensive Configuration

```python
from deepfake_detector.enhanced_cnn import (
    ModelConfig, ModelArchitecture, ExecutionProvider, PrecisionMode
)

config = ModelConfig(
    # Model selection
    architecture=ModelArchitecture.XCEPTION,
    model_path=None,  # Use default model
    custom_url=None,  # Custom download URL
    
    # Execution settings
    execution_providers=[ExecutionProvider.CPU],  # or CUDA, TENSORRT
    precision_mode=PrecisionMode.FP32,            # or FP16, INT8
    batch_size=32,
    num_threads=4,
    
    # Preprocessing
    input_size=(224, 224),
    normalize=True,
    augment_tta=False,  # Test-time augmentation
    
    # Performance optimization
    enable_caching=True,
    cache_size=1000,
    enable_warmup=True,
    optimize_for_mobile=False,
    
    # Ensemble settings
    enable_ensemble=False,
    ensemble_models=["efficientnet_b0", "resnet50"],
    ensemble_weights=[0.6, 0.4]
)
```

### Execution Providers

```python
# CPU Execution (Default)
config = ModelConfig(execution_providers=[ExecutionProvider.CPU])

# GPU Acceleration (requires CUDA)
config = ModelConfig(execution_providers=[ExecutionProvider.CUDA])

# TensorRT Optimization (requires TensorRT)
config = ModelConfig(execution_providers=[ExecutionProvider.TENSORRT])

# Fallback chain
config = ModelConfig(execution_providers=[
    ExecutionProvider.TENSORRT,  # Try TensorRT first
    ExecutionProvider.CUDA,      # Fall back to CUDA
    ExecutionProvider.CPU        # Final fallback
])
```

### Precision Modes

```python
# Full Precision (Default)
config = ModelConfig(precision_mode=PrecisionMode.FP32)

# Half Precision (2x faster, slight accuracy loss)
config = ModelConfig(precision_mode=PrecisionMode.FP16)

# Quantized (4x faster, moderate accuracy loss)
config = ModelConfig(precision_mode=PrecisionMode.INT8)

# Dynamic (automatically choose best precision)
config = ModelConfig(precision_mode=PrecisionMode.DYNAMIC)
```

## Ensemble Prediction

### Multi-Model Ensemble

```python
# Configure ensemble with multiple models
ensemble_config = ModelConfig(
    architecture=ModelArchitecture.XCEPTION,  # Primary model
    enable_ensemble=True,
    ensemble_models=["efficientnet_b0", "resnet50"],
    ensemble_weights=[0.5, 0.3, 0.2]  # Weights for [primary, model1, model2]
)

detector = EnhancedCNNDetector(ensemble_config)

# Ensemble prediction automatically combines all models
result = detector.predict(face_crops, return_detailed=True)
print(f"Ensemble probability: {result.probability:.3f}")
print(f"Ensemble confidence: {result.confidence:.3f}")
```

### Ensemble Strategies

```python
# Accuracy-focused ensemble
accuracy_ensemble = ModelConfig(
    architecture=ModelArchitecture.EFFICIENTNET_B4,
    enable_ensemble=True,
    ensemble_models=["xception", "efficientnet_b0"],
    ensemble_weights=[0.6, 0.3, 0.1]  # Weight toward accuracy
)

# Speed-balanced ensemble
speed_ensemble = ModelConfig(
    architecture=ModelArchitecture.MOBILENET_V3,
    enable_ensemble=True,
    ensemble_models=["efficientnet_b0"],
    ensemble_weights=[0.7, 0.3]  # Fast models only
)
```

## Model Management

### Model Registry System

```python
from deepfake_detector.enhanced_cnn import ModelRegistry, ModelMetadata

# Get model metadata
metadata = ModelRegistry.get_model_metadata(ModelArchitecture.XCEPTION)
print(f"Model: {metadata.name}")
print(f"Accuracy: {metadata.accuracy:.3f}")
print(f"Speed: {metadata.speed_ms:.1f}ms")

# Register custom model
custom_metadata = ModelMetadata(
    name="custom_deepfake_model",
    architecture=ModelArchitecture.CUSTOM,
    input_size=(256, 256),
    accuracy=0.95,
    description="Custom high-accuracy model"
)

ModelRegistry.register_custom_model("custom_model", custom_metadata)
```

### Model Manager Features

```python
from deepfake_detector.enhanced_cnn import ModelManager

# Advanced model management
manager = ModelManager(config)

# Load model with caching
session = manager.load_model(
    ModelArchitecture.XCEPTION,
    model_path=custom_path,
    custom_url="https://example.com/model.onnx"
)

# Cache management
cache_stats = manager.get_cache_stats()
print(f"Cached sessions: {cache_stats['cached_sessions']}")
print(f"Prediction stats: {cache_stats['prediction_stats']}")

# Clear cache when needed
manager.clear_cache()
```

### Model Download and Validation

```python
from deepfake_detector.enhanced_cnn import download_model

# Download specific model
model_path = download_model("xception", force_download=False)
print(f"Model downloaded to: {model_path}")

# Validate model integrity
detector = EnhancedCNNDetector(config)
model_info = detector.get_model_info()
print(f"Model validation: {model_info['primary_model']['available']}")
```

## Performance Optimization

### Batch Processing

```python
# Optimize batch size for throughput
configs = [
    ModelConfig(batch_size=1),   # Low latency
    ModelConfig(batch_size=16),  # Balanced
    ModelConfig(batch_size=64),  # High throughput
]

for config in configs:
    detector = EnhancedCNNDetector(config)
    benchmark = detector.benchmark(num_samples=100)
    print(f"Batch {config.batch_size}: {benchmark['summary']['peak_throughput']:.1f} samples/sec")
```

### Parallel Batch Processing

```python
# Process multiple batches in parallel
face_crops_batches = [
    [crop1, crop2, crop3],  # Batch 1
    [crop4, crop5, crop6],  # Batch 2
    [crop7, crop8, crop9],  # Batch 3
]

results = detector.predict_batch(face_crops_batches, max_workers=4)

for i, result in enumerate(results):
    print(f"Batch {i}: P(fake)={result.probability:.3f}")
```

### Memory and Compute Optimization

```python
# Memory-optimized configuration
memory_config = ModelConfig(
    batch_size=8,           # Smaller batches
    enable_caching=False,   # Disable caching
    optimize_for_mobile=True
)

# Compute-optimized configuration
compute_config = ModelConfig(
    batch_size=64,              # Larger batches
    execution_providers=[ExecutionProvider.CUDA],
    precision_mode=PrecisionMode.FP16,
    enable_caching=True,
    cache_size=2000
)
```

## Prediction Results and Analysis

### Detailed Prediction Results

```python
# Get detailed prediction information
result = detector.predict(face_crops, return_detailed=True)

print(f"Probability: {result.probability:.3f}")
print(f"Confidence: {result.confidence:.3f}")
print(f"Processing time: {result.processing_time*1000:.1f}ms")
print(f"Model used: {result.model_used}")
print(f"Batch size: {result.batch_size}")
print(f"Metadata: {result.metadata}")
```

### Confidence Interpretation

```python
def interpret_prediction(result):
    """Interpret CNN prediction result."""
    prob = result.probability
    conf = result.confidence
    
    if conf < 0.3:
        return "Low confidence - uncertain prediction"
    elif conf < 0.7:
        return "Medium confidence - reasonable prediction"
    else:
        return "High confidence - reliable prediction"
    
    if prob > 0.8 and conf > 0.7:
        return "Likely deepfake (high confidence)"
    elif prob < 0.2 and conf > 0.7:
        return "Likely authentic (high confidence)"
    else:
        return "Uncertain - requires additional analysis"
```

### Ensemble Confidence Analysis

```python
# Analyze ensemble agreement
if config.enable_ensemble:
    # Higher confidence indicates better model agreement
    if result.confidence > 0.8:
        print("Strong ensemble agreement")
    elif result.confidence > 0.5:
        print("Moderate ensemble agreement")
    else:
        print("Weak ensemble agreement - conflicting predictions")
```

## Performance Benchmarking

### Comprehensive Benchmarking

```python
# Benchmark single model
benchmark_results = detector.benchmark(
    num_samples=200,
    image_size=(224, 224)
)

print("Benchmark Results:")
print(f"Single sample latency: {benchmark_results['summary']['single_sample_latency_ms']:.2f}ms")
print(f"Peak throughput: {benchmark_results['summary']['peak_throughput']:.1f} samples/sec")
print(f"Optimal batch size: {benchmark_results['summary']['optimal_batch_size']}")

# Analyze batch performance
for batch_key, batch_result in benchmark_results["batch_results"].items():
    batch_size = batch_key.split("_")[-1]
    throughput = batch_result["throughput_samples_per_second"]
    latency = batch_result["avg_time_seconds"] * 1000
    print(f"Batch {batch_size}: {throughput:.1f} samples/sec, {latency:.1f}ms avg")
```

### Model Comparison Benchmarks

```python
# Compare multiple architectures
models_to_compare = ["xception", "efficientnet_b0", "efficientnet_b4", "resnet50"]
comparison_results = {}

for model_name in models_to_compare:
    config = create_model_config(model_name)
    detector = EnhancedCNNDetector(config)
    
    if detector.available():
        benchmark = detector.benchmark(num_samples=50)
        comparison_results[model_name] = {
            "latency_ms": benchmark["summary"]["single_sample_latency_ms"],
            "throughput": benchmark["summary"]["peak_throughput"],
            "accuracy": ModelRegistry.get_model_metadata(ModelArchitecture(model_name)).accuracy
        }

# Find optimal model for different criteria
best_speed = min(comparison_results.keys(), 
                key=lambda k: comparison_results[k]["latency_ms"])
best_throughput = max(comparison_results.keys(),
                     key=lambda k: comparison_results[k]["throughput"])
best_accuracy = max(comparison_results.keys(),
                   key=lambda k: comparison_results[k]["accuracy"])

print(f"Best speed: {best_speed}")
print(f"Best throughput: {best_throughput}")
print(f"Best accuracy: {best_accuracy}")
```

## CLI Tools and Automation

### Model Management Commands

```bash
# List all available models with details
python -m deepfake_detector.cnn_cli list --output models_info.json

# Download specific models
python -m deepfake_detector.cnn_cli download --models xception efficientnet_b0 --force

# Validate model integrity
python -m deepfake_detector.cnn_cli validate --model xception --output validation_report.json
```

### Performance Analysis Commands

```bash
# Benchmark specific model
python -m deepfake_detector.cnn_cli benchmark \
    --model xception \
    --samples 200 \
    --batch-size 32 \
    --provider cpu \
    --output benchmark_results.json

# Test model with random samples
python -m deepfake_detector.cnn_cli test \
    --model efficientnet_b0 \
    --samples 20 \
    --batch-size 4 \
    --output test_results.json

# Compare multiple models
python -m deepfake_detector.cnn_cli compare \
    --models xception efficientnet_b0 efficientnet_b4 \
    --samples 100 \
    --output comparison_report.json
```

### Automated Optimization

```bash
# Find optimal configuration for your hardware
python -m deepfake_detector.cnn_cli benchmark \
    --model xception \
    --samples 100 \
    --provider cuda \
    --precision fp16 \
    --output gpu_optimization.json

# Validate all models
for model in xception efficientnet_b0 efficientnet_b4 resnet50 mobilenet_v3; do
    python -m deepfake_detector.cnn_cli validate --model $model --output ${model}_validation.json
done
```

## Integration with Detection Pipeline

### Automatic Integration

The enhanced CNN detector integrates seamlessly with the main detection pipeline:

```python
# Configure enhanced CNN in main config
from deepfake_detector.config import DeepfakeDetectorConfig

config = DeepfakeDetectorConfig()
config.algorithms.enable_cnn_analysis = True
config.algorithms.cnn_architecture = "efficientnet_b0"
config.algorithms.cnn_execution_provider = "cuda"
config.algorithms.cnn_batch_size = 16
config.algorithms.enable_ensemble = False

# Run analysis with enhanced CNN
report = analyze_video(video_path, config=config)
print(f"CNN score: {report.scores['cnn']:.3f}")
```

### Configuration-Driven Selection

```python
# Production configuration
config.algorithms.cnn_architecture = "efficientnet_b4"  # High accuracy
config.algorithms.cnn_execution_provider = "cuda"
config.algorithms.cnn_precision_mode = "fp16"
config.algorithms.cnn_batch_size = 32

# Development configuration
config.algorithms.cnn_architecture = "mobilenet_v3"  # Fast inference
config.algorithms.cnn_execution_provider = "cpu"
config.algorithms.cnn_batch_size = 8

# Ensemble configuration
config.algorithms.cnn_enable_ensemble = True
config.algorithms.cnn_ensemble_models = ["xception", "efficientnet_b0"]
```

## Error Handling and Fallbacks

### Graceful Degradation

```python
# The system automatically handles various failure modes:

# 1. Missing dependencies
try:
    detector = EnhancedCNNDetector(config)
except DependencyError as e:
    print(f"Enhanced CNN not available: {e}")
    # Falls back to basic CNN detector
    from deepfake_detector.cnn_detector import CnnDetector
    detector = CnnDetector()

# 2. Model loading failures
config_with_fallback = ModelConfig(
    architecture=ModelArchitecture.XCEPTION,
    execution_providers=[
        ExecutionProvider.CUDA,  # Try GPU first
        ExecutionProvider.CPU    # Fallback to CPU
    ]
)

# 3. Prediction errors
try:
    result = detector.predict(face_crops)
except Exception as e:
    print(f"Prediction failed: {e}")
    result = 0.5  # Neutral score
```

### Validation and Diagnostics

```python
# Comprehensive model validation
def validate_cnn_setup(config):
    """Validate CNN configuration and setup."""
    try:
        detector = EnhancedCNNDetector(config)
        
        if not detector.available():
            return False, "Detector not available"
        
        # Test prediction
        test_crop = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
        result = detector.predict([test_crop], return_detailed=True)
        
        if not (0.0 <= result.probability <= 1.0):
            return False, "Invalid prediction range"
        
        if result.processing_time <= 0:
            return False, "Invalid processing time"
        
        return True, "Validation successful"
    
    except Exception as e:
        return False, f"Validation error: {e}"

# Usage
is_valid, message = validate_cnn_setup(config)
print(f"CNN validation: {message}")
```

## Advanced Features

### Custom Model Integration

```python
# Register and use custom models
custom_metadata = ModelMetadata(
    name="my_custom_model",
    architecture=ModelArchitecture.CUSTOM,
    input_size=(256, 256),
    mean=(0.5, 0.5, 0.5),
    std=(0.5, 0.5, 0.5),
    accuracy=0.94,
    description="Custom trained model"
)

ModelRegistry.register_custom_model("custom", custom_metadata)

# Use custom model
custom_config = ModelConfig(
    architecture=ModelArchitecture.CUSTOM,
    model_path=Path("path/to/custom_model.onnx"),
    input_size=(256, 256)
)
```

### Test-Time Augmentation

```python
# Enable test-time augmentation for improved accuracy
tta_config = ModelConfig(
    architecture=ModelArchitecture.XCEPTION,
    augment_tta=True  # Applies horizontal flip augmentation
)

detector = EnhancedCNNDetector(tta_config)
result = detector.predict(face_crops)
# TTA typically improves accuracy at the cost of 2x inference time
```

### Dynamic Batch Sizing

```python
# Automatically adjust batch size based on available memory
def get_optimal_batch_size(detector, max_memory_mb=4000):
    """Find optimal batch size for available memory."""
    for batch_size in [64, 32, 16, 8, 4, 1]:
        try:
            test_crops = [
                np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
                for _ in range(batch_size)
            ]
            
            result = detector.predict(test_crops)
            return batch_size  # This batch size works
        
        except Exception:
            continue  # Try smaller batch size
    
    return 1  # Fallback to single sample

optimal_batch = get_optimal_batch_size(detector)
print(f"Optimal batch size: {optimal_batch}")
```

## Best Practices

### For Production Deployment

1. **Model Selection**: Use EfficientNet-B0 or B4 for production balance of speed/accuracy
2. **Batch Processing**: Optimize batch size for your hardware (typically 16-32)
3. **GPU Acceleration**: Use CUDA provider when available
4. **Model Caching**: Enable caching for repeated inference
5. **Validation**: Always validate models before deployment

### For Development and Testing

1. **Fast Iteration**: Use MobileNet-V3 for quick development cycles
2. **Comprehensive Testing**: Test multiple architectures to find best fit
3. **Benchmarking**: Regular performance benchmarks to track optimization
4. **Error Handling**: Implement robust fallback mechanisms

### For Research and Experimentation

1. **Ensemble Methods**: Use ensemble for maximum accuracy
2. **Custom Models**: Integrate domain-specific trained models
3. **Detailed Analysis**: Use detailed prediction results for research insights
4. **Performance Profiling**: Detailed benchmarking for optimization research

The enhanced CNN detection system provides research-grade capabilities with production-ready reliability, offering comprehensive model management, advanced optimization features, and enterprise-grade tooling for deepfake detection applications.
