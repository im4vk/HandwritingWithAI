# Deepfake Detector Logging Guide

The deepfake detector includes a comprehensive logging system that provides detailed information about the detection process, performance metrics, and error handling.

## Quick Start

### Basic Usage (Console Only)
```bash
python -m deepfake_detector.detect --input video.mp4
```

### With File Logging
```bash
python -m deepfake_detector.detect --input video.mp4 --log-dir ./logs --log-level DEBUG
```

### Structured JSON Logs
```bash
python -m deepfake_detector.detect --input video.mp4 --log-dir ./logs --structured-logs
```

### Quiet Mode (Minimal Output)
```bash
python -m deepfake_detector.detect --input video.mp4 --quiet
```

## Logging Features

### 1. Multiple Log Levels
- **DEBUG**: Detailed diagnostic information
- **INFO**: General information about the process
- **WARNING**: Warning messages for non-critical issues
- **ERROR**: Error messages for failures

### 2. Multiple Output Formats
- **Standard Format**: Human-readable console/file output
- **Structured JSON**: Machine-readable JSON format for log analysis
- **Performance Format**: Specialized format for performance metrics

### 3. Multiple Output Destinations
- **Console**: Real-time output to terminal
- **Application Log**: Complete application log file
- **Error Log**: Errors and exceptions only
- **Performance Log**: Operation timing and metrics

### 4. Log Rotation
- Automatic rotation when files reach 10MB
- Keeps 5 backup files for application logs
- Keeps 3 backup files for error/performance logs

## Command Line Options

| Option | Description | Default |
|--------|-------------|---------|
| `--log-level` | Set logging level (DEBUG/INFO/WARNING/ERROR) | INFO |
| `--log-dir` | Directory for log files | None (console only) |
| `--no-console-log` | Disable console logging | False |
| `--structured-logs` | Use JSON structured logging | False |
| `--no-performance-monitoring` | Disable performance monitoring | False |
| `--quiet` | Minimal output (only final result) | False |

## Log File Structure

When using `--log-dir`, the following files are created:

```
logs/
├── deepfake_detector.log    # Main application log
├── errors.log               # Errors and exceptions only
└── performance.log          # Operation timing and metrics
```

## Sample Log Outputs

### Standard Format
```
2025-01-15 10:30:45 | INFO     | deepfake_detector.detect | Starting deepfake analysis: video.mp4
2025-01-15 10:30:45 | INFO     | deepfake_detector.io | Reading video: video.mp4 (target_fps=15, max_frames=None)
2025-01-15 10:30:46 | INFO     | deepfake_detector.io | Successfully read 120 frames from video
2025-01-15 10:30:46 | INFO     | deepfake_detector.face | Detecting faces in 120 frames
2025-01-15 10:30:47 | INFO     | deepfake_detector.face | MediaPipe detected 118 face frames
2025-01-15 10:30:47 | DEBUG    | deepfake_detector.detect | Frequency analysis score: 0.3245
2025-01-15 10:30:48 | DEBUG    | deepfake_detector.detect | rPPG analysis score: 0.6789
2025-01-15 10:30:48 | DEBUG    | deepfake_detector.detect | Audio-visual sync score: 0.4567
2025-01-15 10:30:48 | DEBUG    | deepfake_detector.detect | Geometry analysis score: 0.5432
2025-01-15 10:30:49 | INFO     | deepfake_detector.fusion | Fusion using 4 valid scores: ['freq', 'rppg', 'av', 'geom']
2025-01-15 10:30:49 | INFO     | deepfake_detector.detect | Detection complete: fake (probability: 0.6789)
2025-01-15 10:30:49 | INFO     | deepfake_detector.detect | Total analysis time: 4.23s
```

### Structured JSON Format
```json
{"timestamp": "2025-01-15T10:30:45", "level": "INFO", "logger": "deepfake_detector.detect", "message": "Starting deepfake analysis: video.mp4", "module": "detect", "function": "analyze_video", "line": 100}
{"timestamp": "2025-01-15T10:30:49", "level": "INFO", "logger": "deepfake_detector.detect", "message": "Detection complete: fake (probability: 0.6789)", "module": "detect", "function": "analyze_video", "line": 212, "extra": {"final_score": 0.6789, "label": "fake", "individual_scores": {"freq": 0.3245, "rppg": 0.6789, "av": 0.4567, "geom": 0.5432}}}
```

### Performance Log
```
2025-01-15T10:30:45 | PERF | media_loading | 1.2340s | frames=120,audio_samples=192000
2025-01-15T10:30:46 | PERF | face_detection | 0.8760s | faces_detected=118,detection_method=mediapipe
2025-01-15T10:30:47 | PERF | frequency_analysis | 0.3450s | face_crops=118
2025-01-15T10:30:47 | PERF | rppg_analysis | 0.5670s | face_crops=118,timestamps=118
2025-01-15T10:30:48 | PERF | avsync_analysis | 0.2340s | mouth_series=118,audio_available=true
2025-01-15T10:30:48 | PERF | geometry_analysis | 0.1890s | landmarks=118,eye_series=118,centers=118
2025-01-15T10:30:48 | PERF | score_fusion | 0.0123s | valid_scores=4
2025-01-15T10:30:49 | PERF | full_analysis | 4.2300s | frames_processed=120,faces_detected=118,final_score=0.6789,label=fake
```

## Programmatic Usage

### Basic Configuration
```python
from deepfake_detector.logging_config import configure_logging, get_logger

# Configure logging
configure_logging(
    log_level='INFO',
    log_dir='./logs',
    console_output=True,
    file_output=True,
    structured_logs=False,
    performance_monitoring=True
)

# Get logger for your module
logger = get_logger(__name__)
logger.info("Application started")
```

### Operation Timing
```python
from deepfake_detector.logging_config import create_operation_context, log_operation

# Using context manager (automatic timing)
with create_operation_context("my_operation"):
    # Your code here
    result = process_data()

# Manual timing
import time
start = time.time()
result = process_data()
duration = time.time() - start
log_operation("my_operation", duration, success=True, details={"items": 100})
```

### Performance Metrics
```python
from deepfake_detector.logging_config import get_metrics, log_metrics

# Get current metrics
metrics = get_metrics()
print(f"Success rate: {metrics['success_rate']:.2%}")
print(f"Average operation time: {metrics['average_operation_time']:.4f}s")

# Log metrics to performance log
log_metrics()
```

## Production Deployment

### Recommended Configuration
```bash
# Production with structured logs and file output
python -m deepfake_detector.detect \
    --input video.mp4 \
    --log-dir /var/log/deepfake-detector \
    --log-level INFO \
    --structured-logs \
    --quiet
```

### Log Analysis

For structured JSON logs, you can use tools like `jq` for analysis:

```bash
# Get all error messages
cat logs/deepfake_detector.log | jq 'select(.level=="ERROR") | .message'

# Calculate average processing time
cat logs/performance.log | jq 'select(.operation=="full_analysis") | .duration' | awk '{sum+=$1; count++} END {print "Average:", sum/count, "seconds"}'

# Get success rate
cat logs/performance.log | jq 'select(.operation=="full_analysis") | .success' | sort | uniq -c
```

### Log Monitoring

Set up log monitoring with tools like:
- **ELK Stack**: Elasticsearch, Logstash, Kibana
- **Splunk**: For enterprise log analysis
- **Grafana + Loki**: For visualization and alerting
- **CloudWatch**: For AWS deployments

## Troubleshooting

### Common Issues

1. **Permission Denied on Log Directory**
   ```bash
   mkdir -p logs
   chmod 755 logs
   ```

2. **Log Files Not Created**
   - Ensure the log directory exists and is writable
   - Check that `--log-dir` is specified for file output

3. **Performance Impact**
   - Use `--no-performance-monitoring` if logging overhead is too high
   - Use `INFO` or `WARNING` level instead of `DEBUG` in production

4. **Large Log Files**
   - Log rotation is automatic (10MB max per file)
   - Adjust rotation settings in the code if needed

### Debug Mode

For maximum diagnostic information:
```bash
python -m deepfake_detector.detect \
    --input video.mp4 \
    --log-level DEBUG \
    --log-dir ./debug-logs \
    --structured-logs
```

This will provide detailed information about every step of the detection process.

## Integration Examples

### With Docker
```dockerfile
FROM python:3.9-slim

# Install dependencies
COPY requirements.txt .
RUN pip install -r requirements.txt

# Copy application
COPY src/ /app/src/
WORKDIR /app

# Create log directory
RUN mkdir -p /var/log/deepfake-detector

# Run with logging
CMD ["python", "-m", "deepfake_detector.detect", \
     "--input", "/data/input.mp4", \
     "--log-dir", "/var/log/deepfake-detector", \
     "--log-level", "INFO", \
     "--structured-logs", \
     "--quiet"]
```

### With Systemd Service
```ini
[Unit]
Description=Deepfake Detector Service
After=network.target

[Service]
Type=simple
User=deepfake
WorkingDirectory=/opt/deepfake-detector
ExecStart=/opt/deepfake-detector/venv/bin/python -m deepfake_detector.detect \
          --input /data/queue/%i \
          --log-dir /var/log/deepfake-detector \
          --log-level INFO \
          --structured-logs \
          --quiet
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

## Performance Impact

The logging system is designed to be efficient:

- **Lazy Evaluation**: Log messages are only formatted if they will be output
- **Async I/O**: File writes are buffered and non-blocking
- **Minimal Overhead**: Performance monitoring adds <1% processing time
- **Configurable**: Can be completely disabled if needed

Typical overhead:
- Console logging: <0.1ms per message
- File logging: <0.5ms per message
- Structured JSON: <1ms per message
- Performance monitoring: <0.01ms per operation
