# Performance Optimization Guide

The deepfake detector includes comprehensive performance optimizations to maximize processing speed, minimize memory usage, and scale efficiently across different hardware configurations. This guide covers all performance features and optimization strategies.

## Quick Start

### Enable Basic Optimizations
```bash
# Use production configuration with optimizations enabled
python -m deepfake_detector.detect --input video.mp4 --profile production --json results.json

# Enable caching for repeated analysis
python -m deepfake_detector.detect --input video.mp4 --enable-caching --json results.json
```

### Benchmark Performance
```bash
# Benchmark processing performance
python -m deepfake_detector.performance_cli benchmark --file video.mp4 --output benchmark.json

# Optimize configuration for your files
python -m deepfake_detector.performance_cli optimize --file video.mp4 --output optimized_config.json
```

### Monitor Memory Usage
```bash
# Estimate memory requirements
python -m deepfake_detector.performance_cli memory-estimate --file large_video.mp4
```

## Performance Architecture

### Multi-Level Optimization System

1. **Caching System**: Multi-tier caching (memory + disk) for computed results
2. **Parallel Processing**: CPU parallelization for algorithm execution
3. **Streaming Processing**: Memory-efficient chunk-based video processing
4. **Memory Management**: Intelligent garbage collection and memory monitoring
5. **Algorithm Optimization**: Adaptive processing mode selection

### Performance Components

```python
from deepfake_detector.performance import (
    PerformanceOptimizer,      # Main optimization coordinator
    CacheManager,              # Multi-level caching
    StreamingProcessor,        # Memory-efficient video processing
    MemoryManager,             # Memory usage optimization
    ProcessingMode            # Adaptive processing modes
)
```

## Caching System

### Multi-Level Cache Architecture

The caching system uses a hierarchical approach:

1. **Memory Cache**: Fast L1 cache for immediate access
2. **Disk Cache**: Persistent L2 cache for repeated sessions
3. **Distributed Cache**: Optional L3 cache for multi-node deployments

### Cache Configuration

```python
from deepfake_detector.performance import PerformanceConfig

config = PerformanceConfig(
    # Caching settings
    enable_caching=True,
    memory_cache_size=1000,        # Max items in memory
    disk_cache_size_mb=1000,       # Max disk cache size
    cache_ttl_seconds=86400,       # 24 hours
    disk_cache_dir=Path("/tmp/cache")
)
```

### Cache Usage Patterns

```python
# Automatic caching with decorator
from deepfake_detector.performance import cached

@cached("frequency_analysis", {"window_size": 256})
def analyze_frequency(file_path):
    # Analysis code here
    return result

# Manual caching with optimizer
optimizer = PerformanceOptimizer(config)
result = optimizer.cached_analysis(
    "algorithm_name",
    analysis_function,
    file_path,
    parameters={"param1": "value1"}
)
```

### Cache Performance Monitoring

```bash
# Analyze cache performance
python -m deepfake_detector.performance_cli cache-analysis --cache-dir /tmp/cache --output cache_stats.json
```

Cache statistics include:
- **Hit Rate**: Percentage of cache hits vs. misses
- **Storage Efficiency**: Disk usage and file distribution
- **Access Patterns**: Most frequently cached algorithms
- **Age Distribution**: Cache freshness analysis

## Parallel Processing

### CPU Parallelization

The system automatically detects optimal parallelization strategies:

```python
# Enable parallel processing
config = PerformanceConfig(
    enable_parallel=True,
    max_workers=None,  # Auto-detect CPU count
    thread_pool_size=4,
    process_pool_size=2
)

# Manual parallel execution
tasks = [
    ("frequency", freq_analysis, file_path, {}),
    ("rppg", rppg_analysis, file_path, {}),
    ("geometry", geom_analysis, file_path, {})
]

results = optimizer.parallel_analysis(tasks)
```

### Processing Modes

The system automatically selects optimal processing modes:

1. **BATCH**: Sequential processing for small files
2. **PARALLEL**: CPU parallelization for medium files
3. **STREAMING**: Memory-efficient processing for large files
4. **GPU_ACCELERATED**: GPU processing when available

```python
# Processing mode selection is automatic
mode = optimizer.optimize_for_file(video_path)
print(f"Selected mode: {mode.value}")

# Modes: batch, parallel, streaming, gpu_accelerated
```

### Parallel Algorithm Execution

```python
# Algorithms run in parallel when beneficial
def analyze_video_optimized(video_path):
    if processing_mode == ProcessingMode.PARALLEL:
        # Run frequency, rPPG, geometry in parallel
        results = optimizer.parallel_analysis([
            ("frequency", frequency_analysis, crops, {}),
            ("rppg", rppg_analysis, crops, {"timestamps": ts}),
            ("geometry", geometry_analysis, landmarks, {"fps": fps})
        ])
    else:
        # Sequential with caching
        results = [
            optimizer.cached_analysis("frequency", freq_func, path, {}),
            optimizer.cached_analysis("rppg", rppg_func, path, {}),
            optimizer.cached_analysis("geometry", geom_func, path, {})
        ]
```

## Streaming Processing

### Memory-Efficient Video Processing

For large videos, streaming processing prevents memory exhaustion:

```python
# Streaming configuration
config = PerformanceConfig(
    enable_streaming=True,
    streaming_chunk_size=30,      # Frames per chunk
    streaming_overlap=5,          # Overlap between chunks
    max_memory_frames=300         # Max frames in memory
)

# Streaming processor usage
processor = StreamingProcessor(config)

for chunk_index, result in processor.process_video_streaming(
    video_path, analysis_function
):
    print(f"Processed chunk {chunk_index}: {result}")

# Aggregate streaming results
final_result = processor.aggregate_streaming_results(chunk_results)
```

### Streaming Algorithm Integration

```python
# Streaming-aware algorithm implementation
def streaming_frequency_analysis(chunk_data):
    frames = chunk_data['frames']
    frame_indices = chunk_data['frame_indices']
    
    # Process chunk
    chunk_score = analyze_frames(frames)
    
    return {
        'score': chunk_score,
        'frames_processed': len(frames),
        'chunk_index': chunk_data['chunk_index']
    }

# Use with streaming processor
results = list(streaming_processor.process_video_streaming(
    video_path, streaming_frequency_analysis
))
```

### Memory Usage Optimization

```python
# Automatic memory management
if memory_manager.check_memory_pressure():
    gc_stats = memory_manager.force_garbage_collection()
    print(f"Freed {gc_stats['memory_freed_mb']:.1f} MB")

# Memory usage monitoring
usage = memory_manager.get_memory_usage()
print(f"Memory usage: {usage['rss_mb']:.1f} MB ({usage['percent']:.1f}%)")
```

## Configuration Optimization

### Performance Configuration Structure

```python
@dataclass
class PerformanceConfig:
    # Caching configuration
    enable_caching: bool = True
    memory_cache_size: int = 1000
    disk_cache_size_mb: int = 1000
    cache_ttl_seconds: int = 86400
    
    # Streaming configuration
    enable_streaming: bool = True
    streaming_chunk_size: int = 30
    streaming_overlap: int = 5
    max_memory_frames: int = 300
    
    # Parallel processing
    enable_parallel: bool = True
    max_workers: Optional[int] = None
    thread_pool_size: int = 4
    
    # Memory management
    enable_gc: bool = True
    memory_threshold_mb: int = 2000
    
    # GPU acceleration (if available)
    enable_gpu: bool = False
    gpu_memory_fraction: float = 0.7
```

### Configuration Profiles

Predefined optimization profiles for common scenarios:

```python
# Development profile - balanced performance and debugging
config = PerformanceConfig(
    enable_caching=True,
    enable_parallel=False,  # Easier debugging
    enable_streaming=False,
    memory_cache_size=100
)

# Production profile - maximum performance
config = PerformanceConfig(
    enable_caching=True,
    enable_parallel=True,
    enable_streaming=True,
    max_workers=None,  # Use all cores
    memory_cache_size=1000,
    disk_cache_size_mb=2000
)

# Memory-constrained profile
config = PerformanceConfig(
    enable_caching=True,
    enable_streaming=True,
    streaming_chunk_size=15,  # Smaller chunks
    memory_threshold_mb=1000,
    max_workers=2  # Limit parallelism
)
```

### Automatic Configuration Optimization

```bash
# Optimize configuration for your specific files
python -m deepfake_detector.performance_cli optimize \
    --file typical_video.mp4 \
    --output optimized_config.json

# Test different configurations
python -m deepfake_detector.performance_cli benchmark \
    --file video.mp4 \
    --config optimized_config.json \
    --iterations 5 \
    --output benchmark_results.json
```

## Memory Management

### Memory Usage Estimation

```python
# Estimate memory requirements before processing
estimates = estimate_memory_requirements(video_path, target_fps=15)

print(f"Single frame: {estimates['single_frame_mb']:.1f} MB")
print(f"All frames: {estimates['all_frames_mb']:.1f} MB")
print(f"Streaming chunk: {estimates['streaming_chunk_mb']:.1f} MB")
print(f"Recommended RAM: {estimates['recommended_ram_mb']:.1f} MB")
```

### Memory Monitoring and Management

```python
# Continuous memory monitoring
memory_manager = MemoryManager(config)

# Check for memory pressure
if memory_manager.check_memory_pressure():
    # Force garbage collection
    gc_stats = memory_manager.force_garbage_collection()
    
    # Clean up large objects
    cleaned = memory_manager.cleanup_large_objects(threshold_mb=100)
    
    print(f"Memory cleanup: freed {gc_stats['memory_freed_mb']:.1f} MB")
    print(f"Cleaned {cleaned} large objects")
```

### Memory-Efficient Processing Patterns

```python
# Process in chunks to limit memory usage
def process_large_video(video_path, max_memory_mb=1000):
    estimates = estimate_memory_requirements(video_path)
    
    if estimates['all_frames_mb'] > max_memory_mb:
        # Use streaming processing
        return streaming_analysis(video_path)
    else:
        # Use batch processing
        return batch_analysis(video_path)
```

## Performance Monitoring

### Real-Time Performance Tracking

```python
# Get comprehensive performance statistics
optimizer = PerformanceOptimizer(config)
stats = optimizer.get_performance_stats()

print(f"Cache hit rate: {stats['cache']['hit_rate']:.3f}")
print(f"Memory usage: {stats['memory']['current_usage']['rss_mb']:.1f} MB")
print(f"Processing speed: {stats['processing']['samples_per_second']:.1f} samples/sec")
```

### Performance Metrics

The system tracks comprehensive performance metrics:

```python
{
    "cache": {
        "hit_rate": 0.85,           # Cache effectiveness
        "total_hits": 42,
        "total_misses": 8,
        "memory_usage_mb": 156.7,
        "disk_usage_mb": 892.3
    },
    "memory": {
        "current_usage": {
            "rss_mb": 1247.8,        # Resident memory
            "vms_mb": 2156.4,        # Virtual memory
            "percent": 15.6,         # % of system memory
            "available_mb": 6543.2   # Available system memory
        },
        "cleanup_count": 3           # Number of GC cleanups
    },
    "processing": {
        "total_analyses": 15,
        "average_time_seconds": 2.34,
        "samples_per_second": 12.7
    },
    "streaming": {
        "chunks_processed": 8
    }
}
```

### Benchmarking and Profiling

```bash
# Comprehensive benchmarking
python -m deepfake_detector.performance_cli benchmark \
    --file video.mp4 \
    --iterations 10 \
    --enable-caching \
    --enable-parallel \
    --max-workers 8 \
    --output detailed_benchmark.json
```

Benchmark results include:
- **Processing Times**: Average, min, max processing times
- **Memory Usage**: Peak memory consumption per iteration
- **Cache Performance**: Hit rates and cache efficiency
- **Success Rate**: Reliability across multiple runs
- **Resource Utilization**: CPU and memory usage patterns

## Command-Line Performance Tools

### Performance CLI Overview

```bash
# Available performance tools
python -m deepfake_detector.performance_cli --help

# Benchmark processing performance
python -m deepfake_detector.performance_cli benchmark --file video.mp4 --output results.json

# Optimize configuration automatically
python -m deepfake_detector.performance_cli optimize --file video.mp4 --output config.json

# Analyze cache performance
python -m deepfake_detector.performance_cli cache-analysis --cache-dir /tmp/cache --output stats.json

# Estimate memory requirements
python -m deepfake_detector.performance_cli memory-estimate --file video.mp4
```

### Benchmarking Command

```bash
# Basic benchmarking
python -m deepfake_detector.performance_cli benchmark \
    --file video.mp4 \
    --iterations 5 \
    --output benchmark.json

# Advanced benchmarking with custom configuration
python -m deepfake_detector.performance_cli benchmark \
    --file video.mp4 \
    --config custom_config.json \
    --enable-caching \
    --enable-parallel \
    --max-workers 6 \
    --iterations 10 \
    --output detailed_benchmark.json \
    --verbose
```

### Configuration Optimization

```bash
# Automatic optimization
python -m deepfake_detector.performance_cli optimize \
    --file typical_video.mp4 \
    --output optimized_config.json \
    --verbose

# Optimization with base configuration
python -m deepfake_detector.performance_cli optimize \
    --file video.mp4 \
    --config base_config.json \
    --output optimized.json
```

### Cache Analysis

```bash
# Comprehensive cache analysis
python -m deepfake_detector.performance_cli cache-analysis \
    --cache-dir /Users/username/.deepfake_cache \
    --output cache_report.json \
    --verbose
```

Cache analysis provides:
- **Storage Usage**: Total cache size and file distribution
- **Access Patterns**: Most frequently cached algorithms
- **Age Distribution**: Cache freshness and cleanup recommendations
- **Algorithm Breakdown**: Cache usage by detection algorithm
- **File Type Analysis**: Cache distribution by media type

## Hardware-Specific Optimizations

### CPU Optimization

```python
# Optimize for CPU architecture
import os

# Set optimal thread count
optimal_threads = min(os.cpu_count(), 8)  # Don't exceed 8 threads
config = PerformanceConfig(max_workers=optimal_threads)

# Enable CPU-specific optimizations
from deepfake_detector.performance import optimize_opencv_performance
optimize_opencv_performance()  # Optimizes OpenCV for current CPU
```

### Memory-Constrained Systems

```python
# Configuration for limited memory systems
low_memory_config = PerformanceConfig(
    enable_streaming=True,
    streaming_chunk_size=15,      # Smaller chunks
    memory_threshold_mb=500,      # Lower threshold
    memory_cache_size=50,         # Smaller cache
    max_workers=2,                # Limit parallelism
    enable_gc=True                # Aggressive GC
)
```

### High-Performance Systems

```python
# Configuration for high-end systems
high_perf_config = PerformanceConfig(
    enable_caching=True,
    enable_parallel=True,
    max_workers=None,             # Use all cores
    memory_cache_size=2000,       # Large cache
    disk_cache_size_mb=5000,      # Large disk cache
    streaming_chunk_size=60,      # Larger chunks
    memory_threshold_mb=8000      # High threshold
)
```

## Integration Examples

### Production Deployment

```python
# Production-optimized detection service
from deepfake_detector.performance import PerformanceOptimizer
from deepfake_detector.config import load_config

# Load production configuration
config = load_config("production.json")

# Initialize performance optimizer
optimizer = PerformanceOptimizer(config.performance)

# Process videos with optimization
def process_video_production(video_path):
    return analyze_video(
        video_path,
        config=config,
        performance_optimizer=optimizer
    )

# Monitor performance
stats = optimizer.get_performance_stats()
if stats['cache']['hit_rate'] < 0.7:
    print("Warning: Low cache hit rate")

if stats['memory']['current_usage']['percent'] > 80:
    print("Warning: High memory usage")
```

### Batch Processing Optimization

```python
# Optimize for batch processing multiple files
def process_batch_optimized(file_paths, config):
    optimizer = PerformanceOptimizer(config.performance)
    results = []
    
    for i, file_path in enumerate(file_paths):
        # Monitor memory usage
        if optimizer.memory_manager.check_memory_pressure():
            optimizer.memory_manager.force_garbage_collection()
        
        # Process with optimization
        result = analyze_video(
            file_path,
            config=config,
            performance_optimizer=optimizer
        )
        results.append(result)
        
        # Log progress with performance stats
        if (i + 1) % 10 == 0:
            stats = optimizer.get_performance_stats()
            print(f"Processed {i+1}/{len(file_paths)} files")
            print(f"Cache hit rate: {stats['cache']['hit_rate']:.3f}")
            print(f"Average time: {stats['processing']['average_time_seconds']:.2f}s")
    
    return results
```

### Real-Time Processing

```python
# Optimize for real-time processing
def setup_realtime_processing():
    config = PerformanceConfig(
        enable_caching=True,
        memory_cache_size=500,      # Moderate cache
        enable_parallel=False,      # Reduce latency
        enable_streaming=False,     # Direct processing
        memory_threshold_mb=1500
    )
    
    optimizer = PerformanceOptimizer(config)
    
    # Pre-warm cache with model loading
    warmup_video = Path("warmup_sample.mp4")
    if warmup_video.exists():
        analyze_video(warmup_video, performance_optimizer=optimizer)
    
    return optimizer

# Real-time processing loop
optimizer = setup_realtime_processing()

def process_frame_realtime(frame_data):
    return optimizer.cached_analysis(
        "realtime", 
        lambda fp: process_single_frame(frame_data),
        Path("realtime_input"),
        {"frame_hash": hash(frame_data.tobytes())}
    )
```

## Troubleshooting Performance Issues

### Common Performance Problems

1. **Low Cache Hit Rate**
   ```bash
   # Analyze cache performance
   python -m deepfake_detector.performance_cli cache-analysis --cache-dir /tmp/cache --output analysis.json
   
   # Check cache configuration
   # Increase cache size or TTL
   config.memory_cache_size = 2000
   config.cache_ttl_seconds = 172800  # 48 hours
   ```

2. **High Memory Usage**
   ```bash
   # Estimate memory requirements
   python -m deepfake_detector.performance_cli memory-estimate --file large_video.mp4
   
   # Enable streaming for large files
   config.enable_streaming = True
   config.streaming_chunk_size = 20  # Smaller chunks
   ```

3. **Slow Processing**
   ```bash
   # Benchmark different configurations
   python -m deepfake_detector.performance_cli optimize --file video.mp4 --output optimized.json
   
   # Enable parallel processing
   config.enable_parallel = True
   config.max_workers = 4
   ```

### Performance Debugging

```python
# Enable detailed performance logging
configure_logging(
    log_level="DEBUG",
    performance_monitoring=True,
    log_dir="performance_logs"
)

# Monitor processing with timing
from deepfake_detector.logging_config import create_operation_context

with create_operation_context("algorithm_analysis") as ctx:
    result = algorithm_function(input_data)
    print(f"Processing time: {ctx.duration:.3f}s")

# Profile memory usage
import tracemalloc

tracemalloc.start()
result = analyze_video(video_path)
current, peak = tracemalloc.get_traced_memory()
print(f"Memory usage: {current / 1024 / 1024:.1f} MB (peak: {peak / 1024 / 1024:.1f} MB)")
```

### Performance Monitoring Dashboard

```python
# Create performance monitoring dashboard
def create_performance_dashboard(optimizer):
    stats = optimizer.get_performance_stats()
    
    dashboard = {
        "timestamp": time.time(),
        "cache_effectiveness": {
            "hit_rate": stats['cache']['hit_rate'],
            "total_requests": stats['cache']['total_hits'] + stats['cache']['total_misses'],
            "memory_usage_mb": stats['cache'].get('memory_usage_mb', 0)
        },
        "system_resources": {
            "memory_usage_mb": stats['memory']['current_usage']['rss_mb'],
            "memory_percent": stats['memory']['current_usage']['percent'],
            "available_memory_mb": stats['memory']['current_usage']['available_mb']
        },
        "processing_performance": {
            "average_time_seconds": stats['processing']['average_time_seconds'],
            "total_analyses": stats['processing']['total_analyses'],
            "samples_per_second": stats.get('processing', {}).get('samples_per_second', 0)
        }
    }
    
    return dashboard
```

## Best Practices Summary

### For Development
1. **Enable Caching**: Reduces repeated computation during testing
2. **Use Memory Monitoring**: Track memory usage during development
3. **Profile Individual Algorithms**: Identify performance bottlenecks
4. **Test with Representative Data**: Use real-world file sizes and types

### For Production
1. **Optimize Configuration**: Use automated optimization tools
2. **Enable All Optimizations**: Caching, parallel processing, streaming
3. **Monitor Performance**: Track cache hit rates and processing times
4. **Set Resource Limits**: Memory thresholds and worker limits
5. **Regular Cache Cleanup**: Prevent disk cache from growing indefinitely

### For Specific Scenarios
- **Real-Time Processing**: Disable streaming, enable caching, limit parallelism
- **Batch Processing**: Enable all optimizations, large caches, multiple workers
- **Memory-Constrained**: Enable streaming, small chunks, limited parallelism
- **High-Throughput**: Large caches, maximum parallelism, performance monitoring

The performance optimization system provides enterprise-grade scalability while maintaining detection accuracy. Proper configuration can achieve 3-10x performance improvements depending on hardware and workload characteristics.
