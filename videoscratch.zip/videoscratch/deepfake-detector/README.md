# Deepfake Detector (CPU-only, optional extras)

This module provides a CPU-friendly deepfake analysis pipeline that fuses multiple forensic signals:
- Frequency-domain artifacts
- Physiological rPPG pulse coherence
- Audio–visual lip-sync consistency
- Temporal/geometric consistency (Haar-based; optionally MediaPipe landmarks)
- Optional CNN detector via ONNX Runtime (CPU)

Pretrained models (when used) will be downloaded to the repository root `models/` directory.

## Quick start (Python 3.13 CPU baseline)

```bash
cd /deepfake-detector
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
PYTHONPATH=src python -m deepfake_detector.detect --input /path/to/video.mp4 --json report.json --overlay-out overlay.mp4
```

Notes:
- CPU-only. No CUDA required.
- Uses OpenCV Haar cascades by default. MediaPipe support is optional (see below).
- `ffmpeg` must be available on your system PATH for audio extraction.

## Optional: Python 3.12 venv for MediaPipe landmarks

MediaPipe wheels may not be available for Python 3.13 on macOS arm64. To enable landmark-based cues:

```bash
# Ensure python3.12 is available
python3.12 -m venv venv312
source venv312/bin/activate
pip install --upgrade pip
pip install -r requirements.txt mediapipe
PYTHONPATH=src python -m deepfake_detector.detect --input /path/to/video.mp4 --json report.json --overlay-out overlay.mp4
```

The detector will auto-use MediaPipe if import succeeds; otherwise it falls back to Haar.

## Optional: CNN detector (ONNX Runtime)

Install ONNX Runtime CPU and provide a model URL (or place an ONNX model in `models/` as `xception_deepfake.onnx`):

```bash
pip install onnxruntime
PYTHONPATH=src python -m deepfake_detector.detect --input /path/to/video.mp4 \
  --cnn-model-url https://example.com/xception_deepfake.onnx --json report.json
```

Disable CNN:

```bash
PYTHONPATH=src python -m deepfake_detector.detect --input ... --no-cnn
```

## CLI

```bash
PYTHONPATH=src python -m deepfake_detector.detect --input INPUT [--json OUT.json] [--target-fps 15] \
  [--max-frames N] [--overlay-out overlay.mp4] [--no-cnn] [--cnn-model-url URL]
```

## Disclaimer
This is a research/forensics helper; treat outputs as probabilistic signals.

# What’s still pending to call it “complete”:
Unit tests and basic benchmarks
Fusion calibration (tuning weights/thresholds)
CNN model weights (you need to supply an ONNX URL or file)
Real C2PA verification (current check is a minimal metadata hint)
MediaPipe features require a Python 3.12 venv
