# Temporal Face Tracking Guide

The deepfake detector includes advanced temporal face tracking capabilities that provide consistent face detection across video sequences, improved accuracy through motion prediction, and enhanced stability for analysis algorithms.

## Quick Start

### Enable Temporal Tracking
```python
from deepfake_detector.face import detect_face_track

# Temporal tracking is enabled by default
track = detect_face_track(video_frames, use_temporal_tracking=True)

# With timestamps for better motion prediction
track = detect_face_track(video_frames, frame_timestamps=timestamps)
```

### CLI Tools
```bash
# Analyze tracking performance
python -m deepfake_detector.tracking_cli analyze --video video.mp4 --output analysis.json

# Create tracking visualization
python -m deepfake_detector.tracking_cli visualize --video video.mp4 --output tracking_vis.mp4

# Compare tracking configurations
python -m deepfake_detector.tracking_cli compare --video video.mp4 --output comparison.json
```

## Temporal Tracking Architecture

### Core Components

1. **Kalman Filtering**: Predictive motion modeling for smooth tracking
2. **Identity Association**: Robust face matching across frames
3. **Motion Analysis**: Velocity and acceleration tracking
4. **Quality Assessment**: Confidence and stability metrics
5. **Gap Interpolation**: Intelligent filling of missing detections

### System Overview

```python
from deepfake_detector.temporal_tracking import (
    TemporalFaceTracker,    # Main tracking engine
    TrackedFace,            # Individual face track
    KalmanState,            # Motion prediction
    MotionVector           # Movement analysis
)
```

## Motion Prediction with Kalman Filtering

### Kalman Filter Implementation

The system uses a constant velocity motion model:

```python
# State vector: [x, y, dx, dy] (position and velocity)
kalman = KalmanState()

# Predict next position
x, y = kalman.predict(time_delta)

# Update with measurement
kalman.update(observed_x, observed_y, timestamp)

# Get velocity estimate
dx, dy = kalman.get_velocity()
```

### Motion Vector Analysis

```python
# Create motion vector from displacement
motion = MotionVector.from_displacement(dx, dy, confidence)

print(f"Motion: {motion.magnitude:.2f} pixels at {motion.angle:.2f} radians")
print(f"Direction: ({motion.dx:.1f}, {motion.dy:.1f})")
```

### Prediction Accuracy

The Kalman filter provides:
- **Position Prediction**: Next frame face location
- **Velocity Estimation**: Speed and direction of movement
- **Uncertainty Quantification**: Confidence bounds on predictions
- **Adaptive Learning**: Improves accuracy over time

## Face Identity Tracking

### Multi-Face Association

```python
tracker = TemporalFaceTracker(
    max_missing_frames=10,      # Track persistence
    min_track_length=5,         # Minimum valid track
    iou_threshold=0.5,          # Face matching sensitivity
    max_tracks=5                # Maximum simultaneous faces
)

# Track faces across video
tracked_faces = tracker.track_faces_in_video(frames, timestamps)
```

### Association Algorithm

The system uses multiple criteria for face association:

1. **Intersection over Union (IoU)**: Bounding box overlap
2. **Position Prediction**: Kalman filter predictions
3. **Motion Consistency**: Velocity and direction matching
4. **Appearance Similarity**: Feature-based matching (future enhancement)

### Track Management

```python
# Get best quality track
best_track = tracker.get_best_track()

# Create enhanced face track with gap filling
enhanced_track = tracker.create_enhanced_face_track(fill_gaps=True)

print(f"Track quality: {best_track.get_tracking_confidence():.3f}")
print(f"Stability score: {best_track.stability_score:.3f}")
```

## Quality Metrics and Assessment

### Individual Track Quality

```python
tracked_face = TrackedFace(track_id=1)

# Quality components
print(f"Average confidence: {tracked_face.average_confidence:.3f}")
print(f"Stability score: {tracked_face.stability_score:.3f}")
print(f"Motion consistency: {tracked_face.motion_consistency:.3f}")

# Overall tracking confidence
confidence = tracked_face.get_tracking_confidence()
```

### Quality Factors

1. **Detection Confidence**: Average face detection confidence
2. **Stability Score**: Inverse of position variance (steady tracking)
3. **Motion Consistency**: Consistency of movement patterns
4. **Detection Ratio**: Successful detections vs. missed frames
5. **Recency Factor**: How recently the face was detected

### Track Statistics

```python
# Analyze tracking quality across all tracks
from deepfake_detector.temporal_tracking import analyze_face_tracking_quality

analysis = analyze_face_tracking_quality(tracked_faces)

print(f"Total tracks: {analysis['total_tracks']}")
print(f"Average track length: {analysis['track_statistics']['average_length']:.1f}")
print(f"Average confidence: {analysis['quality_metrics']['average_confidence']:.3f}")
print(f"Best track ID: {analysis['best_track']['track_id']}")
```

## Gap Interpolation and Filling

### Intelligent Frame Interpolation

When faces are missed in some frames, the system can interpolate:

```python
# Get interpolated frame for missing detection
interpolated_frame = tracked_face.get_interpolated_frame(
    target_frame_index=10,
    total_frames=100
)

if interpolated_frame:
    print(f"Interpolated position: {interpolated_frame.center_xy}")
    print(f"Reduced confidence: {interpolated_frame.confidence:.3f}")
```

### Interpolation Features

- **Position Interpolation**: Linear interpolation between known positions
- **Bounding Box Scaling**: Smooth size transitions
- **Confidence Reduction**: Lower confidence for interpolated frames
- **Landmark Exclusion**: No landmark interpolation (unreliable)

### Gap Filling Strategy

```python
# Create track with gap filling enabled
enhanced_track = tracker.create_enhanced_face_track(fill_gaps=True)

# Original vs. enhanced frame count
original_frames = len(best_track.frames)
enhanced_frames = len(enhanced_track.frames)

print(f"Filled {enhanced_frames - original_frames} gaps")
```

## Configuration and Tuning

### Temporal Tracking Parameters

```python
from deepfake_detector.config import DeepfakeDetectorConfig

config = DeepfakeDetectorConfig()

# Temporal tracking settings
config.algorithms.enable_temporal_tracking = True
config.algorithms.max_missing_frames = 10
config.algorithms.min_track_length = 5
config.algorithms.face_iou_threshold = 0.5
config.algorithms.max_simultaneous_tracks = 5
config.algorithms.enable_gap_filling = True
```

### Parameter Guidelines

| Parameter | Conservative | Balanced | Aggressive |
|-----------|-------------|----------|------------|
| `max_missing_frames` | 5 | 10 | 15 |
| `min_track_length` | 8 | 5 | 3 |
| `face_iou_threshold` | 0.7 | 0.5 | 0.3 |
| `max_simultaneous_tracks` | 3 | 5 | 8 |

### Use Case Optimization

**High Quality (Accuracy Focus)**:
```python
config.algorithms.max_missing_frames = 8
config.algorithms.min_track_length = 10
config.algorithms.face_iou_threshold = 0.6
```

**Real-Time (Speed Focus)**:
```python
config.algorithms.max_missing_frames = 5
config.algorithms.min_track_length = 3
config.algorithms.face_iou_threshold = 0.4
```

**Crowded Scenes (Multi-Face)**:
```python
config.algorithms.max_simultaneous_tracks = 10
config.algorithms.face_iou_threshold = 0.6
config.algorithms.max_missing_frames = 8
```

## Performance Analysis Tools

### CLI Analysis Commands

```bash
# Basic tracking analysis
python -m deepfake_detector.tracking_cli analyze \
    --video input.mp4 \
    --output analysis.json \
    --max-missing-frames 10 \
    --min-track-length 5

# Visualization with motion vectors
python -m deepfake_detector.tracking_cli visualize \
    --video input.mp4 \
    --output tracking_visualization.mp4 \
    --show-predictions \
    --show-motion-vectors

# Configuration comparison
python -m deepfake_detector.tracking_cli compare \
    --video input.mp4 \
    --output comparison.json \
    --configs tracking_configs.json
```

### Analysis Results

The analysis provides comprehensive metrics:

```json
{
  "performance": {
    "temporal_tracking_time": 2.34,
    "baseline_tracking_time": 3.12,
    "speedup_factor": 1.33,
    "frames_per_second": 12.8
  },
  "temporal_tracking_results": {
    "total_tracks": 2,
    "track_statistics": {
      "average_length": 45.5,
      "max_length": 67,
      "min_length": 24
    },
    "quality_metrics": {
      "average_confidence": 0.847,
      "average_stability": 0.923
    },
    "best_track": {
      "track_id": 1,
      "length": 67,
      "confidence": 0.891,
      "stability": 0.945
    }
  }
}
```

### Visualization Features

The visualization tool creates annotated videos showing:
- **Bounding Boxes**: Colored by track ID
- **Track IDs**: Persistent identity labels
- **Confidence Scores**: Detection confidence values
- **Motion Vectors**: Movement direction and magnitude
- **Predictions**: Estimated positions for missing frames
- **Frame Statistics**: Real-time tracking information

## Integration with Detection Pipeline

### Automatic Integration

Temporal tracking integrates seamlessly with the main detection pipeline:

```python
# Temporal tracking is enabled by default
report = analyze_video(video_path, config=config)

# Access tracking quality in the report
if hasattr(report, 'tracking_metadata'):
    print(f"Tracking confidence: {report.tracking_metadata['confidence']:.3f}")
    print(f"Track stability: {report.tracking_metadata['stability']:.3f}")
```

### Configuration-Driven Behavior

```python
# Enable/disable via configuration
config.algorithms.enable_temporal_tracking = True  # Default: enabled

# Fine-tune parameters
config.algorithms.max_missing_frames = 15  # More persistent tracking
config.algorithms.enable_gap_filling = True  # Fill detection gaps
```

### Fallback Behavior

The system gracefully handles failures:

1. **Temporal Tracking Failure**: Falls back to frame-by-frame detection
2. **No Faces Detected**: Returns None gracefully
3. **Single Frame Input**: Skips temporal tracking automatically
4. **Configuration Errors**: Uses sensible defaults

## Advanced Features

### Custom Tracking Configurations

```python
# Create custom tracker
tracker = TemporalFaceTracker(
    max_missing_frames=12,
    min_track_length=8,
    iou_threshold=0.55,
    max_tracks=3
)

# Manual tracking control
tracked_faces = tracker.track_faces_in_video(frames, timestamps)
best_track = tracker.get_best_track()
```

### Motion Analysis

```python
# Access motion history
for motion in tracked_face.motion_history:
    print(f"Motion: {motion.magnitude:.2f} px, angle: {motion.angle:.2f} rad")
    print(f"Confidence: {motion.confidence:.3f}")

# Analyze motion patterns
if len(tracked_face.motion_history) > 5:
    velocities = [m.magnitude for m in tracked_face.motion_history]
    print(f"Average speed: {np.mean(velocities):.2f} px/frame")
    print(f"Speed variance: {np.var(velocities):.2f}")
```

### Quality-Based Track Selection

```python
# Filter tracks by quality
high_quality_tracks = [
    track for track in tracked_faces 
    if track.get_tracking_confidence() > 0.8
]

# Select track by length and quality
best_track = max(tracked_faces, key=lambda t: (
    len(t.frames) * 0.4 + 
    t.get_tracking_confidence() * 0.6
))
```

## Performance Optimizations

### Memory Management

The temporal tracking system is designed for memory efficiency:

```python
# Automatic cleanup of old motion history
tracked_face.max_motion_history = 10  # Keep last 10 motion vectors

# Memory-efficient frame storage
# Only essential metadata is stored, not full image crops for interpolated frames
```

### Processing Speed

- **Parallel Detection**: Frame-by-frame detection can be parallelized
- **Efficient Association**: O(N²) association algorithm with early termination
- **Lazy Evaluation**: Interpolated frames created only when needed
- **Caching**: Motion predictions cached for reuse

### Scalability

```python
# Control memory usage for long videos
tracker = TemporalFaceTracker(
    max_tracks=3,           # Limit simultaneous tracks
    max_missing_frames=8,   # Reduce track persistence
    min_track_length=5      # Filter short tracks
)
```

## Troubleshooting

### Common Issues

1. **No Faces Tracked**
   ```python
   # Check if temporal tracking is enabled
   if not config.algorithms.enable_temporal_tracking:
       print("Temporal tracking is disabled")
   
   # Verify video has sufficient frames
   if len(frames) < config.algorithms.min_track_length:
       print("Video too short for temporal tracking")
   ```

2. **Poor Tracking Quality**
   ```bash
   # Analyze tracking parameters
   python -m deepfake_detector.tracking_cli analyze --video problematic.mp4 --output debug.json
   
   # Try different configurations
   python -m deepfake_detector.tracking_cli compare --video problematic.mp4 --output comparison.json
   ```

3. **Performance Issues**
   ```python
   # Reduce tracking complexity
   config.algorithms.max_simultaneous_tracks = 3
   config.algorithms.max_missing_frames = 5
   
   # Disable gap filling for speed
   config.algorithms.enable_gap_filling = False
   ```

### Debugging Tools

```python
# Enable detailed logging
configure_logging(log_level="DEBUG")

# Access detailed tracking metadata
analysis = analyze_face_tracking_quality(tracked_faces)
print(json.dumps(analysis, indent=2))

# Visualize tracking for debugging
python -m deepfake_detector.tracking_cli visualize \
    --video debug.mp4 \
    --output debug_vis.mp4 \
    --verbose
```

## Best Practices

### For Optimal Accuracy
1. **Use Appropriate Thresholds**: Start with default values and tune based on results
2. **Enable Gap Filling**: Improves temporal consistency
3. **Monitor Quality Metrics**: Track confidence and stability scores
4. **Validate on Representative Data**: Test on videos similar to your use case

### For Performance
1. **Limit Simultaneous Tracks**: Reduce `max_simultaneous_tracks` for speed
2. **Optimize Missing Frame Tolerance**: Balance persistence vs. computation
3. **Use Appropriate Minimum Length**: Filter out noise tracks
4. **Consider Disabling Gap Filling**: For real-time applications

### For Robustness
1. **Handle Edge Cases**: Very short videos, no faces, single frames
2. **Monitor Failure Modes**: Track fallback usage and failure rates
3. **Validate Configuration**: Ensure parameters are within reasonable ranges
4. **Test Diverse Content**: Various lighting, angles, and movement patterns

The temporal tracking system significantly improves face detection consistency and provides the foundation for more accurate deepfake analysis by ensuring stable face identification across video sequences.
