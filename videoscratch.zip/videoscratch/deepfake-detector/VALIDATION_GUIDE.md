# Deepfake Detector Validation Guide

The deepfake detector includes a comprehensive validation framework for evaluating detection accuracy against known datasets. This guide covers everything from dataset preparation to advanced evaluation techniques.

## Quick Start

### Simple Validation on CSV Dataset
```bash
# Basic validation
python -m deepfake_detector.validate_cli --csv dataset.csv --output results.json

# With custom configuration
python -m deepfake_detector.validate_cli --csv dataset.csv --config production.json --output results.json
```

### Validation on Directory Structure
```bash
# Validate using directory structure (real/ and fake/ folders)
python -m deepfake_detector.validate_cli --real-dir real_videos/ --fake-dir fake_videos/ --output results.json
```

### Quick File Validation
```bash
# Quick validation on specific files
python -m deepfake_detector.validate_cli --quick real1.mp4:0 fake1.mp4:1 fake2.mp4:1 --output results.json
```

## Validation Framework Architecture

### Core Components

1. **ValidationDataset**: Dataset management with flexible loading options
2. **ValidationFramework**: Main validation engine with parallel processing
3. **ValidationMetrics**: Comprehensive accuracy and performance metrics
4. **Cross-Validation**: Statistical validation with k-fold support
5. **CLI Tool**: Command-line interface for batch processing

### Supported Dataset Formats

#### 1. CSV Format
```csv
file_path,label,quality,source
real_samples/video1.mp4,0,high,interview
fake_samples/video1.mp4,1,medium,deepfake
```

**Supported Label Formats:**
- **Binary**: `0` (real), `1` (fake)
- **String**: `"real"`, `"fake"`, `"deepfake"`
- **Probability**: Continuous values in `[0,1]` range

#### 2. Directory Structure
```
dataset/
├── real/
│   ├── video1.mp4
│   ├── video2.avi
│   └── ...
└── fake/
    ├── deepfake1.mp4
    ├── deepfake2.mov
    └── ...
```

#### 3. Programmatic Loading
```python
from deepfake_detector.validation import ValidationDataset

dataset = ValidationDataset("my_dataset")
dataset.add_sample(Path("real.mp4"), 0.0, {"quality": "high"})
dataset.add_sample(Path("fake.mp4"), 1.0, {"method": "faceswap"})
```

## Comprehensive Metrics

### Accuracy Metrics
- **Accuracy**: Overall classification accuracy
- **Balanced Accuracy**: Accounts for class imbalance
- **Precision**: True positives / (True positives + False positives)
- **Recall (Sensitivity)**: True positives / (True positives + False negatives)
- **Specificity**: True negatives / (True negatives + False positives)
- **F1-Score**: Harmonic mean of precision and recall
- **Matthews Correlation Coefficient**: Correlation between predictions and truth

### Threshold Analysis
- **Optimal Threshold**: Threshold maximizing Youden's J statistic
- **ROC AUC**: Area under Receiver Operating Characteristic curve
- **PR AUC**: Area under Precision-Recall curve
- **Confusion Matrix**: Detailed breakdown of classification results

### Performance Metrics
- **Processing Speed**: Samples per second
- **Success Rate**: Fraction of samples processed successfully
- **Error Analysis**: Breakdown of failure types
- **Algorithm Contributions**: Individual algorithm performance analysis

## Command-Line Interface

### Basic Usage
```bash
python -m deepfake_detector.validate_cli [OPTIONS]
```

### Dataset Input Options
| Option | Description | Example |
|--------|-------------|---------|
| `--csv FILE` | CSV file with paths and labels | `--csv dataset.csv` |
| `--real-dir DIR` | Directory with real samples | `--real-dir real/` |
| `--fake-dir DIR` | Directory with fake samples | `--fake-dir fake/` |
| `--quick FILES` | Quick validation on specific files | `--quick file1:0 file2:1` |

### CSV Configuration
| Option | Description | Default |
|--------|-------------|---------|
| `--file-column NAME` | Column name for file paths | `file_path` |
| `--label-column NAME` | Column name for labels | `label` |
| `--label-format FORMAT` | Label format (binary/string/probability) | `binary` |
| `--root-path PATH` | Root path for relative file paths | None |

### Validation Options
| Option | Description | Default |
|--------|-------------|---------|
| `--config FILE` | Configuration file | None |
| `--profile NAME` | Configuration profile | None |
| `--cross-validate K` | K-fold cross-validation | None |
| `--split-test RATIO` | Fraction of dataset for testing | 1.0 |
| `--max-workers N` | Parallel workers | 4 |
| `--timeout SECONDS` | Timeout per sample | 60.0 |

### Output Options
| Option | Description | Default |
|--------|-------------|---------|
| `--output FILE` | JSON output file | Required |
| `--save-individual` | Save individual results | False |
| `--results-dir DIR` | Directory for individual results | None |
| `--verbose` | Verbose output | False |

## Advanced Validation Techniques

### Cross-Validation
```bash
# 5-fold cross-validation
python -m deepfake_detector.validate_cli \
    --csv dataset.csv \
    --cross-validate 5 \
    --output cv_results.json
```

**Benefits:**
- **Robust Accuracy Estimates**: Reduces variance in accuracy measurements
- **Statistical Significance**: Provides confidence intervals
- **Overfitting Detection**: Identifies if model generalizes well
- **Dataset Size Efficiency**: Uses entire dataset for both training and testing

### Stratified Validation
```bash
# Use 20% of dataset for testing (stratified)
python -m deepfake_detector.validate_cli \
    --csv dataset.csv \
    --split-test 0.2 \
    --random-seed 42 \
    --output stratified_results.json
```

### Performance Benchmarking
```bash
# High-performance validation with detailed logging
python -m deepfake_detector.validate_cli \
    --csv large_dataset.csv \
    --max-workers 8 \
    --timeout 30 \
    --save-individual \
    --results-dir detailed_results/ \
    --log-dir validation_logs/ \
    --output benchmark.json
```

## Programmatic Usage

### Basic Validation
```python
from deepfake_detector.validation import ValidationFramework, create_validation_dataset

# Load dataset
dataset = create_validation_dataset("test", csv_path="dataset.csv")

# Create framework
framework = ValidationFramework()

# Validate
metrics = framework.validate_dataset(dataset)
print(f"Accuracy: {metrics.accuracy:.3f}")
```

### Advanced Configuration
```python
from deepfake_detector.config import load_config
from deepfake_detector.validation import ValidationFramework

# Load configuration
config = load_config("production.json")

# Create framework with configuration
framework = ValidationFramework(config)

# Validate with custom settings
metrics = framework.validate_dataset(
    dataset,
    max_workers=8,
    timeout_per_sample=30.0,
    save_individual_results=True,
    results_dir=Path("results/")
)
```

### Cross-Validation
```python
# Perform 5-fold cross-validation
cv_results = framework.cross_validate(dataset, k_folds=5)

print(f"CV Accuracy: {cv_results['metrics']['accuracy_mean']:.3f} ± "
      f"{cv_results['metrics']['accuracy_std']:.3f}")
```

### Dataset Management
```python
# Load and filter dataset
dataset = create_validation_dataset("full", csv_path="dataset.csv")

# Filter for high-quality samples only
high_quality = dataset.filter_samples(
    lambda s: s.metadata.get("quality") == "high"
)

# Split dataset
train, val, test = dataset.split_dataset(
    train_ratio=0.7, val_ratio=0.15, test_ratio=0.15, stratify=True
)
```

## Validation Results Analysis

### JSON Output Structure
```json
{
  "validation_type": "single_run",
  "dataset_name": "test_dataset",
  "dataset_statistics": {
    "total_samples": 1000,
    "real_samples": 500,
    "fake_samples": 500,
    "class_balance": 0.5
  },
  "validation_metrics": {
    "accuracy": 0.924,
    "precision": 0.918,
    "recall": 0.931,
    "f1_score": 0.924,
    "auc_roc": 0.967,
    "auc_pr": 0.963,
    "optimal_threshold": 0.52,
    "confusion_matrix": {
      "true_positives": 466,
      "true_negatives": 458,
      "false_positives": 42,
      "false_negatives": 34
    },
    "algorithm_contributions": {
      "cnn": 0.891,
      "frequency": 0.756,
      "geometry": 0.734,
      "rppg": 0.698,
      "av": 0.634
    }
  }
}
```

### Interpreting Results

#### Accuracy Metrics
- **Accuracy > 0.9**: Excellent performance
- **Accuracy 0.8-0.9**: Good performance
- **Accuracy 0.7-0.8**: Acceptable performance
- **Accuracy < 0.7**: Poor performance, needs improvement

#### AUC Metrics
- **AUC > 0.95**: Excellent discrimination
- **AUC 0.9-0.95**: Very good discrimination
- **AUC 0.8-0.9**: Good discrimination
- **AUC 0.7-0.8**: Acceptable discrimination
- **AUC < 0.7**: Poor discrimination

#### Algorithm Contributions
Individual algorithm AUC scores show which detection methods work best:
- **CNN**: Deep learning features
- **Frequency**: Compression artifacts
- **Geometry**: Facial landmark consistency
- **rPPG**: Remote pulse detection
- **Audio-Visual**: Lip-sync analysis

## Dataset Preparation Best Practices

### Data Quality Guidelines

1. **Balanced Classes**: Aim for 50/50 real/fake split
2. **Diverse Sources**: Include multiple generation methods for fakes
3. **Quality Variation**: Mix of high/medium/low quality samples
4. **Temporal Diversity**: Various video lengths and frame rates
5. **Demographic Diversity**: Multiple ages, genders, ethnicities

### Sample Dataset Structure
```csv
file_path,label,quality,generation_method,duration_sec,resolution
real/interview_01.mp4,0,high,original,120,1920x1080
fake/faceswap_01.mp4,1,medium,faceswap,120,1920x1080
fake/deepfakes_01.mp4,1,high,deepfakes,90,1280x720
real/news_clip_01.mp4,0,high,original,180,1920x1080
```

### Metadata Recommendations
- **quality**: `high`, `medium`, `low`
- **generation_method**: `faceswap`, `deepfakes`, `first_order_motion`, etc.
- **source**: `interview`, `news`, `social_media`, `presentation`
- **duration_sec**: Video length in seconds
- **resolution**: Video resolution (e.g., `1920x1080`)

## Performance Optimization

### Parallel Processing
```bash
# Use maximum CPU cores
python -m deepfake_detector.validate_cli \
    --csv dataset.csv \
    --max-workers $(nproc) \
    --output results.json
```

### Memory Management
```bash
# Reduce timeout for faster processing
python -m deepfake_detector.validate_cli \
    --csv dataset.csv \
    --timeout 30 \
    --max-workers 4 \
    --output results.json
```

### Batch Processing
```python
# Process large datasets in batches
def validate_large_dataset(dataset_path, batch_size=100):
    full_dataset = create_validation_dataset("full", csv_path=dataset_path)
    
    all_results = []
    for i in range(0, len(full_dataset.samples), batch_size):
        batch_samples = full_dataset.samples[i:i+batch_size]
        batch_dataset = ValidationDataset("batch")
        batch_dataset.samples = batch_samples
        
        metrics = framework.validate_dataset(batch_dataset)
        all_results.append(metrics)
    
    return all_results
```

## Troubleshooting

### Common Issues

1. **File Not Found Errors**
   ```bash
   # Ensure correct root path
   python -m deepfake_detector.validate_cli \
       --csv dataset.csv \
       --root-path /path/to/dataset/ \
       --output results.json
   ```

2. **Timeout Errors**
   ```bash
   # Increase timeout for slow samples
   python -m deepfake_detector.validate_cli \
       --csv dataset.csv \
       --timeout 120 \
       --output results.json
   ```

3. **Memory Issues**
   ```bash
   # Reduce parallel workers
   python -m deepfake_detector.validate_cli \
       --csv dataset.csv \
       --max-workers 2 \
       --output results.json
   ```

4. **CSV Format Issues**
   ```bash
   # Specify custom column names
   python -m deepfake_detector.validate_cli \
       --csv dataset.csv \
       --file-column "video_path" \
       --label-column "is_fake" \
       --label-format "string" \
       --output results.json
   ```

### Debug Mode
```bash
# Enable detailed logging
python -m deepfake_detector.validate_cli \
    --csv dataset.csv \
    --log-level DEBUG \
    --log-dir debug_logs/ \
    --verbose \
    --output results.json
```

## Integration with Existing Workflows

### CI/CD Integration
```bash
#!/bin/bash
# validation_test.sh

# Run validation on test dataset
python -m deepfake_detector.validate_cli \
    --csv test_dataset.csv \
    --config production.json \
    --output validation_results.json

# Check if accuracy is above threshold
ACCURACY=$(python -c "
import json
with open('validation_results.json') as f:
    data = json.load(f)
print(data['validation_metrics']['accuracy'])
")

if (( $(echo "$ACCURACY > 0.85" | bc -l) )); then
    echo "Validation passed: accuracy = $ACCURACY"
    exit 0
else
    echo "Validation failed: accuracy = $ACCURACY (threshold: 0.85)"
    exit 1
fi
```

### Automated Reporting
```python
import json
from pathlib import Path

def generate_validation_report(results_file):
    with open(results_file) as f:
        data = json.load(f)
    
    metrics = data['validation_metrics']
    
    report = f"""
# Validation Report
    
**Dataset**: {data['dataset_name']}
**Samples**: {data['dataset_statistics']['total_samples']}

## Results
- **Accuracy**: {metrics['accuracy']:.3f}
- **Precision**: {metrics['precision']:.3f}
- **Recall**: {metrics['recall']:.3f}
- **F1-Score**: {metrics['f1_score']:.3f}
- **AUC-ROC**: {metrics['auc_roc']:.3f}

## Algorithm Performance
"""
    
    if metrics.get('algorithm_contributions'):
        for alg, score in sorted(metrics['algorithm_contributions'].items(), 
                               key=lambda x: x[1], reverse=True):
            report += f"- **{alg}**: {score:.3f}\n"
    
    return report
```

## Best Practices Summary

### For Accurate Validation
1. **Use Balanced Datasets**: Equal real/fake samples
2. **Cross-Validate**: Use k-fold CV for robust estimates
3. **Stratify Splits**: Maintain class balance in train/test splits
4. **Set Random Seeds**: Ensure reproducible results
5. **Monitor All Metrics**: Don't rely on accuracy alone

### For Efficient Processing
1. **Optimize Workers**: Use appropriate number of parallel workers
2. **Set Reasonable Timeouts**: Balance speed vs. completion rate
3. **Process in Batches**: Handle large datasets efficiently
4. **Save Individual Results**: Enable debugging and analysis
5. **Use Configuration Profiles**: Optimize settings for your use case

### For Production Use
1. **Automate Validation**: Integrate into CI/CD pipelines
2. **Monitor Performance**: Track accuracy over time
3. **Version Datasets**: Maintain dataset versions and results
4. **Document Results**: Generate automated reports
5. **Set Quality Gates**: Define minimum accuracy thresholds

The validation framework provides enterprise-grade evaluation capabilities that ensure your deepfake detection system performs reliably across diverse datasets and deployment scenarios.
