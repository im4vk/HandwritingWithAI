#!/usr/bin/env python3
"""Test runner script for deepfake detector."""

import sys
import subprocess
from pathlib import Path


def run_tests(test_type: str = "all"):
    """Run tests with different configurations."""
    project_root = Path(__file__).parent
    
    # Ensure we're in the right directory
    import os
    os.chdir(project_root)
    
    # Add src to Python path
    env = os.environ.copy()
    pythonpath = str(project_root / "src")
    if "PYTHONPATH" in env:
        env["PYTHONPATH"] = f"{pythonpath}:{env['PYTHONPATH']}"
    else:
        env["PYTHONPATH"] = pythonpath
    
    base_cmd = ["python", "-m", "pytest"]
    
    if test_type == "unit":
        cmd = base_cmd + ["-m", "unit"]
    elif test_type == "integration":
        cmd = base_cmd + ["-m", "integration"]
    elif test_type == "fast":
        cmd = base_cmd + ["-m", "not slow"]
    elif test_type == "coverage":
        cmd = base_cmd + ["--cov-report=html", "--cov-report=term"]
    else:  # all tests
        cmd = base_cmd
    
    print(f"Running command: {' '.join(cmd)}")
    print(f"PYTHONPATH: {env.get('PYTHONPATH', 'Not set')}")
    
    try:
        result = subprocess.run(cmd, env=env, check=False)
        return result.returncode
    except FileNotFoundError:
        print("Error: pytest not found. Please install pytest: pip install pytest pytest-cov")
        return 1


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run deepfake detector tests")
    parser.add_argument(
        "--type", 
        choices=["all", "unit", "integration", "fast", "coverage"],
        default="all",
        help="Type of tests to run"
    )
    
    args = parser.parse_args()
    exit_code = run_tests(args.type)
    sys.exit(exit_code)
