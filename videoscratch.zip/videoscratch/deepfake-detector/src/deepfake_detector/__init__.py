__all__ = [
    "analyze_video",
]

__version__ = "0.1.0"

from .detect import analyze_video  # noqa: E402
