from .detect import main

if __name__ == "__main__":
    main()
