"""Advanced fusion algorithm with signal quality-based weighting.

This module provides enhanced score fusion techniques that adapt weights based on:
- Signal quality metrics
- Confidence estimation  
- Temporal consistency
- Cross-algorithm correlation
- Uncertainty quantification
"""

from __future__ import annotations

import logging
import math
from typing import Dict, Optional, List, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import numpy as np

from .exceptions import (
    InputValidationError,
    AnalysisError,
    validate_input,
    handle_processing_error,
)


class FusionMethod(Enum):
    """Enumeration of available fusion methods."""
    SIMPLE_WEIGHTED = "simple_weighted"
    QUALITY_ADAPTIVE = "quality_adaptive"
    CONFIDENCE_WEIGHTED = "confidence_weighted"
    TEMPORAL_CONSISTENCY = "temporal_consistency"
    BAYESIAN_FUSION = "bayesian_fusion"
    ENSEMBLE_VOTING = "ensemble_voting"


@dataclass
class SignalQuality:
    """Signal quality metrics for an algorithm."""
    snr: Optional[float] = None              # Signal-to-noise ratio
    confidence: Optional[float] = None        # Algorithm confidence [0,1]
    temporal_consistency: Optional[float] = None  # Temporal stability [0,1]
    data_completeness: Optional[float] = None     # Fraction of valid data [0,1]
    artifact_level: Optional[float] = None       # Detected artifacts [0,1]
    processing_quality: Optional[float] = None   # Processing success rate [0,1]
    
    def compute_overall_quality(self) -> float:
        """Compute overall quality score from available metrics."""
        metrics = []
        
        if self.confidence is not None:
            metrics.append(self.confidence)
        
        if self.temporal_consistency is not None:
            metrics.append(self.temporal_consistency)
        
        if self.data_completeness is not None:
            metrics.append(self.data_completeness)
        
        if self.artifact_level is not None:
            metrics.append(1.0 - self.artifact_level)  # Lower artifacts = higher quality
        
        if self.processing_quality is not None:
            metrics.append(self.processing_quality)
        
        if self.snr is not None:
            # Convert SNR to [0,1] range, assuming reasonable SNR range of [0, 30]
            snr_normalized = min(1.0, max(0.0, self.snr / 30.0))
            metrics.append(snr_normalized)
        
        if not metrics:
            return 1.0  # Default to full quality if no metrics available
        
        # Use weighted average with emphasis on confidence and completeness
        weights = []
        for i, metric in enumerate(metrics):
            if i < 2:  # First two metrics (confidence, consistency) get higher weight
                weights.append(1.5)
            else:
                weights.append(1.0)
        
        weighted_sum = sum(m * w for m, w in zip(metrics, weights))
        total_weight = sum(weights)
        
        return weighted_sum / total_weight


@dataclass
class AlgorithmResult:
    """Enhanced result structure for algorithm outputs."""
    score: float
    quality: SignalQuality
    metadata: Optional[Dict[str, Any]] = None
    
    def is_reliable(self, min_quality: float = 0.5) -> bool:
        """Check if result is reliable enough for fusion."""
        overall_quality = self.quality.compute_overall_quality()
        return (overall_quality >= min_quality and 
                0.0 <= self.score <= 1.0 and
                not (np.isnan(self.score) or np.isinf(self.score)))


class AdvancedFusion:
    """Advanced fusion engine with quality-adaptive weighting."""
    
    def __init__(self, 
                 base_weights: Optional[Dict[str, float]] = None,
                 fusion_method: FusionMethod = FusionMethod.QUALITY_ADAPTIVE,
                 min_quality_threshold: float = 0.3,
                 confidence_threshold: float = 0.5,
                 uncertainty_penalty: float = 0.2,
                 temporal_window: int = 5):
        """Initialize the advanced fusion engine.
        
        Args:
            base_weights: Base weights for each algorithm
            fusion_method: Fusion method to use
            min_quality_threshold: Minimum quality to include in fusion
            confidence_threshold: Confidence threshold for decisions
            uncertainty_penalty: Penalty for high uncertainty
            temporal_window: Window size for temporal analysis
        """
        self.logger = logging.getLogger(__name__)
        
        # Default base weights
        self.base_weights = base_weights or {
            "freq": 1.0,
            "rppg": 1.0,
            "av": 1.0,
            "geom": 1.0,
            "cnn": 1.2,  # Slightly higher weight for CNN
        }
        
        self.fusion_method = fusion_method
        self.min_quality_threshold = min_quality_threshold
        self.confidence_threshold = confidence_threshold
        self.uncertainty_penalty = uncertainty_penalty
        self.temporal_window = temporal_window
        
        # History for temporal analysis
        self.score_history: List[Dict[str, AlgorithmResult]] = []
        self.weight_history: List[Dict[str, float]] = []
        
        self.logger.info(f"Initialized AdvancedFusion with method: {fusion_method.value}")
    
    def fuse_scores(self, results: Dict[str, AlgorithmResult]) -> Tuple[float, Dict[str, Any]]:
        """Fuse algorithm results with quality-adaptive weighting.
        
        Args:
            results: Dictionary of algorithm results with quality metrics
            
        Returns:
            Tuple of (final_probability, fusion_metadata)
            
        Raises:
            InputValidationError: If input is invalid
            AnalysisError: If fusion fails
        """
        try:
            validate_input(results, "results", dict)
            
            if not results:
                raise InputValidationError("No results provided for fusion")
            
            # Filter reliable results
            reliable_results = self._filter_reliable_results(results)
            
            if not reliable_results:
                self.logger.warning("No reliable results for fusion, returning neutral probability")
                return 0.5, {"reliable_algorithms": [], "quality_filtered": True}
            
            # Apply fusion method
            if self.fusion_method == FusionMethod.SIMPLE_WEIGHTED:
                prob, metadata = self._simple_weighted_fusion(reliable_results)
            elif self.fusion_method == FusionMethod.QUALITY_ADAPTIVE:
                prob, metadata = self._quality_adaptive_fusion(reliable_results)
            elif self.fusion_method == FusionMethod.CONFIDENCE_WEIGHTED:
                prob, metadata = self._confidence_weighted_fusion(reliable_results)
            elif self.fusion_method == FusionMethod.TEMPORAL_CONSISTENCY:
                prob, metadata = self._temporal_consistency_fusion(reliable_results)
            elif self.fusion_method == FusionMethod.BAYESIAN_FUSION:
                prob, metadata = self._bayesian_fusion(reliable_results)
            elif self.fusion_method == FusionMethod.ENSEMBLE_VOTING:
                prob, metadata = self._ensemble_voting_fusion(reliable_results)
            else:
                raise InputValidationError(f"Unsupported fusion method: {self.fusion_method}")
            
            # Update history
            self.score_history.append(results)
            if len(self.score_history) > self.temporal_window:
                self.score_history.pop(0)
            
            # Validate result
            if not (0.0 <= prob <= 1.0):
                raise AnalysisError(f"Fusion produced invalid probability: {prob}")
            
            # Add global metadata
            metadata.update({
                "fusion_method": self.fusion_method.value,
                "algorithms_used": list(reliable_results.keys()),
                "total_algorithms": len(results),
                "reliability_rate": len(reliable_results) / len(results)
            })
            
            self.logger.info(f"Advanced fusion complete: {prob:.4f} using {len(reliable_results)}/{len(results)} algorithms")
            
            return float(prob), metadata
            
        except (InputValidationError, AnalysisError):
            raise
        except Exception as e:
            raise handle_processing_error("advanced score fusion", e)
    
    def _filter_reliable_results(self, results: Dict[str, AlgorithmResult]) -> Dict[str, AlgorithmResult]:
        """Filter results based on reliability criteria."""
        reliable = {}
        
        for name, result in results.items():
            if result.is_reliable(self.min_quality_threshold):
                reliable[name] = result
                self.logger.debug(f"Algorithm {name} passed reliability check (quality: {result.quality.compute_overall_quality():.3f})")
            else:
                self.logger.warning(f"Algorithm {name} failed reliability check (quality: {result.quality.compute_overall_quality():.3f})")
        
        return reliable
    
    def _simple_weighted_fusion(self, results: Dict[str, AlgorithmResult]) -> Tuple[float, Dict[str, Any]]:
        """Simple weighted average fusion."""
        total_weight = 0.0
        weighted_sum = 0.0
        weights_used = {}
        
        for name, result in results.items():
            weight = self.base_weights.get(name, 1.0)
            weighted_sum += weight * result.score
            total_weight += weight
            weights_used[name] = weight
        
        if total_weight == 0:
            return 0.5, {"weights": weights_used, "method": "simple_weighted"}
        
        prob = weighted_sum / total_weight
        
        return prob, {
            "weights": weights_used,
            "method": "simple_weighted",
            "total_weight": total_weight
        }
    
    def _quality_adaptive_fusion(self, results: Dict[str, AlgorithmResult]) -> Tuple[float, Dict[str, Any]]:
        """Quality-adaptive weighted fusion."""
        total_weight = 0.0
        weighted_sum = 0.0
        adaptive_weights = {}
        quality_scores = {}
        
        for name, result in results.items():
            base_weight = self.base_weights.get(name, 1.0)
            quality_score = result.quality.compute_overall_quality()
            
            # Adaptive weight combines base weight with quality score
            adaptive_weight = base_weight * (0.3 + 0.7 * quality_score)  # Quality influences 70% of weight
            
            weighted_sum += adaptive_weight * result.score
            total_weight += adaptive_weight
            
            adaptive_weights[name] = adaptive_weight
            quality_scores[name] = quality_score
            
            self.logger.debug(f"Algorithm {name}: base_weight={base_weight:.3f}, quality={quality_score:.3f}, adaptive_weight={adaptive_weight:.3f}")
        
        if total_weight == 0:
            return 0.5, {"adaptive_weights": adaptive_weights, "quality_scores": quality_scores}
        
        prob = weighted_sum / total_weight
        
        return prob, {
            "adaptive_weights": adaptive_weights,
            "quality_scores": quality_scores,
            "method": "quality_adaptive",
            "total_weight": total_weight,
            "quality_boost": max(quality_scores.values()) if quality_scores else 0.0
        }
    
    def _confidence_weighted_fusion(self, results: Dict[str, AlgorithmResult]) -> Tuple[float, Dict[str, Any]]:
        """Confidence-weighted fusion with uncertainty penalties."""
        total_weight = 0.0
        weighted_sum = 0.0
        confidence_weights = {}
        uncertainties = {}
        
        for name, result in results.items():
            base_weight = self.base_weights.get(name, 1.0)
            confidence = result.quality.confidence or 0.5
            
            # Calculate uncertainty penalty
            uncertainty = 1.0 - confidence
            uncertainty_penalty = self.uncertainty_penalty * uncertainty
            
            # Weight is base weight boosted by confidence, reduced by uncertainty
            confidence_weight = base_weight * confidence * (1.0 - uncertainty_penalty)
            
            weighted_sum += confidence_weight * result.score
            total_weight += confidence_weight
            
            confidence_weights[name] = confidence_weight
            uncertainties[name] = uncertainty
            
            self.logger.debug(f"Algorithm {name}: confidence={confidence:.3f}, uncertainty_penalty={uncertainty_penalty:.3f}, final_weight={confidence_weight:.3f}")
        
        if total_weight == 0:
            return 0.5, {"confidence_weights": confidence_weights, "uncertainties": uncertainties}
        
        prob = weighted_sum / total_weight
        
        # Apply global uncertainty adjustment
        avg_uncertainty = np.mean(list(uncertainties.values())) if uncertainties else 0.0
        uncertainty_adjustment = 0.5 * avg_uncertainty  # Pull toward neutral for high uncertainty
        prob = prob * (1.0 - uncertainty_adjustment) + 0.5 * uncertainty_adjustment
        
        return prob, {
            "confidence_weights": confidence_weights,
            "uncertainties": uncertainties,
            "method": "confidence_weighted",
            "avg_uncertainty": avg_uncertainty,
            "uncertainty_adjustment": uncertainty_adjustment
        }
    
    def _temporal_consistency_fusion(self, results: Dict[str, AlgorithmResult]) -> Tuple[float, Dict[str, Any]]:
        """Temporal consistency-aware fusion."""
        if not self.score_history:
            # Fall back to quality adaptive for first frame
            return self._quality_adaptive_fusion(results)
        
        total_weight = 0.0
        weighted_sum = 0.0
        temporal_weights = {}
        consistency_scores = {}
        
        for name, result in results.items():
            base_weight = self.base_weights.get(name, 1.0)
            
            # Calculate temporal consistency
            consistency = self._calculate_temporal_consistency(name, result.score)
            quality_score = result.quality.compute_overall_quality()
            
            # Weight combines base weight, quality, and temporal consistency
            temporal_weight = base_weight * (0.4 * quality_score + 0.6 * consistency)
            
            weighted_sum += temporal_weight * result.score
            total_weight += temporal_weight
            
            temporal_weights[name] = temporal_weight
            consistency_scores[name] = consistency
        
        if total_weight == 0:
            return 0.5, {"temporal_weights": temporal_weights, "consistency_scores": consistency_scores}
        
        prob = weighted_sum / total_weight
        
        return prob, {
            "temporal_weights": temporal_weights,
            "consistency_scores": consistency_scores,
            "method": "temporal_consistency",
            "history_length": len(self.score_history)
        }
    
    def _bayesian_fusion(self, results: Dict[str, AlgorithmResult]) -> Tuple[float, Dict[str, Any]]:
        """Bayesian fusion with prior and likelihood estimation."""
        # Prior probability (can be learned from data)
        prior_fake = 0.5  # Neutral prior
        
        # For Bayesian fusion, we need to estimate likelihoods
        log_odds = math.log(prior_fake / (1.0 - prior_fake))
        
        likelihood_ratios = {}
        
        for name, result in results.items():
            score = result.score
            quality = result.quality.compute_overall_quality()
            
            # Estimate likelihood ratio based on score and quality
            # High quality algorithms have more extreme likelihood ratios
            if score > 0.5:
                # Evidence for fake
                likelihood_ratio = (score / (1.0 - score)) * (1.0 + quality)
            else:
                # Evidence for real  
                likelihood_ratio = ((1.0 - score) / score) * (1.0 + quality)
                likelihood_ratio = 1.0 / likelihood_ratio
            
            # Weight by base algorithm weight
            weight = self.base_weights.get(name, 1.0)
            log_likelihood_ratio = math.log(likelihood_ratio)
            
            log_odds += weight * log_likelihood_ratio
            likelihood_ratios[name] = likelihood_ratio
            
            self.logger.debug(f"Algorithm {name}: score={score:.3f}, quality={quality:.3f}, LR={likelihood_ratio:.3f}")
        
        # Convert back to probability
        odds = math.exp(log_odds)
        prob = odds / (1.0 + odds)
        
        return prob, {
            "likelihood_ratios": likelihood_ratios,
            "method": "bayesian_fusion",
            "log_odds": log_odds,
            "prior": prior_fake
        }
    
    def _ensemble_voting_fusion(self, results: Dict[str, AlgorithmResult]) -> Tuple[float, Dict[str, Any]]:
        """Ensemble voting with quality-weighted votes."""
        votes_fake = 0.0
        votes_real = 0.0
        total_weight = 0.0
        votes_detail = {}
        
        for name, result in results.items():
            score = result.score
            quality = result.quality.compute_overall_quality()
            base_weight = self.base_weights.get(name, 1.0)
            
            # Vote weight combines base weight and quality
            vote_weight = base_weight * quality
            
            # Convert score to vote (with soft voting based on confidence)
            if score > 0.5:
                fake_vote = (score - 0.5) * 2.0  # Scale to [0,1]
                real_vote = 1.0 - fake_vote
            else:
                real_vote = (0.5 - score) * 2.0  # Scale to [0,1]
                fake_vote = 1.0 - real_vote
            
            votes_fake += vote_weight * fake_vote
            votes_real += vote_weight * real_vote
            total_weight += vote_weight
            
            votes_detail[name] = {
                "fake_vote": fake_vote,
                "real_vote": real_vote,
                "weight": vote_weight,
                "quality": quality
            }
        
        if total_weight == 0:
            return 0.5, {"votes": votes_detail, "method": "ensemble_voting"}
        
        # Normalize votes and convert to probability
        fake_ratio = votes_fake / total_weight
        real_ratio = votes_real / total_weight
        
        # Probability is the fake vote ratio
        prob = fake_ratio
        
        return prob, {
            "votes": votes_detail,
            "method": "ensemble_voting",
            "fake_votes": votes_fake,
            "real_votes": votes_real,
            "total_weight": total_weight,
            "vote_confidence": abs(fake_ratio - real_ratio)  # Confidence in the vote
        }
    
    def _calculate_temporal_consistency(self, algorithm_name: str, current_score: float) -> float:
        """Calculate temporal consistency for an algorithm."""
        if not self.score_history:
            return 1.0  # No history, assume consistent
        
        historical_scores = []
        for frame_results in self.score_history:
            if algorithm_name in frame_results:
                historical_scores.append(frame_results[algorithm_name].score)
        
        if len(historical_scores) < 2:
            return 1.0  # Not enough history
        
        # Calculate variance and convert to consistency score
        scores_array = np.array(historical_scores + [current_score])
        variance = np.var(scores_array)
        
        # Consistency is inversely related to variance
        # Map variance to [0,1] range where 0 variance = 1.0 consistency
        max_variance = 0.25  # Variance of uniform distribution over [0,1]
        consistency = max(0.0, 1.0 - (variance / max_variance))
        
        return consistency
    
    def get_algorithm_statistics(self) -> Dict[str, Dict[str, float]]:
        """Get statistics about algorithm performance over time."""
        if not self.score_history:
            return {}
        
        stats = {}
        
        for algorithm in self.base_weights.keys():
            scores = []
            qualities = []
            
            for frame_results in self.score_history:
                if algorithm in frame_results:
                    result = frame_results[algorithm]
                    scores.append(result.score)
                    qualities.append(result.quality.compute_overall_quality())
            
            if scores:
                stats[algorithm] = {
                    "mean_score": np.mean(scores),
                    "std_score": np.std(scores),
                    "mean_quality": np.mean(qualities),
                    "std_quality": np.std(qualities),
                    "consistency": 1.0 - (np.std(scores) / 0.5),  # Normalized consistency
                    "reliability": len(scores) / len(self.score_history)  # Fraction of frames processed
                }
        
        return stats
    
    def reset_history(self):
        """Reset temporal history."""
        self.score_history.clear()
        self.weight_history.clear()
        self.logger.info("Reset fusion history")


# Convenience functions for backward compatibility
def fuse_scores_advanced(results: Dict[str, AlgorithmResult], 
                        method: FusionMethod = FusionMethod.QUALITY_ADAPTIVE,
                        **kwargs) -> float:
    """Convenience function for advanced score fusion.
    
    Args:
        results: Dictionary of algorithm results
        method: Fusion method to use
        **kwargs: Additional parameters for fusion engine
        
    Returns:
        Final probability
    """
    fusion_engine = AdvancedFusion(fusion_method=method, **kwargs)
    prob, _ = fusion_engine.fuse_scores(results)
    return prob


def create_algorithm_result(score: float, 
                          confidence: Optional[float] = None,
                          temporal_consistency: Optional[float] = None,
                          data_completeness: Optional[float] = None,
                          **quality_kwargs) -> AlgorithmResult:
    """Convenience function to create AlgorithmResult.
    
    Args:
        score: Algorithm score [0,1]
        confidence: Algorithm confidence [0,1]
        temporal_consistency: Temporal consistency [0,1]
        data_completeness: Data completeness [0,1]
        **quality_kwargs: Additional quality metrics
        
    Returns:
        AlgorithmResult instance
    """
    quality = SignalQuality(
        confidence=confidence,
        temporal_consistency=temporal_consistency,
        data_completeness=data_completeness,
        **quality_kwargs
    )
    
    return AlgorithmResult(score=score, quality=quality)
