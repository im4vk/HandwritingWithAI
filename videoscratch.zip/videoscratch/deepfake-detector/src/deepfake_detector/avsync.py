from __future__ import annotations

from typing import List, Optional

import numpy as np


def av_sync_fake_score(
    mouth_open_series: Optional[List[float]],
    frame_timestamps_s: List[float],
    audio_mono: Optional[np.ndarray],
    audio_sr: Optional[int],
) -> float:
    """Heuristic deepfake-likelihood from audio–visual sync.

    If mouth series is unavailable, return 0.5 (uninformative).
    """
    if audio_mono is None or audio_sr is None or not mouth_open_series:
        return 0.5
    if len(mouth_open_series) < 10:
        return 0.5

    # Build video-time envelope from audio by simple RMS over windows at frame times
    t_frames = np.array(frame_timestamps_s, dtype=np.float32)
    if len(t_frames) != len(mouth_open_series):
        # Uniform fallback
        dt = 1.0 / 15.0
        t_frames = np.arange(len(mouth_open_series), dtype=np.float32) * dt

    # Sample audio RMS around each frame timestamp (window +/- 20 ms)
    win = int(0.02 * audio_sr)
    if win <= 0:
        return 0.5

    audio = audio_mono.astype(np.float32, copy=False)
    env = []
    for t in t_frames:
        center = int(t * audio_sr)
        a = max(0, center - win)
        b = min(len(audio), center + win)
        seg = audio[a:b]
        if len(seg) == 0:
            env.append(0.0)
        else:
            env.append(float(np.sqrt(np.mean(seg ** 2))))

    env = np.array(env, dtype=np.float32)
    mouth = np.array(mouth_open_series, dtype=np.float32)

    # Normalize
    env = (env - env.mean()) / (env.std() + 1e-6)
    mouth = (mouth - mouth.mean()) / (mouth.std() + 1e-6)

    corr = float(np.corrcoef(env, mouth)[0, 1])
    corr = abs(corr)

    # Map correlation to fake-likelihood
    fake = 1.0 - np.clip((corr - 0.2) / (0.8 - 0.2 + 1e-6), 0.0, 1.0)
    return float(fake)
