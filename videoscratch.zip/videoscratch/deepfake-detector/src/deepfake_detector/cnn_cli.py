"""Command-line interface for CNN model management and optimization."""

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

import numpy as np

from .enhanced_cnn import (
    EnhancedCNNDetector,
    ModelConfig,
    ModelArchitecture,
    ExecutionProvider,
    PrecisionMode,
    list_available_models,
    create_model_config,
    download_model
)
from .logging_config import configure_logging, get_logger


def list_models_command(args) -> None:
    """List available CNN models."""
    logger = get_logger(__name__)
    
    try:
        models_info = list_available_models()
        
        print("Available CNN Models:")
        print("=" * 50)
        
        for model_name, metadata in models_info["models"].items():
            print(f"\nModel: {model_name}")
            print(f"  Architecture: {metadata['architecture']}")
            print(f"  Input Size: {metadata['input_size']}")
            print(f"  Accuracy: {metadata['accuracy']:.3f}" if metadata['accuracy'] else "  Accuracy: N/A")
            print(f"  Speed: {metadata['speed_ms']:.1f}ms" if metadata['speed_ms'] else "  Speed: N/A")
            print(f"  Description: {metadata['description']}")
        
        print(f"\nTotal Models: {models_info['total_models']}")
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(models_info, f, indent=2, ensure_ascii=False)
            print(f"\nModel information saved to: {args.output}")
    
    except Exception as e:
        logger.error(f"Failed to list models: {e}")
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def download_model_command(args) -> None:
    """Download CNN models."""
    logger = get_logger(__name__)
    
    try:
        models_to_download = args.models if args.models else ["xception"]
        
        for model_name in models_to_download:
            print(f"Downloading model: {model_name}")
            
            model_path = download_model(
                model_name, 
                force_download=args.force
            )
            
            print(f"  Downloaded to: {model_path}")
            
            # Verify file size
            if model_path.exists():
                size_mb = model_path.stat().st_size / (1024 * 1024)
                print(f"  File size: {size_mb:.1f} MB")
            
        print(f"\nSuccessfully downloaded {len(models_to_download)} model(s)")
    
    except Exception as e:
        logger.error(f"Failed to download models: {e}")
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def benchmark_model_command(args) -> None:
    """Benchmark CNN model performance."""
    logger = get_logger(__name__)
    
    try:
        # Create model configuration
        config = create_model_config(
            args.model,
            batch_size=args.batch_size,
            num_threads=args.threads,
            execution_providers=[ExecutionProvider(args.provider)] if args.provider else [ExecutionProvider.CPU],
            precision_mode=PrecisionMode(args.precision) if args.precision else PrecisionMode.FP32
        )
        
        print(f"Benchmarking model: {args.model}")
        print(f"Configuration:")
        print(f"  Batch size: {config.batch_size}")
        print(f"  Threads: {config.num_threads}")
        print(f"  Provider: {config.execution_providers[0].value}")
        print(f"  Precision: {config.precision_mode.value}")
        
        # Initialize detector
        detector = EnhancedCNNDetector(config)
        
        if not detector.available():
            raise RuntimeError(f"Model {args.model} is not available")
        
        # Run benchmark
        print(f"\nRunning benchmark with {args.samples} samples...")
        
        benchmark_results = detector.benchmark(
            num_samples=args.samples,
            image_size=tuple(args.image_size) if args.image_size else (224, 224)
        )
        
        # Display results
        print("\nBenchmark Results:")
        print("=" * 50)
        
        summary = benchmark_results["summary"]
        print(f"Single Sample Latency: {summary['single_sample_latency_ms']:.2f} ms")
        print(f"Peak Throughput: {summary['peak_throughput']:.1f} samples/sec")
        print(f"Optimal Batch Size: {summary['optimal_batch_size']}")
        
        print("\nBatch Size Performance:")
        for batch_key, batch_result in benchmark_results["batch_results"].items():
            batch_size = batch_key.split("_")[-1]
            print(f"  Batch {batch_size:>2}: {batch_result['throughput_samples_per_second']:>6.1f} samples/sec, "
                  f"{batch_result['avg_time_seconds']*1000:>5.1f} ms avg")
        
        # Save results if requested
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(benchmark_results, f, indent=2, ensure_ascii=False)
            print(f"\nBenchmark results saved to: {args.output}")
    
    except Exception as e:
        logger.error(f"Benchmark failed: {e}")
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def test_model_command(args) -> None:
    """Test CNN model with sample images."""
    logger = get_logger(__name__)
    
    try:
        # Create model configuration
        config = create_model_config(
            args.model,
            batch_size=args.batch_size,
            execution_providers=[ExecutionProvider(args.provider)] if args.provider else [ExecutionProvider.CPU]
        )
        
        print(f"Testing model: {args.model}")
        
        # Initialize detector
        detector = EnhancedCNNDetector(config)
        
        if not detector.available():
            raise RuntimeError(f"Model {args.model} is not available")
        
        # Get model information
        model_info = detector.get_model_info()
        print(f"Model loaded successfully:")
        print(f"  Input shape: {model_info['primary_model']['input_shape']}")
        print(f"  Output shape: {model_info['primary_model']['output_shape']}")
        print(f"  Execution providers: {model_info['primary_model']['execution_providers']}")
        
        # Test with dummy images
        print(f"\nTesting with {args.samples} random images...")
        
        # Generate random test images
        test_images = []
        for i in range(args.samples):
            # Create random image with some structure
            img = np.random.randint(50, 200, (224, 224, 3), dtype=np.uint8)
            
            # Add some fake-like artifacts to half the images
            if i % 2 == 0:
                # Add compression artifacts simulation
                noise = np.random.normal(0, 10, img.shape).astype(np.int16)
                img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
            
            test_images.append(img)
        
        # Run predictions
        results = []
        for i, img in enumerate(test_images):
            result = detector.predict([img], return_detailed=True)
            results.append(result)
            
            print(f"  Image {i+1:2d}: P(fake)={result.probability:.3f}, "
                  f"confidence={result.confidence:.3f}, "
                  f"time={result.processing_time*1000:.1f}ms")
        
        # Summary statistics
        probabilities = [r.probability for r in results]
        confidences = [r.confidence for r in results]
        times = [r.processing_time for r in results]
        
        print(f"\nSummary Statistics:")
        print(f"  Average probability: {np.mean(probabilities):.3f} ± {np.std(probabilities):.3f}")
        print(f"  Average confidence: {np.mean(confidences):.3f} ± {np.std(confidences):.3f}")
        print(f"  Average time: {np.mean(times)*1000:.1f} ± {np.std(times)*1000:.1f} ms")
        print(f"  Total time: {sum(times):.3f} seconds")
        
        # Save results if requested
        if args.output:
            test_results = {
                "model": args.model,
                "configuration": {
                    "batch_size": args.batch_size,
                    "provider": args.provider or "cpu",
                    "samples": args.samples
                },
                "model_info": model_info,
                "predictions": [
                    {
                        "probability": r.probability,
                        "confidence": r.confidence,
                        "processing_time": r.processing_time
                    }
                    for r in results
                ],
                "statistics": {
                    "avg_probability": float(np.mean(probabilities)),
                    "std_probability": float(np.std(probabilities)),
                    "avg_confidence": float(np.mean(confidences)),
                    "std_confidence": float(np.std(confidences)),
                    "avg_time_ms": float(np.mean(times) * 1000),
                    "std_time_ms": float(np.std(times) * 1000),
                    "total_time_seconds": float(sum(times))
                }
            }
            
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(test_results, f, indent=2, ensure_ascii=False)
            print(f"\nTest results saved to: {args.output}")
    
    except Exception as e:
        logger.error(f"Model test failed: {e}")
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def compare_models_command(args) -> None:
    """Compare performance of multiple CNN models."""
    logger = get_logger(__name__)
    
    try:
        models_to_compare = args.models if args.models else ["xception", "efficientnet_b0"]
        
        print(f"Comparing models: {', '.join(models_to_compare)}")
        print(f"Test samples: {args.samples}")
        
        results = {}
        
        for model_name in models_to_compare:
            print(f"\nTesting {model_name}...")
            
            try:
                # Create configuration
                config = create_model_config(
                    model_name,
                    batch_size=args.batch_size,
                    execution_providers=[ExecutionProvider(args.provider)] if args.provider else [ExecutionProvider.CPU]
                )
                
                # Initialize detector
                detector = EnhancedCNNDetector(config)
                
                if not detector.available():
                    print(f"  Skipping {model_name}: not available")
                    continue
                
                # Run benchmark
                benchmark_results = detector.benchmark(
                    num_samples=min(args.samples, 50)  # Limit for comparison
                )
                
                # Get model info
                model_info = detector.get_model_info()
                
                results[model_name] = {
                    "benchmark": benchmark_results,
                    "model_info": model_info,
                    "available": True
                }
                
                # Display brief results
                summary = benchmark_results["summary"]
                print(f"  Latency: {summary['single_sample_latency_ms']:.1f} ms")
                print(f"  Throughput: {summary['peak_throughput']:.1f} samples/sec")
                
            except Exception as e:
                print(f"  Failed to test {model_name}: {e}")
                results[model_name] = {
                    "available": False,
                    "error": str(e)
                }
        
        # Generate comparison report
        print(f"\nComparison Results:")
        print("=" * 80)
        print(f"{'Model':<20} {'Latency (ms)':<15} {'Throughput (s/s)':<18} {'Status':<10}")
        print("-" * 80)
        
        for model_name, result in results.items():
            if result["available"]:
                summary = result["benchmark"]["summary"]
                latency = summary["single_sample_latency_ms"]
                throughput = summary["peak_throughput"]
                status = "Available"
            else:
                latency = "N/A"
                throughput = "N/A"
                status = "Failed"
            
            print(f"{model_name:<20} {str(latency):<15} {str(throughput):<18} {status:<10}")
        
        # Find best models
        available_results = {k: v for k, v in results.items() if v["available"]}
        
        if available_results:
            # Best latency
            best_latency = min(available_results.keys(), 
                             key=lambda k: available_results[k]["benchmark"]["summary"]["single_sample_latency_ms"])
            
            # Best throughput
            best_throughput = max(available_results.keys(),
                                key=lambda k: available_results[k]["benchmark"]["summary"]["peak_throughput"])
            
            print(f"\nRecommendations:")
            print(f"  Best Latency: {best_latency}")
            print(f"  Best Throughput: {best_throughput}")
        
        # Save results if requested
        if args.output:
            comparison_results = {
                "models_compared": models_to_compare,
                "test_configuration": {
                    "samples": args.samples,
                    "batch_size": args.batch_size,
                    "provider": args.provider or "cpu"
                },
                "results": results,
                "recommendations": {
                    "best_latency": best_latency if available_results else None,
                    "best_throughput": best_throughput if available_results else None
                } if available_results else {}
            }
            
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(comparison_results, f, indent=2, ensure_ascii=False)
            print(f"\nComparison results saved to: {args.output}")
    
    except Exception as e:
        logger.error(f"Model comparison failed: {e}")
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def validate_model_command(args) -> None:
    """Validate CNN model integrity and compatibility."""
    logger = get_logger(__name__)
    
    try:
        print(f"Validating model: {args.model}")
        
        # Create configuration
        config = create_model_config(args.model)
        
        validation_results = {
            "model": args.model,
            "validation_time": time.time(),
            "checks": {}
        }
        
        # Check 1: Model loading
        print("1. Testing model loading...")
        try:
            detector = EnhancedCNNDetector(config)
            validation_results["checks"]["loading"] = {
                "passed": detector.available(),
                "message": "Model loaded successfully" if detector.available() else "Failed to load model"
            }
            print(f"   ✓ Model loading: {'PASS' if detector.available() else 'FAIL'}")
        except Exception as e:
            validation_results["checks"]["loading"] = {
                "passed": False,
                "message": f"Loading error: {e}"
            }
            print(f"   ✗ Model loading: FAIL - {e}")
            
            if args.output:
                with open(args.output, 'w', encoding='utf-8') as f:
                    json.dump(validation_results, f, indent=2, ensure_ascii=False)
            return
        
        # Check 2: Model info extraction
        print("2. Testing model information extraction...")
        try:
            model_info = detector.get_model_info()
            input_shape = model_info["primary_model"]["input_shape"]
            output_shape = model_info["primary_model"]["output_shape"]
            
            validation_results["checks"]["model_info"] = {
                "passed": True,
                "message": f"Input: {input_shape}, Output: {output_shape}",
                "input_shape": input_shape,
                "output_shape": output_shape
            }
            print(f"   ✓ Model info: PASS")
            print(f"     Input shape: {input_shape}")
            print(f"     Output shape: {output_shape}")
        except Exception as e:
            validation_results["checks"]["model_info"] = {
                "passed": False,
                "message": f"Info extraction error: {e}"
            }
            print(f"   ✗ Model info: FAIL - {e}")
        
        # Check 3: Basic prediction
        print("3. Testing basic prediction...")
        try:
            test_image = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
            result = detector.predict([test_image], return_detailed=True)
            
            # Validate result
            valid_prob = 0.0 <= result.probability <= 1.0
            valid_conf = 0.0 <= result.confidence <= 1.0
            valid_time = result.processing_time > 0
            
            validation_results["checks"]["prediction"] = {
                "passed": valid_prob and valid_conf and valid_time,
                "message": f"Probability: {result.probability:.3f}, Confidence: {result.confidence:.3f}",
                "probability": result.probability,
                "confidence": result.confidence,
                "processing_time": result.processing_time
            }
            
            print(f"   ✓ Basic prediction: PASS")
            print(f"     Probability: {result.probability:.3f}")
            print(f"     Confidence: {result.confidence:.3f}")
            print(f"     Processing time: {result.processing_time*1000:.1f} ms")
        except Exception as e:
            validation_results["checks"]["prediction"] = {
                "passed": False,
                "message": f"Prediction error: {e}"
            }
            print(f"   ✗ Basic prediction: FAIL - {e}")
        
        # Check 4: Batch prediction
        print("4. Testing batch prediction...")
        try:
            test_images = [
                np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
                for _ in range(4)
            ]
            
            batch_result = detector.predict(test_images, return_detailed=True)
            
            validation_results["checks"]["batch_prediction"] = {
                "passed": True,
                "message": f"Batch size: {batch_result.batch_size}, Time: {batch_result.processing_time:.3f}s",
                "batch_size": batch_result.batch_size,
                "processing_time": batch_result.processing_time
            }
            
            print(f"   ✓ Batch prediction: PASS")
            print(f"     Batch size: {batch_result.batch_size}")
            print(f"     Processing time: {batch_result.processing_time*1000:.1f} ms")
        except Exception as e:
            validation_results["checks"]["batch_prediction"] = {
                "passed": False,
                "message": f"Batch prediction error: {e}"
            }
            print(f"   ✗ Batch prediction: FAIL - {e}")
        
        # Check 5: Performance consistency
        print("5. Testing performance consistency...")
        try:
            test_image = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
            times = []
            
            for _ in range(10):
                start_time = time.time()
                detector.predict([test_image])
                end_time = time.time()
                times.append(end_time - start_time)
            
            avg_time = np.mean(times)
            std_time = np.std(times)
            cv = std_time / avg_time if avg_time > 0 else float('inf')  # Coefficient of variation
            
            consistent = cv < 0.2  # Less than 20% variation
            
            validation_results["checks"]["consistency"] = {
                "passed": consistent,
                "message": f"Avg: {avg_time*1000:.1f}ms, CV: {cv:.3f}",
                "avg_time_ms": avg_time * 1000,
                "std_time_ms": std_time * 1000,
                "coefficient_of_variation": cv
            }
            
            print(f"   ✓ Performance consistency: {'PASS' if consistent else 'WARN'}")
            print(f"     Average time: {avg_time*1000:.1f} ms")
            print(f"     Std deviation: {std_time*1000:.1f} ms")
            print(f"     Coefficient of variation: {cv:.3f}")
        except Exception as e:
            validation_results["checks"]["consistency"] = {
                "passed": False,
                "message": f"Consistency test error: {e}"
            }
            print(f"   ✗ Performance consistency: FAIL - {e}")
        
        # Summary
        passed_checks = sum(1 for check in validation_results["checks"].values() if check["passed"])
        total_checks = len(validation_results["checks"])
        
        print(f"\nValidation Summary:")
        print(f"  Passed: {passed_checks}/{total_checks} checks")
        print(f"  Overall status: {'PASS' if passed_checks == total_checks else 'PARTIAL' if passed_checks > 0 else 'FAIL'}")
        
        validation_results["summary"] = {
            "total_checks": total_checks,
            "passed_checks": passed_checks,
            "overall_status": "PASS" if passed_checks == total_checks else "PARTIAL" if passed_checks > 0 else "FAIL"
        }
        
        # Save results if requested
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(validation_results, f, indent=2, ensure_ascii=False)
            print(f"\nValidation results saved to: {args.output}")
    
    except Exception as e:
        logger.error(f"Model validation failed: {e}")
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    """Main CLI function for CNN management."""
    parser = argparse.ArgumentParser(
        description="CNN model management and optimization tools",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List available models
  python -m deepfake_detector.cnn_cli list

  # Download a specific model
  python -m deepfake_detector.cnn_cli download --models xception efficientnet_b0

  # Benchmark model performance
  python -m deepfake_detector.cnn_cli benchmark --model xception --samples 100

  # Test model with random images
  python -m deepfake_detector.cnn_cli test --model xception --samples 10

  # Compare multiple models
  python -m deepfake_detector.cnn_cli compare --models xception efficientnet_b0 resnet50

  # Validate model integrity
  python -m deepfake_detector.cnn_cli validate --model xception
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # List command
    list_parser = subparsers.add_parser("list", help="List available models")
    list_parser.add_argument("--output", type=str, help="Output JSON file")
    
    # Download command
    download_parser = subparsers.add_parser("download", help="Download models")
    download_parser.add_argument("--models", nargs="+", help="Models to download")
    download_parser.add_argument("--force", action="store_true", help="Force re-download")
    
    # Benchmark command
    benchmark_parser = subparsers.add_parser("benchmark", help="Benchmark model performance")
    benchmark_parser.add_argument("--model", required=True, help="Model to benchmark")
    benchmark_parser.add_argument("--samples", type=int, default=100, help="Number of samples")
    benchmark_parser.add_argument("--batch-size", type=int, default=32, help="Batch size")
    benchmark_parser.add_argument("--threads", type=int, default=4, help="Number of threads")
    benchmark_parser.add_argument("--provider", choices=["cpu", "cuda"], help="Execution provider")
    benchmark_parser.add_argument("--precision", choices=["fp32", "fp16", "int8"], help="Precision mode")
    benchmark_parser.add_argument("--image-size", type=int, nargs=2, help="Image size (width height)")
    benchmark_parser.add_argument("--output", type=str, help="Output JSON file")
    
    # Test command
    test_parser = subparsers.add_parser("test", help="Test model with sample images")
    test_parser.add_argument("--model", required=True, help="Model to test")
    test_parser.add_argument("--samples", type=int, default=10, help="Number of test samples")
    test_parser.add_argument("--batch-size", type=int, default=1, help="Batch size")
    test_parser.add_argument("--provider", choices=["cpu", "cuda"], help="Execution provider")
    test_parser.add_argument("--output", type=str, help="Output JSON file")
    
    # Compare command
    compare_parser = subparsers.add_parser("compare", help="Compare multiple models")
    compare_parser.add_argument("--models", nargs="+", help="Models to compare")
    compare_parser.add_argument("--samples", type=int, default=50, help="Number of samples")
    compare_parser.add_argument("--batch-size", type=int, default=16, help="Batch size")
    compare_parser.add_argument("--provider", choices=["cpu", "cuda"], help="Execution provider")
    compare_parser.add_argument("--output", type=str, help="Output JSON file")
    
    # Validate command
    validate_parser = subparsers.add_parser("validate", help="Validate model integrity")
    validate_parser.add_argument("--model", required=True, help="Model to validate")
    validate_parser.add_argument("--output", type=str, help="Output JSON file")
    
    # Common options
    for subparser in [list_parser, download_parser, benchmark_parser, test_parser, compare_parser, validate_parser]:
        subparser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
        subparser.add_argument("--verbose", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Configure logging
    configure_logging(
        log_level=args.log_level,
        console_output=not args.verbose,  # Reduce console noise unless verbose
        performance_monitoring=True
    )
    
    # Execute command
    try:
        if args.command == "list":
            list_models_command(args)
        elif args.command == "download":
            download_model_command(args)
        elif args.command == "benchmark":
            benchmark_model_command(args)
        elif args.command == "test":
            test_model_command(args)
        elif args.command == "compare":
            compare_models_command(args)
        elif args.command == "validate":
            validate_model_command(args)
    
    except KeyboardInterrupt:
        print("\nOperation interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"Command failed: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
