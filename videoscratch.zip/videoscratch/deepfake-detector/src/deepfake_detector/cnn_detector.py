from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import numpy as np

try:
    import onnxruntime as ort  # type: ignore
    _HAS_ORT = True
except Exception:  # noqa: BLE001
    _HAS_ORT = False

from .models import ensure_model_file


class CnnDetector:
    def __init__(self, model_url: Optional[str] = None, model_filename: str = "xception_deepfake.onnx") -> None:
        self.session: Optional["ort.InferenceSession"] = None
        if not _HAS_ORT:
            return
        model_path = ensure_model_file(model_filename, download_url=model_url) if model_url else ensure_model_file(model_filename)
        if model_path.exists():
            providers = ["CPUExecutionProvider"]
            self.session = ort.InferenceSession(str(model_path), providers=providers)

    def available(self) -> bool:
        return self.session is not None

    def predict(self, face_crops_bgr: List[np.ndarray]) -> float:
        if not self.available() or not face_crops_bgr:
            return 0.5
        # Preprocess: resize to 224, normalize to [0,1], convert BGR->RGB, NHWC->NCHW
        batch = []
        for img in face_crops_bgr:
            import cv2
            x = cv2.resize(img, (224, 224))
            x = cv2.cvtColor(x, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
            x = np.transpose(x, (2, 0, 1))  # C,H,W
            batch.append(x)
        x = np.stack(batch, axis=0)
        inp_name = self.session.get_inputs()[0].name  # type: ignore[union-attr]
        out = self.session.run(None, {inp_name: x})  # type: ignore[union-attr]
        logits = out[0]
        # Assume output: [N, 1] logit for fake class
        probs = 1.0 / (1.0 + np.exp(-logits))
        return float(np.mean(probs))
