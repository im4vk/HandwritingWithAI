"""Configuration management system for the deepfake detector.

This module provides centralized configuration management with support for:
- Default settings
- Environment variables
- Configuration files (YAML, JSON, TOML)
- Command-line overrides
- Validation and type checking
- Environment-specific profiles
"""

import os
import json
import logging
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Dict, Any, Optional, Union, List, Tuple
from enum import Enum
import tempfile

# Try to import optional configuration file parsers
try:
    import yaml
    _HAS_YAML = True
except ImportError:
    _HAS_YAML = False

try:
    import tomllib  # Python 3.11+
    _HAS_TOML = True
except ImportError:
    try:
        import tomli as tomllib  # Fallback for older Python
        _HAS_TOML = True
    except ImportError:
        _HAS_TOML = False

from .exceptions import InputValidationError, ProcessingError


class LogLevel(Enum):
    """Enumeration for log levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


class FaceDetectionMethod(Enum):
    """Enumeration for face detection methods."""
    AUTO = "auto"
    MEDIAPIPE = "mediapipe"
    HAAR = "haar"
    BOTH = "both"


class FusionMethod(Enum):
    """Enumeration for score fusion methods."""
    SIMPLE = "simple"
    WEIGHTED = "weighted"
    QUALITY_ADAPTIVE = "quality_adaptive"
    CONFIDENCE_WEIGHTED = "confidence_weighted"
    TEMPORAL_CONSISTENCY = "temporal_consistency"
    BAYESIAN = "bayesian"
    ENSEMBLE_VOTING = "ensemble_voting"


class Environment(Enum):
    """Enumeration for deployment environments."""
    DEVELOPMENT = "development"
    TESTING = "testing"
    PRODUCTION = "production"


@dataclass
class ProcessingConfig:
    """Configuration for video/image processing parameters."""
    target_fps: int = 15
    max_frames: Optional[int] = None
    face_crop_size: int = 224
    face_detection_confidence: float = 0.5
    face_detection_method: FaceDetectionMethod = FaceDetectionMethod.AUTO
    enable_face_tracking: bool = True
    tracking_max_distance: float = 50.0
    min_face_size: Tuple[int, int] = (30, 30)
    max_face_size: Tuple[int, int] = (300, 300)

    def __post_init__(self):
        """Validate configuration values."""
        if self.target_fps <= 0 or self.target_fps > 120:
            raise InputValidationError("target_fps must be between 1 and 120")
        if self.max_frames is not None and self.max_frames <= 0:
            raise InputValidationError("max_frames must be positive")
        if self.face_crop_size <= 0:
            raise InputValidationError("face_crop_size must be positive")
        if not (0.0 <= self.face_detection_confidence <= 1.0):
            raise InputValidationError("face_detection_confidence must be between 0.0 and 1.0")
        if self.tracking_max_distance <= 0:
            raise InputValidationError("tracking_max_distance must be positive")


@dataclass
class AlgorithmConfig:
    """Configuration for detection algorithms."""
    # Frequency analysis
    enable_frequency_analysis: bool = True
    frequency_analysis_weight: float = 1.0
    radial_frequency_bands: int = 8
    
    # rPPG analysis
    enable_rppg_analysis: bool = True
    rppg_analysis_weight: float = 1.0
    rppg_bandpass_low: float = 0.75  # Hz
    rppg_bandpass_high: float = 4.0  # Hz
    rppg_window_size: int = 256
    
    # Audio-visual sync
    enable_avsync_analysis: bool = True
    avsync_analysis_weight: float = 1.0
    avsync_correlation_threshold: float = 0.3
    
    # Geometry analysis
    enable_geometry_analysis: bool = True
    geometry_analysis_weight: float = 1.0
    geometry_smoothing_window: int = 5
    geometry_outlier_threshold: float = 2.0
    
    # CNN analysis
    enable_cnn_analysis: bool = True
    cnn_analysis_weight: float = 1.0
    cnn_model_url: Optional[str] = None
    cnn_batch_size: int = 32
    cnn_confidence_threshold: float = 0.5
    
    # Enhanced CNN settings
    cnn_architecture: str = "xception"  # Model architecture to use
    cnn_execution_provider: str = "cpu"  # cpu, cuda, tensorrt
    cnn_precision_mode: str = "fp32"  # fp32, fp16, int8
    cnn_enable_ensemble: bool = False
    cnn_ensemble_models: List[str] = field(default_factory=list)
    cnn_enable_optimization: bool = True
    
    # Fusion settings
    fusion_method: FusionMethod = FusionMethod.WEIGHTED
    enable_quality_weighting: bool = False
    min_quality_threshold: float = 0.3
    uncertainty_penalty: float = 0.2
    temporal_fusion_window: int = 5
    
    # Temporal tracking settings
    enable_temporal_tracking: bool = True
    max_missing_frames: int = 10
    min_track_length: int = 5
    face_iou_threshold: float = 0.5
    max_simultaneous_tracks: int = 5
    enable_gap_filling: bool = True

    def __post_init__(self):
        """Validate algorithm configuration."""
        weights = [
            self.frequency_analysis_weight,
            self.rppg_analysis_weight,
            self.avsync_analysis_weight,
            self.geometry_analysis_weight,
            self.cnn_analysis_weight
        ]
        
        for weight in weights:
            if weight < 0:
                raise InputValidationError("Algorithm weights must be non-negative")
        
        if sum(weights) == 0:
            raise InputValidationError("At least one algorithm weight must be positive")
        
        if not (0.1 <= self.rppg_bandpass_low <= 2.0):
            raise InputValidationError("rppg_bandpass_low must be between 0.1 and 2.0 Hz")
        if not (2.0 <= self.rppg_bandpass_high <= 10.0):
            raise InputValidationError("rppg_bandpass_high must be between 2.0 and 10.0 Hz")
        if self.rppg_bandpass_low >= self.rppg_bandpass_high:
            raise InputValidationError("rppg_bandpass_low must be less than rppg_bandpass_high")


@dataclass
class LoggingConfig:
    """Configuration for logging system."""
    log_level: LogLevel = LogLevel.INFO
    log_dir: Optional[str] = None
    console_output: bool = True
    file_output: bool = False
    structured_logs: bool = False
    performance_monitoring: bool = True
    max_file_size: int = 10 * 1024 * 1024  # 10MB
    backup_count: int = 5
    quiet_mode: bool = False

    def __post_init__(self):
        """Validate logging configuration."""
        if self.max_file_size <= 0:
            raise InputValidationError("max_file_size must be positive")
        if self.backup_count < 0:
            raise InputValidationError("backup_count must be non-negative")


@dataclass
class PerformanceConfig:
    """Configuration for performance optimization."""
    enable_caching: bool = True
    cache_size: int = 100
    cache_ttl: int = 3600  # seconds
    enable_multiprocessing: bool = False
    enable_streaming: bool = False
    enable_parallel: bool = True
    num_workers: Optional[int] = None
    max_workers: Optional[int] = None
    chunk_size: int = 10
    memory_limit: Optional[int] = None  # MB
    gpu_acceleration: bool = False
    gpu_device_id: int = 0
    disk_cache_dir: Optional[str] = None

    def __post_init__(self):
        """Validate performance configuration."""
        if self.cache_size <= 0:
            raise InputValidationError("cache_size must be positive")
        if self.cache_ttl <= 0:
            raise InputValidationError("cache_ttl must be positive")
        if self.num_workers is not None and self.num_workers <= 0:
            raise InputValidationError("num_workers must be positive")
        if self.chunk_size <= 0:
            raise InputValidationError("chunk_size must be positive")
        if self.memory_limit is not None and self.memory_limit <= 0:
            raise InputValidationError("memory_limit must be positive")


@dataclass
class OutputConfig:
    """Configuration for output generation."""
    output_format: str = "json"
    include_intermediate_scores: bool = True
    include_confidence_intervals: bool = False
    include_processing_metadata: bool = True
    overlay_output: bool = False
    overlay_font_scale: float = 0.7
    overlay_thickness: int = 2
    save_face_crops: bool = False
    save_debug_images: bool = False
    temp_dir: str = "/tmp"  # Temporary directory for processing

    def __post_init__(self):
        """Validate output configuration."""
        valid_formats = ["json", "yaml", "csv", "xml"]
        if self.output_format not in valid_formats:
            raise InputValidationError(f"output_format must be one of {valid_formats}")
        if self.overlay_font_scale <= 0:
            raise InputValidationError("overlay_font_scale must be positive")
        if self.overlay_thickness <= 0:
            raise InputValidationError("overlay_thickness must be positive")


@dataclass
class DeepfakeDetectorConfig:
    """Main configuration class for the deepfake detector."""
    # Sub-configurations
    processing: ProcessingConfig = field(default_factory=ProcessingConfig)
    algorithms: AlgorithmConfig = field(default_factory=AlgorithmConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    performance: PerformanceConfig = field(default_factory=PerformanceConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    
    # Global settings
    environment: Environment = Environment.DEVELOPMENT
    debug_mode: bool = False
    strict_validation: bool = True
    config_version: str = "1.0"

    def __post_init__(self):
        """Post-initialization validation and setup."""
        # Adjust settings based on environment
        if self.environment == Environment.PRODUCTION:
            if self.debug_mode:
                self.debug_mode = False
                logging.getLogger(__name__).warning(
                    "Debug mode disabled in production environment"
                )
            if self.logging.log_level == LogLevel.DEBUG:
                self.logging.log_level = LogLevel.INFO
                logging.getLogger(__name__).warning(
                    "Log level changed from DEBUG to INFO in production"
                )

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'DeepfakeDetectorConfig':
        """Create configuration from dictionary."""
        # Create sub-configurations
        processing_data = config_dict.get('processing', {})
        algorithms_data = config_dict.get('algorithms', {})
        logging_data = config_dict.get('logging', {})
        performance_data = config_dict.get('performance', {})
        output_data = config_dict.get('output', {})
        
        # Handle enum conversions and special types
        if 'face_detection_method' in processing_data:
            processing_data['face_detection_method'] = FaceDetectionMethod(
                processing_data['face_detection_method']
            )
        
        if 'fusion_method' in algorithms_data:
            algorithms_data['fusion_method'] = FusionMethod(
                algorithms_data['fusion_method']
            )
        
        # Convert lists back to tuples for tuple fields
        if 'min_face_size' in processing_data and isinstance(processing_data['min_face_size'], list):
            processing_data['min_face_size'] = tuple(processing_data['min_face_size'])
        if 'max_face_size' in processing_data and isinstance(processing_data['max_face_size'], list):
            processing_data['max_face_size'] = tuple(processing_data['max_face_size'])
        
        if 'log_level' in logging_data:
            logging_data['log_level'] = LogLevel(logging_data['log_level'])
        
        if 'environment' in config_dict:
            config_dict['environment'] = Environment(config_dict['environment'])
        
        # Create sub-configurations
        processing = ProcessingConfig(**processing_data)
        algorithms = AlgorithmConfig(**algorithms_data)
        logging_config = LoggingConfig(**logging_data)
        performance = PerformanceConfig(**performance_data)
        output = OutputConfig(**output_data)
        
        # Create main configuration
        main_config_data = {k: v for k, v in config_dict.items() 
                           if k not in ['processing', 'algorithms', 'logging', 'performance', 'output']}
        
        return cls(
            processing=processing,
            algorithms=algorithms,
            logging=logging_config,
            performance=performance,
            output=output,
            **main_config_data
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        result = {}
        
        # Convert main fields
        for field_info in fields(self):
            value = getattr(self, field_info.name)
            if hasattr(value, '__dataclass_fields__'):  # Sub-configuration dataclass
                # Convert nested dataclass to dict
                nested_dict = {}
                for nested_field in fields(value):
                    nested_value = getattr(value, nested_field.name)
                    if isinstance(nested_value, Enum):
                        nested_dict[nested_field.name] = nested_value.value
                    elif isinstance(nested_value, (tuple, list)):
                        nested_dict[nested_field.name] = list(nested_value)
                    else:
                        nested_dict[nested_field.name] = nested_value
                result[field_info.name] = nested_dict
            elif isinstance(value, Enum):
                result[field_info.name] = value.value
            elif isinstance(value, (tuple, list)):
                result[field_info.name] = list(value)
            else:
                result[field_info.name] = value
        
        return result

    def save(self, file_path: Union[str, Path], format: str = "auto") -> None:
        """Save configuration to file."""
        file_path = Path(file_path)
        
        if format == "auto":
            # Determine format from file extension
            suffix = file_path.suffix.lower()
            if suffix == ".yaml" or suffix == ".yml":
                format = "yaml"
            elif suffix == ".json":
                format = "json"
            elif suffix == ".toml":
                format = "toml"
            else:
                format = "json"  # Default
        
        config_dict = self.to_dict()
        
        # Ensure directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == "json":
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)
        
        elif format == "yaml":
            if not _HAS_YAML:
                raise ProcessingError("PyYAML not installed. Install with: pip install PyYAML")
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)
        
        elif format == "toml":
            if not _HAS_TOML:
                raise ProcessingError("TOML support not available. Install with: pip install tomli")
            # Note: Writing TOML requires additional library like tomli-w
            raise ProcessingError("TOML writing not implemented. Use JSON or YAML format.")
        
        else:
            raise InputValidationError(f"Unsupported format: {format}")

    @classmethod
    def load(cls, file_path: Union[str, Path]) -> 'DeepfakeDetectorConfig':
        """Load configuration from file."""
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise ProcessingError(f"Configuration file not found: {file_path}")
        
        suffix = file_path.suffix.lower()
        
        try:
            if suffix == ".json":
                with open(file_path, 'r', encoding='utf-8') as f:
                    config_dict = json.load(f)
            
            elif suffix in [".yaml", ".yml"]:
                if not _HAS_YAML:
                    raise ProcessingError("PyYAML not installed. Install with: pip install PyYAML")
                with open(file_path, 'r', encoding='utf-8') as f:
                    config_dict = yaml.safe_load(f)
            
            elif suffix == ".toml":
                if not _HAS_TOML:
                    raise ProcessingError("TOML support not available. Install with: pip install tomli")
                with open(file_path, 'rb') as f:
                    config_dict = tomllib.load(f)
            
            else:
                raise InputValidationError(f"Unsupported configuration file format: {suffix}")
            
            return cls.from_dict(config_dict)
        
        except Exception as e:
            raise ProcessingError(f"Failed to load configuration from {file_path}: {e}")

    def update_from_env(self, prefix: str = "DEEPFAKE_") -> None:
        """Update configuration from environment variables."""
        env_mapping = {
            # Processing
            f"{prefix}TARGET_FPS": ("processing", "target_fps", int),
            f"{prefix}MAX_FRAMES": ("processing", "max_frames", int),
            f"{prefix}FACE_CROP_SIZE": ("processing", "face_crop_size", int),
            f"{prefix}FACE_DETECTION_METHOD": ("processing", "face_detection_method", FaceDetectionMethod),
            
            # Algorithms
            f"{prefix}ENABLE_CNN": ("algorithms", "enable_cnn_analysis", bool),
            f"{prefix}CNN_MODEL_URL": ("algorithms", "cnn_model_url", str),
            f"{prefix}CNN_BATCH_SIZE": ("algorithms", "cnn_batch_size", int),
            
            # Logging
            f"{prefix}LOG_LEVEL": ("logging", "log_level", LogLevel),
            f"{prefix}LOG_DIR": ("logging", "log_dir", str),
            f"{prefix}STRUCTURED_LOGS": ("logging", "structured_logs", bool),
            
            # Performance
            f"{prefix}ENABLE_CACHING": ("performance", "enable_caching", bool),
            f"{prefix}CACHE_SIZE": ("performance", "cache_size", int),
            f"{prefix}NUM_WORKERS": ("performance", "num_workers", int),
            f"{prefix}GPU_ACCELERATION": ("performance", "gpu_acceleration", bool),
            
            # Global
            f"{prefix}ENVIRONMENT": ("", "environment", Environment),
            f"{prefix}DEBUG_MODE": ("", "debug_mode", bool),
        }
        
        for env_var, (section, field_name, field_type) in env_mapping.items():
            env_value = os.environ.get(env_var)
            if env_value is not None:
                try:
                    # Convert string to appropriate type
                    if field_type == bool:
                        converted_value = env_value.lower() in ('true', '1', 'yes', 'on')
                    elif field_type == int:
                        converted_value = int(env_value)
                    elif field_type == float:
                        converted_value = float(env_value)
                    elif issubclass(field_type, Enum):
                        converted_value = field_type(env_value)
                    else:
                        converted_value = env_value
                    
                    # Set the value
                    if section:
                        section_obj = getattr(self, section)
                        setattr(section_obj, field_name, converted_value)
                    else:
                        setattr(self, field_name, converted_value)
                
                except (ValueError, TypeError) as e:
                    logging.getLogger(__name__).warning(
                        f"Failed to convert environment variable {env_var}={env_value}: {e}"
                    )

    def validate(self) -> List[str]:
        """Validate the entire configuration and return any issues."""
        issues = []
        
        # Validate that at least one algorithm is enabled
        enabled_algorithms = sum([
            self.algorithms.enable_frequency_analysis,
            self.algorithms.enable_rppg_analysis,
            self.algorithms.enable_avsync_analysis,
            self.algorithms.enable_geometry_analysis,
            self.algorithms.enable_cnn_analysis
        ])
        
        if enabled_algorithms == 0:
            issues.append("At least one detection algorithm must be enabled")
        
        # Validate performance settings consistency
        if self.performance.enable_multiprocessing and self.performance.num_workers is None:
            issues.append("num_workers must be specified when multiprocessing is enabled")
        
        # Validate GPU settings
        if self.performance.gpu_acceleration and not self.algorithms.enable_cnn_analysis:
            issues.append("GPU acceleration requires CNN analysis to be enabled")
        
        # Validate output settings
        if self.output.save_face_crops or self.output.save_debug_images:
            if self.logging.log_dir is None:
                issues.append("log_dir must be specified when saving face crops or debug images")
        
        return issues

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the current configuration."""
        enabled_algorithms = []
        if self.algorithms.enable_frequency_analysis:
            enabled_algorithms.append("frequency")
        if self.algorithms.enable_rppg_analysis:
            enabled_algorithms.append("rppg")
        if self.algorithms.enable_avsync_analysis:
            enabled_algorithms.append("avsync")
        if self.algorithms.enable_geometry_analysis:
            enabled_algorithms.append("geometry")
        if self.algorithms.enable_cnn_analysis:
            enabled_algorithms.append("cnn")
        
        return {
            "environment": self.environment.value,
            "target_fps": self.processing.target_fps,
            "face_detection_method": self.processing.face_detection_method.value,
            "enabled_algorithms": enabled_algorithms,
            "caching_enabled": self.performance.enable_caching,
            "multiprocessing_enabled": self.performance.enable_multiprocessing,
            "gpu_acceleration": self.performance.gpu_acceleration,
            "log_level": self.logging.log_level.value,
            "performance_monitoring": self.logging.performance_monitoring,
            "validation_issues": len(self.validate())
        }


# Global configuration instance
_global_config: Optional[DeepfakeDetectorConfig] = None


def get_config() -> DeepfakeDetectorConfig:
    """Get the global configuration instance."""
    global _global_config
    if _global_config is None:
        _global_config = DeepfakeDetectorConfig()
    return _global_config


def set_config(config: DeepfakeDetectorConfig) -> None:
    """Set the global configuration instance."""
    global _global_config
    _global_config = config


def load_config(file_path: Optional[Union[str, Path]] = None,
                env_prefix: str = "DEEPFAKE_",
                create_default: bool = True) -> DeepfakeDetectorConfig:
    """Load configuration from multiple sources with precedence order:
    
    1. Command line arguments (handled elsewhere)
    2. Environment variables
    3. Configuration file
    4. Default values
    
    Args:
        file_path: Optional path to configuration file
        env_prefix: Prefix for environment variables
        create_default: Whether to create default config if no file found
        
    Returns:
        Loaded configuration instance
    """
    # Start with default configuration
    config = DeepfakeDetectorConfig()
    
    # Load from file if specified
    if file_path is not None:
        file_path = Path(file_path)
        if file_path.exists():
            try:
                config = DeepfakeDetectorConfig.load(file_path)
                logging.getLogger(__name__).info(f"Loaded configuration from {file_path}")
            except Exception as e:
                logging.getLogger(__name__).error(f"Failed to load config from {file_path}: {e}")
                if not create_default:
                    raise
        elif create_default:
            # Create default configuration file
            try:
                config.save(file_path)
                logging.getLogger(__name__).info(f"Created default configuration at {file_path}")
            except Exception as e:
                logging.getLogger(__name__).warning(f"Failed to create default config: {e}")
    
    # Override with environment variables
    config.update_from_env(env_prefix)
    
    # Validate configuration
    issues = config.validate()
    if issues:
        error_msg = "Configuration validation failed:\n" + "\n".join(f"- {issue}" for issue in issues)
        if config.strict_validation:
            raise ProcessingError(error_msg)
        else:
            logging.getLogger(__name__).warning(error_msg)
    
    # Set as global configuration
    set_config(config)
    
    return config


def create_profile_configs() -> Dict[str, DeepfakeDetectorConfig]:
    """Create predefined configuration profiles for different use cases."""
    profiles = {}
    
    # Development profile
    dev_config = DeepfakeDetectorConfig(
        environment=Environment.DEVELOPMENT,
        debug_mode=True,
        logging=LoggingConfig(
            log_level=LogLevel.DEBUG,
            console_output=True,
            file_output=True,
            performance_monitoring=True
        ),
        performance=PerformanceConfig(
            enable_caching=True,
            enable_multiprocessing=False,
            gpu_acceleration=False
        )
    )
    profiles["development"] = dev_config
    
    # Production profile
    prod_config = DeepfakeDetectorConfig(
        environment=Environment.PRODUCTION,
        debug_mode=False,
        strict_validation=True,
        logging=LoggingConfig(
            log_level=LogLevel.INFO,
            console_output=False,
            file_output=True,
            structured_logs=True,
            performance_monitoring=True
        ),
        performance=PerformanceConfig(
            enable_caching=True,
            enable_multiprocessing=True,
            num_workers=4,
            gpu_acceleration=True
        ),
        output=OutputConfig(
            include_processing_metadata=False,
            save_debug_images=False
        )
    )
    profiles["production"] = prod_config
    
    # Fast processing profile
    fast_config = DeepfakeDetectorConfig(
        processing=ProcessingConfig(
            target_fps=10,
            max_frames=60,
            face_detection_method=FaceDetectionMethod.HAAR
        ),
        algorithms=AlgorithmConfig(
            enable_frequency_analysis=True,
            enable_rppg_analysis=False,
            enable_avsync_analysis=False,
            enable_geometry_analysis=True,
            enable_cnn_analysis=True
        ),
        performance=PerformanceConfig(
            enable_caching=True,
            enable_multiprocessing=True,
            gpu_acceleration=True
        )
    )
    profiles["fast"] = fast_config
    
    # Accuracy profile
    accuracy_config = DeepfakeDetectorConfig(
        processing=ProcessingConfig(
            target_fps=25,
            face_detection_method=FaceDetectionMethod.MEDIAPIPE
        ),
        algorithms=AlgorithmConfig(
            enable_frequency_analysis=True,
            enable_rppg_analysis=True,
            enable_avsync_analysis=True,
            enable_geometry_analysis=True,
            enable_cnn_analysis=True
        ),
        performance=PerformanceConfig(
            enable_caching=True,
            gpu_acceleration=True
        )
    )
    profiles["accuracy"] = accuracy_config
    
    return profiles
