from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Optional

import cv2

from . import io
from .avsync import av_sync_fake_score
from .cnn_detector import CnnDetector
from .enhanced_cnn import EnhancedCNNDetector, ModelConfig, ModelArchitecture, create_model_config
from .face import FaceTrack, detect_face_track
from .frequency import frequency_fake_score
from .fusion import fuse_scores, fuse_scores_with_config, estimate_score_quality, analyze_fusion_reliability
from .geometry import geometry_fake_score
from .provenance import provenance_hint
from .rppg import rppg_fake_score
from .logging_config import (
    ensure_logging_configured,
    get_logger, 
    create_operation_context,
    log_operation,
    get_metrics,
    log_metrics,
)
from .exceptions import (
    DeepfakeDetectorError,
    InputValidationError,
    ProcessingError,
    validate_input,
    handle_processing_error,
)
from .config import (
    DeepfakeDetectorConfig,
    get_config,
    load_config,
    create_profile_configs,
)
from .performance import (
    PerformanceOptimizer,
    PerformanceConfig,
    ProcessingMode,
    cached,
    estimate_memory_requirements,
)


@dataclass
class DetectionReport:
    input_path: str
    final_probability: float
    label: str
    scores: Dict[str, float]
    provenance: Optional[str] = None
    fusion_metadata: Optional[Dict[str, any]] = None
    performance_stats: Optional[Dict[str, any]] = None


def _render_overlay(frames_bgr, track: FaceTrack, scores: Dict[str, float], final_prob: float):
    overlay_frames = []
    score_text = f"P(fake)={final_prob:.2f} | freq={scores.get('freq',0):.2f} rppg={scores.get('rppg',0):.2f} av={scores.get('av',0):.2f} geom={scores.get('geom',0):.2f} cnn={scores.get('cnn',0):.2f}"
    tf_color = (0, 0, 255) if final_prob >= 0.5 else (0, 200, 0)

    frame_map = {ff.frame_index: ff for ff in track.frames}
    for idx, frame in enumerate(frames_bgr):
        f = frame.copy()
        if idx in frame_map:
            ff = frame_map[idx]
            x, y, w, h = ff.box_xywh
            cv2.rectangle(f, (x, y), (x + w, y + h), (0, 255, 255), 2)
            if ff.mouth_open is not None:
                cv2.putText(f, f"mouth:{ff.mouth_open:.2f}", (x, max(0, y - 25)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
            if ff.eye_open is not None:
                cv2.putText(f, f"eye:{ff.eye_open:.2f}", (x, max(0, y - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
        cv2.putText(f, score_text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, tf_color, 2)
        overlay_frames.append(f)
    return overlay_frames


def analyze_video(input_path: str | Path,
                  config: Optional[DeepfakeDetectorConfig] = None,
                  target_fps: Optional[int] = None, 
                  max_frames: Optional[int] = None,
                  overlay_out: Optional[str] = None, 
                  use_cnn: Optional[bool] = None, 
                  cnn_model_url: Optional[str] = None,
                  performance_optimizer: Optional[PerformanceOptimizer] = None) -> DetectionReport:
    """Analyze video or image for deepfake detection.
    
    Args:
        input_path: Path to input video or image
        config: Configuration object (uses global config if None)
        target_fps: Target frame rate for processing (overrides config)
        max_frames: Maximum number of frames to process (overrides config)
        overlay_out: Optional path for overlay video output
        use_cnn: Whether to use CNN detection (overrides config)
        cnn_model_url: Optional URL for CNN model download (overrides config)
        
    Returns:
        DetectionReport: Complete detection results
        
    Raises:
        InputValidationError: If input parameters are invalid
        ProcessingError: If analysis fails
    """
    # Get configuration
    if config is None:
        config = get_config()
    
    # Initialize performance optimizer
    if performance_optimizer is None:
        perf_config = PerformanceConfig(
            enable_caching=config.performance.enable_caching if hasattr(config, 'performance') else True,
            enable_streaming=config.performance.enable_streaming if hasattr(config, 'performance') else False,
            enable_parallel=config.performance.enable_parallel if hasattr(config, 'performance') else True,
            max_workers=config.performance.max_workers if hasattr(config, 'performance') else None,
            disk_cache_dir=Path(config.output.temp_dir) / "cache" if hasattr(config, 'output') else None
        )
        performance_optimizer = PerformanceOptimizer(perf_config)
    
    # Configure logging from config
    from .logging_config import configure_logging
    configure_logging(
        log_level=config.logging.log_level.value,
        log_dir=config.logging.log_dir,
        console_output=config.logging.console_output,
        file_output=config.logging.file_output,
        structured_logs=config.logging.structured_logs,
        performance_monitoring=config.logging.performance_monitoring,
        max_file_size=config.logging.max_file_size,
        backup_count=config.logging.backup_count
    )
    
    logger = get_logger(__name__)
    
    # Apply parameter overrides
    effective_fps = target_fps if target_fps is not None else config.processing.target_fps
    effective_max_frames = max_frames if max_frames is not None else config.processing.max_frames
    effective_use_cnn = use_cnn if use_cnn is not None else config.algorithms.enable_cnn_analysis
    effective_cnn_url = cnn_model_url if cnn_model_url is not None else config.algorithms.cnn_model_url
    
    # Input validation
    validate_input(input_path, "input_path")
    validate_input(effective_fps, "target_fps", int, min_value=1, max_value=120)
    if effective_max_frames is not None:
        validate_input(effective_max_frames, "max_frames", int, min_value=1)
    
    input_path_str = str(input_path)
    path = Path(input_path_str)
    
    logger.info(f"Starting deepfake analysis: {input_path_str}")
    logger.info(f"Environment: {config.environment.value}")
    logger.info(f"Parameters: fps={effective_fps}, max_frames={effective_max_frames}, use_cnn={effective_use_cnn}")
    logger.info(f"Enabled algorithms: {[name for name, enabled in [
        ('frequency', config.algorithms.enable_frequency_analysis),
        ('rppg', config.algorithms.enable_rppg_analysis),
        ('avsync', config.algorithms.enable_avsync_analysis),
        ('geometry', config.algorithms.enable_geometry_analysis),
        ('cnn', effective_use_cnn)
    ] if enabled]}")
    
    total_start_time = time.time()
    
    try:
        # Load media with timing
        with create_operation_context("media_loading"):
            if io.is_image_file(path):
                logger.info("Processing single image")
                data = io.read_image(path)
            else:
                logger.info("Processing video")
                data = io.read_video(path, target_fps=effective_fps, max_frames=effective_max_frames)
            
            logger.info(f"Loaded {len(data.frames_bgr)} frames")
            if data.audio_mono is not None:
                logger.info(f"Audio: {len(data.audio_mono)} samples at {data.audio_sr} Hz")

        # Face detection and tracking with temporal consistency
        with create_operation_context("face_detection"):
            use_temporal = config.algorithms.enable_temporal_tracking if hasattr(config.algorithms, 'enable_temporal_tracking') else True
            track: Optional[FaceTrack] = detect_face_track(
                data.frames_bgr, 
                use_temporal_tracking=use_temporal and len(data.frames_bgr) > 1,
                frame_timestamps=data.frame_timestamps_s
            )

        if track is None:
            logger.warning("No faces detected in video/image, using default scores")
            scores = {"freq": 0.5, "rppg": 0.5, "av": 0.5, "geom": 0.5, "cnn": 0.5}
            final = fuse_scores(scores)
            label = "fake" if final >= 0.5 else "real"
            
            total_time = time.time() - total_start_time
            log_operation("full_analysis", total_time, True, {
                'frames_processed': len(data.frames_bgr),
                'faces_detected': 0,
                'final_score': final,
                'label': label
            })
            
            return DetectionReport(
                input_path=input_path_str, 
                final_probability=final, 
                label=label, 
                scores=scores, 
                provenance=provenance_hint(input_path_str)
            )

        logger.info(f"Detected faces in {len(track.frames)} frames")

        # Collect per-module inputs
        logger.debug("Preparing analysis inputs")
        face_crops = [ff.face_crop for ff in track.frames]
        landmarks_xy_list = [ff.landmarks_xy for ff in track.frames]
        mouth_open_series = [ff.mouth_open for ff in track.frames if ff.mouth_open is not None]
        mouth_open_series = mouth_open_series if len(mouth_open_series) == len(track.frames) else None
        eye_open_series = [ff.eye_open for ff in track.frames]
        centers_xy = [ff.center_xy for ff in track.frames]
        
        logger.debug(f"Analysis inputs: {len(face_crops)} face crops, "
                    f"mouth_series={'available' if mouth_open_series else 'none'}, "
                    f"{len(eye_open_series)} eye measurements")

        # Run individual detection algorithms with performance optimization
        scores = {}
        
        # Determine optimal processing mode based on file characteristics
        processing_mode = performance_optimizer.optimize_for_file(path)
        logger.info(f"Using processing mode: {processing_mode.value}")
        
        # Prepare algorithm tasks for potential parallel execution
        algorithm_tasks = []
        
        # Frequency analysis
        if config.algorithms.enable_frequency_analysis:
            algorithm_tasks.append((
                "frequency",
                lambda crops: frequency_fake_score(crops),
                face_crops,
                {}
            ))
        else:
            logger.debug("Frequency analysis disabled in config")

        # rPPG analysis
        if config.algorithms.enable_rppg_analysis:
            algorithm_tasks.append((
                "rppg", 
                lambda crops, timestamps: rppg_fake_score(crops, timestamps),
                face_crops,
                {"timestamps": data.frame_timestamps_s[:len(face_crops)]}
            ))
        else:
            logger.debug("rPPG analysis disabled in config")

        # Audio-visual sync analysis
        if config.algorithms.enable_avsync_analysis:
            algorithm_tasks.append((
                "avsync",
                lambda mouth_series, timestamps, audio, sr: av_sync_fake_score(mouth_series, timestamps, audio, sr),
                mouth_open_series,
                {
                    "timestamps": data.frame_timestamps_s[:len(track.frames)],
                    "audio": data.audio_mono,
                    "sr": data.audio_sr
                }
            ))
        else:
            logger.debug("Audio-visual sync analysis disabled in config")

        # Geometry analysis  
        if config.algorithms.enable_geometry_analysis:
            algorithm_tasks.append((
                "geometry",
                lambda landmarks, fps, eye_series, centers: geometry_fake_score(landmarks, fps, eye_series, centers),
                landmarks_xy_list,
                {
                    "fps": data.fps if data.fps else effective_fps,
                    "eye_series": eye_open_series,
                    "centers": centers_xy
                }
            ))
        else:
            logger.debug("Geometry analysis disabled in config")

        # CNN analysis with enhanced detector
        if effective_use_cnn:
            # Use enhanced CNN detector if model architecture is specified
            if hasattr(config.algorithms, 'cnn_architecture') and config.algorithms.cnn_architecture:
                try:
                    cnn_config = create_model_config(
                        config.algorithms.cnn_architecture,
                        batch_size=getattr(config.algorithms, 'cnn_batch_size', 32),
                        custom_url=effective_cnn_url
                    )
                    
                    algorithm_tasks.append((
                        "cnn",
                        lambda crops, cnn_cfg: EnhancedCNNDetector(cnn_cfg).predict(crops),
                        face_crops,
                        {"cnn_cfg": cnn_config}
                    ))
                    logger.debug(f"Using enhanced CNN detector with {config.algorithms.cnn_architecture}")
                except Exception as e:
                    logger.warning(f"Failed to use enhanced CNN detector: {e}, falling back to basic detector")
                    # Fallback to basic detector
                    algorithm_tasks.append((
                        "cnn",
                        lambda crops, model_url: CnnDetector(model_url=model_url).predict(crops),
                        face_crops,
                        {"model_url": effective_cnn_url}
                    ))
            else:
                # Use basic detector
                algorithm_tasks.append((
                    "cnn",
                    lambda crops, model_url: CnnDetector(model_url=model_url).predict(crops),
                    face_crops,
                    {"model_url": effective_cnn_url}
                ))
                logger.debug("Using basic CNN detector")
        else:
            logger.debug("CNN analysis disabled")
        
        # Execute algorithms based on processing mode
        if processing_mode == ProcessingMode.PARALLEL and len(algorithm_tasks) > 1:
            logger.info("Running algorithms in parallel")
            
            # Convert tasks to the format expected by parallel_analysis
            parallel_tasks = []
            for name, func, primary_input, kwargs in algorithm_tasks:
                # Create a wrapper that handles the specific input format
                def create_wrapper(algorithm_func, input_data, params):
                    def wrapper(file_path):
                        # Ignore file_path for in-memory algorithms
                        if name == "avsync":
                            return algorithm_func(input_data, **params)
                        elif name == "geometry":
                            return algorithm_func(input_data, **params)
                        elif name == "cnn":
                            return algorithm_func(input_data, **params)
                        elif name == "rppg":
                            return algorithm_func(input_data, params["timestamps"])
                        else:
                            return algorithm_func(input_data)
                    return wrapper
                
                wrapper_func = create_wrapper(func, primary_input, kwargs)
                parallel_tasks.append((name, wrapper_func, path, {}))
            
            # Run in parallel
            results = performance_optimizer.parallel_analysis(parallel_tasks)
            
            # Assign results
            for i, (name, _, _, _) in enumerate(parallel_tasks):
                if results[i] is not None:
                    scores[name.replace("frequency", "freq").replace("geometry", "geom").replace("avsync", "av")] = results[i]
                    logger.debug(f"{name} analysis score: {results[i]:.4f}")
        
        else:
            logger.info("Running algorithms sequentially with caching")
            
            # Execute algorithms sequentially with caching
            for name, func, primary_input, kwargs in algorithm_tasks:
                try:
                    with create_operation_context(f"{name}_analysis"):
                        if name == "frequency":
                            result = performance_optimizer.cached_analysis(
                                name, lambda fp: frequency_fake_score(face_crops), 
                                path, {"face_crops_hash": hash(str(len(face_crops)))}
                            )
                        elif name == "rppg":
                            result = performance_optimizer.cached_analysis(
                                name, lambda fp: rppg_fake_score(face_crops, kwargs["timestamps"]),
                                path, {"face_crops_hash": hash(str(len(face_crops)))}
                            )
                        elif name == "avsync":
                            result = performance_optimizer.cached_analysis(
                                name, lambda fp: av_sync_fake_score(primary_input, **kwargs),
                                path, {"audio_hash": hash(str(len(data.audio_mono or [])))}
                            )
                        elif name == "geometry":
                            result = performance_optimizer.cached_analysis(
                                name, lambda fp: geometry_fake_score(primary_input, **kwargs),
                                path, {"landmarks_hash": hash(str(len(landmarks_xy_list)))}
                            )
                        elif name == "cnn":
                            result = performance_optimizer.cached_analysis(
                                name, lambda fp: CnnDetector(model_url=kwargs["model_url"]).predict(face_crops),
                                path, {"model_url": kwargs["model_url"]}
                            )
                        
                        score_key = name.replace("frequency", "freq").replace("geometry", "geom").replace("avsync", "av")
                        scores[score_key] = result
                        logger.debug(f"{name} analysis score: {result:.4f}")
                        
                except Exception as e:
                    logger.warning(f"{name} analysis failed: {e}")
                    # Use neutral score for failed algorithms
                    score_key = name.replace("frequency", "freq").replace("geometry", "geom").replace("avsync", "av")
                    scores[score_key] = 0.5

        # Enhanced score fusion with quality metrics
        with create_operation_context("score_fusion"):
            # Estimate quality metrics for each algorithm
            quality_metrics = {}
            processing_metadata = {
                'frames_processed': len(track.frames),
                'total_frames': len(data.frames_bgr),
                'face_stability': len(track.frames) / len(data.frames_bgr) if data.frames_bgr else 1.0,
                'tracking_stability': 0.8,  # Could be computed from actual tracking data
                'landmark_detection_rate': len([ff for ff in track.frames if ff.landmarks_xy is not None]) / max(1, len(track.frames))
            }
            
            for name, score in scores.items():
                if score is not None:
                    quality_metrics[name] = estimate_score_quality(
                        score, name, processing_metadata
                    )
            
            # Analyze fusion reliability
            reliability_analysis = analyze_fusion_reliability(scores, quality_metrics)
            logger.info(f"Fusion reliability: {reliability_analysis['reliable']}, "
                       f"algorithms: {reliability_analysis['algorithm_count']}, "
                       f"avg_quality: {reliability_analysis.get('avg_quality', 'N/A')}")
            
            # Use enhanced fusion if quality weighting is enabled
            if config.algorithms.enable_quality_weighting:
                logger.info("Using quality-adaptive fusion")
                fusion_result = fuse_scores_with_config(
                    scores, config, quality_metrics, use_advanced=True
                )
                
                if isinstance(fusion_result, dict):
                    final = fusion_result['probability']
                    fusion_metadata = fusion_result.get('metadata', {})
                    logger.info(f"Advanced fusion method: {fusion_result.get('fusion_method')}")
                    logger.info(f"Quality scores: {fusion_result.get('quality_scores', {})}")
                else:
                    final = fusion_result
                    fusion_metadata = {}
            else:
                # Use configuration-weighted fusion
                logger.info("Using configuration-weighted fusion")
                final = fuse_scores_with_config(scores, config)
                fusion_metadata = {}
            
            label = "fake" if final >= 0.5 else "real"
            
        logger.info(f"Detection complete: {label} (probability: {final:.4f})")
        logger.info(f"Individual scores: {', '.join(f'{k}={v:.3f}' for k, v in scores.items() if v is not None)}")

        # Generate overlay video if requested
        if overlay_out is not None and not io.is_image_file(path):
            with create_operation_context("overlay_generation"):
                logger.info(f"Generating overlay video: {overlay_out}")
                overlay_frames = _render_overlay(data.frames_bgr, track, scores, final)
                io.write_overlay_video(overlay_frames, overlay_out, fps=data.fps)

        # Get performance statistics
        performance_stats = performance_optimizer.get_performance_stats()
        
        # Log final metrics
        total_time = time.time() - total_start_time
        log_operation("full_analysis", total_time, True, {
            'frames_processed': len(data.frames_bgr),
            'faces_detected': len(track.frames),
            'final_score': final,
            'label': label,
            'individual_scores': scores,
            'cnn_used': effective_use_cnn,
            'processing_mode': processing_mode.value,
            'cache_hit_rate': performance_stats.get('cache', {}).get('hit_rate', 0.0),
            'memory_usage_mb': performance_stats.get('memory', {}).get('current_usage', {}).get('rss_mb', 0.0)
        })
        
        logger.info(f"Total analysis time: {total_time:.2f}s")
        logger.info(f"Cache hit rate: {performance_stats.get('cache', {}).get('hit_rate', 0.0):.3f}")
        logger.info(f"Memory usage: {performance_stats.get('memory', {}).get('current_usage', {}).get('rss_mb', 0.0):.1f} MB")
        
        return DetectionReport(
            input_path=input_path_str, 
            final_probability=final, 
            label=label, 
            scores=scores, 
            provenance=provenance_hint(input_path_str),
            fusion_metadata=fusion_metadata,
            performance_stats=performance_stats
        )
        
    except DeepfakeDetectorError:
        logger.error(f"Detection failed for {input_path_str}")
        raise
    except Exception as e:
        total_time = time.time() - total_start_time
        log_operation("full_analysis", total_time, False, {
            'error_type': type(e).__name__,
            'error_message': str(e)
        })
        raise handle_processing_error(f"analyze video {input_path_str}", e)


def main() -> None:
    parser = argparse.ArgumentParser(description="CPU-only deepfake detector (multi-signal)")
    parser.add_argument("--input", required=True, help="Path to input video or image")
    parser.add_argument("--json", dest="json_out", default=None, help="Optional JSON output path")
    
    # Configuration options
    parser.add_argument("--config", type=str, default=None, help="Path to configuration file (JSON/YAML/TOML)")
    parser.add_argument("--profile", type=str, choices=["development", "production", "fast", "accuracy"], 
                       help="Use predefined configuration profile")
    parser.add_argument("--save-config", type=str, default=None, help="Save current configuration to file")
    
    # Processing overrides
    parser.add_argument("--target-fps", type=int, default=None, help="Target FPS for processing (overrides config)")
    parser.add_argument("--max-frames", type=int, default=None, help="Process at most N output frames (overrides config)")
    parser.add_argument("--overlay-out", type=str, default=None, help="Optional path to save an overlay MP4 for videos")
    
    # Algorithm overrides
    parser.add_argument("--no-cnn", action="store_true", help="Disable CNN detector")
    parser.add_argument("--cnn-model-url", type=str, default=None, help="Optional URL to auto-download ONNX model")
    parser.add_argument("--disable-frequency", action="store_true", help="Disable frequency analysis")
    parser.add_argument("--disable-rppg", action="store_true", help="Disable rPPG analysis") 
    parser.add_argument("--disable-avsync", action="store_true", help="Disable audio-visual sync analysis")
    parser.add_argument("--disable-geometry", action="store_true", help="Disable geometry analysis")
    
    # Logging configuration options
    parser.add_argument("--log-level", default=None, choices=["DEBUG", "INFO", "WARNING", "ERROR"], 
                       help="Set logging level (overrides config)")
    parser.add_argument("--log-dir", type=str, default=None, help="Directory for log files (overrides config)")
    parser.add_argument("--no-console-log", action="store_true", help="Disable console logging")
    parser.add_argument("--structured-logs", action="store_true", help="Use JSON structured logging")
    parser.add_argument("--no-performance-monitoring", action="store_true", help="Disable performance monitoring")
    parser.add_argument("--quiet", action="store_true", help="Minimal output (only final result)")
    
    # Environment and performance
    parser.add_argument("--environment", choices=["development", "testing", "production"], 
                       help="Set deployment environment")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--gpu", action="store_true", help="Enable GPU acceleration")
    
    args = parser.parse_args()

    try:
        # Load configuration
        if args.profile:
            # Use predefined profile
            profiles = create_profile_configs()
            if args.profile not in profiles:
                print(f"Error: Unknown profile '{args.profile}'", file=sys.stderr)
                sys.exit(1)
            config = profiles[args.profile]
            logger = get_logger(__name__)
            logger.info(f"Using configuration profile: {args.profile}")
        elif args.config:
            # Load from configuration file
            config = load_config(args.config, create_default=False)
            logger = get_logger(__name__)
            logger.info(f"Loaded configuration from: {args.config}")
        else:
            # Use default configuration with environment variable overrides
            config = load_config(create_default=True)
        
        # Apply command-line overrides
        if args.environment:
            from .config import Environment
            config.environment = Environment(args.environment)
        
        if args.debug:
            config.debug_mode = True
            config.logging.log_level = config.logging.log_level.__class__("DEBUG")
        
        if args.log_level:
            from .config import LogLevel
            config.logging.log_level = LogLevel(args.log_level)
        
        if args.log_dir:
            config.logging.log_dir = args.log_dir
            config.logging.file_output = True
        
        if args.no_console_log:
            config.logging.console_output = False
        
        if args.structured_logs:
            config.logging.structured_logs = True
        
        if args.no_performance_monitoring:
            config.logging.performance_monitoring = False
        
        if args.quiet:
            config.logging.quiet_mode = True
            config.logging.console_output = False
        
        if args.gpu:
            config.performance.gpu_acceleration = True
        
        # Algorithm toggles
        if args.no_cnn:
            config.algorithms.enable_cnn_analysis = False
        if args.disable_frequency:
            config.algorithms.enable_frequency_analysis = False
        if args.disable_rppg:
            config.algorithms.enable_rppg_analysis = False
        if args.disable_avsync:
            config.algorithms.enable_avsync_analysis = False
        if args.disable_geometry:
            config.algorithms.enable_geometry_analysis = False
        
        # Validate configuration
        issues = config.validate()
        if issues:
            print("Configuration validation warnings:", file=sys.stderr)
            for issue in issues:
                print(f"  - {issue}", file=sys.stderr)
        
        # Save configuration if requested
        if args.save_config:
            config.save(args.save_config)
            print(f"Configuration saved to: {args.save_config}")
        
        # Configure logging from config
        from .logging_config import configure_logging
        configure_logging(
            log_level=config.logging.log_level.value,
            log_dir=config.logging.log_dir,
            console_output=config.logging.console_output and not config.logging.quiet_mode,
            file_output=config.logging.file_output,
            structured_logs=config.logging.structured_logs,
            performance_monitoring=config.logging.performance_monitoring,
            max_file_size=config.logging.max_file_size,
            backup_count=config.logging.backup_count
        )
        
        logger = get_logger(__name__)
        logger.info("Deepfake detector starting")
        logger.info(f"Configuration summary: {config.get_summary()}")
        
        # Run analysis with configuration
        report = analyze_video(
            args.input,
            config=config,
            target_fps=args.target_fps,
            max_frames=args.max_frames,
            overlay_out=args.overlay_out,
            use_cnn=None if not args.no_cnn else False,
            cnn_model_url=args.cnn_model_url,
        )

        # Output results
        if not args.quiet:
            print(json.dumps(asdict(report), indent=2))
        else:
            # Minimal output for quiet mode
            print(f"{report.label},{report.final_probability:.4f}")

        if args.json_out:
            with open(args.json_out, "w", encoding="utf-8") as f:
                json.dump(asdict(report), f, indent=2)
            logger.info(f"Results saved to {args.json_out}")
        
        # Log performance metrics
        log_metrics()
        
        logger.info("Analysis completed successfully")
        
    except Exception as e:
        logger.error(f"Analysis failed: {e}", exc_info=True)
        if not config.logging.quiet_mode:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    except Exception as e:
        # Configuration or setup errors
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
