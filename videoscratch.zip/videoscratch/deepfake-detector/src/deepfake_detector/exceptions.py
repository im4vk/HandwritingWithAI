"""Custom exceptions for the deepfake detector."""

from typing import Optional, Any
import logging


class DeepfakeDetectorError(Exception):
    """Base exception for all deepfake detector errors."""
    
    def __init__(self, message: str, cause: Optional[Exception] = None, context: Optional[dict] = None):
        super().__init__(message)
        self.message = message
        self.cause = cause
        self.context = context or {}
        
        # Log the error when created
        logger = logging.getLogger(__name__)
        logger.error(f"{self.__class__.__name__}: {message}", extra={
            'cause': str(cause) if cause else None,
            'context': self.context
        })


class InputValidationError(DeepfakeDetectorError):
    """Raised when input validation fails."""
    pass


class ProcessingError(DeepfakeDetectorError):
    """Raised when processing operations fail."""
    pass


class ModelLoadError(DeepfakeDetectorError):
    """Raised when model loading fails."""
    pass


class VideoReadError(DeepfakeDetectorError):
    """Raised when video reading fails."""
    pass


class AudioExtractionError(DeepfakeDetectorError):
    """Raised when audio extraction fails."""
    pass


class FaceDetectionError(DeepfakeDetectorError):
    """Raised when face detection fails."""
    pass


class AnalysisError(DeepfakeDetectorError):
    """Raised when analysis operations fail."""
    pass


class ConfigurationError(DeepfakeDetectorError):
    """Raised when configuration is invalid."""
    pass


class DependencyError(DeepfakeDetectorError):
    """Raised when required dependencies are missing."""
    pass


def validate_input(value: Any, name: str, expected_type: type = None, 
                  min_value: float = None, max_value: float = None,
                  min_length: int = None, max_length: int = None,
                  non_empty: bool = False) -> None:
    """Validate input parameters with comprehensive checks.
    
    Args:
        value: The value to validate
        name: Name of the parameter for error messages
        expected_type: Expected type of the value
        min_value: Minimum numeric value (for numbers)
        max_value: Maximum numeric value (for numbers)
        min_length: Minimum length (for sequences)
        max_length: Maximum length (for sequences)
        non_empty: Whether the value should be non-empty
        
    Raises:
        InputValidationError: If validation fails
    """
    context = {
        'parameter': name,
        'value_type': type(value).__name__,
        'value_length': len(value) if hasattr(value, '__len__') else None
    }
    
    if value is None:
        raise InputValidationError(f"Parameter '{name}' cannot be None", context=context)
    
    if expected_type is not None and not isinstance(value, expected_type):
        raise InputValidationError(
            f"Parameter '{name}' must be of type {expected_type.__name__}, got {type(value).__name__}",
            context=context
        )
    
    # Numeric validation
    if min_value is not None or max_value is not None:
        try:
            numeric_value = float(value)
            if min_value is not None and numeric_value < min_value:
                raise InputValidationError(
                    f"Parameter '{name}' must be >= {min_value}, got {numeric_value}",
                    context=context
                )
            if max_value is not None and numeric_value > max_value:
                raise InputValidationError(
                    f"Parameter '{name}' must be <= {max_value}, got {numeric_value}",
                    context=context
                )
        except (ValueError, TypeError) as e:
            raise InputValidationError(
                f"Parameter '{name}' must be numeric for range validation",
                cause=e, context=context
            )
    
    # Length validation
    if hasattr(value, '__len__'):
        length = len(value)
        if min_length is not None and length < min_length:
            raise InputValidationError(
                f"Parameter '{name}' must have length >= {min_length}, got {length}",
                context=context
            )
        if max_length is not None and length > max_length:
            raise InputValidationError(
                f"Parameter '{name}' must have length <= {max_length}, got {length}",
                context=context
            )
        if non_empty and length == 0:
            raise InputValidationError(
                f"Parameter '{name}' cannot be empty",
                context=context
            )


def handle_processing_error(operation: str, cause: Exception, context: dict = None) -> ProcessingError:
    """Create a ProcessingError with standardized formatting.
    
    Args:
        operation: Description of the operation that failed
        cause: The underlying exception
        context: Additional context information
        
    Returns:
        ProcessingError: Formatted processing error
    """
    error_context = context or {}
    error_context.update({
        'operation': operation,
        'cause_type': type(cause).__name__
    })
    
    return ProcessingError(
        f"Failed to {operation}: {str(cause)}",
        cause=cause,
        context=error_context
    )


def check_dependencies(dependencies: dict) -> None:
    """Check that required dependencies are available.
    
    Args:
        dependencies: Dict of {name: (module, error_message)}
        
    Raises:
        DependencyError: If any dependency is missing
    """
    missing = []
    
    for name, (module, error_msg) in dependencies.items():
        if module is None:
            missing.append((name, error_msg))
    
    if missing:
        error_msg = "Missing required dependencies:\n" + "\n".join(
            f"- {name}: {msg}" for name, msg in missing
        )
        raise DependencyError(error_msg, context={'missing_dependencies': missing})


def safe_operation(operation_name: str, operation_func, *args, default_value=None, **kwargs):
    """Execute an operation safely with proper error handling.
    
    Args:
        operation_name: Name of the operation for logging
        operation_func: Function to execute
        *args: Arguments to pass to the function
        default_value: Value to return if operation fails (if None, re-raise)
        **kwargs: Keyword arguments to pass to the function
        
    Returns:
        Result of the operation or default_value
        
    Raises:
        ProcessingError: If operation fails and no default_value provided
    """
    logger = logging.getLogger(__name__)
    
    try:
        logger.debug(f"Starting operation: {operation_name}")
        result = operation_func(*args, **kwargs)
        logger.debug(f"Completed operation: {operation_name}")
        return result
        
    except DeepfakeDetectorError:
        # Re-raise our own exceptions
        raise
        
    except Exception as e:
        logger.warning(f"Operation '{operation_name}' failed: {e}")
        
        if default_value is not None:
            logger.info(f"Returning default value for failed operation: {operation_name}")
            return default_value
        else:
            raise handle_processing_error(operation_name, e)


class ErrorRecoveryStrategy:
    """Strategy for handling errors with different recovery approaches."""
    
    @staticmethod
    def return_default(default_value):
        """Return a default value when error occurs."""
        def handler(func):
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    logger = logging.getLogger(func.__module__)
                    logger.warning(f"Function {func.__name__} failed, returning default: {e}")
                    return default_value
            return wrapper
        return handler
    
    @staticmethod
    def log_and_reraise(logger_name: str = None):
        """Log error and re-raise."""
        def handler(func):
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    logger = logging.getLogger(logger_name or func.__module__)
                    logger.error(f"Function {func.__name__} failed: {e}")
                    raise
            return wrapper
        return handler
    
    @staticmethod
    def convert_to_processing_error(operation_name: str):
        """Convert any exception to ProcessingError."""
        def handler(func):
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except DeepfakeDetectorError:
                    raise
                except Exception as e:
                    raise handle_processing_error(operation_name or func.__name__, e)
            return wrapper
        return handler
