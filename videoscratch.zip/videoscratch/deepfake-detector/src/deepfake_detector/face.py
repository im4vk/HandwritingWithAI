from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple

import cv2
import numpy as np

from .exceptions import (
    FaceDetectionError,
    InputValidationError,
    ProcessingError,
    DependencyError,
    validate_input,
    handle_processing_error,
    safe_operation,
)

try:
    import mediapipe as mp  # type: ignore
    _HAS_MEDIAPIPE = True
except Exception:  # noqa: BLE001
    mp = None
    _HAS_MEDIAPIPE = False


@dataclass
class FaceFrame:
    frame_index: int
    face_crop: Optional[np.ndarray]  # BGR 224x224 or None for interpolated frames
    landmarks_xy: Optional[np.ndarray]  # (N, 2) or None
    mouth_open: Optional[float]  # scalar or None
    eye_open: Optional[float]  # scalar or None
    center_xy: Tuple[float, float]
    box_xywh: Tuple[int, int, int, int]
    confidence: float = 1.0  # Detection confidence [0,1]


@dataclass
class FaceTrack:
    frames: List[FaceFrame]


def _compute_face_crop_by_box(frame_bgr: np.ndarray, box: tuple[int, int, int, int], size: int = 224) -> np.ndarray:
    """Compute face crop from bounding box with padding.
    
    Args:
        frame_bgr: Input BGR frame
        box: Face bounding box (x, y, w, h)
        size: Target crop size (default: 224)
        
    Returns:
        Face crop resized to target size
        
    Raises:
        InputValidationError: If inputs are invalid
        FaceDetectionError: If crop computation fails
    """
    logger = logging.getLogger(__name__)
    
    try:
        validate_input(frame_bgr, "frame_bgr", np.ndarray)
        validate_input(box, "box", tuple)
        validate_input(size, "size", int, min_value=32, max_value=1024)
        
        if frame_bgr.size == 0:
            raise FaceDetectionError("Input frame is empty")
        
        if len(box) != 4:
            raise InputValidationError(f"Box must have 4 elements, got {len(box)}")
        
        x, y, w, h = box
        
        # Validate box coordinates
        if w <= 0 or h <= 0:
            raise FaceDetectionError(f"Invalid box dimensions: w={w}, h={h}")
        
        frame_height, frame_width = frame_bgr.shape[:2]
        
        # Add padding around face box
        x0 = max(0, x - int(0.1 * w))
        y0 = max(0, y - int(0.15 * h))
        x1 = min(frame_width, x + w + int(0.1 * w))
        y1 = min(frame_height, y + h + int(0.1 * h))
        
        # Ensure valid crop region
        if x1 <= x0 or y1 <= y0:
            logger.warning(f"Invalid crop region: ({x0}, {y0}) to ({x1}, {y1}), using full frame")
            crop = frame_bgr
        else:
            crop = frame_bgr[y0:y1, x0:x1]
            
        if crop.size == 0:
            logger.warning("Empty crop region, using full frame")
            crop = frame_bgr
            
        # Resize to target size
        crop_resized = cv2.resize(crop, (size, size), interpolation=cv2.INTER_LINEAR)
        
        if crop_resized.size == 0:
            raise FaceDetectionError("Failed to resize face crop")
        
        return crop_resized
        
    except (InputValidationError, FaceDetectionError):
        raise
    except Exception as e:
        raise handle_processing_error("compute face crop", e)


def _mouth_metric(face_crop_bgr: np.ndarray) -> Optional[float]:
    """Compute mouth openness metric using smile cascade.
    
    Args:
        face_crop_bgr: Face crop in BGR format
        
    Returns:
        Mouth openness metric (0.0-1.0) or None if detection fails
    """
    logger = logging.getLogger(__name__)
    
    def _compute_mouth_metric():
        validate_input(face_crop_bgr, "face_crop_bgr", np.ndarray)
        
        if face_crop_bgr.size == 0:
            raise FaceDetectionError("Empty face crop provided")
        
        gray = cv2.cvtColor(face_crop_bgr, cv2.COLOR_BGR2GRAY)
        h = gray.shape[0]
        
        if h == 0:
            raise FaceDetectionError("Face crop has zero height")
        
        # Focus on lower half of face for mouth region
        roi = gray[h // 2 : h, :]
        
        # Load smile cascade
        cascade_path = cv2.data.haarcascades + "haarcascade_smile.xml"
        smile_cascade = cv2.CascadeClassifier(cascade_path)
        
        if smile_cascade.empty():
            raise FaceDetectionError(f"Could not load smile cascade from {cascade_path}")
        
        # Detect smiles (proxy for mouth openness)
        smiles = smile_cascade.detectMultiScale(roi, scaleFactor=1.2, minNeighbors=20)
        
        if len(smiles) == 0:
            logger.debug("No mouth/smile detected, returning 0.0")
            return 0.0
        
        # Use largest detection
        _, _, _, hh = max(smiles, key=lambda b: b[2] * b[3])
        metric = float(hh) / float(h)
        
        # Clamp to valid range
        return max(0.0, min(1.0, metric))
    
    return safe_operation("compute mouth metric", _compute_mouth_metric, default_value=None)


def _eye_metric(face_crop_bgr: np.ndarray) -> Optional[float]:
    """Compute eye openness metric using eye cascade.
    
    Args:
        face_crop_bgr: Face crop in BGR format
        
    Returns:
        Eye openness metric (0.0-1.0) or None if detection fails
    """
    logger = logging.getLogger(__name__)
    
    def _compute_eye_metric():
        validate_input(face_crop_bgr, "face_crop_bgr", np.ndarray)
        
        if face_crop_bgr.size == 0:
            raise FaceDetectionError("Empty face crop provided")
        
        gray = cv2.cvtColor(face_crop_bgr, cv2.COLOR_BGR2GRAY)
        h = gray.shape[0]
        
        if h == 0:
            raise FaceDetectionError("Face crop has zero height")
        
        # Load eye cascade
        cascade_path = cv2.data.haarcascades + "haarcascade_eye.xml"
        eye_cascade = cv2.CascadeClassifier(cascade_path)
        
        if eye_cascade.empty():
            raise FaceDetectionError(f"Could not load eye cascade from {cascade_path}")
        
        # Detect eyes
        eyes = eye_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=10, minSize=(20, 20))
        
        if len(eyes) == 0:
            logger.debug("No eyes detected, returning 0.0")
            return 0.0
        
        # Use up to 2 largest eye detections
        sorted_eyes = sorted(eyes, key=lambda e: e[2] * e[3], reverse=True)
        top_eyes = sorted_eyes[:2]
        
        total_h = sum(int(e[3]) for e in top_eyes)
        metric = float(total_h) / float(h)
        
        # Clamp to valid range
        return max(0.0, min(1.0, metric))
    
    return safe_operation("compute eye metric", _compute_eye_metric, default_value=None)


def _mediapipe_track(frames_bgr: List[np.ndarray]) -> Optional[FaceTrack]:
    if not _HAS_MEDIAPIPE:
        return None
    face_mesh = mp.solutions.face_mesh.FaceMesh(
        static_image_mode=False,
        refine_landmarks=True,
        max_num_faces=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )
    track_frames: List[FaceFrame] = []
    for idx, frame_bgr in enumerate(frames_bgr):
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        result = face_mesh.process(frame_rgb)
        if not result.multi_face_landmarks:
            continue
        lm = result.multi_face_landmarks[0]
        h, w = frame_bgr.shape[:2]
        pts = np.array([[p.x * w, p.y * h] for p in lm.landmark], dtype=np.float32)
        x, y, wbox, hbox = int(np.clip(pts[:, 0].min() - 10, 0, w-1)), int(np.clip(pts[:, 1].min() - 10, 0, h-1)), \
                            int(np.clip(pts[:, 0].max() - pts[:, 0].min() + 20, 1, w)), int(np.clip(pts[:, 1].max() - pts[:, 1].min() + 20, 1, h))
        face_crop = _compute_face_crop_by_box(frame_bgr, (x, y, wbox, hbox))
        # Simple mouth openness proxy using inner/outer lip indices
        upper_idxs = [13, 81, 82]
        lower_idxs = [14, 178, 87] if 14 < pts.shape[0] else [178, 87]
        upper_y = np.mean([pts[i, 1] for i in upper_idxs if i < pts.shape[0]])
        lower_y = np.mean([pts[i, 1] for i in lower_idxs if i < pts.shape[0]])
        mouth_open = float(max(0.0, lower_y - upper_y))
        center_xy = (float(x + wbox / 2.0), float(y + hbox / 2.0))
        track_frames.append(FaceFrame(idx, face_crop, pts, mouth_open, None, center_xy, (x, y, wbox, hbox), confidence=0.9))
    face_mesh.close()
    if not track_frames:
        return None
    return FaceTrack(track_frames)


def _haar_track(frames_bgr: List[np.ndarray]) -> Optional[FaceTrack]:
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    if face_cascade.empty():
        return None
    track_frames: List[FaceFrame] = []
    for idx, frame_bgr in enumerate(frames_bgr):
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))
        if len(faces) == 0:
            continue
        x, y, w, h = max(faces, key=lambda b: b[2] * b[3])
        face_crop = _compute_face_crop_by_box(frame_bgr, (x, y, w, h))
        center_xy = (float(x + w / 2.0), float(y + h / 2.0))
        mouth_open = _mouth_metric(face_crop)
        eye_open = _eye_metric(face_crop)
        track_frames.append(FaceFrame(idx, face_crop, None, mouth_open, eye_open, center_xy, (int(x), int(y), int(w), int(h)), confidence=0.8))
    if not track_frames:
        return None
    return FaceTrack(track_frames)


def detect_face_track(frames_bgr: List[np.ndarray], 
                     use_temporal_tracking: bool = True,
                     frame_timestamps: Optional[List[float]] = None) -> Optional[FaceTrack]:
    """Detect and track faces across video frames.
    
    Args:
        frames_bgr: List of BGR frames
        use_temporal_tracking: Whether to use enhanced temporal tracking
        frame_timestamps: Optional timestamps for temporal tracking
        
    Returns:
        FaceTrack containing detected faces, or None if no faces found
        
    Raises:
        InputValidationError: If input parameters are invalid
        FaceDetectionError: If face detection fails
    """
    logger = logging.getLogger(__name__)
    
    # Input validation
    validate_input(frames_bgr, "frames_bgr", list, non_empty=True)
    
    if not all(isinstance(frame, np.ndarray) for frame in frames_bgr):
        raise InputValidationError("All frames must be numpy arrays")
    
    if not all(frame.size > 0 for frame in frames_bgr):
        raise InputValidationError("All frames must be non-empty")
    
    if frame_timestamps is not None:
        validate_input(frame_timestamps, "frame_timestamps", list)
        if len(frame_timestamps) != len(frames_bgr):
            raise InputValidationError("Frame timestamps must match number of frames")
    
    logger.info(f"Detecting faces in {len(frames_bgr)} frames (temporal_tracking={use_temporal_tracking})")
    
    # Use temporal tracking for video sequences
    if use_temporal_tracking and len(frames_bgr) > 1:
        try:
            from .temporal_tracking import detect_face_track_temporal
            temporal_track = detect_face_track_temporal(frames_bgr, frame_timestamps, fill_gaps=True)
            if temporal_track:
                logger.info(f"Temporal tracking successful: {len(temporal_track.frames)} faces")
                return temporal_track
            else:
                logger.warning("Temporal tracking failed, falling back to frame-by-frame detection")
        except Exception as e:
            logger.warning(f"Temporal tracking error: {e}, falling back to frame-by-frame detection")
    
    try:
        # Fallback to original frame-by-frame detection
        # Prefer MediaPipe if available for better accuracy
        if _HAS_MEDIAPIPE:
            logger.debug("Using MediaPipe for face detection")
            track = safe_operation("MediaPipe face tracking", _mediapipe_track, frames_bgr, default_value=None)
            
            if track is not None:
                logger.info(f"MediaPipe detected {len(track.frames)} face frames")
                return track
            else:
                logger.warning("MediaPipe face detection failed, falling back to Haar cascades")
        else:
            logger.debug("MediaPipe not available, using Haar cascades")
        
        # Fallback to Haar cascades
        logger.debug("Using Haar cascades for face detection")
        track = safe_operation("Haar cascade face tracking", _haar_track, frames_bgr, default_value=None)
        
        if track is not None:
            logger.info(f"Haar cascades detected {len(track.frames)} face frames")
            return track
        else:
            logger.warning("No faces detected in any frames")
            return None
            
    except Exception as e:
        raise handle_processing_error("detect face track", e)
