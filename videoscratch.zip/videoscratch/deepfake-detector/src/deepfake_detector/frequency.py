from __future__ import annotations

from typing import List

import cv2
import numpy as np


def _radial_power_ratio(gray: np.ndarray, high_cut: float = 0.3) -> float:
    """Compute ratio of high-frequency power to total power.

    gray: 2D image [H, W], float32 in [0, 1]
    high_cut: normalized radial frequency threshold (0..0.5), where > high_cut counted as high-freq
    """
    h, w = gray.shape
    f = np.fft.fftshift(np.fft.fft2(gray))
    psd = np.abs(f) ** 2

    cy, cx = h // 2, w // 2
    yy, xx = np.mgrid[0:h, 0:w]
    rr = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    r_norm = rr / rr.max()  # 0..1

    high_mask = r_norm >= high_cut

    total = float(psd.sum() + 1e-8)
    high = float(psd[high_mask].sum())
    return high / total


def frequency_fake_score(face_crops_bgr: List[np.ndarray]) -> float:
    """Return a heuristic deepfake-likelihood score [0,1] from frequency domain.

    Heuristic: real faces tend to have a moderate high-frequency ratio; too low (over-smoothing)
    or too high (noisy/over-sharpened) may indicate synthesis.
    """
    if not face_crops_bgr:
        return 0.5

    ratios = []
    for crop in face_crops_bgr:
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        gray = cv2.resize(gray, (224, 224), interpolation=cv2.INTER_AREA)
        gray_f = gray.astype(np.float32) / 255.0
        r = _radial_power_ratio(gray_f, high_cut=0.35)
        ratios.append(r)

    r_mean = float(np.mean(ratios))

    # Map ratio to fake-likelihood. Target "natural" range ~ [0.10, 0.30]
    lo, hi = 0.10, 0.30
    if r_mean < lo:
        # Below natural → smoothed → more fake-like
        score = np.clip((lo - r_mean) / lo, 0.0, 1.0)
    elif r_mean > hi:
        # Above natural → over-sharpened/noisy → more fake-like
        score = np.clip((r_mean - hi) / (0.6 - hi), 0.0, 1.0)
    else:
        # Inside band → low fake-likelihood
        score = 0.2 * (1.0 - (r_mean - lo) / (hi - lo))

    return float(score)
