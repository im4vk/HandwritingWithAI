from __future__ import annotations

import logging
import math
from typing import Dict, Optional, Any, Union
import numpy as np

from .exceptions import (
    InputValidationError,
    AnalysisError,
    validate_input,
    handle_processing_error,
)

# Import advanced fusion capabilities
try:
    from .advanced_fusion import (
        AdvancedFusion,
        AlgorithmResult,
        SignalQuality,
        FusionMethod,
        create_algorithm_result
    )
    _HAS_ADVANCED_FUSION = True
except ImportError:
    _HAS_ADVANCED_FUSION = False


def _sigmoid(x: float) -> float:
    """Sigmoid activation function with overflow protection.
    
    Args:
        x: Input value
        
    Returns:
        Sigmoid output in range (0, 1)
        
    Raises:
        AnalysisError: If computation fails
    """
    try:
        validate_input(x, "x", (int, float))
        
        # Clamp x to prevent overflow
        x_clamped = max(-500.0, min(500.0, float(x)))
        
        if x_clamped != x:
            logger = logging.getLogger(__name__)
            logger.warning(f"Sigmoid input {x} clamped to {x_clamped} to prevent overflow")
        
        result = 1.0 / (1.0 + math.exp(-x_clamped))
        
        if not (0.0 <= result <= 1.0):
            raise AnalysisError(f"Sigmoid produced invalid result: {result}")
        
        return result
        
    except (InputValidationError, AnalysisError):
        raise
    except Exception as e:
        raise handle_processing_error("compute sigmoid", e)


def fuse_scores(scores: Dict[str, float]) -> float:
    """Fuse individual fake-likelihood scores into a final probability.

    Args:
        scores: Dictionary of detection scores in [0,1] range
                Keys: "freq", "rppg", "av", "geom" (cnn scores ignored)
                Values: Higher values indicate more fake-like
                
    Returns:
        Final probability in [0,1] range where higher = more fake-like
        
    Raises:
        InputValidationError: If input parameters are invalid
        AnalysisError: If fusion computation fails
    """
    logger = logging.getLogger(__name__)
    
    try:
        validate_input(scores, "scores", dict)
        
        # Define weights for each detection method
        w = {
            "freq": 1.0,
            "rppg": 1.0,
            "av": 1.0,
            "geom": 1.0,
        }
        
        # Track valid scores for logging
        valid_scores = {}
        invalid_scores = {}
        
        # Center around 0.5 baseline and accumulate weighted deviations
        z = 0.0
        
        for key, val in scores.items():
            if key in w:
                # Validate individual score
                if val is None:
                    logger.debug(f"Skipping None score for {key}")
                    continue
                    
                try:
                    score_val = float(val)
                    
                    # Check for NaN/Inf
                    if np.isnan(score_val) or np.isinf(score_val):
                        logger.warning(f"Invalid score for {key}: {score_val}, skipping")
                        invalid_scores[key] = score_val
                        continue
                    
                    # Clamp to valid range [0, 1]
                    if not (0.0 <= score_val <= 1.0):
                        logger.warning(f"Score for {key} out of range [0,1]: {score_val}, clamping")
                        score_val = max(0.0, min(1.0, score_val))
                    
                    # Apply weight and center around 0.5
                    weighted_deviation = w[key] * (score_val - 0.5)
                    z += weighted_deviation
                    
                    valid_scores[key] = score_val
                    logger.debug(f"Applied score {key}: {score_val} -> deviation {weighted_deviation}")
                    
                except (ValueError, TypeError) as e:
                    logger.warning(f"Could not convert score for {key} to float: {val}, skipping")
                    invalid_scores[key] = val
                    continue
            else:
                logger.debug(f"Ignoring unknown score key: {key}")
        
        logger.info(f"Fusion using {len(valid_scores)} valid scores: {list(valid_scores.keys())}")
        
        if invalid_scores:
            logger.warning(f"Skipped {len(invalid_scores)} invalid scores: {invalid_scores}")
        
        # If no valid scores, return neutral probability
        if not valid_scores:
            logger.warning("No valid scores provided, returning neutral probability 0.5")
            return 0.5
        
        # Apply sigmoid to convert accumulated deviation to probability
        logger.debug(f"Accumulated weighted deviation: {z}")
        prob = _sigmoid(z)
        
        # Final validation
        if not (0.0 <= prob <= 1.0):
            raise AnalysisError(f"Fusion produced invalid probability: {prob}")
        
        logger.info(f"Final fusion probability: {prob:.4f}")
        return float(prob)
        
    except (InputValidationError, AnalysisError):
        raise
    except Exception as e:
        raise handle_processing_error("fuse detection scores", e)


def fuse_scores_with_config(scores: Dict[str, float], 
                           config: Optional[Any] = None,
                           quality_metrics: Optional[Dict[str, Dict[str, float]]] = None,
                           use_advanced: bool = False) -> Union[float, Dict[str, Any]]:
    """Enhanced fusion with configuration support and quality metrics.
    
    Args:
        scores: Dictionary of detection scores
        config: Configuration object with algorithm weights and fusion settings
        quality_metrics: Dictionary of quality metrics per algorithm
        use_advanced: Whether to use advanced fusion methods
        
    Returns:
        Final probability or (probability, metadata) if advanced fusion is used
        
    Raises:
        InputValidationError: If input parameters are invalid
        AnalysisError: If fusion computation fails
    """
    logger = logging.getLogger(__name__)
    
    try:
        # Use advanced fusion if available and requested
        if use_advanced and _HAS_ADVANCED_FUSION and quality_metrics:
            return _fuse_with_advanced_methods(scores, config, quality_metrics)
        
        # Use configuration weights if available
        if config and hasattr(config, 'algorithms'):
            weights = {
                "freq": config.algorithms.frequency_analysis_weight,
                "rppg": config.algorithms.rppg_analysis_weight,
                "av": config.algorithms.avsync_analysis_weight,
                "geom": config.algorithms.geometry_analysis_weight,
                "cnn": config.algorithms.cnn_analysis_weight,
            }
            return _fuse_scores_weighted(scores, weights)
        
        # Fall back to simple fusion
        return fuse_scores(scores)
        
    except Exception as e:
        raise handle_processing_error("enhanced score fusion", e)


def _fuse_scores_weighted(scores: Dict[str, float], weights: Dict[str, float]) -> float:
    """Weighted fusion with custom weights.
    
    Args:
        scores: Dictionary of detection scores
        weights: Dictionary of algorithm weights
        
    Returns:
        Final probability
    """
    logger = logging.getLogger(__name__)
    
    total_weight = 0.0
    weighted_sum = 0.0
    used_algorithms = []
    
    for key, score in scores.items():
        if key in weights and score is not None:
            try:
                score_val = float(score)
                if not (np.isnan(score_val) or np.isinf(score_val)):
                    weight = weights[key]
                    weighted_sum += weight * score_val
                    total_weight += weight
                    used_algorithms.append(key)
                    logger.debug(f"Applied weighted score {key}: {score_val} * {weight}")
            except (ValueError, TypeError):
                logger.warning(f"Invalid score for {key}: {score}")
                continue
    
    if total_weight == 0:
        logger.warning("No valid weighted scores, returning neutral probability")
        return 0.5
    
    prob = weighted_sum / total_weight
    
    # Apply sigmoid transformation to weighted sum (centered around 0.5)
    z = (prob - 0.5) * len(used_algorithms)  # Scale by number of algorithms
    final_prob = _sigmoid(z)
    
    logger.info(f"Weighted fusion using {len(used_algorithms)} algorithms: {final_prob:.4f}")
    return final_prob


def _fuse_with_advanced_methods(scores: Dict[str, float], 
                               config: Optional[Any],
                               quality_metrics: Dict[str, Dict[str, float]]) -> Dict[str, Any]:
    """Use advanced fusion methods with quality metrics.
    
    Args:
        scores: Dictionary of detection scores
        config: Configuration object
        quality_metrics: Quality metrics per algorithm
        
    Returns:
        Dictionary with probability and metadata
    """
    logger = logging.getLogger(__name__)
    
    # Create AlgorithmResult objects
    results = {}
    for name, score in scores.items():
        if score is None or np.isnan(score) or np.isinf(score):
            continue
            
        # Extract quality metrics for this algorithm
        quality_data = quality_metrics.get(name, {})
        
        # Create quality object
        quality = SignalQuality(
            confidence=quality_data.get('confidence'),
            temporal_consistency=quality_data.get('temporal_consistency'),
            data_completeness=quality_data.get('data_completeness'),
            snr=quality_data.get('snr'),
            artifact_level=quality_data.get('artifact_level'),
            processing_quality=quality_data.get('processing_quality')
        )
        
        results[name] = AlgorithmResult(score=score, quality=quality)
    
    # Determine fusion method from config
    fusion_method = FusionMethod.QUALITY_ADAPTIVE
    if config and hasattr(config, 'algorithms'):
        # Could add fusion method to config in future
        pass
    
    # Create base weights from config
    base_weights = None
    if config and hasattr(config, 'algorithms'):
        base_weights = {
            "freq": config.algorithms.frequency_analysis_weight,
            "rppg": config.algorithms.rppg_analysis_weight,
            "av": config.algorithms.avsync_analysis_weight,
            "geom": config.algorithms.geometry_analysis_weight,
            "cnn": config.algorithms.cnn_analysis_weight,
        }
    
    # Perform advanced fusion
    fusion_engine = AdvancedFusion(
        base_weights=base_weights,
        fusion_method=fusion_method,
        min_quality_threshold=0.3
    )
    
    probability, metadata = fusion_engine.fuse_scores(results)
    
    logger.info(f"Advanced fusion complete: {probability:.4f} using {metadata.get('fusion_method')}")
    
    return {
        "probability": probability,
        "metadata": metadata,
        "algorithms_used": metadata.get("algorithms_used", []),
        "quality_scores": {name: result.quality.compute_overall_quality() 
                          for name, result in results.items()},
        "fusion_method": metadata.get("fusion_method")
    }


def estimate_score_quality(score: float, 
                          algorithm_name: str,
                          processing_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, float]:
    """Estimate quality metrics for a detection score.
    
    Args:
        score: Detection score [0,1]
        algorithm_name: Name of the algorithm
        processing_metadata: Optional processing metadata
        
    Returns:
        Dictionary of estimated quality metrics
    """
    metadata = processing_metadata or {}
    quality = {}
    
    # Confidence estimation based on score extremity
    # Scores closer to 0 or 1 are considered more confident
    score_extremity = 2.0 * abs(score - 0.5)  # Range [0,1]
    quality['confidence'] = score_extremity
    
    # Data completeness from metadata
    if 'frames_processed' in metadata and 'total_frames' in metadata:
        quality['data_completeness'] = metadata['frames_processed'] / max(1, metadata['total_frames'])
    else:
        quality['data_completeness'] = 1.0  # Assume complete if unknown
    
    # Processing quality estimation
    if 'processing_errors' in metadata:
        error_rate = metadata['processing_errors'] / max(1, metadata.get('total_operations', 1))
        quality['processing_quality'] = 1.0 - error_rate
    else:
        quality['processing_quality'] = 1.0  # Assume good quality if unknown
    
    # Algorithm-specific quality estimation
    if algorithm_name == 'freq':
        # Frequency analysis quality could be based on image quality
        quality['snr'] = metadata.get('image_quality_score', 15.0)  # Default moderate SNR
    elif algorithm_name == 'rppg':
        # rPPG quality depends on face stability and lighting
        quality['temporal_consistency'] = metadata.get('face_stability', 0.8)
    elif algorithm_name == 'av':
        # Audio-visual sync depends on audio quality and lip detection
        quality['snr'] = metadata.get('audio_snr', 10.0)
        quality['temporal_consistency'] = metadata.get('lip_detection_rate', 0.7)
    elif algorithm_name == 'geom':
        # Geometry analysis depends on landmark detection quality
        quality['data_completeness'] = metadata.get('landmark_detection_rate', 0.9)
        quality['temporal_consistency'] = metadata.get('tracking_stability', 0.8)
    elif algorithm_name == 'cnn':
        # CNN quality could be based on model confidence
        quality['confidence'] = metadata.get('model_confidence', score_extremity)
    
    # Artifact level estimation (inverse of processing quality)
    quality['artifact_level'] = 1.0 - quality.get('processing_quality', 1.0)
    
    return quality


def analyze_fusion_reliability(scores: Dict[str, float],
                              quality_metrics: Optional[Dict[str, Dict[str, float]]] = None) -> Dict[str, Any]:
    """Analyze the reliability of fusion results.
    
    Args:
        scores: Detection scores
        quality_metrics: Optional quality metrics
        
    Returns:
        Dictionary with reliability analysis
    """
    if not scores:
        return {"reliable": False, "reason": "No scores provided"}
    
    valid_scores = []
    algorithm_count = 0
    quality_analysis = {}
    
    for name, score in scores.items():
        if score is not None and not (np.isnan(score) or np.isinf(score)):
            valid_scores.append(score)
            algorithm_count += 1
            
            # Analyze quality if available
            if quality_metrics and name in quality_metrics:
                quality_data = quality_metrics[name]
                overall_quality = SignalQuality(**quality_data).compute_overall_quality()
                quality_analysis[name] = overall_quality
    
    if not valid_scores:
        return {"reliable": False, "reason": "No valid scores"}
    
    # Calculate score statistics
    score_mean = np.mean(valid_scores)
    score_std = np.std(valid_scores)
    score_range = max(valid_scores) - min(valid_scores)
    
    # Reliability criteria
    min_algorithms = 2
    max_score_std = 0.3
    min_avg_quality = 0.5
    
    reliability_issues = []
    
    if algorithm_count < min_algorithms:
        reliability_issues.append(f"Too few algorithms ({algorithm_count} < {min_algorithms})")
    
    if score_std > max_score_std:
        reliability_issues.append(f"High score variance ({score_std:.3f} > {max_score_std})")
    
    if quality_analysis:
        avg_quality = np.mean(list(quality_analysis.values()))
        if avg_quality < min_avg_quality:
            reliability_issues.append(f"Low average quality ({avg_quality:.3f} < {min_avg_quality})")
    
    reliable = len(reliability_issues) == 0
    
    return {
        "reliable": reliable,
        "issues": reliability_issues,
        "algorithm_count": algorithm_count,
        "score_statistics": {
            "mean": score_mean,
            "std": score_std,
            "range": score_range,
            "min": min(valid_scores),
            "max": max(valid_scores)
        },
        "quality_analysis": quality_analysis,
        "avg_quality": np.mean(list(quality_analysis.values())) if quality_analysis else None
    }
