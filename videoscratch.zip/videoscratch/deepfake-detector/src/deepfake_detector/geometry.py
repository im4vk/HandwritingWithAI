from __future__ import annotations

from typing import List, Optional

import numpy as np


def geometry_fake_score(landmarks_xy_list: Optional[List[np.ndarray]] | Optional[List[None]], fps: float, *,
                        eye_open_series: Optional[List[Optional[float]]] = None,
                        centers_xy: Optional[List[tuple[float, float]]] = None) -> float:
    # Without landmarks, rely on eye openness and face center jitter
    if eye_open_series is None or centers_xy is None or len(eye_open_series) < 10 or len(centers_xy) < 10:
        return 0.5

    # Blink-like behavior: variance in eye_open; too flat may indicate artifacts
    eye_vals = np.array([v if v is not None else 0.0 for v in eye_open_series], dtype=np.float32)
    eye_std = float(np.std(eye_vals))
    # Map eye_std to fake-likelihood: very low variance => more fake
    eye_fake = float(np.clip((0.05 - eye_std) / 0.05, 0.0, 1.0))

    # Center jitter magnitude per frame
    centers = np.array(centers_xy, dtype=np.float32)
    displacements = np.linalg.norm(np.diff(centers, axis=0), axis=1)
    mean_disp = float(np.mean(displacements))
    # Very low jitter over long sequences can indicate over-stabilized synthesis
    jitter_fake = float(np.clip((1.5 - mean_disp) / 1.5, 0.0, 1.0))

    score = float(np.clip(0.6 * jitter_fake + 0.4 * eye_fake, 0.0, 1.0))
    return score
