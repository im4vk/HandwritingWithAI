from __future__ import annotations

import logging
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import ffmpeg
import librosa
import numpy as np

from .exceptions import (
    VideoReadError,
    AudioExtractionError,
    InputValidationError,
    validate_input,
    handle_processing_error,
)


@dataclass
class VideoData:
    frames_bgr: List[np.ndarray]
    frame_timestamps_s: List[float]
    fps: float
    audio_mono: Optional[np.ndarray]
    audio_sr: Optional[int]


def read_video(
    input_path: str | Path,
    target_fps: int = 15,
    max_frames: Optional[int] = None,
) -> VideoData:
    """Load video frames (downsampled) and mono audio.

    - Frames are BGR (OpenCV convention)
    - Audio is mono float32, sampled at 16 kHz
    
    Args:
        input_path: Path to the video file
        target_fps: Target framerate for output (default: 15)
        max_frames: Maximum number of frames to read (default: None)
        
    Returns:
        VideoData: Contains frames, timestamps, fps, and audio
        
    Raises:
        InputValidationError: If input parameters are invalid
        VideoReadError: If video cannot be read or processed
    """
    logger = logging.getLogger(__name__)
    
    # Input validation
    validate_input(input_path, "input_path")
    validate_input(target_fps, "target_fps", int, min_value=1, max_value=120)
    if max_frames is not None:
        validate_input(max_frames, "max_frames", int, min_value=1)
    
    input_path_str = str(input_path)
    input_file = Path(input_path_str)
    
    # Check if file exists
    if not input_file.exists():
        raise VideoReadError(f"Video file does not exist: {input_path_str}")
    
    if not input_file.is_file():
        raise VideoReadError(f"Path is not a file: {input_path_str}")

    logger.info(f"Reading video: {input_path_str} (target_fps={target_fps}, max_frames={max_frames})")

    try:
        cap = cv2.VideoCapture(input_path_str)
        if not cap.isOpened():
            raise VideoReadError(f"Cannot open video file: {input_path_str}")

        src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
        
        logger.debug(f"Video properties: src_fps={src_fps}, total_frames={total_frames}")
        
        if src_fps <= 0:
            logger.warning(f"Invalid source FPS ({src_fps}), using default 30.0")
            src_fps = 30.0

        frame_interval = max(1, int(round(src_fps / float(target_fps))))
        frames_bgr: List[np.ndarray] = []
        frame_timestamps_s: List[float] = []

        frame_idx = 0
        out_idx = 0
        
        while True:
            ok, frame = cap.read()
            if not ok:
                break
                
            if frame is None:
                logger.warning(f"Received None frame at index {frame_idx}")
                frame_idx += 1
                continue
                
            if frame_idx % frame_interval == 0:
                frames_bgr.append(frame.copy())  # Ensure we own the memory
                frame_timestamps_s.append(out_idx / float(target_fps))
                out_idx += 1
                
                if max_frames is not None and len(frames_bgr) >= max_frames:
                    logger.debug(f"Reached max_frames limit: {max_frames}")
                    break
                    
            frame_idx += 1

        cap.release()
        
        if not frames_bgr:
            raise VideoReadError(f"No frames could be read from video: {input_path_str}")
        
        logger.info(f"Successfully read {len(frames_bgr)} frames from video")

        # Extract audio (may fail, but video reading should still succeed)
        audio, sr = _extract_audio_mono(input_path_str, target_sr=16_000)
        
        if audio is None:
            logger.warning(f"Could not extract audio from video: {input_path_str}")

        return VideoData(
            frames_bgr=frames_bgr,
            frame_timestamps_s=frame_timestamps_s,
            fps=float(target_fps),
            audio_mono=audio,
            audio_sr=sr,
        )
        
    except VideoReadError:
        raise
    except Exception as e:
        raise handle_processing_error(f"read video from {input_path_str}", e)


def _extract_audio_mono(input_path: str, target_sr: int = 16_000) -> Tuple[Optional[np.ndarray], Optional[int]]:
    """Extract mono audio from video file.
    
    Args:
        input_path: Path to the video file
        target_sr: Target sample rate (default: 16000 Hz)
        
    Returns:
        Tuple of (audio_array, sample_rate) or (None, None) if extraction fails
    """
    logger = logging.getLogger(__name__)
    
    try:
        validate_input(input_path, "input_path", str, non_empty=True)
        validate_input(target_sr, "target_sr", int, min_value=8000, max_value=48000)
        
        logger.debug(f"Extracting audio from {input_path} (target_sr={target_sr})")
        
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as tmp:
            try:
                # Run ffmpeg to extract audio
                (
                    ffmpeg
                    .input(input_path)
                    .output(
                        tmp.name,
                        ac=1,
                        ar=target_sr,
                        format="wav",
                        loglevel="error",
                    )
                    .overwrite_output()
                    .run(quiet=True, capture_stdout=True, capture_stderr=True)
                )
                
                # Load with librosa
                audio, sr = librosa.load(tmp.name, sr=target_sr, mono=True)
                
                if audio is None or len(audio) == 0:
                    logger.warning(f"Empty audio extracted from {input_path}")
                    return None, None
                
                logger.debug(f"Successfully extracted {len(audio)} audio samples at {sr} Hz")
                return audio.astype(np.float32, copy=False), int(sr)
                
            except ffmpeg.Error as e:
                logger.warning(f"FFmpeg error extracting audio from {input_path}: {e}")
                return None, None
                
    except InputValidationError:
        logger.error(f"Invalid parameters for audio extraction: input_path={input_path}, target_sr={target_sr}")
        return None, None
    except Exception as e:
        logger.warning(f"Unexpected error extracting audio from {input_path}: {e}")
        return None, None


def is_image_file(path: str | Path) -> bool:
    ext = str(path).lower().split(".")[-1]
    return ext in {"jpg", "jpeg", "png", "bmp", "webp"}


def read_image(input_path: str | Path) -> VideoData:
    """Read a single image file and wrap it as VideoData.
    
    Args:
        input_path: Path to the image file
        
    Returns:
        VideoData: Single frame wrapped as video data
        
    Raises:
        InputValidationError: If input parameters are invalid
        VideoReadError: If image cannot be read
    """
    logger = logging.getLogger(__name__)
    
    validate_input(input_path, "input_path")
    
    input_path_str = str(input_path)
    input_file = Path(input_path_str)
    
    # Check file existence and type
    if not input_file.exists():
        raise VideoReadError(f"Image file does not exist: {input_path_str}")
    
    if not input_file.is_file():
        raise VideoReadError(f"Path is not a file: {input_path_str}")
    
    if not is_image_file(input_path_str):
        raise VideoReadError(f"File is not a supported image format: {input_path_str}")
    
    logger.info(f"Reading image: {input_path_str}")
    
    try:
        img = cv2.imread(input_path_str, cv2.IMREAD_COLOR)
        if img is None:
            raise VideoReadError(f"Cannot read image (corrupted or unsupported format): {input_path_str}")
        
        if img.size == 0:
            raise VideoReadError(f"Image has zero size: {input_path_str}")
        
        logger.debug(f"Successfully read image with shape {img.shape}")
        
        return VideoData(
            frames_bgr=[img.copy()],  # Ensure we own the memory
            frame_timestamps_s=[0.0],
            fps=0.0,
            audio_mono=None,
            audio_sr=None,
        )
        
    except VideoReadError:
        raise
    except Exception as e:
        raise handle_processing_error(f"read image from {input_path_str}", e)


def write_overlay_video(frames_bgr: List[np.ndarray], out_path: str | Path, fps: float) -> None:
    """Write frames to a video file.
    
    Args:
        frames_bgr: List of BGR frames to write
        out_path: Output video file path
        fps: Frame rate for the output video
        
    Raises:
        InputValidationError: If input parameters are invalid
        VideoReadError: If video cannot be written
    """
    logger = logging.getLogger(__name__)
    
    validate_input(frames_bgr, "frames_bgr", list, non_empty=True)
    validate_input(out_path, "out_path")
    validate_input(fps, "fps", (int, float), min_value=1.0, max_value=120.0)
    
    if not frames_bgr:
        logger.warning("No frames provided for video writing")
        return
    
    output_path_str = str(out_path)
    output_file = Path(output_path_str)
    
    # Create output directory if it doesn't exist
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Writing {len(frames_bgr)} frames to video: {output_path_str} (fps={fps})")
    
    try:
        # Validate frame dimensions
        h, w = frames_bgr[0].shape[:2]
        if h <= 0 or w <= 0:
            raise VideoReadError(f"Invalid frame dimensions: {w}x{h}")
        
        # Check all frames have same dimensions
        for i, frame in enumerate(frames_bgr):
            if frame.shape[:2] != (h, w):
                raise VideoReadError(f"Frame {i} has different dimensions {frame.shape[:2]} vs expected ({h}, {w})")
        
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        effective_fps = fps if fps > 0 else 15.0
        
        vw = cv2.VideoWriter(output_path_str, fourcc, effective_fps, (w, h))
        
        if not vw.isOpened():
            raise VideoReadError(f"Cannot open video writer for: {output_path_str}")
        
        frames_written = 0
        for i, frame in enumerate(frames_bgr):
            if frame is None:
                logger.warning(f"Skipping None frame at index {i}")
                continue
                
            vw.write(frame)
            frames_written += 1
        
        vw.release()
        
        if frames_written == 0:
            raise VideoReadError("No valid frames were written to video")
        
        logger.info(f"Successfully wrote {frames_written} frames to {output_path_str}")
        
    except VideoReadError:
        raise
    except Exception as e:
        raise handle_processing_error(f"write video to {output_path_str}", e)


def write_video(frames_bgr: List[np.ndarray], output_path: str | Path, fps: float = 15.0) -> None:
    """Write video frames to file.
    
    Args:
        frames_bgr: List of BGR frames
        output_path: Output video path
        fps: Frames per second
        
    Raises:
        VideoReadError: If writing fails
    """
    write_overlay_video(frames_bgr, output_path, fps)
