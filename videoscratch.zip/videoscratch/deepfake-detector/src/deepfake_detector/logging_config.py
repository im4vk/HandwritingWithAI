"""Comprehensive logging configuration for the deepfake detector."""

import logging
import logging.config
import logging.handlers
import os
import sys
import json
import time
from pathlib import Path
from typing import Dict, Any, Optional, Union
from datetime import datetime
import traceback


class StructuredFormatter(logging.Formatter):
    """Custom formatter that creates structured log records."""
    
    def __init__(self, include_extra: bool = True):
        super().__init__()
        self.include_extra = include_extra
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as structured JSON."""
        # Base log data
        log_data = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
        }
        
        # Add exception information if present
        if record.exc_info:
            log_data['exception'] = {
                'type': record.exc_info[0].__name__ if record.exc_info[0] else None,
                'message': str(record.exc_info[1]) if record.exc_info[1] else None,
                'traceback': traceback.format_exception(*record.exc_info) if record.exc_info else None
            }
        
        # Add extra context if available and requested
        if self.include_extra and hasattr(record, '__dict__'):
            extra_data = {}
            for key, value in record.__dict__.items():
                if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 'pathname', 
                             'filename', 'module', 'lineno', 'funcName', 'created', 
                             'msecs', 'relativeCreated', 'thread', 'threadName', 
                             'processName', 'process', 'exc_info', 'exc_text', 'stack_info']:
                    try:
                        # Ensure value is JSON serializable
                        json.dumps(value)
                        extra_data[key] = value
                    except (TypeError, ValueError):
                        extra_data[key] = str(value)
            
            if extra_data:
                log_data['extra'] = extra_data
        
        return json.dumps(log_data, ensure_ascii=False)


class PerformanceFormatter(logging.Formatter):
    """Formatter optimized for performance monitoring."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record for performance monitoring."""
        if hasattr(record, 'operation') and hasattr(record, 'duration'):
            return f"{datetime.fromtimestamp(record.created).isoformat()} | " \
                   f"PERF | {record.operation} | {record.duration:.4f}s | " \
                   f"{getattr(record, 'details', '')}"
        
        return super().format(record)


class DeepfakeDetectorLogger:
    """Central logging manager for the deepfake detector."""
    
    def __init__(self):
        self.configured = False
        self.log_dir: Optional[Path] = None
        self.performance_logger: Optional[logging.Logger] = None
        self.metrics = {
            'operations_total': 0,
            'operations_failed': 0,
            'total_processing_time': 0.0,
            'start_time': time.time()
        }
    
    def configure(self, 
                  log_level: Union[str, int] = logging.INFO,
                  log_dir: Optional[Union[str, Path]] = None,
                  console_output: bool = True,
                  file_output: bool = True,
                  structured_logs: bool = False,
                  performance_monitoring: bool = True,
                  max_file_size: int = 10 * 1024 * 1024,  # 10MB
                  backup_count: int = 5) -> None:
        """Configure the logging system.
        
        Args:
            log_level: Minimum log level to capture
            log_dir: Directory for log files (None = disabled)
            console_output: Enable console logging
            file_output: Enable file logging
            structured_logs: Use JSON structured logging
            performance_monitoring: Enable performance tracking
            max_file_size: Maximum size for log files before rotation
            backup_count: Number of backup files to keep
        """
        # Set up log directory
        if log_dir:
            self.log_dir = Path(log_dir)
            self.log_dir.mkdir(parents=True, exist_ok=True)
        elif file_output:
            # Default to logs subdirectory
            self.log_dir = Path.cwd() / "logs"
            self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Clear any existing configuration
        logging.getLogger().handlers.clear()
        
        # Configure root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(log_level)
        
        handlers = []
        
        # Console handler
        if console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            if structured_logs:
                console_handler.setFormatter(StructuredFormatter(include_extra=False))
            else:
                console_handler.setFormatter(logging.Formatter(
                    '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s'
                ))
            console_handler.setLevel(log_level)
            handlers.append(console_handler)
        
        # File handlers
        if file_output and self.log_dir:
            # Main application log
            app_log_file = self.log_dir / "deepfake_detector.log"
            app_handler = logging.handlers.RotatingFileHandler(
                app_log_file, 
                maxBytes=max_file_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            
            if structured_logs:
                app_handler.setFormatter(StructuredFormatter(include_extra=True))
            else:
                app_handler.setFormatter(logging.Formatter(
                    '%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s'
                ))
            app_handler.setLevel(log_level)
            handlers.append(app_handler)
            
            # Error log (errors and above only)
            error_log_file = self.log_dir / "errors.log"
            error_handler = logging.handlers.RotatingFileHandler(
                error_log_file,
                maxBytes=max_file_size,
                backupCount=backup_count,
                encoding='utf-8'
            )
            error_handler.setFormatter(logging.Formatter(
                '%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s\n'
                'Exception: %(exc_info)s\n'
            ))
            error_handler.setLevel(logging.ERROR)
            handlers.append(error_handler)
        
        # Add all handlers to root logger
        for handler in handlers:
            root_logger.addHandler(handler)
        
        # Set up performance monitoring
        if performance_monitoring:
            self._setup_performance_monitoring(structured_logs)
        
        # Configure specific loggers
        self._configure_module_loggers()
        
        self.configured = True
        
        # Log configuration
        logger = logging.getLogger(__name__)
        logger.info("Logging system configured successfully")
        logger.info(f"Log level: {logging.getLevelName(log_level)}")
        logger.info(f"Log directory: {self.log_dir}")
        logger.info(f"Console output: {console_output}")
        logger.info(f"File output: {file_output}")
        logger.info(f"Structured logs: {structured_logs}")
        logger.info(f"Performance monitoring: {performance_monitoring}")
    
    def _setup_performance_monitoring(self, structured_logs: bool) -> None:
        """Set up performance monitoring logger."""
        if not self.log_dir:
            return
        
        self.performance_logger = logging.getLogger('deepfake_detector.performance')
        self.performance_logger.setLevel(logging.INFO)
        
        # Performance log file
        perf_log_file = self.log_dir / "performance.log"
        perf_handler = logging.handlers.RotatingFileHandler(
            perf_log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=3,
            encoding='utf-8'
        )
        
        if structured_logs:
            perf_handler.setFormatter(StructuredFormatter(include_extra=True))
        else:
            perf_handler.setFormatter(PerformanceFormatter())
        
        self.performance_logger.addHandler(perf_handler)
        self.performance_logger.propagate = False  # Don't propagate to root logger
    
    def _configure_module_loggers(self) -> None:
        """Configure loggers for specific modules."""
        module_configs = {
            'deepfake_detector.io': logging.INFO,
            'deepfake_detector.face': logging.INFO,
            'deepfake_detector.frequency': logging.INFO,
            'deepfake_detector.rppg': logging.INFO,
            'deepfake_detector.avsync': logging.INFO,
            'deepfake_detector.geometry': logging.INFO,
            'deepfake_detector.fusion': logging.INFO,
            'deepfake_detector.detect': logging.INFO,
            'deepfake_detector.cnn_detector': logging.INFO,
            'deepfake_detector.models': logging.INFO,
        }
        
        for module_name, level in module_configs.items():
            logger = logging.getLogger(module_name)
            logger.setLevel(level)
    
    def log_operation(self, operation: str, duration: float, success: bool = True, 
                     details: Optional[Dict[str, Any]] = None) -> None:
        """Log performance metrics for an operation.
        
        Args:
            operation: Name of the operation
            duration: Time taken in seconds
            success: Whether the operation succeeded
            details: Additional operation details
        """
        if not self.performance_logger:
            return
        
        # Update metrics
        self.metrics['operations_total'] += 1
        if not success:
            self.metrics['operations_failed'] += 1
        self.metrics['total_processing_time'] += duration
        
        # Log the operation
        extra_data = {
            'operation': operation,
            'duration': duration,
            'success': success,
            'details': details or {}
        }
        
        self.performance_logger.info(
            f"Operation completed: {operation}",
            extra=extra_data
        )
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics."""
        current_time = time.time()
        uptime = current_time - self.metrics['start_time']
        
        return {
            'uptime_seconds': uptime,
            'operations_total': self.metrics['operations_total'],
            'operations_failed': self.metrics['operations_failed'],
            'success_rate': (
                (self.metrics['operations_total'] - self.metrics['operations_failed']) / 
                max(1, self.metrics['operations_total'])
            ),
            'total_processing_time': self.metrics['total_processing_time'],
            'average_operation_time': (
                self.metrics['total_processing_time'] / 
                max(1, self.metrics['operations_total'])
            ),
            'operations_per_second': self.metrics['operations_total'] / max(1, uptime)
        }
    
    def log_metrics(self) -> None:
        """Log current performance metrics."""
        if not self.performance_logger:
            return
        
        metrics = self.get_metrics()
        self.performance_logger.info("Performance metrics", extra={'metrics': metrics})
    
    def create_operation_context(self, operation_name: str):
        """Create a context manager for timing operations."""
        return OperationTimer(self, operation_name)


class OperationTimer:
    """Context manager for timing operations."""
    
    def __init__(self, logger_manager: DeepfakeDetectorLogger, operation_name: str):
        self.logger_manager = logger_manager
        self.operation_name = operation_name
        self.start_time = None
        self.logger = logging.getLogger(f"deepfake_detector.{operation_name}")
    
    def __enter__(self):
        self.start_time = time.time()
        self.logger.debug(f"Starting operation: {self.operation_name}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = time.time() - self.start_time
        success = exc_type is None
        
        if success:
            self.logger.debug(f"Completed operation: {self.operation_name} in {duration:.4f}s")
        else:
            self.logger.error(f"Failed operation: {self.operation_name} after {duration:.4f}s")
        
        self.logger_manager.log_operation(
            self.operation_name, 
            duration, 
            success,
            {'exception_type': exc_type.__name__ if exc_type else None}
        )


# Global logger manager instance
_logger_manager = DeepfakeDetectorLogger()


def configure_logging(**kwargs) -> None:
    """Configure the global logging system."""
    _logger_manager.configure(**kwargs)


def get_logger(name: str) -> logging.Logger:
    """Get a logger with the specified name."""
    return logging.getLogger(name)


def log_operation(operation: str, duration: float, success: bool = True, 
                 details: Optional[Dict[str, Any]] = None) -> None:
    """Log an operation to the performance monitor."""
    _logger_manager.log_operation(operation, duration, success, details)


def get_metrics() -> Dict[str, Any]:
    """Get current performance metrics."""
    return _logger_manager.get_metrics()


def log_metrics() -> None:
    """Log current performance metrics."""
    _logger_manager.log_metrics()


def create_operation_context(operation_name: str):
    """Create a context manager for timing operations."""
    return _logger_manager.create_operation_context(operation_name)


def ensure_logging_configured(default_level: Union[str, int] = logging.INFO) -> None:
    """Ensure logging is configured with default settings if not already done."""
    if not _logger_manager.configured:
        configure_logging(
            log_level=default_level,
            console_output=True,
            file_output=False,  # Default to console only
            structured_logs=False,
            performance_monitoring=True
        )
