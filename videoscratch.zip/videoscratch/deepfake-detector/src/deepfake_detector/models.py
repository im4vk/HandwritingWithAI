from __future__ import annotations

from pathlib import Path
from typing import Optional


def get_models_root(preferred_root: Optional[Path] = None) -> Path:
    """Return the directory where large pretrained models should live.

    Preference order:
    1) Provided preferred_root
    2) Environment variable DETECTOR_MODELS_DIR
    3) Current working directory / "models"
    """
    import os

    if preferred_root is not None:
        models_dir = Path(preferred_root) / "models"
    else:
        env_dir = os.environ.get("DETECTOR_MODELS_DIR")
        if env_dir:
            models_dir = Path(env_dir)
        else:
            models_dir = Path.cwd() / "models"
    models_dir.mkdir(parents=True, exist_ok=True)
    return models_dir


def ensure_model_file(filename: str, download_url: Optional[str] = None) -> Path:
    """Ensure a model file exists inside the models directory.

    If download_url is provided and file is missing, attempt to download.
    """
    import urllib.request

    models_dir = get_models_root()
    target = models_dir / filename

    if target.exists():
        return target

    if download_url is None:
        # Caller can handle missing file; we just reserve the path.
        return target

    try:
        tmp = target.with_suffix(target.suffix + ".tmp")
        urllib.request.urlretrieve(download_url, tmp)
        tmp.replace(target)
    except Exception as exc:  # noqa: BLE001
        # Best-effort download; caller can decide how to proceed if missing
        raise RuntimeError(f"Failed to download model from {download_url}: {exc}") from exc

    return target
