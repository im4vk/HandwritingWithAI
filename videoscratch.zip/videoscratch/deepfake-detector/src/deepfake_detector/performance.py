"""Performance optimization module for deepfake detection.

This module provides comprehensive performance optimizations including:
- Multi-level caching system (memory, disk, distributed)
- Streaming video processing for memory efficiency
- GPU acceleration management
- Parallel processing optimization
- Memory management and garbage collection
- Performance profiling and monitoring
"""

from __future__ import annotations

import gc
import hashlib
import pickle
import sys
import time
import weakref
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import wraps, lru_cache
from pathlib import Path
from threading import RLock
from typing import Dict, List, Optional, Any, Callable, Tuple, Union, Iterator
import numpy as np
from dataclasses import dataclass, field
from enum import Enum
import logging

from .exceptions import ProcessingError, handle_processing_error
from .logging_config import get_logger, create_operation_context


class CacheLevel(Enum):
    """Cache level enumeration."""
    MEMORY = "memory"
    DISK = "disk"
    DISTRIBUTED = "distributed"


class ProcessingMode(Enum):
    """Processing mode enumeration."""
    BATCH = "batch"
    STREAMING = "streaming"
    PARALLEL = "parallel"
    GPU_ACCELERATED = "gpu_accelerated"


@dataclass
class PerformanceConfig:
    """Performance configuration."""
    
    # Caching configuration
    enable_caching: bool = True
    cache_levels: List[CacheLevel] = field(default_factory=lambda: [CacheLevel.MEMORY, CacheLevel.DISK])
    memory_cache_size: int = 1000  # Max items in memory cache
    disk_cache_dir: Optional[Path] = None
    disk_cache_size_mb: int = 1000  # Max disk cache size in MB
    cache_ttl_seconds: int = 86400  # 24 hours
    
    # Streaming configuration
    enable_streaming: bool = True
    streaming_chunk_size: int = 30  # Frames per chunk
    streaming_overlap: int = 5  # Overlap between chunks
    max_memory_frames: int = 300  # Max frames in memory
    
    # Parallel processing
    enable_parallel: bool = True
    max_workers: Optional[int] = None  # Auto-detect if None
    thread_pool_size: int = 4
    process_pool_size: int = 2
    
    # GPU acceleration
    enable_gpu: bool = False
    gpu_memory_fraction: float = 0.7
    gpu_batch_size: int = 32
    
    # Memory management
    enable_gc: bool = True
    gc_threshold: int = 700  # Generations before GC
    memory_threshold_mb: int = 2000  # Memory usage threshold
    
    # Performance monitoring
    enable_profiling: bool = False
    profile_output_dir: Optional[Path] = None
    performance_logging: bool = True


@dataclass
class CacheKey:
    """Cache key for storing processed results."""
    
    file_path: str
    algorithm: str
    parameters_hash: str
    file_mtime: float
    file_size: int
    
    def __post_init__(self):
        """Generate composite hash for the cache key."""
        content = f"{self.file_path}_{self.algorithm}_{self.parameters_hash}_{self.file_mtime}_{self.file_size}"
        self.hash = hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def __str__(self) -> str:
        return self.hash
    
    def __hash__(self) -> int:
        return hash(self.hash)
    
    def __eq__(self, other) -> bool:
        return isinstance(other, CacheKey) and self.hash == other.hash


@dataclass
class CacheItem:
    """Cache item with metadata."""
    
    key: CacheKey
    value: Any
    timestamp: float
    access_count: int = 0
    size_bytes: int = 0
    
    def __post_init__(self):
        """Calculate item size."""
        if self.size_bytes == 0:
            try:
                self.size_bytes = len(pickle.dumps(self.value))
            except Exception:
                self.size_bytes = 1024  # Default size if pickling fails


class MemoryCache:
    """Thread-safe in-memory cache with LRU eviction."""
    
    def __init__(self, max_size: int = 1000, ttl_seconds: int = 86400):
        """Initialize memory cache.
        
        Args:
            max_size: Maximum number of items
            ttl_seconds: Time-to-live in seconds
        """
        self.max_size = max_size
        self.ttl_seconds = ttl_seconds
        self._cache: Dict[str, CacheItem] = {}
        self._access_order: List[str] = []
        self._lock = RLock()
        self.logger = get_logger(__name__)
        
        # Statistics
        self.hits = 0
        self.misses = 0
        self.evictions = 0
    
    def get(self, key: CacheKey) -> Optional[Any]:
        """Get item from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found/expired
        """
        with self._lock:
            key_str = str(key)
            
            if key_str not in self._cache:
                self.misses += 1
                return None
            
            item = self._cache[key_str]
            
            # Check TTL
            if time.time() - item.timestamp > self.ttl_seconds:
                self._remove_item(key_str)
                self.misses += 1
                return None
            
            # Update access order
            if key_str in self._access_order:
                self._access_order.remove(key_str)
            self._access_order.append(key_str)
            
            item.access_count += 1
            self.hits += 1
            
            return item.value
    
    def put(self, key: CacheKey, value: Any) -> None:
        """Put item in cache.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        with self._lock:
            key_str = str(key)
            
            # Create cache item
            item = CacheItem(
                key=key,
                value=value,
                timestamp=time.time()
            )
            
            # Remove existing item if present
            if key_str in self._cache:
                self._remove_item(key_str)
            
            # Add new item
            self._cache[key_str] = item
            self._access_order.append(key_str)
            
            # Evict if necessary
            while len(self._cache) > self.max_size:
                self._evict_lru()
    
    def _remove_item(self, key_str: str) -> None:
        """Remove item from cache."""
        if key_str in self._cache:
            del self._cache[key_str]
        if key_str in self._access_order:
            self._access_order.remove(key_str)
    
    def _evict_lru(self) -> None:
        """Evict least recently used item."""
        if self._access_order:
            lru_key = self._access_order[0]
            self._remove_item(lru_key)
            self.evictions += 1
    
    def clear(self) -> None:
        """Clear all cache items."""
        with self._lock:
            self._cache.clear()
            self._access_order.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            total_requests = self.hits + self.misses
            hit_rate = self.hits / total_requests if total_requests > 0 else 0.0
            
            total_size = sum(item.size_bytes for item in self._cache.values())
            
            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "hits": self.hits,
                "misses": self.misses,
                "evictions": self.evictions,
                "hit_rate": hit_rate,
                "total_size_bytes": total_size,
                "total_size_mb": total_size / (1024 * 1024)
            }


class DiskCache:
    """Persistent disk cache with automatic cleanup."""
    
    def __init__(self, cache_dir: Path, max_size_mb: int = 1000):
        """Initialize disk cache.
        
        Args:
            cache_dir: Cache directory
            max_size_mb: Maximum cache size in MB
        """
        self.cache_dir = Path(cache_dir)
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.logger = get_logger(__name__)
        
        # Create metadata file
        self.metadata_file = self.cache_dir / "cache_metadata.json"
        self._load_metadata()
    
    def _load_metadata(self) -> None:
        """Load cache metadata."""
        import json
        
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r') as f:
                    self.metadata = json.load(f)
            except Exception as e:
                self.logger.warning(f"Failed to load cache metadata: {e}")
                self.metadata = {}
        else:
            self.metadata = {}
    
    def _save_metadata(self) -> None:
        """Save cache metadata."""
        import json
        
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            self.logger.warning(f"Failed to save cache metadata: {e}")
    
    def get(self, key: CacheKey) -> Optional[Any]:
        """Get item from disk cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found
        """
        cache_file = self.cache_dir / f"{key.hash}.pkl"
        
        if not cache_file.exists():
            return None
        
        try:
            # Check if file is newer than cache
            if cache_file.stat().st_mtime < key.file_mtime:
                cache_file.unlink()
                return None
            
            with open(cache_file, 'rb') as f:
                return pickle.load(f)
                
        except Exception as e:
            self.logger.warning(f"Failed to load from disk cache: {e}")
            if cache_file.exists():
                cache_file.unlink()
            return None
    
    def put(self, key: CacheKey, value: Any) -> None:
        """Put item in disk cache.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        cache_file = self.cache_dir / f"{key.hash}.pkl"
        
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump(value, f)
            
            # Update metadata
            self.metadata[key.hash] = {
                "timestamp": time.time(),
                "file_path": key.file_path,
                "algorithm": key.algorithm,
                "size_bytes": cache_file.stat().st_size
            }
            
            self._save_metadata()
            self._cleanup_if_needed()
            
        except Exception as e:
            self.logger.warning(f"Failed to save to disk cache: {e}")
    
    def _cleanup_if_needed(self) -> None:
        """Clean up cache if size exceeds limit."""
        total_size = sum(
            (self.cache_dir / f"{key}.pkl").stat().st_size
            for key in self.metadata.keys()
            if (self.cache_dir / f"{key}.pkl").exists()
        )
        
        if total_size > self.max_size_bytes:
            # Sort by timestamp and remove oldest
            sorted_items = sorted(
                self.metadata.items(),
                key=lambda x: x[1]["timestamp"]
            )
            
            for key, meta in sorted_items:
                cache_file = self.cache_dir / f"{key}.pkl"
                if cache_file.exists():
                    cache_file.unlink()
                del self.metadata[key]
                
                # Recalculate size
                total_size -= meta["size_bytes"]
                if total_size <= self.max_size_bytes * 0.8:  # Leave 20% headroom
                    break
            
            self._save_metadata()


class CacheManager:
    """Multi-level cache manager."""
    
    def __init__(self, config: PerformanceConfig):
        """Initialize cache manager.
        
        Args:
            config: Performance configuration
        """
        self.config = config
        self.logger = get_logger(__name__)
        
        # Initialize caches
        self.memory_cache = None
        self.disk_cache = None
        
        if CacheLevel.MEMORY in config.cache_levels:
            self.memory_cache = MemoryCache(
                config.memory_cache_size,
                config.cache_ttl_seconds
            )
        
        if CacheLevel.DISK in config.cache_levels and config.disk_cache_dir:
            self.disk_cache = DiskCache(
                config.disk_cache_dir,
                config.disk_cache_size_mb
            )
    
    def get(self, key: CacheKey) -> Optional[Any]:
        """Get item from cache hierarchy.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None
        """
        if not self.config.enable_caching:
            return None
        
        # Try memory cache first
        if self.memory_cache:
            value = self.memory_cache.get(key)
            if value is not None:
                return value
        
        # Try disk cache
        if self.disk_cache:
            value = self.disk_cache.get(key)
            if value is not None:
                # Promote to memory cache
                if self.memory_cache:
                    self.memory_cache.put(key, value)
                return value
        
        return None
    
    def put(self, key: CacheKey, value: Any) -> None:
        """Put item in cache hierarchy.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        if not self.config.enable_caching:
            return
        
        # Store in memory cache
        if self.memory_cache:
            self.memory_cache.put(key, value)
        
        # Store in disk cache
        if self.disk_cache:
            self.disk_cache.put(key, value)
    
    def create_key(self, file_path: Path, algorithm: str, parameters: Dict[str, Any]) -> CacheKey:
        """Create cache key for file and algorithm.
        
        Args:
            file_path: Path to input file
            algorithm: Algorithm name
            parameters: Algorithm parameters
            
        Returns:
            Cache key
        """
        # Hash parameters
        param_str = str(sorted(parameters.items()))
        param_hash = hashlib.sha256(param_str.encode()).hexdigest()[:8]
        
        # Get file metadata
        try:
            stat = file_path.stat()
            file_mtime = stat.st_mtime
            file_size = stat.st_size
        except OSError:
            file_mtime = 0
            file_size = 0
        
        return CacheKey(
            file_path=str(file_path),
            algorithm=algorithm,
            parameters_hash=param_hash,
            file_mtime=file_mtime,
            file_size=file_size
        )
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        stats = {}
        
        if self.memory_cache:
            stats["memory"] = self.memory_cache.get_stats()
        
        if self.disk_cache:
            stats["disk"] = {
                "cache_dir": str(self.disk_cache.cache_dir),
                "max_size_mb": self.disk_cache.max_size_bytes / (1024 * 1024),
                "entries": len(self.disk_cache.metadata)
            }
        
        return stats


class StreamingProcessor:
    """Streaming video processor for memory-efficient analysis."""
    
    def __init__(self, config: PerformanceConfig):
        """Initialize streaming processor.
        
        Args:
            config: Performance configuration
        """
        self.config = config
        self.logger = get_logger(__name__)
    
    def process_video_streaming(self, 
                               video_path: Path, 
                               processor_func: Callable,
                               **kwargs) -> Iterator[Tuple[int, Any]]:
        """Process video in streaming chunks.
        
        Args:
            video_path: Path to video file
            processor_func: Function to process each chunk
            **kwargs: Additional arguments for processor
            
        Yields:
            Tuple of (chunk_index, processed_result)
        """
        try:
            import cv2
        except ImportError:
            raise ProcessingError("OpenCV not available for streaming processing")
        
        cap = None
        try:
            cap = cv2.VideoCapture(str(video_path))
            if not cap.isOpened():
                raise ProcessingError(f"Cannot open video: {video_path}")
            
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            
            chunk_size = self.config.streaming_chunk_size
            overlap = self.config.streaming_overlap
            
            chunk_index = 0
            frame_buffer = []
            frame_index = 0
            
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                frame_buffer.append((frame_index, frame))
                frame_index += 1
                
                # Process chunk when buffer is full
                if len(frame_buffer) >= chunk_size:
                    chunk_data = {
                        'frames': [f[1] for f in frame_buffer],
                        'frame_indices': [f[0] for f in frame_buffer],
                        'fps': fps,
                        'total_frames': total_frames,
                        'chunk_index': chunk_index
                    }
                    
                    try:
                        result = processor_func(chunk_data, **kwargs)
                        yield chunk_index, result
                    except Exception as e:
                        self.logger.warning(f"Failed to process chunk {chunk_index}: {e}")
                        yield chunk_index, None
                    
                    # Remove processed frames, keep overlap
                    if overlap > 0 and len(frame_buffer) > overlap:
                        frame_buffer = frame_buffer[-overlap:]
                    else:
                        frame_buffer = []
                    
                    chunk_index += 1
                    
                    # Memory management
                    if chunk_index % 10 == 0:
                        gc.collect()
            
            # Process remaining frames
            if frame_buffer:
                chunk_data = {
                    'frames': [f[1] for f in frame_buffer],
                    'frame_indices': [f[0] for f in frame_buffer],
                    'fps': fps,
                    'total_frames': total_frames,
                    'chunk_index': chunk_index
                }
                
                try:
                    result = processor_func(chunk_data, **kwargs)
                    yield chunk_index, result
                except Exception as e:
                    self.logger.warning(f"Failed to process final chunk: {e}")
                    yield chunk_index, None
        
        finally:
            if cap:
                cap.release()
    
    def aggregate_streaming_results(self, chunk_results: List[Tuple[int, Any]]) -> Any:
        """Aggregate results from streaming chunks.
        
        Args:
            chunk_results: List of (chunk_index, result) tuples
            
        Returns:
            Aggregated result
        """
        # Filter out None results
        valid_results = [(i, r) for i, r in chunk_results if r is not None]
        
        if not valid_results:
            return None
        
        # Simple aggregation - average numeric values
        if isinstance(valid_results[0][1], (int, float)):
            values = [r[1] for r in valid_results]
            return sum(values) / len(values)
        
        # Dictionary aggregation
        elif isinstance(valid_results[0][1], dict):
            aggregated = {}
            for _, result in valid_results:
                for key, value in result.items():
                    if key not in aggregated:
                        aggregated[key] = []
                    aggregated[key].append(value)
            
            # Average numeric values
            for key, values in aggregated.items():
                if all(isinstance(v, (int, float)) for v in values):
                    aggregated[key] = sum(values) / len(values)
                else:
                    aggregated[key] = values  # Keep as list for non-numeric
            
            return aggregated
        
        # Default: return first valid result
        return valid_results[0][1]


class MemoryManager:
    """Memory management utilities."""
    
    def __init__(self, config: PerformanceConfig):
        """Initialize memory manager.
        
        Args:
            config: Performance configuration
        """
        self.config = config
        self.logger = get_logger(__name__)
        self._memory_threshold = config.memory_threshold_mb * 1024 * 1024
        
        # Configure garbage collection
        if config.enable_gc:
            gc.set_threshold(config.gc_threshold)
    
    def get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage.
        
        Returns:
            Dictionary with memory statistics
        """
        try:
            import psutil
            
            process = psutil.Process()
            memory_info = process.memory_info()
            
            return {
                "rss_mb": memory_info.rss / (1024 * 1024),
                "vms_mb": memory_info.vms / (1024 * 1024),
                "percent": process.memory_percent(),
                "available_mb": psutil.virtual_memory().available / (1024 * 1024)
            }
        except ImportError:
            # Fallback when psutil is not available
            import resource
            import os
            
            try:
                # Get RSS from resource module (Unix-like systems)
                rusage = resource.getrusage(resource.RUSAGE_SELF)
                rss_kb = rusage.ru_maxrss
                # On Linux, ru_maxrss is in KB; on macOS, it's in bytes
                if sys.platform == 'darwin':
                    rss_mb = rss_kb / (1024 * 1024)
                else:
                    rss_mb = rss_kb / 1024
                
                return {
                    "rss_mb": rss_mb,
                    "vms_mb": 0.0,  # Not available without psutil
                    "percent": 0.0,  # Not available without psutil
                    "available_mb": 0.0  # Not available without psutil
                }
            except Exception:
                # Ultimate fallback
                return {
                    "rss_mb": 0.0,
                    "vms_mb": 0.0,
                    "percent": 0.0,
                    "available_mb": 0.0
                }
    
    def check_memory_pressure(self) -> bool:
        """Check if memory usage is high.
        
        Returns:
            True if memory pressure detected
        """
        try:
            memory_info = self.get_memory_usage()
            return memory_info["rss_mb"] * 1024 * 1024 > self._memory_threshold
        except Exception:
            return False
    
    def force_garbage_collection(self) -> Dict[str, int]:
        """Force garbage collection and return statistics.
        
        Returns:
            GC statistics
        """
        before_memory = self.get_memory_usage()
        
        # Force GC
        collected = gc.collect()
        
        after_memory = self.get_memory_usage()
        
        return {
            "objects_collected": collected,
            "memory_freed_mb": before_memory["rss_mb"] - after_memory["rss_mb"],
            "before_memory_mb": before_memory["rss_mb"],
            "after_memory_mb": after_memory["rss_mb"]
        }
    
    def cleanup_large_objects(self, threshold_mb: float = 100.0) -> int:
        """Clean up large objects from memory.
        
        Args:
            threshold_mb: Size threshold in MB
            
        Returns:
            Number of objects cleaned
        """
        import sys
        
        threshold_bytes = threshold_mb * 1024 * 1024
        cleaned = 0
        
        for obj in gc.get_objects():
            try:
                obj_size = sys.getsizeof(obj)
                if obj_size > threshold_bytes:
                    # Try to delete if it's a numpy array or similar
                    if hasattr(obj, '__del__'):
                        del obj
                        cleaned += 1
            except Exception:
                continue
        
        gc.collect()
        return cleaned


class PerformanceOptimizer:
    """Main performance optimization coordinator."""
    
    def __init__(self, config: PerformanceConfig):
        """Initialize performance optimizer.
        
        Args:
            config: Performance configuration
        """
        self.config = config
        self.logger = get_logger(__name__)
        
        # Initialize components
        self.cache_manager = CacheManager(config)
        self.streaming_processor = StreamingProcessor(config)
        self.memory_manager = MemoryManager(config)
        
        # Performance tracking
        self.performance_stats = {
            "cache_hits": 0,
            "cache_misses": 0,
            "streaming_chunks": 0,
            "memory_cleanups": 0,
            "processing_times": []
        }
    
    def cached_analysis(self, 
                       algorithm_name: str,
                       analysis_func: Callable,
                       file_path: Path,
                       parameters: Dict[str, Any],
                       **kwargs) -> Any:
        """Run analysis with caching support.
        
        Args:
            algorithm_name: Name of the algorithm
            analysis_func: Function to run analysis
            file_path: Path to input file
            parameters: Algorithm parameters
            **kwargs: Additional arguments
            
        Returns:
            Analysis result
        """
        # Create cache key
        cache_key = self.cache_manager.create_key(file_path, algorithm_name, parameters)
        
        # Try to get from cache
        cached_result = self.cache_manager.get(cache_key)
        if cached_result is not None:
            self.performance_stats["cache_hits"] += 1
            self.logger.debug(f"Cache hit for {algorithm_name} on {file_path.name}")
            return cached_result
        
        self.performance_stats["cache_misses"] += 1
        
        # Run analysis
        with create_operation_context(f"{algorithm_name}_analysis"):
            start_time = time.time()
            
            try:
                result = analysis_func(file_path, **kwargs)
                
                # Cache the result
                self.cache_manager.put(cache_key, result)
                
                processing_time = time.time() - start_time
                self.performance_stats["processing_times"].append(processing_time)
                
                self.logger.debug(f"Analysis completed for {algorithm_name} on {file_path.name} in {processing_time:.2f}s")
                
                return result
                
            except Exception as e:
                self.logger.warning(f"Analysis failed for {algorithm_name} on {file_path.name}: {e}")
                raise
    
    def streaming_analysis(self,
                          algorithm_name: str,
                          analysis_func: Callable,
                          video_path: Path,
                          **kwargs) -> Any:
        """Run analysis with streaming processing.
        
        Args:
            algorithm_name: Name of the algorithm
            analysis_func: Function to analyze each chunk
            video_path: Path to video file
            **kwargs: Additional arguments
            
        Returns:
            Aggregated analysis result
        """
        if not self.config.enable_streaming:
            return self.cached_analysis(algorithm_name, analysis_func, video_path, {}, **kwargs)
        
        chunk_results = []
        
        try:
            for chunk_index, result in self.streaming_processor.process_video_streaming(
                video_path, analysis_func, **kwargs
            ):
                chunk_results.append((chunk_index, result))
                self.performance_stats["streaming_chunks"] += 1
                
                # Memory management
                if self.memory_manager.check_memory_pressure():
                    gc_stats = self.memory_manager.force_garbage_collection()
                    self.performance_stats["memory_cleanups"] += 1
                    self.logger.info(f"Memory cleanup: freed {gc_stats['memory_freed_mb']:.1f} MB")
            
            # Aggregate results
            return self.streaming_processor.aggregate_streaming_results(chunk_results)
            
        except Exception as e:
            self.logger.error(f"Streaming analysis failed for {algorithm_name}: {e}")
            raise
    
    def parallel_analysis(self,
                         tasks: List[Tuple[str, Callable, Path, Dict[str, Any]]],
                         **kwargs) -> List[Any]:
        """Run multiple analyses in parallel.
        
        Args:
            tasks: List of (algorithm_name, function, file_path, parameters) tuples
            **kwargs: Additional arguments
            
        Returns:
            List of results corresponding to input tasks
        """
        if not self.config.enable_parallel or len(tasks) == 1:
            return [
                self.cached_analysis(alg, func, path, params, **kwargs)
                for alg, func, path, params in tasks
            ]
        
        results = [None] * len(tasks)
        
        with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
            # Submit all tasks
            future_to_index = {
                executor.submit(
                    self.cached_analysis, alg, func, path, params, **kwargs
                ): i
                for i, (alg, func, path, params) in enumerate(tasks)
            }
            
            # Collect results
            for future in as_completed(future_to_index):
                index = future_to_index[future]
                try:
                    results[index] = future.result()
                except Exception as e:
                    self.logger.warning(f"Parallel task {index} failed: {e}")
                    results[index] = None
        
        return results
    
    def optimize_for_file(self, file_path: Path) -> ProcessingMode:
        """Determine optimal processing mode for a file.
        
        Args:
            file_path: Path to input file
            
        Returns:
            Recommended processing mode
        """
        try:
            import cv2
            
            # Get video info
            cap = cv2.VideoCapture(str(file_path))
            if not cap.isOpened():
                return ProcessingMode.BATCH
            
            frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            duration = frame_count / fps if fps > 0 else 0
            
            cap.release()
            
            # Decision logic
            if duration > 300:  # > 5 minutes
                return ProcessingMode.STREAMING
            elif frame_count > 1000:  # Many frames
                return ProcessingMode.PARALLEL
            elif self.config.enable_gpu:
                return ProcessingMode.GPU_ACCELERATED
            else:
                return ProcessingMode.BATCH
                
        except Exception:
            return ProcessingMode.BATCH
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get comprehensive performance statistics.
        
        Returns:
            Performance statistics dictionary
        """
        cache_stats = self.cache_manager.get_stats()
        memory_stats = self.memory_manager.get_memory_usage()
        
        processing_times = self.performance_stats["processing_times"]
        avg_processing_time = sum(processing_times) / len(processing_times) if processing_times else 0
        
        total_requests = self.performance_stats["cache_hits"] + self.performance_stats["cache_misses"]
        cache_hit_rate = self.performance_stats["cache_hits"] / total_requests if total_requests > 0 else 0
        
        return {
            "cache": {
                "hit_rate": cache_hit_rate,
                "total_hits": self.performance_stats["cache_hits"],
                "total_misses": self.performance_stats["cache_misses"],
                "details": cache_stats
            },
            "memory": {
                "current_usage": memory_stats,
                "cleanup_count": self.performance_stats["memory_cleanups"]
            },
            "streaming": {
                "chunks_processed": self.performance_stats["streaming_chunks"]
            },
            "processing": {
                "total_analyses": len(processing_times),
                "average_time_seconds": avg_processing_time,
                "total_time_seconds": sum(processing_times)
            }
        }
    
    def cleanup(self) -> None:
        """Clean up resources and perform final optimizations."""
        # Clear caches
        if self.cache_manager.memory_cache:
            self.cache_manager.memory_cache.clear()
        
        # Force garbage collection
        self.memory_manager.force_garbage_collection()
        
        # Clean up large objects
        cleaned = self.memory_manager.cleanup_large_objects()
        if cleaned > 0:
            self.logger.info(f"Cleaned up {cleaned} large objects during shutdown")


# Decorator for automatic caching
def cached(algorithm_name: str, parameters: Optional[Dict[str, Any]] = None):
    """Decorator for automatic caching of analysis functions.
    
    Args:
        algorithm_name: Name of the algorithm
        parameters: Optional parameters dictionary
        
    Returns:
        Decorated function
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Get performance optimizer from kwargs or create default
            optimizer = kwargs.pop('performance_optimizer', None)
            if optimizer is None:
                config = PerformanceConfig()
                optimizer = PerformanceOptimizer(config)
            
            # Extract file path from args
            file_path = None
            if args and isinstance(args[0], (str, Path)):
                file_path = Path(args[0])
            elif 'file_path' in kwargs:
                file_path = Path(kwargs['file_path'])
            
            if file_path is None:
                # No file path, run function directly
                return func(*args, **kwargs)
            
            # Use cached analysis
            return optimizer.cached_analysis(
                algorithm_name,
                lambda fp, **kw: func(fp, **{k: v for k, v in kw.items() if k != 'performance_optimizer'}),
                file_path,
                parameters or {},
                **kwargs
            )
        
        return wrapper
    
    return decorator


# Utility functions
def estimate_memory_requirements(video_path: Path, target_fps: Optional[float] = None) -> Dict[str, float]:
    """Estimate memory requirements for processing a video.
    
    Args:
        video_path: Path to video file
        target_fps: Target FPS (if different from original)
        
    Returns:
        Memory requirement estimates in MB
    """
    try:
        import cv2
        
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            return {"error": "Cannot open video"}
        
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        cap.release()
        
        # Calculate frame size (3 channels, 8 bits per channel)
        frame_size_bytes = width * height * 3
        frame_size_mb = frame_size_bytes / (1024 * 1024)
        
        # Estimate memory for different processing modes
        if target_fps and target_fps != fps:
            effective_frames = int(frame_count * target_fps / fps)
        else:
            effective_frames = frame_count
        
        estimates = {
            "single_frame_mb": frame_size_mb,
            "all_frames_mb": frame_size_mb * effective_frames,
            "streaming_chunk_mb": frame_size_mb * 30,  # 30 frames per chunk
            "parallel_batch_mb": frame_size_mb * 100,  # 100 frames per batch
            "recommended_ram_mb": max(512, frame_size_mb * 200)  # Recommended RAM
        }
        
        return estimates
        
    except Exception as e:
        return {"error": str(e)}


def optimize_opencv_performance() -> None:
    """Optimize OpenCV performance settings."""
    try:
        import cv2
        
        # Enable optimizations
        cv2.setUseOptimized(True)
        
        # Set number of threads (use half of available cores)
        import os
        num_cores = os.cpu_count() or 4
        cv2.setNumThreads(max(1, num_cores // 2))
        
        logging.getLogger(__name__).info(f"OpenCV optimized with {cv2.getNumThreads()} threads")
        
    except ImportError:
        pass
    except Exception as e:
        logging.getLogger(__name__).warning(f"Failed to optimize OpenCV: {e}")


# Initialize performance optimizations on import
optimize_opencv_performance()
