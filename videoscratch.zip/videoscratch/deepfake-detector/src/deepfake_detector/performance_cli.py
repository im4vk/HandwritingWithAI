"""Command-line interface for performance optimization and monitoring."""

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, Any, List

from .performance import (
    PerformanceOptimizer,
    PerformanceConfig,
    estimate_memory_requirements,
    optimize_opencv_performance
)
from .config import load_config
from .logging_config import configure_logging, get_logger


def benchmark_file(file_path: Path, 
                  config: PerformanceConfig,
                  iterations: int = 3) -> Dict[str, Any]:
    """Benchmark processing performance for a file.
    
    Args:
        file_path: Path to test file
        config: Performance configuration
        iterations: Number of iterations for averaging
        
    Returns:
        Benchmark results
    """
    from .detect import analyze_video
    
    optimizer = PerformanceOptimizer(config)
    logger = get_logger(__name__)
    
    results = {
        "file_path": str(file_path),
        "file_size_mb": file_path.stat().st_size / (1024 * 1024),
        "iterations": iterations,
        "performance_config": {
            "caching_enabled": config.enable_caching,
            "parallel_enabled": config.enable_parallel,
            "streaming_enabled": config.enable_streaming,
            "max_workers": config.max_workers
        },
        "timing_results": [],
        "memory_usage": [],
        "cache_performance": {}
    }
    
    logger.info(f"Benchmarking {file_path} with {iterations} iterations")
    
    for i in range(iterations):
        logger.info(f"Iteration {i + 1}/{iterations}")
        
        # Clear cache between iterations (except first to test cache performance)
        if i > 0 and hasattr(optimizer.cache_manager, 'memory_cache'):
            optimizer.cache_manager.memory_cache.clear()
        
        # Record initial memory
        initial_memory = optimizer.memory_manager.get_memory_usage()
        
        # Time the analysis
        start_time = time.time()
        try:
            report = analyze_video(file_path, performance_optimizer=optimizer)
            end_time = time.time()
            
            processing_time = end_time - start_time
            success = True
            error_message = None
            
        except Exception as e:
            end_time = time.time()
            processing_time = end_time - start_time
            success = False
            error_message = str(e)
            logger.warning(f"Iteration {i + 1} failed: {e}")
        
        # Record final memory
        final_memory = optimizer.memory_manager.get_memory_usage()
        
        # Get performance stats
        perf_stats = optimizer.get_performance_stats()
        
        iteration_result = {
            "iteration": i + 1,
            "processing_time_seconds": processing_time,
            "success": success,
            "error_message": error_message,
            "memory_initial_mb": initial_memory["rss_mb"],
            "memory_final_mb": final_memory["rss_mb"],
            "memory_peak_delta_mb": final_memory["rss_mb"] - initial_memory["rss_mb"],
            "cache_hit_rate": perf_stats.get("cache", {}).get("hit_rate", 0.0),
            "cache_hits": perf_stats.get("cache", {}).get("total_hits", 0),
            "cache_misses": perf_stats.get("cache", {}).get("total_misses", 0)
        }
        
        if success and hasattr(report, 'performance_stats'):
            iteration_result["processing_mode"] = report.performance_stats.get("processing", {}).get("mode")
        
        results["timing_results"].append(iteration_result)
        results["memory_usage"].append({
            "iteration": i + 1,
            "initial_mb": initial_memory["rss_mb"],
            "final_mb": final_memory["rss_mb"],
            "peak_delta_mb": final_memory["rss_mb"] - initial_memory["rss_mb"]
        })
    
    # Calculate summary statistics
    successful_iterations = [r for r in results["timing_results"] if r["success"]]
    
    if successful_iterations:
        processing_times = [r["processing_time_seconds"] for r in successful_iterations]
        memory_deltas = [r["memory_peak_delta_mb"] for r in successful_iterations]
        
        results["summary"] = {
            "success_rate": len(successful_iterations) / iterations,
            "average_processing_time_seconds": sum(processing_times) / len(processing_times),
            "min_processing_time_seconds": min(processing_times),
            "max_processing_time_seconds": max(processing_times),
            "average_memory_delta_mb": sum(memory_deltas) / len(memory_deltas),
            "max_memory_delta_mb": max(memory_deltas),
            "overall_cache_hit_rate": successful_iterations[-1]["cache_hit_rate"] if successful_iterations else 0.0
        }
    else:
        results["summary"] = {
            "success_rate": 0.0,
            "error": "All iterations failed"
        }
    
    # Get final performance statistics
    final_perf_stats = optimizer.get_performance_stats()
    results["cache_performance"] = final_perf_stats.get("cache", {})
    
    return results


def analyze_cache_performance(cache_dir: Path) -> Dict[str, Any]:
    """Analyze cache performance and contents.
    
    Args:
        cache_dir: Cache directory to analyze
        
    Returns:
        Cache analysis results
    """
    if not cache_dir.exists():
        return {"error": "Cache directory does not exist"}
    
    cache_files = list(cache_dir.glob("*.pkl"))
    metadata_file = cache_dir / "cache_metadata.json"
    
    total_size = sum(f.stat().st_size for f in cache_files)
    
    analysis = {
        "cache_directory": str(cache_dir),
        "total_files": len(cache_files),
        "total_size_mb": total_size / (1024 * 1024),
        "files_by_age": {},
        "largest_files": [],
        "metadata_available": metadata_file.exists()
    }
    
    # Analyze file ages
    if cache_files:
        now = time.time()
        for cache_file in cache_files:
            age_hours = (now - cache_file.stat().st_mtime) / 3600
            age_bucket = f"{int(age_hours)}h" if age_hours < 24 else f"{int(age_hours/24)}d"
            analysis["files_by_age"][age_bucket] = analysis["files_by_age"].get(age_bucket, 0) + 1
        
        # Find largest files
        file_sizes = [(f, f.stat().st_size) for f in cache_files]
        file_sizes.sort(key=lambda x: x[1], reverse=True)
        
        analysis["largest_files"] = [
            {
                "filename": f.name,
                "size_mb": size / (1024 * 1024),
                "age_hours": (now - f.stat().st_mtime) / 3600
            }
            for f, size in file_sizes[:10]
        ]
    
    # Load metadata if available
    if metadata_file.exists():
        try:
            with open(metadata_file, 'r') as f:
                metadata = json.load(f)
            
            analysis["algorithms"] = {}
            analysis["file_types"] = {}
            
            for key, meta in metadata.items():
                algorithm = meta.get("algorithm", "unknown")
                analysis["algorithms"][algorithm] = analysis["algorithms"].get(algorithm, 0) + 1
                
                file_path = meta.get("file_path", "")
                if file_path:
                    ext = Path(file_path).suffix.lower()
                    analysis["file_types"][ext] = analysis["file_types"].get(ext, 0) + 1
        
        except Exception as e:
            analysis["metadata_error"] = str(e)
    
    return analysis


def optimize_configuration(test_file: Path, 
                         base_config: PerformanceConfig) -> Dict[str, Any]:
    """Optimize performance configuration for a test file.
    
    Args:
        test_file: File to use for optimization testing
        base_config: Base configuration to optimize
        
    Returns:
        Optimization results with recommendations
    """
    logger = get_logger(__name__)
    logger.info(f"Optimizing configuration for {test_file}")
    
    # Test different configurations
    test_configs = {
        "baseline": base_config,
        "caching_only": PerformanceConfig(
            enable_caching=True,
            enable_parallel=False,
            enable_streaming=False
        ),
        "parallel_only": PerformanceConfig(
            enable_caching=False,
            enable_parallel=True,
            max_workers=4
        ),
        "caching_and_parallel": PerformanceConfig(
            enable_caching=True,
            enable_parallel=True,
            max_workers=4
        ),
        "streaming": PerformanceConfig(
            enable_caching=True,
            enable_streaming=True,
            streaming_chunk_size=30
        )
    }
    
    results = {
        "test_file": str(test_file),
        "configurations": {},
        "recommendations": {}
    }
    
    best_performance = None
    best_config_name = None
    
    for config_name, config in test_configs.items():
        logger.info(f"Testing configuration: {config_name}")
        
        try:
            benchmark = benchmark_file(test_file, config, iterations=2)
            
            if benchmark["summary"]["success_rate"] > 0:
                avg_time = benchmark["summary"]["average_processing_time_seconds"]
                avg_memory = benchmark["summary"]["average_memory_delta_mb"]
                cache_hit_rate = benchmark["summary"]["overall_cache_hit_rate"]
                
                # Calculate performance score (lower is better for time and memory)
                performance_score = avg_time + (avg_memory / 1000) - (cache_hit_rate * 0.5)
                
                results["configurations"][config_name] = {
                    "average_time_seconds": avg_time,
                    "average_memory_mb": avg_memory,
                    "cache_hit_rate": cache_hit_rate,
                    "performance_score": performance_score,
                    "success_rate": benchmark["summary"]["success_rate"]
                }
                
                if best_performance is None or performance_score < best_performance:
                    best_performance = performance_score
                    best_config_name = config_name
            
            else:
                results["configurations"][config_name] = {
                    "error": "Configuration failed",
                    "success_rate": 0.0
                }
        
        except Exception as e:
            logger.warning(f"Configuration {config_name} failed: {e}")
            results["configurations"][config_name] = {
                "error": str(e),
                "success_rate": 0.0
            }
    
    # Generate recommendations
    if best_config_name:
        best_config = test_configs[best_config_name]
        results["recommendations"]["best_configuration"] = best_config_name
        results["recommendations"]["suggested_settings"] = {
            "enable_caching": best_config.enable_caching,
            "enable_parallel": best_config.enable_parallel,
            "enable_streaming": best_config.enable_streaming,
            "max_workers": best_config.max_workers
        }
        
        # Additional recommendations based on file characteristics
        file_size_mb = test_file.stat().st_size / (1024 * 1024)
        memory_estimates = estimate_memory_requirements(test_file)
        
        if file_size_mb > 100:
            results["recommendations"]["notes"] = [
                "Large file detected - consider enabling streaming for memory efficiency"
            ]
        
        if memory_estimates.get("recommended_ram_mb", 0) > 4000:
            results["recommendations"]["notes"] = results["recommendations"].get("notes", []) + [
                "High memory usage expected - enable streaming and limit parallel workers"
            ]
    
    else:
        results["recommendations"]["error"] = "No configuration succeeded"
    
    return results


def main():
    """Main CLI function for performance tools."""
    parser = argparse.ArgumentParser(
        description="Performance optimization and monitoring tools",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Benchmark a video file
  python -m deepfake_detector.performance_cli benchmark --file video.mp4 --output results.json
  
  # Optimize configuration for a file
  python -m deepfake_detector.performance_cli optimize --file video.mp4 --output config.json
  
  # Analyze cache performance
  python -m deepfake_detector.performance_cli cache-analysis --cache-dir /tmp/cache --output cache_stats.json
  
  # Estimate memory requirements
  python -m deepfake_detector.performance_cli memory-estimate --file video.mp4
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Benchmark command
    bench_parser = subparsers.add_parser("benchmark", help="Benchmark processing performance")
    bench_parser.add_argument("--file", required=True, type=str, help="File to benchmark")
    bench_parser.add_argument("--iterations", type=int, default=3, help="Number of iterations")
    bench_parser.add_argument("--config", type=str, help="Configuration file")
    bench_parser.add_argument("--output", type=str, required=True, help="Output JSON file")
    bench_parser.add_argument("--enable-caching", action="store_true", help="Enable caching")
    bench_parser.add_argument("--enable-parallel", action="store_true", help="Enable parallel processing")
    bench_parser.add_argument("--max-workers", type=int, help="Maximum parallel workers")
    
    # Optimize command
    opt_parser = subparsers.add_parser("optimize", help="Optimize configuration for a file")
    opt_parser.add_argument("--file", required=True, type=str, help="File to optimize for")
    opt_parser.add_argument("--config", type=str, help="Base configuration file")
    opt_parser.add_argument("--output", type=str, required=True, help="Output JSON file")
    
    # Cache analysis command
    cache_parser = subparsers.add_parser("cache-analysis", help="Analyze cache performance")
    cache_parser.add_argument("--cache-dir", required=True, type=str, help="Cache directory")
    cache_parser.add_argument("--output", type=str, required=True, help="Output JSON file")
    
    # Memory estimation command
    mem_parser = subparsers.add_parser("memory-estimate", help="Estimate memory requirements")
    mem_parser.add_argument("--file", required=True, type=str, help="File to analyze")
    mem_parser.add_argument("--target-fps", type=float, help="Target FPS")
    mem_parser.add_argument("--output", type=str, help="Output JSON file")
    
    # Common options
    for subparser in [bench_parser, opt_parser, cache_parser, mem_parser]:
        subparser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
        subparser.add_argument("--verbose", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Configure logging
    configure_logging(
        log_level=args.log_level,
        console_output=True,
        performance_monitoring=True
    )
    
    logger = get_logger(__name__)
    
    try:
        if args.command == "benchmark":
            # Load configuration
            if args.config:
                main_config = load_config(args.config)
                perf_config = main_config.performance
            else:
                perf_config = PerformanceConfig()
            
            # Apply CLI overrides
            if args.enable_caching:
                perf_config.enable_caching = True
            if args.enable_parallel:
                perf_config.enable_parallel = True
            if args.max_workers:
                perf_config.max_workers = args.max_workers
            
            logger.info(f"Benchmarking {args.file}")
            results = benchmark_file(Path(args.file), perf_config, args.iterations)
            
            # Save results
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2)
            
            # Print summary
            if results["summary"]["success_rate"] > 0:
                summary = results["summary"]
                print(f"\nBenchmark Results:")
                print(f"  Success Rate: {summary['success_rate']:.1%}")
                print(f"  Average Time: {summary['average_processing_time_seconds']:.2f}s")
                print(f"  Memory Usage: {summary['average_memory_delta_mb']:.1f} MB")
                print(f"  Cache Hit Rate: {summary['overall_cache_hit_rate']:.1%}")
            else:
                print(f"\nBenchmark failed: {results['summary'].get('error', 'Unknown error')}")
        
        elif args.command == "optimize":
            # Load base configuration
            if args.config:
                main_config = load_config(args.config)
                base_config = main_config.performance
            else:
                base_config = PerformanceConfig()
            
            logger.info(f"Optimizing configuration for {args.file}")
            results = optimize_configuration(Path(args.file), base_config)
            
            # Save results
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2)
            
            # Print recommendations
            if "best_configuration" in results["recommendations"]:
                print(f"\nOptimization Results:")
                print(f"  Best Configuration: {results['recommendations']['best_configuration']}")
                print(f"  Suggested Settings:")
                for key, value in results["recommendations"]["suggested_settings"].items():
                    print(f"    {key}: {value}")
                
                if "notes" in results["recommendations"]:
                    print(f"  Additional Notes:")
                    for note in results["recommendations"]["notes"]:
                        print(f"    - {note}")
            else:
                print(f"Optimization failed: {results['recommendations'].get('error', 'Unknown error')}")
        
        elif args.command == "cache-analysis":
            logger.info(f"Analyzing cache directory: {args.cache_dir}")
            results = analyze_cache_performance(Path(args.cache_dir))
            
            # Save results
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2)
            
            # Print summary
            if "error" not in results:
                print(f"\nCache Analysis:")
                print(f"  Total Files: {results['total_files']}")
                print(f"  Total Size: {results['total_size_mb']:.1f} MB")
                print(f"  Files by Age: {results['files_by_age']}")
                
                if results.get("algorithms"):
                    print(f"  Algorithms: {results['algorithms']}")
            else:
                print(f"Cache analysis failed: {results['error']}")
        
        elif args.command == "memory-estimate":
            logger.info(f"Estimating memory requirements for {args.file}")
            results = estimate_memory_requirements(Path(args.file), args.target_fps)
            
            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(results, f, indent=2)
            
            # Print estimates
            if "error" not in results:
                print(f"\nMemory Requirements:")
                print(f"  Single Frame: {results['single_frame_mb']:.1f} MB")
                print(f"  All Frames: {results['all_frames_mb']:.1f} MB")
                print(f"  Streaming Chunk: {results['streaming_chunk_mb']:.1f} MB")
                print(f"  Recommended RAM: {results['recommended_ram_mb']:.1f} MB")
            else:
                print(f"Memory estimation failed: {results['error']}")
        
        logger.info(f"Command completed. Results saved to {args.output}")
        
    except KeyboardInterrupt:
        logger.info("Operation interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Command failed: {e}", exc_info=True)
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
