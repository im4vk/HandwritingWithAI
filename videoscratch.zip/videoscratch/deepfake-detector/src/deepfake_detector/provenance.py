from __future__ import annotations

from pathlib import Path
from typing import Optional


def provenance_hint(path: str | Path) -> Optional[str]:
    """Best-effort provenance hint.

    This is a placeholder. It scans for an XMP header in the file bytes to hint presence of metadata
    (e.g., could be used later to check C2PA/Content Credentials with proper libs).
    Returns a short status string or None if no hint is found.
    """
    p = Path(path)
    if not p.exists() or not p.is_file():
        return None
    try:
        with open(p, "rb") as f:
            head = f.read(8192)
        if b"http://ns.adobe.com/xap/1.0/" in head or b"<x:xmpmeta" in head:
            return "XMP metadata present"
    except Exception:
        return None
    return None
