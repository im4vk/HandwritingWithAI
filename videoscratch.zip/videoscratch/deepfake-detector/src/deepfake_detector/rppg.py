from __future__ import annotations

from typing import List

import numpy as np
from scipy import signal


def _bandpass(sig: np.ndarray, sr: float, lo_hz: float, hi_hz: float) -> np.ndarray:
    nyq = 0.5 * sr
    lo = max(0.001, lo_hz / nyq)
    hi = min(0.99, hi_hz / nyq)
    b, a = signal.butter(3, [lo, hi], btype="bandpass")
    return signal.filtfilt(b, a, sig)


def rppg_fake_score(
    face_crops_bgr: List[np.ndarray],
    frame_timestamps_s: List[float],
) -> float:
    """Compute a heuristic deepfake-likelihood score from rPPG.

    1) Build a green-channel mean trace over frames (forehead-biased by center-top).
    2) Bandpass in 0.7–3.0 Hz (42–180 bpm).
    3) Measure spectral peak strength; stronger coherent peak → more real. Score = 1 - coherence.
    """
    if not face_crops_bgr or len(face_crops_bgr) < 20:
        return 0.5

    # Build signal: mean green channel of upper region (forehead area proxy)
    greens = []
    for crop in face_crops_bgr:
        h, w = crop.shape[:2]
        roi = crop[: h // 3, w // 4 : 3 * w // 4, 1]  # upper-middle band, green channel
        greens.append(float(np.mean(roi)))

    greens = np.array(greens, dtype=np.float32)

    # Timebase
    t = np.array(frame_timestamps_s, dtype=np.float32)
    if len(t) != len(greens):
        # Fallback to uniform sampling if mismatch
        dt = np.median(np.diff(t)) if len(t) > 1 else 1 / 15.0
        t = np.arange(len(greens), dtype=np.float32) * dt

    # Resample to uniform grid
    dt = np.median(np.diff(t)) if len(t) > 1 else 1 / 15.0
    sr = 1.0 / max(dt, 1e-3)

    # Detrend and normalize
    sig = greens - np.mean(greens)
    sig = sig / (np.std(sig) + 1e-6)

    # Bandpass 0.7–3.0 Hz
    sig_bp = _bandpass(sig, sr=sr, lo_hz=0.7, hi_hz=3.0)

    # Spectral analysis
    freqs, psd = signal.welch(sig_bp, fs=sr, nperseg=min(256, len(sig_bp)))
    mask = (freqs >= 0.7) & (freqs <= 3.0)
    if not np.any(mask):
        return 0.5

    peak = float(psd[mask].max())
    total = float(psd[mask].sum() + 1e-8)
    coherence = peak / total  # higher → more real

    # Map to fake-likelihood
    # If coherence >= 0.5, strong pulse → very real; if <= 0.15 → likely fake
    fake_score = 1.0 - np.clip((coherence - 0.15) / (0.5 - 0.15 + 1e-6), 0.0, 1.0)
    return float(fake_score)
