"""Enhanced face tracking with temporal consistency.

This module provides advanced face tracking capabilities including:
- Temporal consistency across video frames
- Kalman filtering for smooth motion prediction
- Identity tracking and association
- Quality-based face selection
- Motion analysis and stability metrics
"""

from __future__ import annotations

import numpy as np
import cv2
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any
from pathlib import Path
import logging
import time

from .face import FaceFrame, FaceTrack
from .exceptions import ProcessingError, handle_processing_error
from .logging_config import get_logger, create_operation_context


@dataclass
class MotionVector:
    """Motion vector for tracking movement."""
    dx: float
    dy: float
    magnitude: float
    angle: float
    confidence: float
    
    @classmethod
    def from_displacement(cls, dx: float, dy: float, confidence: float = 1.0) -> 'MotionVector':
        """Create motion vector from displacement.
        
        Args:
            dx: X displacement
            dy: Y displacement
            confidence: Motion confidence [0,1]
            
        Returns:
            MotionVector instance
        """
        magnitude = np.sqrt(dx*dx + dy*dy)
        angle = np.arctan2(dy, dx) if magnitude > 0 else 0.0
        
        return cls(
            dx=dx,
            dy=dy, 
            magnitude=magnitude,
            angle=angle,
            confidence=confidence
        )


@dataclass
class KalmanState:
    """Kalman filter state for face tracking."""
    
    # State vector: [x, y, dx, dy] (position and velocity)
    state: np.ndarray = field(default_factory=lambda: np.zeros(4))
    
    # Covariance matrix
    covariance: np.ndarray = field(default_factory=lambda: np.eye(4) * 1000)
    
    # Process noise
    process_noise: float = 1.0
    
    # Measurement noise  
    measurement_noise: float = 10.0
    
    # Time of last update
    last_update_time: float = 0.0
    
    def __post_init__(self):
        """Initialize matrices."""
        # State transition matrix (constant velocity model)
        self.F = np.array([
            [1, 0, 1, 0],  # x = x + dx
            [0, 1, 0, 1],  # y = y + dy
            [0, 0, 1, 0],  # dx = dx
            [0, 0, 0, 1]   # dy = dy
        ], dtype=np.float32)
        
        # Observation matrix (we observe position only)
        self.H = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0]
        ], dtype=np.float32)
        
        # Process noise covariance
        self.Q = np.eye(4) * self.process_noise
        
        # Measurement noise covariance
        self.R = np.eye(2) * self.measurement_noise
    
    def predict(self, dt: float) -> Tuple[float, float]:
        """Predict next position.
        
        Args:
            dt: Time delta since last update
            
        Returns:
            Predicted (x, y) position
        """
        # Update time component in transition matrix
        F_dt = self.F.copy()
        F_dt[0, 2] = dt
        F_dt[1, 3] = dt
        
        # Predict state
        self.state = F_dt @ self.state
        
        # Predict covariance
        Q_dt = self.Q * (dt * dt)
        self.covariance = F_dt @ self.covariance @ F_dt.T + Q_dt
        
        return self.state[0], self.state[1]
    
    def update(self, x: float, y: float, timestamp: float) -> None:
        """Update with measurement.
        
        Args:
            x: Observed x position
            y: Observed y position
            timestamp: Measurement timestamp
        """
        # Measurement vector
        z = np.array([x, y])
        
        # Innovation (measurement residual)
        y_residual = z - (self.H @ self.state)
        
        # Innovation covariance
        S = self.H @ self.covariance @ self.H.T + self.R
        
        # Kalman gain
        K = self.covariance @ self.H.T @ np.linalg.inv(S)
        
        # Update state
        self.state = self.state + K @ y_residual
        
        # Update covariance
        I_KH = np.eye(4) - K @ self.H
        self.covariance = I_KH @ self.covariance
        
        self.last_update_time = timestamp
    
    def get_velocity(self) -> Tuple[float, float]:
        """Get current velocity estimate.
        
        Returns:
            (dx, dy) velocity
        """
        return self.state[2], self.state[3]
    
    def get_position_uncertainty(self) -> float:
        """Get position uncertainty (trace of position covariance).
        
        Returns:
            Position uncertainty measure
        """
        return np.trace(self.covariance[:2, :2])


@dataclass
class TrackedFace:
    """A face being tracked across multiple frames."""
    
    track_id: int
    frames: List[FaceFrame] = field(default_factory=list)
    kalman_filter: KalmanState = field(default_factory=KalmanState)
    
    # Tracking metadata
    first_seen: float = 0.0
    last_seen: float = 0.0
    total_detections: int = 0
    missed_detections: int = 0
    
    # Quality metrics
    average_confidence: float = 0.0
    stability_score: float = 0.0
    motion_consistency: float = 0.0
    
    # Motion analysis
    motion_history: List[MotionVector] = field(default_factory=list)
    max_motion_history: int = 10
    
    def add_detection(self, face_frame: FaceFrame, timestamp: float) -> None:
        """Add a new face detection.
        
        Args:
            face_frame: Detected face frame
            timestamp: Detection timestamp
        """
        self.frames.append(face_frame)
        self.last_seen = timestamp
        self.total_detections += 1
        
        if self.first_seen == 0.0:
            self.first_seen = timestamp
            # Initialize Kalman filter with first detection
            x, y = face_frame.center_xy
            self.kalman_filter.state = np.array([x, y, 0, 0])
            self.kalman_filter.last_update_time = timestamp
        else:
            # Update Kalman filter
            x, y = face_frame.center_xy
            self.kalman_filter.update(x, y, timestamp)
            
            # Compute motion vector
            if len(self.frames) >= 2:
                prev_frame = self.frames[-2]
                prev_x, prev_y = prev_frame.center_xy
                curr_x, curr_y = face_frame.center_xy
                
                motion = MotionVector.from_displacement(
                    curr_x - prev_x,
                    curr_y - prev_y,
                    confidence=min(prev_frame.confidence, face_frame.confidence)
                )
                
                self.motion_history.append(motion)
                if len(self.motion_history) > self.max_motion_history:
                    self.motion_history.pop(0)
        
        # Update quality metrics
        self._update_quality_metrics()
    
    def predict_next_position(self, timestamp: float) -> Tuple[float, float]:
        """Predict next face position.
        
        Args:
            timestamp: Prediction timestamp
            
        Returns:
            Predicted (x, y) position
        """
        dt = timestamp - self.kalman_filter.last_update_time
        return self.kalman_filter.predict(dt)
    
    def get_tracking_confidence(self) -> float:
        """Get overall tracking confidence.
        
        Returns:
            Confidence score [0,1]
        """
        if self.total_detections == 0:
            return 0.0
        
        # Combine multiple confidence factors
        detection_ratio = self.total_detections / (self.total_detections + self.missed_detections)
        recency_factor = max(0.0, 1.0 - (time.time() - self.last_seen) / 5.0)  # 5 second decay
        
        return (
            0.4 * self.average_confidence +
            0.3 * detection_ratio +
            0.2 * self.stability_score +
            0.1 * recency_factor
        )
    
    def _update_quality_metrics(self) -> None:
        """Update quality metrics based on current detections."""
        if not self.frames:
            return
        
        # Average confidence
        confidences = [f.confidence for f in self.frames]
        self.average_confidence = np.mean(confidences)
        
        # Stability score (inverse of position variance)
        if len(self.frames) >= 3:
            positions = np.array([f.center_xy for f in self.frames])
            position_var = np.var(positions, axis=0).sum()
            self.stability_score = 1.0 / (1.0 + position_var / 1000.0)
        else:
            self.stability_score = 0.5
        
        # Motion consistency (consistency of motion vectors)
        if len(self.motion_history) >= 3:
            angles = [m.angle for m in self.motion_history]
            angle_var = np.var(angles)
            self.motion_consistency = 1.0 / (1.0 + angle_var)
        else:
            self.motion_consistency = 0.5
    
    def get_interpolated_frame(self, frame_index: int, total_frames: int) -> Optional[FaceFrame]:
        """Get interpolated face frame for missing detections.
        
        Args:
            frame_index: Target frame index
            total_frames: Total frames in video
            
        Returns:
            Interpolated FaceFrame or None if not possible
        """
        if len(self.frames) < 2:
            return None
        
        # Find surrounding frames
        before_frame = None
        after_frame = None
        
        for frame in self.frames:
            if frame.frame_index <= frame_index:
                before_frame = frame
            elif frame.frame_index > frame_index and after_frame is None:
                after_frame = frame
                break
        
        if before_frame is None or after_frame is None:
            return None
        
        # Interpolate position
        t = (frame_index - before_frame.frame_index) / (after_frame.frame_index - before_frame.frame_index)
        
        before_x, before_y = before_frame.center_xy
        after_x, after_y = after_frame.center_xy
        
        interp_x = before_x + t * (after_x - before_x)
        interp_y = before_y + t * (after_y - before_y)
        
        # Interpolate bounding box
        before_box = before_frame.box_xywh
        after_box = after_frame.box_xywh
        
        interp_box = [
            before_box[0] + t * (after_box[0] - before_box[0]),
            before_box[1] + t * (after_box[1] - before_box[1]),
            before_box[2] + t * (after_box[2] - before_box[2]),
            before_box[3] + t * (after_box[3] - before_box[3])
        ]
        
        # Create interpolated frame
        return FaceFrame(
            frame_index=frame_index,
            box_xywh=interp_box,
            landmarks_xy=None,  # Cannot reliably interpolate landmarks
            face_crop=None,     # No actual image crop
            confidence=min(before_frame.confidence, after_frame.confidence) * 0.8,  # Reduced confidence
            center_xy=(interp_x, interp_y),
            mouth_open=None,
            eye_open=0.5  # Neutral value
        )


class TemporalFaceTracker:
    """Enhanced face tracker with temporal consistency."""
    
    def __init__(self, 
                 max_missing_frames: int = 10,
                 min_track_length: int = 5,
                 iou_threshold: float = 0.5,
                 max_tracks: int = 5):
        """Initialize temporal face tracker.
        
        Args:
            max_missing_frames: Maximum frames a track can be missing before deletion
            min_track_length: Minimum track length to be considered valid
            iou_threshold: IoU threshold for face association
            max_tracks: Maximum number of simultaneous tracks
        """
        self.max_missing_frames = max_missing_frames
        self.min_track_length = min_track_length
        self.iou_threshold = iou_threshold
        self.max_tracks = max_tracks
        
        self.active_tracks: List[TrackedFace] = []
        self.completed_tracks: List[TrackedFace] = []
        self.next_track_id = 1
        
        self.logger = get_logger(__name__)
    
    def track_faces_in_video(self, frames_bgr: List[np.ndarray], timestamps: Optional[List[float]] = None) -> List[TrackedFace]:
        """Track faces across video frames.
        
        Args:
            frames_bgr: List of video frames
            timestamps: Optional timestamps for each frame
            
        Returns:
            List of completed face tracks
        """
        if timestamps is None:
            timestamps = list(range(len(frames_bgr)))
        
        self.logger.info(f"Starting temporal face tracking on {len(frames_bgr)} frames")
        
        with create_operation_context("temporal_face_tracking"):
            for frame_idx, (frame, timestamp) in enumerate(zip(frames_bgr, timestamps)):
                self._process_frame(frame, frame_idx, timestamp)
                
                if (frame_idx + 1) % 100 == 0:
                    self.logger.debug(f"Processed {frame_idx + 1}/{len(frames_bgr)} frames")
            
            # Finalize all remaining tracks
            self._finalize_tracks()
        
        # Filter tracks by minimum length
        valid_tracks = [track for track in self.completed_tracks 
                       if len(track.frames) >= self.min_track_length]
        
        self.logger.info(f"Temporal tracking complete: {len(valid_tracks)} valid tracks from {len(self.completed_tracks)} total")
        
        return valid_tracks
    
    def _process_frame(self, frame: np.ndarray, frame_idx: int, timestamp: float) -> None:
        """Process a single frame for face tracking.
        
        Args:
            frame: Input frame
            frame_idx: Frame index
            timestamp: Frame timestamp
        """
        # Detect faces in current frame
        face_detections = self._detect_faces_in_frame(frame, frame_idx)
        
        if not face_detections:
            # No faces detected, increment missed counts
            for track in self.active_tracks:
                track.missed_detections += 1
            self._cleanup_lost_tracks()
            return
        
        # Predict positions for active tracks
        predicted_positions = {}
        for track in self.active_tracks:
            predicted_positions[track.track_id] = track.predict_next_position(timestamp)
        
        # Associate detections with existing tracks
        associations = self._associate_detections_to_tracks(face_detections, predicted_positions)
        
        # Update existing tracks
        for detection_idx, track_id in associations.items():
            track = self._get_track_by_id(track_id)
            if track:
                track.add_detection(face_detections[detection_idx], timestamp)
        
        # Create new tracks for unassociated detections
        unassociated = set(range(len(face_detections))) - set(associations.keys())
        for detection_idx in unassociated:
            if len(self.active_tracks) < self.max_tracks:
                self._create_new_track(face_detections[detection_idx], timestamp)
        
        # Cleanup lost tracks
        self._cleanup_lost_tracks()
    
    def _detect_faces_in_frame(self, frame: np.ndarray, frame_idx: int) -> List[FaceFrame]:
        """Detect faces in a single frame.
        
        Args:
            frame: Input frame
            frame_idx: Frame index
            
        Returns:
            List of detected faces
        """
        # Use existing face detection from face.py
        from .face import _haar_track
        
        try:
            # Use Haar cascade for detection (faster for tracking)
            face_track = _haar_track([frame])
            
            if face_track and face_track.frames:
                # Update frame index
                for face_frame in face_track.frames:
                    face_frame.frame_index = frame_idx
                return face_track.frames
            else:
                return []
        
        except Exception as e:
            self.logger.warning(f"Face detection failed for frame {frame_idx}: {e}")
            return []
    
    def _associate_detections_to_tracks(self, 
                                      detections: List[FaceFrame], 
                                      predicted_positions: Dict[int, Tuple[float, float]]) -> Dict[int, int]:
        """Associate face detections with existing tracks.
        
        Args:
            detections: Current frame detections
            predicted_positions: Predicted positions for active tracks
            
        Returns:
            Dictionary mapping detection_idx -> track_id
        """
        if not self.active_tracks or not detections:
            return {}
        
        # Compute association matrix
        association_matrix = np.zeros((len(detections), len(self.active_tracks)))
        
        for det_idx, detection in enumerate(detections):
            det_x, det_y = detection.center_xy
            
            for track_idx, track in enumerate(self.active_tracks):
                # Use predicted position if available, otherwise use last known position
                if track.track_id in predicted_positions:
                    pred_x, pred_y = predicted_positions[track.track_id]
                else:
                    pred_x, pred_y = track.frames[-1].center_xy if track.frames else (0, 0)
                
                # Compute distance
                distance = np.sqrt((det_x - pred_x)**2 + (det_y - pred_y)**2)
                
                # Compute IoU if possible
                iou = self._compute_face_iou(detection, track.frames[-1] if track.frames else None)
                
                # Combined association score (lower is better)
                if iou > 0:
                    association_matrix[det_idx, track_idx] = 1.0 - iou
                else:
                    # Fallback to distance-based association
                    max_distance = 100.0  # pixels
                    association_matrix[det_idx, track_idx] = min(1.0, distance / max_distance)
        
        # Hungarian algorithm for optimal assignment (simplified greedy approach)
        associations = {}
        used_tracks = set()
        
        # Sort by best association score
        candidates = []
        for det_idx in range(len(detections)):
            for track_idx in range(len(self.active_tracks)):
                score = association_matrix[det_idx, track_idx]
                if score < 0.5:  # Threshold for valid association
                    candidates.append((score, det_idx, track_idx))
        
        candidates.sort()  # Sort by score (lower is better)
        
        for score, det_idx, track_idx in candidates:
            track_id = self.active_tracks[track_idx].track_id
            if det_idx not in associations and track_id not in used_tracks:
                associations[det_idx] = track_id
                used_tracks.add(track_id)
        
        return associations
    
    def _compute_face_iou(self, face1: FaceFrame, face2: Optional[FaceFrame]) -> float:
        """Compute IoU between two face detections.
        
        Args:
            face1: First face detection
            face2: Second face detection
            
        Returns:
            IoU score [0,1]
        """
        if face2 is None:
            return 0.0
        
        # Extract bounding boxes
        x1, y1, w1, h1 = face1.box_xywh
        x2, y2, w2, h2 = face2.box_xywh
        
        # Convert to corner format
        x1_min, y1_min, x1_max, y1_max = x1, y1, x1 + w1, y1 + h1
        x2_min, y2_min, x2_max, y2_max = x2, y2, x2 + w2, y2 + h2
        
        # Compute intersection
        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)
        
        if inter_x_max <= inter_x_min or inter_y_max <= inter_y_min:
            return 0.0
        
        intersection = (inter_x_max - inter_x_min) * (inter_y_max - inter_y_min)
        
        # Compute union
        area1 = w1 * h1
        area2 = w2 * h2
        union = area1 + area2 - intersection
        
        return intersection / union if union > 0 else 0.0
    
    def _get_track_by_id(self, track_id: int) -> Optional[TrackedFace]:
        """Get track by ID.
        
        Args:
            track_id: Track ID
            
        Returns:
            TrackedFace or None
        """
        for track in self.active_tracks:
            if track.track_id == track_id:
                return track
        return None
    
    def _create_new_track(self, face_frame: FaceFrame, timestamp: float) -> None:
        """Create a new face track.
        
        Args:
            face_frame: Initial face detection
            timestamp: Detection timestamp
        """
        track = TrackedFace(track_id=self.next_track_id)
        track.add_detection(face_frame, timestamp)
        
        self.active_tracks.append(track)
        self.next_track_id += 1
        
        self.logger.debug(f"Created new face track {track.track_id}")
    
    def _cleanup_lost_tracks(self) -> None:
        """Remove tracks that have been lost for too long."""
        tracks_to_remove = []
        
        for track in self.active_tracks:
            if track.missed_detections >= self.max_missing_frames:
                tracks_to_remove.append(track)
        
        for track in tracks_to_remove:
            self.active_tracks.remove(track)
            self.completed_tracks.append(track)
            self.logger.debug(f"Finalized track {track.track_id} with {len(track.frames)} detections")
    
    def _finalize_tracks(self) -> None:
        """Finalize all remaining active tracks."""
        for track in self.active_tracks:
            self.completed_tracks.append(track)
            self.logger.debug(f"Finalized remaining track {track.track_id} with {len(track.frames)} detections")
        
        self.active_tracks.clear()
    
    def get_best_track(self) -> Optional[TrackedFace]:
        """Get the best quality face track.
        
        Returns:
            Best TrackedFace or None
        """
        if not self.completed_tracks:
            return None
        
        # Score tracks by quality and length
        scored_tracks = []
        for track in self.completed_tracks:
            if len(track.frames) >= self.min_track_length:
                score = (
                    0.4 * track.get_tracking_confidence() +
                    0.3 * (len(track.frames) / 100.0) +  # Length bonus
                    0.2 * track.stability_score +
                    0.1 * track.motion_consistency
                )
                scored_tracks.append((score, track))
        
        if not scored_tracks:
            return None
        
        # Return highest scoring track
        scored_tracks.sort(reverse=True)
        return scored_tracks[0][1]
    
    def create_enhanced_face_track(self, fill_gaps: bool = True) -> Optional[FaceTrack]:
        """Create an enhanced FaceTrack with temporal consistency.
        
        Args:
            fill_gaps: Whether to fill gaps with interpolated frames
            
        Returns:
            Enhanced FaceTrack or None
        """
        best_track = self.get_best_track()
        if not best_track:
            return None
        
        frames = best_track.frames.copy()
        
        if fill_gaps and len(frames) >= 2:
            # Fill gaps with interpolated frames
            filled_frames = []
            
            # Sort frames by frame index
            frames.sort(key=lambda f: f.frame_index)
            
            for i in range(len(frames) - 1):
                filled_frames.append(frames[i])
                
                current_idx = frames[i].frame_index
                next_idx = frames[i + 1].frame_index
                
                # Fill gaps between frames
                if next_idx - current_idx > 1:
                    for gap_idx in range(current_idx + 1, next_idx):
                        interpolated = best_track.get_interpolated_frame(
                            gap_idx, 
                            frames[-1].frame_index + 1
                        )
                        if interpolated:
                            filled_frames.append(interpolated)
            
            # Add the last frame
            filled_frames.append(frames[-1])
            frames = filled_frames
        
        # Create enhanced FaceTrack
        enhanced_track = FaceTrack(frames=frames)
        
        self.logger.info(f"Created enhanced face track with {len(frames)} frames "
                        f"(original: {len(best_track.frames)}, confidence: {best_track.get_tracking_confidence():.3f})")
        
        return enhanced_track


# Integration functions for backward compatibility
def detect_face_track_temporal(frames_bgr: List[np.ndarray], 
                              timestamps: Optional[List[float]] = None,
                              fill_gaps: bool = True) -> Optional[FaceTrack]:
    """Detect face track with temporal consistency.
    
    Args:
        frames_bgr: List of video frames
        timestamps: Optional frame timestamps
        fill_gaps: Whether to fill gaps with interpolated frames
        
    Returns:
        Enhanced FaceTrack or None
    """
    try:
        tracker = TemporalFaceTracker()
        tracker.track_faces_in_video(frames_bgr, timestamps)
        return tracker.create_enhanced_face_track(fill_gaps=fill_gaps)
    
    except Exception as e:
        # Fallback to original detection
        logger = get_logger(__name__)
        logger.warning(f"Temporal tracking failed, falling back to original detection: {e}")
        
        from .face import detect_face_track
        return detect_face_track(frames_bgr)


def analyze_face_tracking_quality(tracked_faces: List[TrackedFace]) -> Dict[str, Any]:
    """Analyze quality of face tracking results.
    
    Args:
        tracked_faces: List of tracked faces
        
    Returns:
        Quality analysis results
    """
    if not tracked_faces:
        return {
            "total_tracks": 0,
            "error": "No tracks to analyze"
        }
    
    # Compute statistics
    track_lengths = [len(track.frames) for track in tracked_faces]
    confidences = [track.get_tracking_confidence() for track in tracked_faces]
    stability_scores = [track.stability_score for track in tracked_faces]
    
    # Motion analysis
    total_motion_vectors = sum(len(track.motion_history) for track in tracked_faces)
    motion_magnitudes = []
    for track in tracked_faces:
        motion_magnitudes.extend([mv.magnitude for mv in track.motion_history])
    
    analysis = {
        "total_tracks": len(tracked_faces),
        "track_statistics": {
            "average_length": np.mean(track_lengths),
            "max_length": max(track_lengths),
            "min_length": min(track_lengths),
            "length_std": np.std(track_lengths)
        },
        "quality_metrics": {
            "average_confidence": np.mean(confidences),
            "confidence_std": np.std(confidences),
            "average_stability": np.mean(stability_scores),
            "stability_std": np.std(stability_scores)
        },
        "motion_analysis": {
            "total_motion_vectors": total_motion_vectors,
            "average_motion_magnitude": np.mean(motion_magnitudes) if motion_magnitudes else 0.0,
            "motion_std": np.std(motion_magnitudes) if motion_magnitudes else 0.0
        },
        "best_track": {
            "track_id": None,
            "length": 0,
            "confidence": 0.0
        }
    }
    
    # Find best track
    if tracked_faces:
        best_track = max(tracked_faces, key=lambda t: t.get_tracking_confidence())
        analysis["best_track"] = {
            "track_id": best_track.track_id,
            "length": len(best_track.frames),
            "confidence": best_track.get_tracking_confidence(),
            "stability": best_track.stability_score,
            "motion_consistency": best_track.motion_consistency
        }
    
    return analysis
