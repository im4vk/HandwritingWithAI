"""Command-line interface for temporal tracking analysis and visualization."""

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

import numpy as np
import cv2

from .temporal_tracking import (
    TemporalFaceTracker,
    TrackedFace,
    analyze_face_tracking_quality
)
from .face import detect_face_track
from .io import read_video, write_video
from .logging_config import configure_logging, get_logger


def analyze_tracking_performance(video_path: Path, 
                               output_path: Path,
                               config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Analyze temporal tracking performance on a video.
    
    Args:
        video_path: Path to input video
        output_path: Path to save analysis results
        config: Optional tracking configuration
        
    Returns:
        Analysis results
    """
    logger = get_logger(__name__)
    logger.info(f"Analyzing temporal tracking performance for {video_path}")
    
    # Load video
    video_data = read_video(video_path, target_fps=15, max_frames=300)  # Limit for analysis
    frames = video_data.frames_bgr
    timestamps = video_data.frame_timestamps_s
    
    if len(frames) < 5:
        return {"error": "Video too short for temporal analysis"}
    
    # Configure tracker
    tracker_config = {
        "max_missing_frames": config.get("max_missing_frames", 10) if config else 10,
        "min_track_length": config.get("min_track_length", 5) if config else 5,
        "iou_threshold": config.get("iou_threshold", 0.5) if config else 0.5,
        "max_tracks": config.get("max_tracks", 5) if config else 5
    }
    
    # Run temporal tracking
    start_time = time.time()
    
    tracker = TemporalFaceTracker(**tracker_config)
    tracked_faces = tracker.track_faces_in_video(frames, timestamps)
    
    tracking_time = time.time() - start_time
    
    # Run baseline frame-by-frame detection for comparison
    start_time = time.time()
    
    baseline_track = detect_face_track(frames, use_temporal_tracking=False)
    
    baseline_time = time.time() - start_time
    
    # Analyze results
    tracking_analysis = analyze_face_tracking_quality(tracked_faces)
    
    results = {
        "video_info": {
            "path": str(video_path),
            "total_frames": len(frames),
            "duration_seconds": timestamps[-1] if timestamps else len(frames) / 15.0,
            "fps": len(frames) / timestamps[-1] if timestamps and timestamps[-1] > 0 else 15.0
        },
        "tracking_config": tracker_config,
        "performance": {
            "temporal_tracking_time": tracking_time,
            "baseline_tracking_time": baseline_time,
            "speedup_factor": baseline_time / tracking_time if tracking_time > 0 else 0.0,
            "frames_per_second": len(frames) / tracking_time if tracking_time > 0 else 0.0
        },
        "temporal_tracking_results": tracking_analysis,
        "baseline_results": {
            "detected_faces": len(baseline_track.frames) if baseline_track else 0,
            "detection_rate": len(baseline_track.frames) / len(frames) if baseline_track else 0.0
        },
        "comparison": {
            "temporal_faces": tracking_analysis.get("total_tracks", 0),
            "temporal_detection_quality": 0.0,
            "consistency_improvement": 0.0
        }
    }
    
    # Calculate quality improvements
    if tracking_analysis.get("total_tracks", 0) > 0 and baseline_track:
        best_track_info = tracking_analysis.get("best_track", {})
        temporal_quality = best_track_info.get("confidence", 0.0)
        baseline_quality = 1.0 if baseline_track else 0.0  # Baseline doesn't have quality metrics
        
        results["comparison"]["temporal_detection_quality"] = temporal_quality
        results["comparison"]["consistency_improvement"] = max(0.0, temporal_quality - 0.5)
    
    # Save results
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    logger.info(f"Tracking analysis completed. Results saved to {output_path}")
    
    return results


def visualize_tracking(video_path: Path, 
                      output_path: Path,
                      config: Optional[Dict[str, Any]] = None,
                      show_predictions: bool = True,
                      show_motion_vectors: bool = True) -> None:
    """Create visualization video showing temporal tracking results.
    
    Args:
        video_path: Path to input video
        output_path: Path to save visualization video
        config: Optional tracking configuration
        show_predictions: Whether to show position predictions
        show_motion_vectors: Whether to show motion vectors
    """
    logger = get_logger(__name__)
    logger.info(f"Creating tracking visualization for {video_path}")
    
    # Load video
    video_data = read_video(video_path, target_fps=15, max_frames=300)
    frames = video_data.frames_bgr
    timestamps = video_data.frame_timestamps_s
    
    if len(frames) < 5:
        logger.error("Video too short for tracking visualization")
        return
    
    # Configure tracker
    tracker_config = {
        "max_missing_frames": config.get("max_missing_frames", 10) if config else 10,
        "min_track_length": config.get("min_track_length", 3) if config else 3,
        "iou_threshold": config.get("iou_threshold", 0.5) if config else 0.5,
        "max_tracks": config.get("max_tracks", 5) if config else 5
    }
    
    # Run tracking
    tracker = TemporalFaceTracker(**tracker_config)
    tracked_faces = tracker.track_faces_in_video(frames, timestamps)
    
    # Create visualization frames
    vis_frames = []
    colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0), (255, 0, 255)]
    
    for frame_idx, frame in enumerate(frames):
        vis_frame = frame.copy()
        
        # Draw tracked faces
        for track_idx, track in enumerate(tracked_faces):
            color = colors[track_idx % len(colors)]
            
            # Find face detection for this frame
            current_detection = None
            for face_frame in track.frames:
                if face_frame.frame_index == frame_idx:
                    current_detection = face_frame
                    break
            
            if current_detection:
                # Draw bounding box
                x, y, w, h = [int(v) for v in current_detection.box_xywh]
                cv2.rectangle(vis_frame, (x, y), (x + w, y + h), color, 2)
                
                # Draw track ID
                cv2.putText(vis_frame, f"Track {track.track_id}", 
                          (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
                
                # Draw confidence
                cv2.putText(vis_frame, f"Conf: {current_detection.confidence:.2f}",
                          (x, y + h + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
                
                # Draw center point
                center_x, center_y = [int(v) for v in current_detection.center_xy]
                cv2.circle(vis_frame, (center_x, center_y), 3, color, -1)
                
                # Draw motion vector if available
                if show_motion_vectors and len(track.motion_history) > 0:
                    latest_motion = track.motion_history[-1]
                    if latest_motion.magnitude > 1.0:  # Only show significant motion
                        end_x = int(center_x + latest_motion.dx * 5)  # Scale for visibility
                        end_y = int(center_y + latest_motion.dy * 5)
                        cv2.arrowedLine(vis_frame, (center_x, center_y), (end_x, end_y), color, 2)
            
            # Show predictions for active tracks
            elif show_predictions and frame_idx < len(frames) - 1:
                # Check if track was active recently
                last_detection_frame = max([f.frame_index for f in track.frames]) if track.frames else -1
                if frame_idx - last_detection_frame <= tracker_config["max_missing_frames"]:
                    # Predict position
                    timestamp = timestamps[frame_idx] if frame_idx < len(timestamps) else frame_idx
                    pred_x, pred_y = track.predict_next_position(timestamp)
                    
                    # Draw predicted position
                    pred_x, pred_y = int(pred_x), int(pred_y)
                    cv2.circle(vis_frame, (pred_x, pred_y), 5, color, 1)
                    cv2.putText(vis_frame, f"Pred {track.track_id}", 
                              (pred_x + 10, pred_y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
        
        # Add frame info
        cv2.putText(vis_frame, f"Frame {frame_idx}/{len(frames)-1}", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(vis_frame, f"Tracks: {len(tracked_faces)}", 
                   (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        vis_frames.append(vis_frame)
    
    # Save visualization video
    write_video(vis_frames, output_path, fps=video_data.fps or 15.0)
    
    logger.info(f"Tracking visualization saved to {output_path}")


def compare_tracking_methods(video_path: Path, 
                           output_path: Path,
                           configs: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Compare different tracking configurations.
    
    Args:
        video_path: Path to input video
        output_path: Path to save comparison results
        configs: List of tracking configurations to compare
        
    Returns:
        Comparison results
    """
    logger = get_logger(__name__)
    logger.info(f"Comparing tracking methods for {video_path}")
    
    # Default configurations if none provided
    if not configs:
        configs = [
            {"name": "default", "max_missing_frames": 10, "min_track_length": 5, "iou_threshold": 0.5},
            {"name": "strict", "max_missing_frames": 5, "min_track_length": 8, "iou_threshold": 0.7},
            {"name": "permissive", "max_missing_frames": 15, "min_track_length": 3, "iou_threshold": 0.3},
            {"name": "high_quality", "max_missing_frames": 8, "min_track_length": 10, "iou_threshold": 0.6}
        ]
    
    # Load video
    video_data = read_video(video_path, target_fps=15, max_frames=200)  # Limit for comparison
    frames = video_data.frames_bgr
    timestamps = video_data.frame_timestamps_s
    
    results = {
        "video_info": {
            "path": str(video_path),
            "total_frames": len(frames),
            "duration_seconds": timestamps[-1] if timestamps else len(frames) / 15.0
        },
        "configurations": [],
        "comparison_summary": {}
    }
    
    for config in configs:
        config_name = config.pop("name", "unnamed")
        logger.info(f"Testing configuration: {config_name}")
        
        start_time = time.time()
        
        # Run tracking with this configuration
        tracker = TemporalFaceTracker(**config)
        tracked_faces = tracker.track_faces_in_video(frames, timestamps)
        
        tracking_time = time.time() - start_time
        
        # Analyze results
        analysis = analyze_face_tracking_quality(tracked_faces)
        
        config_results = {
            "name": config_name,
            "configuration": config,
            "performance": {
                "tracking_time": tracking_time,
                "frames_per_second": len(frames) / tracking_time if tracking_time > 0 else 0.0
            },
            "results": analysis
        }
        
        results["configurations"].append(config_results)
    
    # Generate comparison summary
    if results["configurations"]:
        # Find best configuration by different criteria
        best_by_quality = max(results["configurations"], 
                            key=lambda c: c["results"].get("quality_metrics", {}).get("average_confidence", 0))
        best_by_speed = max(results["configurations"], 
                          key=lambda c: c["performance"]["frames_per_second"])
        best_by_tracks = max(results["configurations"], 
                           key=lambda c: c["results"].get("total_tracks", 0))
        
        results["comparison_summary"] = {
            "best_quality": {
                "name": best_by_quality["name"],
                "quality_score": best_by_quality["results"].get("quality_metrics", {}).get("average_confidence", 0)
            },
            "fastest": {
                "name": best_by_speed["name"],
                "fps": best_by_speed["performance"]["frames_per_second"]
            },
            "most_tracks": {
                "name": best_by_tracks["name"],
                "track_count": best_by_tracks["results"].get("total_tracks", 0)
            }
        }
    
    # Save results
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    logger.info(f"Tracking comparison completed. Results saved to {output_path}")
    
    return results


def main():
    """Main CLI function for temporal tracking tools."""
    parser = argparse.ArgumentParser(
        description="Temporal tracking analysis and visualization tools",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze tracking performance
  python -m deepfake_detector.tracking_cli analyze --video video.mp4 --output analysis.json
  
  # Create tracking visualization
  python -m deepfake_detector.tracking_cli visualize --video video.mp4 --output tracking_vis.mp4
  
  # Compare tracking configurations
  python -m deepfake_detector.tracking_cli compare --video video.mp4 --output comparison.json
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Analyze command
    analyze_parser = subparsers.add_parser("analyze", help="Analyze tracking performance")
    analyze_parser.add_argument("--video", required=True, type=str, help="Input video file")
    analyze_parser.add_argument("--output", required=True, type=str, help="Output JSON file")
    analyze_parser.add_argument("--max-missing-frames", type=int, default=10, help="Max missing frames")
    analyze_parser.add_argument("--min-track-length", type=int, default=5, help="Min track length")
    analyze_parser.add_argument("--iou-threshold", type=float, default=0.5, help="IoU threshold")
    analyze_parser.add_argument("--max-tracks", type=int, default=5, help="Max simultaneous tracks")
    
    # Visualize command
    vis_parser = subparsers.add_parser("visualize", help="Create tracking visualization")
    vis_parser.add_argument("--video", required=True, type=str, help="Input video file")
    vis_parser.add_argument("--output", required=True, type=str, help="Output video file")
    vis_parser.add_argument("--max-missing-frames", type=int, default=10, help="Max missing frames")
    vis_parser.add_argument("--min-track-length", type=int, default=3, help="Min track length")
    vis_parser.add_argument("--iou-threshold", type=float, default=0.5, help="IoU threshold")
    vis_parser.add_argument("--max-tracks", type=int, default=5, help="Max simultaneous tracks")
    vis_parser.add_argument("--no-predictions", action="store_true", help="Don't show predictions")
    vis_parser.add_argument("--no-motion", action="store_true", help="Don't show motion vectors")
    
    # Compare command
    compare_parser = subparsers.add_parser("compare", help="Compare tracking configurations")
    compare_parser.add_argument("--video", required=True, type=str, help="Input video file")
    compare_parser.add_argument("--output", required=True, type=str, help="Output JSON file")
    compare_parser.add_argument("--configs", type=str, help="JSON file with configurations to compare")
    
    # Common options
    for subparser in [analyze_parser, vis_parser, compare_parser]:
        subparser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
        subparser.add_argument("--verbose", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Configure logging
    configure_logging(
        log_level=args.log_level,
        console_output=True,
        performance_monitoring=True
    )
    
    logger = get_logger(__name__)
    
    try:
        if args.command == "analyze":
            config = {
                "max_missing_frames": args.max_missing_frames,
                "min_track_length": args.min_track_length,
                "iou_threshold": args.iou_threshold,
                "max_tracks": args.max_tracks
            }
            
            results = analyze_tracking_performance(
                Path(args.video), 
                Path(args.output),
                config
            )
            
            # Print summary
            print(f"\nTracking Analysis Results:")
            print(f"  Video: {Path(args.video).name}")
            print(f"  Total Frames: {results['video_info']['total_frames']}")
            print(f"  Tracking Time: {results['performance']['temporal_tracking_time']:.2f}s")
            print(f"  Detected Tracks: {results['temporal_tracking_results']['total_tracks']}")
            
            if results['temporal_tracking_results']['total_tracks'] > 0:
                best_track = results['temporal_tracking_results']['best_track']
                print(f"  Best Track Quality: {best_track['confidence']:.3f}")
                print(f"  Best Track Length: {best_track['length']} frames")
        
        elif args.command == "visualize":
            config = {
                "max_missing_frames": args.max_missing_frames,
                "min_track_length": args.min_track_length,
                "iou_threshold": args.iou_threshold,
                "max_tracks": args.max_tracks
            }
            
            visualize_tracking(
                Path(args.video),
                Path(args.output),
                config,
                show_predictions=not args.no_predictions,
                show_motion_vectors=not args.no_motion
            )
            
            print(f"Tracking visualization saved to: {args.output}")
        
        elif args.command == "compare":
            configs = None
            if args.configs:
                with open(args.configs, 'r') as f:
                    configs = json.load(f)
            
            results = compare_tracking_methods(
                Path(args.video),
                Path(args.output),
                configs
            )
            
            # Print comparison summary
            print(f"\nTracking Configuration Comparison:")
            print(f"  Video: {Path(args.video).name}")
            print(f"  Configurations Tested: {len(results['configurations'])}")
            
            if "comparison_summary" in results:
                summary = results["comparison_summary"]
                print(f"  Best Quality: {summary['best_quality']['name']} ({summary['best_quality']['quality_score']:.3f})")
                print(f"  Fastest: {summary['fastest']['name']} ({summary['fastest']['fps']:.1f} fps)")
                print(f"  Most Tracks: {summary['most_tracks']['name']} ({summary['most_tracks']['track_count']} tracks)")
        
        logger.info(f"Command completed successfully")
        
    except KeyboardInterrupt:
        logger.info("Operation interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Command failed: {e}", exc_info=True)
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
