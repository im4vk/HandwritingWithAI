"""Command-line interface for validation framework."""

import argparse
import sys
import json
from pathlib import Path
from typing import Optional

from .validation import (
    ValidationFramework,
    ValidationDataset,
    DatasetType,
    LabelFormat,
    create_validation_dataset
)
from .config import load_config, create_profile_configs
from .logging_config import configure_logging, get_logger


def main():
    """Main CLI function for validation."""
    parser = argparse.ArgumentParser(
        description="Validate deepfake detection accuracy on datasets",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Validate on CSV dataset
  python -m deepfake_detector.validate_cli --csv dataset.csv --output results.json
  
  # Validate on directory structure
  python -m deepfake_detector.validate_cli --real-dir real/ --fake-dir fake/ --output results.json
  
  # Cross-validation with specific config
  python -m deepfake_detector.validate_cli --csv dataset.csv --cross-validate 5 --config production.json
  
  # Quick validation on a few files
  python -m deepfake_detector.validate_cli --quick real1.mp4:0 fake1.mp4:1 fake2.mp4:1
        """
    )
    
    # Dataset input options
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument("--csv", type=str, help="CSV file with file paths and labels")
    input_group.add_argument("--real-dir", type=str, help="Directory containing real samples")
    input_group.add_argument("--quick", nargs="+", help="Quick validation: file1:label1 file2:label2 ...")
    
    # Dataset options
    parser.add_argument("--fake-dir", type=str, help="Directory containing fake samples (required with --real-dir)")
    parser.add_argument("--dataset-name", type=str, default="validation_dataset", help="Name for the dataset")
    parser.add_argument("--dataset-type", type=str, choices=[dt.value for dt in DatasetType], 
                       default="custom", help="Type of dataset")
    parser.add_argument("--label-format", type=str, choices=[lf.value for lf in LabelFormat],
                       default="binary", help="Format of labels in CSV")
    parser.add_argument("--file-column", type=str, default="file_path", help="CSV column name for file paths")
    parser.add_argument("--label-column", type=str, default="label", help="CSV column name for labels")
    parser.add_argument("--root-path", type=str, help="Root path for relative file paths in CSV")
    
    # Validation options
    parser.add_argument("--config", type=str, help="Configuration file path")
    parser.add_argument("--profile", type=str, choices=["development", "production", "fast", "accuracy"],
                       help="Use predefined configuration profile")
    parser.add_argument("--cross-validate", type=int, metavar="K", help="Perform K-fold cross-validation")
    parser.add_argument("--split-test", type=float, default=1.0, metavar="RATIO",
                       help="Use only this fraction of dataset for testing (default: 1.0)")
    parser.add_argument("--max-workers", type=int, default=4, help="Maximum number of parallel workers")
    parser.add_argument("--timeout", type=float, default=60.0, help="Timeout per sample in seconds")
    parser.add_argument("--random-seed", type=int, default=42, help="Random seed for reproducibility")
    
    # Output options
    parser.add_argument("--output", type=str, required=True, help="Output JSON file for results")
    parser.add_argument("--save-individual", action="store_true", help="Save individual sample results")
    parser.add_argument("--results-dir", type=str, help="Directory to save individual results")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    
    # Logging options
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument("--log-dir", type=str, help="Directory for log files")
    parser.add_argument("--quiet", action="store_true", help="Minimal console output")
    
    args = parser.parse_args()
    
    # Configure logging
    configure_logging(
        log_level=args.log_level,
        log_dir=args.log_dir,
        console_output=not args.quiet,
        file_output=args.log_dir is not None,
        structured_logs=False,
        performance_monitoring=True
    )
    
    logger = get_logger(__name__)
    logger.info("Starting deepfake detection validation")
    
    try:
        # Load configuration
        config = None
        if args.profile:
            profiles = create_profile_configs()
            config = profiles[args.profile]
            logger.info(f"Using configuration profile: {args.profile}")
        elif args.config:
            config = load_config(args.config, create_default=False)
            logger.info(f"Loaded configuration from: {args.config}")
        
        # Create validation framework
        framework = ValidationFramework(config)
        
        # Load dataset
        if args.csv:
            logger.info(f"Loading dataset from CSV: {args.csv}")
            dataset = ValidationDataset(
                args.dataset_name, 
                DatasetType(args.dataset_type),
                Path(args.root_path) if args.root_path else None
            )
            dataset.load_from_csv(
                Path(args.csv),
                file_column=args.file_column,
                label_column=args.label_column,
                label_format=LabelFormat(args.label_format)
            )
            
        elif args.real_dir:
            if not args.fake_dir:
                parser.error("--fake-dir is required when using --real-dir")
            
            logger.info(f"Loading dataset from directories: {args.real_dir}, {args.fake_dir}")
            dataset = create_validation_dataset(
                args.dataset_name,
                real_dir=Path(args.real_dir),
                fake_dir=Path(args.fake_dir),
                dataset_type=DatasetType(args.dataset_type)
            )
            
        elif args.quick:
            logger.info("Performing quick validation")
            dataset = ValidationDataset(args.dataset_name, DatasetType.CUSTOM)
            
            for file_label in args.quick:
                if ":" not in file_label:
                    parser.error(f"Invalid format for quick validation: {file_label}. Use file:label")
                
                file_path, label_str = file_label.rsplit(":", 1)
                try:
                    label = float(label_str)
                    if not (0.0 <= label <= 1.0):
                        parser.error(f"Label must be between 0.0 and 1.0: {label}")
                except ValueError:
                    parser.error(f"Invalid label format: {label_str}")
                
                dataset.add_sample(Path(file_path), label)
        
        # Print dataset statistics
        stats = dataset.get_statistics()
        logger.info(f"Dataset loaded: {stats['total_samples']} samples "
                   f"({stats['real_samples']} real, {stats['fake_samples']} fake)")
        
        if args.verbose:
            logger.info(f"Dataset statistics: {json.dumps(stats, indent=2)}")
        
        # Split dataset if requested
        if args.split_test < 1.0:
            logger.info(f"Using {args.split_test:.1%} of dataset for testing")
            train_dataset, val_dataset, test_dataset = dataset.split_dataset(
                train_ratio=0.0,
                val_ratio=1.0 - args.split_test,
                test_ratio=args.split_test,
                stratify=True,
                random_seed=args.random_seed
            )
            dataset = test_dataset
            logger.info(f"Test set: {len(dataset.samples)} samples")
        
        # Perform validation
        if args.cross_validate:
            logger.info(f"Performing {args.cross_validate}-fold cross-validation")
            cv_results = framework.cross_validate(
                dataset, 
                k_folds=args.cross_validate, 
                random_seed=args.random_seed
            )
            
            # Save cross-validation results
            output_data = {
                "validation_type": "cross_validation",
                "dataset_name": args.dataset_name,
                "dataset_statistics": stats,
                "cross_validation_results": cv_results,
                "configuration": {
                    "k_folds": args.cross_validate,
                    "random_seed": args.random_seed,
                    "config_profile": args.profile,
                    "config_file": args.config
                }
            }
            
            # Print summary
            metrics = cv_results["metrics"]
            print(f"\nCross-Validation Results ({args.cross_validate} folds):")
            print(f"  Accuracy:  {metrics['accuracy_mean']:.3f} ± {metrics['accuracy_std']:.3f}")
            print(f"  Precision: {metrics['precision_mean']:.3f} ± {metrics['precision_std']:.3f}")
            print(f"  Recall:    {metrics['recall_mean']:.3f} ± {metrics['recall_std']:.3f}")
            print(f"  F1-Score:  {metrics['f1_score_mean']:.3f} ± {metrics['f1_score_std']:.3f}")
            print(f"  AUC-ROC:   {metrics['auc_roc_mean']:.3f} ± {metrics['auc_roc_std']:.3f}")
            
        else:
            logger.info("Performing single validation run")
            metrics = framework.validate_dataset(
                dataset,
                max_workers=args.max_workers,
                timeout_per_sample=args.timeout,
                save_individual_results=args.save_individual,
                results_dir=Path(args.results_dir) if args.results_dir else None
            )
            
            # Save validation results
            output_data = {
                "validation_type": "single_run",
                "dataset_name": args.dataset_name,
                "dataset_statistics": stats,
                "validation_metrics": {
                    "accuracy": metrics.accuracy,
                    "precision": metrics.precision,
                    "recall": metrics.recall,
                    "f1_score": metrics.f1_score,
                    "auc_roc": metrics.auc_roc,
                    "auc_pr": metrics.auc_pr,
                    "optimal_threshold": metrics.optimal_threshold,
                    "specificity": metrics.specificity,
                    "sensitivity": metrics.sensitivity,
                    "balanced_accuracy": metrics.balanced_accuracy,
                    "matthews_cc": metrics.matthews_cc,
                    "confusion_matrix": {
                        "true_positives": metrics.true_positives,
                        "true_negatives": metrics.true_negatives,
                        "false_positives": metrics.false_positives,
                        "false_negatives": metrics.false_negatives
                    },
                    "performance": {
                        "total_samples": metrics.total_samples,
                        "successful_samples": metrics.successful_samples,
                        "error_rate": metrics.error_rate,
                        "average_processing_time": metrics.average_processing_time,
                        "samples_per_second": metrics.samples_per_second
                    },
                    "algorithm_contributions": metrics.algorithm_contributions,
                    "errors_by_type": metrics.errors_by_type
                },
                "configuration": {
                    "max_workers": args.max_workers,
                    "timeout_per_sample": args.timeout,
                    "config_profile": args.profile,
                    "config_file": args.config
                }
            }
            
            # Print summary
            print(f"\nValidation Results:")
            print(f"  Dataset: {args.dataset_name} ({metrics.total_samples} samples)")
            print(f"  Success Rate: {metrics.successful_samples}/{metrics.total_samples} ({(1-metrics.error_rate)*100:.1f}%)")
            print(f"  Accuracy: {metrics.accuracy:.3f}")
            print(f"  Precision: {metrics.precision:.3f}")
            print(f"  Recall: {metrics.recall:.3f}")
            print(f"  F1-Score: {metrics.f1_score:.3f}")
            print(f"  AUC-ROC: {metrics.auc_roc:.3f}")
            print(f"  AUC-PR: {metrics.auc_pr:.3f}")
            print(f"  Optimal Threshold: {metrics.optimal_threshold:.3f}")
            print(f"  Processing Speed: {metrics.samples_per_second:.1f} samples/sec")
            
            if metrics.algorithm_contributions:
                print(f"\nAlgorithm Contributions (AUC):")
                for alg, contribution in sorted(metrics.algorithm_contributions.items(), 
                                              key=lambda x: x[1], reverse=True):
                    print(f"  {alg}: {contribution:.3f}")
            
            if metrics.errors_by_type:
                print(f"\nErrors by Type:")
                for error_type, count in metrics.errors_by_type.items():
                    print(f"  {error_type}: {count}")
        
        # Save results to file
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Results saved to: {output_path}")
        print(f"\nDetailed results saved to: {output_path}")
        
        if args.save_individual and args.results_dir:
            print(f"Individual results saved to: {args.results_dir}")
        
    except KeyboardInterrupt:
        logger.info("Validation interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Validation failed: {e}", exc_info=True)
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
