"""Validation framework for deepfake detection evaluation.

This module provides comprehensive validation capabilities including:
- Dataset loading and management
- Accuracy metrics computation
- ROC/PR curve analysis
- Cross-validation support
- Benchmark comparison
- Error analysis
"""

from __future__ import annotations

import logging
import json
import csv
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

from .exceptions import (
    InputValidationError,
    ProcessingError,
    validate_input,
    handle_processing_error,
)
from .logging_config import get_logger, create_operation_context


class DatasetType(Enum):
    """Enumeration of dataset types."""
    CELEB_DF = "celeb_df"
    DFDC = "dfdc"
    FACEFORENSICS = "faceforensics"
    DEEPFAKES_DETECTION = "deepfakes_detection"
    CUSTOM = "custom"


class LabelFormat(Enum):
    """Enumeration of label formats."""
    BINARY = "binary"           # 0=real, 1=fake
    STRING = "string"           # "real"/"fake"
    PROBABILITY = "probability" # [0,1] continuous


@dataclass
class ValidationSample:
    """Single validation sample."""
    file_path: Path
    ground_truth: float        # 0=real, 1=fake
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Validate sample data."""
        if not isinstance(self.file_path, Path):
            self.file_path = Path(self.file_path)
        
        if not (0.0 <= self.ground_truth <= 1.0):
            raise InputValidationError(f"Ground truth must be in [0,1], got {self.ground_truth}")


@dataclass
class ValidationResult:
    """Results from validating a single sample."""
    sample: ValidationSample
    prediction: float
    processing_time: float
    success: bool
    error_message: Optional[str] = None
    algorithm_scores: Optional[Dict[str, float]] = None
    quality_metrics: Optional[Dict[str, Dict[str, float]]] = None
    fusion_metadata: Optional[Dict[str, Any]] = None


@dataclass
class ValidationMetrics:
    """Comprehensive validation metrics."""
    # Basic metrics
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    auc_roc: float
    auc_pr: float
    
    # Threshold-based metrics
    optimal_threshold: float
    true_positives: int
    true_negatives: int
    false_positives: int
    false_negatives: int
    
    # Advanced metrics
    specificity: float
    sensitivity: float
    balanced_accuracy: float
    matthews_cc: float
    
    # Performance metrics
    total_samples: int
    successful_samples: int
    average_processing_time: float
    samples_per_second: float
    
    # Error analysis
    error_rate: float
    errors_by_type: Dict[str, int] = field(default_factory=dict)
    
    # Per-algorithm metrics
    algorithm_contributions: Optional[Dict[str, float]] = None
    quality_statistics: Optional[Dict[str, Dict[str, float]]] = None


class ValidationDataset:
    """Manages validation datasets."""
    
    def __init__(self, 
                 name: str,
                 dataset_type: DatasetType = DatasetType.CUSTOM,
                 root_path: Optional[Path] = None):
        """Initialize validation dataset.
        
        Args:
            name: Dataset name
            dataset_type: Type of dataset
            root_path: Root directory containing dataset files
        """
        self.name = name
        self.dataset_type = dataset_type
        self.root_path = Path(root_path) if root_path else None
        self.samples: List[ValidationSample] = []
        self.logger = get_logger(__name__)
        
        self.logger.info(f"Initialized validation dataset: {name} ({dataset_type.value})")
    
    def load_from_csv(self, csv_path: Path, 
                     file_column: str = "file_path",
                     label_column: str = "label",
                     label_format: LabelFormat = LabelFormat.BINARY) -> None:
        """Load dataset from CSV file.
        
        Args:
            csv_path: Path to CSV file
            file_column: Column name for file paths
            label_column: Column name for labels
            label_format: Format of labels in CSV
        """
        try:
            validate_input(csv_path, "csv_path", Path)
            
            if not csv_path.exists():
                raise ProcessingError(f"CSV file not found: {csv_path}")
            
            self.samples.clear()
            
            with open(csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                
                for row_idx, row in enumerate(reader):
                    try:
                        if file_column not in row:
                            raise ProcessingError(f"Column '{file_column}' not found in CSV")
                        if label_column not in row:
                            raise ProcessingError(f"Column '{label_column}' not found in CSV")
                        
                        # Parse file path
                        file_path = Path(row[file_column])
                        if self.root_path and not file_path.is_absolute():
                            file_path = self.root_path / file_path
                        
                        # Parse label
                        label_str = row[label_column].strip()
                        if label_format == LabelFormat.BINARY:
                            ground_truth = float(label_str)
                        elif label_format == LabelFormat.STRING:
                            ground_truth = 1.0 if label_str.lower() in ['fake', 'deepfake', '1', 'true'] else 0.0
                        elif label_format == LabelFormat.PROBABILITY:
                            ground_truth = float(label_str)
                        else:
                            raise ProcessingError(f"Unsupported label format: {label_format}")
                        
                        # Extract metadata from remaining columns
                        metadata = {k: v for k, v in row.items() 
                                   if k not in [file_column, label_column]}
                        
                        sample = ValidationSample(
                            file_path=file_path,
                            ground_truth=ground_truth,
                            metadata=metadata
                        )
                        self.samples.append(sample)
                        
                    except Exception as e:
                        self.logger.warning(f"Failed to parse row {row_idx}: {e}")
                        continue
            
            self.logger.info(f"Loaded {len(self.samples)} samples from {csv_path}")
            
        except Exception as e:
            raise handle_processing_error(f"load dataset from CSV {csv_path}", e)
    
    def load_from_directory(self, 
                           real_dir: Path,
                           fake_dir: Path,
                           file_extensions: List[str] = None) -> None:
        """Load dataset from directory structure.
        
        Args:
            real_dir: Directory containing real samples
            fake_dir: Directory containing fake samples
            file_extensions: Allowed file extensions (default: common video/image formats)
        """
        try:
            if file_extensions is None:
                file_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.jpg', '.jpeg', '.png', '.bmp']
            
            self.samples.clear()
            
            # Load real samples
            if real_dir.exists():
                for file_path in real_dir.rglob('*'):
                    if file_path.is_file() and file_path.suffix.lower() in file_extensions:
                        sample = ValidationSample(
                            file_path=file_path,
                            ground_truth=0.0,
                            metadata={'source_dir': 'real'}
                        )
                        self.samples.append(sample)
            
            # Load fake samples
            if fake_dir.exists():
                for file_path in fake_dir.rglob('*'):
                    if file_path.is_file() and file_path.suffix.lower() in file_extensions:
                        sample = ValidationSample(
                            file_path=file_path,
                            ground_truth=1.0,
                            metadata={'source_dir': 'fake'}
                        )
                        self.samples.append(sample)
            
            self.logger.info(f"Loaded {len(self.samples)} samples from directories")
            self.logger.info(f"Real samples: {sum(1 for s in self.samples if s.ground_truth == 0.0)}")
            self.logger.info(f"Fake samples: {sum(1 for s in self.samples if s.ground_truth == 1.0)}")
            
        except Exception as e:
            raise handle_processing_error("load dataset from directories", e)
    
    def add_sample(self, file_path: Path, ground_truth: float, metadata: Dict[str, Any] = None) -> None:
        """Add a single sample to the dataset.
        
        Args:
            file_path: Path to sample file
            ground_truth: Ground truth label (0=real, 1=fake)
            metadata: Optional metadata dictionary
        """
        sample = ValidationSample(
            file_path=file_path,
            ground_truth=ground_truth,
            metadata=metadata or {}
        )
        self.samples.append(sample)
    
    def filter_samples(self, condition: Callable[[ValidationSample], bool]) -> 'ValidationDataset':
        """Filter samples based on condition.
        
        Args:
            condition: Function that returns True for samples to keep
            
        Returns:
            New ValidationDataset with filtered samples
        """
        filtered_dataset = ValidationDataset(
            name=f"{self.name}_filtered",
            dataset_type=self.dataset_type,
            root_path=self.root_path
        )
        
        filtered_dataset.samples = [s for s in self.samples if condition(s)]
        
        self.logger.info(f"Filtered dataset from {len(self.samples)} to {len(filtered_dataset.samples)} samples")
        
        return filtered_dataset
    
    def split_dataset(self, train_ratio: float = 0.7, 
                     val_ratio: float = 0.15,
                     test_ratio: float = 0.15,
                     stratify: bool = True,
                     random_seed: int = 42) -> Tuple['ValidationDataset', 'ValidationDataset', 'ValidationDataset']:
        """Split dataset into train/validation/test sets.
        
        Args:
            train_ratio: Fraction for training set
            val_ratio: Fraction for validation set
            test_ratio: Fraction for test set
            stratify: Whether to maintain class balance
            random_seed: Random seed for reproducibility
            
        Returns:
            Tuple of (train_dataset, val_dataset, test_dataset)
        """
        if abs(train_ratio + val_ratio + test_ratio - 1.0) > 1e-6:
            raise InputValidationError("Split ratios must sum to 1.0")
        
        np.random.seed(random_seed)
        
        if stratify:
            # Separate by class
            real_samples = [s for s in self.samples if s.ground_truth == 0.0]
            fake_samples = [s for s in self.samples if s.ground_truth == 1.0]
            
            # Shuffle each class
            np.random.shuffle(real_samples)
            np.random.shuffle(fake_samples)
            
            # Split each class
            def split_list(lst, ratios):
                n = len(lst)
                train_end = int(n * ratios[0])
                val_end = train_end + int(n * ratios[1])
                return lst[:train_end], lst[train_end:val_end], lst[val_end:]
            
            real_train, real_val, real_test = split_list(real_samples, [train_ratio, val_ratio, test_ratio])
            fake_train, fake_val, fake_test = split_list(fake_samples, [train_ratio, val_ratio, test_ratio])
            
            # Combine and shuffle
            train_samples = real_train + fake_train
            val_samples = real_val + fake_val
            test_samples = real_test + fake_test
            
        else:
            # Simple random split
            shuffled_samples = self.samples.copy()
            np.random.shuffle(shuffled_samples)
            
            n = len(shuffled_samples)
            train_end = int(n * train_ratio)
            val_end = train_end + int(n * val_ratio)
            
            train_samples = shuffled_samples[:train_end]
            val_samples = shuffled_samples[train_end:val_end]
            test_samples = shuffled_samples[val_end:]
        
        # Create datasets
        train_dataset = ValidationDataset(f"{self.name}_train", self.dataset_type, self.root_path)
        val_dataset = ValidationDataset(f"{self.name}_val", self.dataset_type, self.root_path)
        test_dataset = ValidationDataset(f"{self.name}_test", self.dataset_type, self.root_path)
        
        train_dataset.samples = train_samples
        val_dataset.samples = val_samples
        test_dataset.samples = test_samples
        
        self.logger.info(f"Split dataset: train={len(train_samples)}, val={len(val_samples)}, test={len(test_samples)}")
        
        return train_dataset, val_dataset, test_dataset
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get dataset statistics.
        
        Returns:
            Dictionary with dataset statistics
        """
        if not self.samples:
            return {"total_samples": 0}
        
        real_count = sum(1 for s in self.samples if s.ground_truth == 0.0)
        fake_count = len(self.samples) - real_count
        
        # File extension distribution
        extensions = {}
        for sample in self.samples:
            ext = sample.file_path.suffix.lower()
            extensions[ext] = extensions.get(ext, 0) + 1
        
        # Metadata analysis
        metadata_keys = set()
        for sample in self.samples:
            metadata_keys.update(sample.metadata.keys())
        
        return {
            "total_samples": len(self.samples),
            "real_samples": real_count,
            "fake_samples": fake_count,
            "class_balance": fake_count / len(self.samples) if self.samples else 0.0,
            "file_extensions": extensions,
            "metadata_keys": list(metadata_keys),
            "dataset_type": self.dataset_type.value
        }


class ValidationFramework:
    """Main validation framework for deepfake detection."""
    
    def __init__(self, config: Optional[Any] = None):
        """Initialize validation framework.
        
        Args:
            config: Configuration object
        """
        self.config = config
        self.logger = get_logger(__name__)
        self.results_history: List[ValidationResult] = []
        
        # Import detection function
        try:
            from .detect import analyze_video
            self.analyze_video = analyze_video
        except ImportError:
            self.logger.warning("Could not import analyze_video function")
            self.analyze_video = None
    
    def validate_dataset(self, 
                        dataset: ValidationDataset,
                        max_workers: int = 4,
                        timeout_per_sample: float = 60.0,
                        save_individual_results: bool = False,
                        results_dir: Optional[Path] = None) -> ValidationMetrics:
        """Validate detection performance on a dataset.
        
        Args:
            dataset: Dataset to validate on
            max_workers: Maximum number of parallel workers
            timeout_per_sample: Timeout per sample in seconds
            save_individual_results: Whether to save individual results
            results_dir: Directory to save individual results
            
        Returns:
            ValidationMetrics with comprehensive results
        """
        if self.analyze_video is None:
            raise ProcessingError("Detection function not available")
        
        if not dataset.samples:
            raise InputValidationError("Dataset contains no samples")
        
        self.logger.info(f"Starting validation on {len(dataset.samples)} samples")
        self.logger.info(f"Using {max_workers} workers with {timeout_per_sample}s timeout per sample")
        
        results: List[ValidationResult] = []
        start_time = time.time()
        
        # Create results directory if needed
        if save_individual_results and results_dir:
            results_dir = Path(results_dir)
            results_dir.mkdir(parents=True, exist_ok=True)
        
        with create_operation_context("dataset_validation"):
            if max_workers == 1:
                # Single-threaded processing
                for i, sample in enumerate(dataset.samples):
                    result = self._validate_single_sample(sample, timeout_per_sample)
                    results.append(result)
                    
                    if save_individual_results and results_dir:
                        self._save_individual_result(result, results_dir, i)
                    
                    if (i + 1) % 10 == 0:
                        self.logger.info(f"Processed {i + 1}/{len(dataset.samples)} samples")
            else:
                # Multi-threaded processing
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    # Submit all tasks
                    future_to_sample = {
                        executor.submit(self._validate_single_sample, sample, timeout_per_sample): (i, sample)
                        for i, sample in enumerate(dataset.samples)
                    }
                    
                    # Collect results
                    for future in as_completed(future_to_sample):
                        i, sample = future_to_sample[future]
                        try:
                            result = future.result(timeout=timeout_per_sample + 10)
                            results.append(result)
                            
                            if save_individual_results and results_dir:
                                self._save_individual_result(result, results_dir, i)
                                
                        except Exception as e:
                            self.logger.error(f"Failed to process sample {i}: {e}")
                            # Create failed result
                            result = ValidationResult(
                                sample=sample,
                                prediction=0.5,  # Neutral prediction
                                processing_time=timeout_per_sample,
                                success=False,
                                error_message=str(e)
                            )
                            results.append(result)
                        
                        if len(results) % 10 == 0:
                            self.logger.info(f"Processed {len(results)}/{len(dataset.samples)} samples")
        
        total_time = time.time() - start_time
        self.logger.info(f"Validation completed in {total_time:.2f}s")
        
        # Store results for analysis
        self.results_history.extend(results)
        
        # Compute metrics
        metrics = self._compute_validation_metrics(results, total_time)
        
        return metrics
    
    def _validate_single_sample(self, sample: ValidationSample, timeout: float) -> ValidationResult:
        """Validate a single sample.
        
        Args:
            sample: Sample to validate
            timeout: Timeout in seconds
            
        Returns:
            ValidationResult for the sample
        """
        start_time = time.time()
        
        try:
            # Check if file exists
            if not sample.file_path.exists():
                raise ProcessingError(f"File not found: {sample.file_path}")
            
            # Analyze the sample
            if self.config:
                report = self.analyze_video(sample.file_path, config=self.config)
            else:
                from .detect import analyze_video
                report = analyze_video(sample.file_path)
            
            processing_time = time.time() - start_time
            
            # Extract detailed information
            algorithm_scores = report.scores if hasattr(report, 'scores') else None
            
            result = ValidationResult(
                sample=sample,
                prediction=report.final_probability,
                processing_time=processing_time,
                success=True,
                algorithm_scores=algorithm_scores
            )
            
            return result
            
        except Exception as e:
            processing_time = time.time() - start_time
            
            result = ValidationResult(
                sample=sample,
                prediction=0.5,  # Neutral prediction for failed samples
                processing_time=processing_time,
                success=False,
                error_message=str(e)
            )
            
            return result
    
    def _save_individual_result(self, result: ValidationResult, results_dir: Path, index: int) -> None:
        """Save individual validation result.
        
        Args:
            result: ValidationResult to save
            results_dir: Directory to save to
            index: Sample index
        """
        try:
            result_data = {
                "index": index,
                "file_path": str(result.sample.file_path),
                "ground_truth": result.sample.ground_truth,
                "prediction": result.prediction,
                "processing_time": result.processing_time,
                "success": result.success,
                "error_message": result.error_message,
                "algorithm_scores": result.algorithm_scores,
                "metadata": result.sample.metadata
            }
            
            result_file = results_dir / f"result_{index:06d}.json"
            with open(result_file, 'w', encoding='utf-8') as f:
                json.dump(result_data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            self.logger.warning(f"Failed to save individual result {index}: {e}")
    
    def _compute_validation_metrics(self, results: List[ValidationResult], total_time: float) -> ValidationMetrics:
        """Compute comprehensive validation metrics.
        
        Args:
            results: List of validation results
            total_time: Total processing time
            
        Returns:
            ValidationMetrics object
        """
        # Filter successful results
        successful_results = [r for r in results if r.success]
        
        if not successful_results:
            raise ProcessingError("No successful validation results")
        
        # Extract predictions and ground truth
        y_true = np.array([r.sample.ground_truth for r in successful_results])
        y_pred = np.array([r.prediction for r in successful_results])
        
        # Find optimal threshold using Youden's J statistic
        thresholds = np.linspace(0.0, 1.0, 101)
        best_threshold = 0.5
        best_j_score = 0.0
        
        for threshold in thresholds:
            y_pred_binary = (y_pred >= threshold).astype(int)
            tn, fp, fn, tp = self._confusion_matrix_elements(y_true, y_pred_binary)
            
            if tp + fn > 0 and tn + fp > 0:
                sensitivity = tp / (tp + fn)
                specificity = tn / (tn + fp)
                j_score = sensitivity + specificity - 1
                
                if j_score > best_j_score:
                    best_j_score = j_score
                    best_threshold = threshold
        
        # Compute metrics at optimal threshold
        y_pred_binary = (y_pred >= best_threshold).astype(int)
        tn, fp, fn, tp = self._confusion_matrix_elements(y_true, y_pred_binary)
        
        # Basic metrics
        accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0.0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
        sensitivity = recall
        
        f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
        balanced_accuracy = (sensitivity + specificity) / 2
        
        # Matthews correlation coefficient
        denominator = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        matthews_cc = ((tp * tn) - (fp * fn)) / denominator if denominator > 0 else 0.0
        
        # AUC metrics
        try:
            auc_roc = self._compute_auc_roc(y_true, y_pred)
            auc_pr = self._compute_auc_pr(y_true, y_pred)
        except Exception as e:
            self.logger.warning(f"Failed to compute AUC metrics: {e}")
            auc_roc = 0.0
            auc_pr = 0.0
        
        # Performance metrics
        processing_times = [r.processing_time for r in successful_results]
        average_processing_time = np.mean(processing_times)
        samples_per_second = len(successful_results) / total_time if total_time > 0 else 0.0
        
        # Error analysis
        failed_results = [r for r in results if not r.success]
        error_rate = len(failed_results) / len(results) if results else 0.0
        
        errors_by_type = {}
        for result in failed_results:
            error_type = type(Exception()).__name__  # Simplified error classification
            if result.error_message:
                # Extract error type from message
                if "not found" in result.error_message.lower():
                    error_type = "FileNotFound"
                elif "timeout" in result.error_message.lower():
                    error_type = "Timeout"
                elif "memory" in result.error_message.lower():
                    error_type = "MemoryError"
                else:
                    error_type = "ProcessingError"
            
            errors_by_type[error_type] = errors_by_type.get(error_type, 0) + 1
        
        # Algorithm analysis
        algorithm_contributions = None
        quality_statistics = None
        
        if successful_results and successful_results[0].algorithm_scores:
            algorithm_contributions = self._analyze_algorithm_contributions(successful_results)
        
        return ValidationMetrics(
            accuracy=accuracy,
            precision=precision,
            recall=recall,
            f1_score=f1_score,
            auc_roc=auc_roc,
            auc_pr=auc_pr,
            optimal_threshold=best_threshold,
            true_positives=int(tp),
            true_negatives=int(tn),
            false_positives=int(fp),
            false_negatives=int(fn),
            specificity=specificity,
            sensitivity=sensitivity,
            balanced_accuracy=balanced_accuracy,
            matthews_cc=matthews_cc,
            total_samples=len(results),
            successful_samples=len(successful_results),
            average_processing_time=average_processing_time,
            samples_per_second=samples_per_second,
            error_rate=error_rate,
            errors_by_type=errors_by_type,
            algorithm_contributions=algorithm_contributions,
            quality_statistics=quality_statistics
        )
    
    def _confusion_matrix_elements(self, y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[int, int, int, int]:
        """Compute confusion matrix elements.
        
        Returns:
            Tuple of (tn, fp, fn, tp)
        """
        tn = np.sum((y_true == 0) & (y_pred == 0))
        fp = np.sum((y_true == 0) & (y_pred == 1))
        fn = np.sum((y_true == 1) & (y_pred == 0))
        tp = np.sum((y_true == 1) & (y_pred == 1))
        
        return tn, fp, fn, tp
    
    def _compute_auc_roc(self, y_true: np.ndarray, y_scores: np.ndarray) -> float:
        """Compute ROC AUC using trapezoidal rule."""
        # Sort by decreasing score
        desc_score_indices = np.argsort(y_scores)[::-1]
        y_scores_sorted = y_scores[desc_score_indices]
        y_true_sorted = y_true[desc_score_indices]
        
        # Compute TPR and FPR
        tprs = []
        fprs = []
        
        thresholds = np.unique(y_scores_sorted)
        thresholds = np.append(thresholds, thresholds[-1] - 1e-6)  # Add point for (0,0)
        
        for threshold in thresholds:
            y_pred = (y_scores >= threshold).astype(int)
            tn, fp, fn, tp = self._confusion_matrix_elements(y_true, y_pred)
            
            tpr = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
            
            tprs.append(tpr)
            fprs.append(fpr)
        
        # Compute AUC using trapezoidal rule
        fprs = np.array(fprs)
        tprs = np.array(tprs)
        
        # Sort by FPR
        sorted_indices = np.argsort(fprs)
        fprs_sorted = fprs[sorted_indices]
        tprs_sorted = tprs[sorted_indices]
        
        auc = np.trapz(tprs_sorted, fprs_sorted)
        return float(auc)
    
    def _compute_auc_pr(self, y_true: np.ndarray, y_scores: np.ndarray) -> float:
        """Compute Precision-Recall AUC."""
        thresholds = np.unique(y_scores)
        thresholds = np.append(thresholds, thresholds[-1] - 1e-6)
        
        precisions = []
        recalls = []
        
        for threshold in thresholds:
            y_pred = (y_scores >= threshold).astype(int)
            tn, fp, fn, tp = self._confusion_matrix_elements(y_true, y_pred)
            
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            
            precisions.append(precision)
            recalls.append(recall)
        
        # Sort by recall
        recalls = np.array(recalls)
        precisions = np.array(precisions)
        
        sorted_indices = np.argsort(recalls)
        recalls_sorted = recalls[sorted_indices]
        precisions_sorted = precisions[sorted_indices]
        
        auc = np.trapz(precisions_sorted, recalls_sorted)
        return float(auc)
    
    def _analyze_algorithm_contributions(self, results: List[ValidationResult]) -> Dict[str, float]:
        """Analyze individual algorithm contributions to accuracy.
        
        Args:
            results: List of successful validation results
            
        Returns:
            Dictionary mapping algorithm names to contribution scores
        """
        algorithm_names = set()
        for result in results:
            if result.algorithm_scores:
                algorithm_names.update(result.algorithm_scores.keys())
        
        contributions = {}
        
        for alg_name in algorithm_names:
            # Extract algorithm scores and predictions
            alg_scores = []
            ground_truths = []
            
            for result in results:
                if (result.algorithm_scores and 
                    alg_name in result.algorithm_scores and 
                    result.algorithm_scores[alg_name] is not None):
                    
                    alg_scores.append(result.algorithm_scores[alg_name])
                    ground_truths.append(result.sample.ground_truth)
            
            if len(alg_scores) > 10:  # Need sufficient samples
                try:
                    # Compute individual algorithm AUC
                    auc = self._compute_auc_roc(np.array(ground_truths), np.array(alg_scores))
                    contributions[alg_name] = auc
                except Exception as e:
                    self.logger.warning(f"Failed to compute contribution for {alg_name}: {e}")
                    contributions[alg_name] = 0.5
        
        return contributions
    
    def cross_validate(self, 
                      dataset: ValidationDataset,
                      k_folds: int = 5,
                      random_seed: int = 42) -> Dict[str, Any]:
        """Perform k-fold cross-validation.
        
        Args:
            dataset: Dataset for cross-validation
            k_folds: Number of folds
            random_seed: Random seed
            
        Returns:
            Dictionary with cross-validation results
        """
        if len(dataset.samples) < k_folds:
            raise InputValidationError(f"Dataset too small for {k_folds}-fold CV")
        
        np.random.seed(random_seed)
        
        # Shuffle samples
        shuffled_samples = dataset.samples.copy()
        np.random.shuffle(shuffled_samples)
        
        # Create folds
        fold_size = len(shuffled_samples) // k_folds
        folds = []
        
        for i in range(k_folds):
            start_idx = i * fold_size
            end_idx = start_idx + fold_size if i < k_folds - 1 else len(shuffled_samples)
            folds.append(shuffled_samples[start_idx:end_idx])
        
        # Perform validation on each fold
        fold_metrics = []
        
        for fold_idx in range(k_folds):
            self.logger.info(f"Cross-validation fold {fold_idx + 1}/{k_folds}")
            
            # Create test dataset for this fold
            test_dataset = ValidationDataset(f"{dataset.name}_fold_{fold_idx}", dataset.dataset_type)
            test_dataset.samples = folds[fold_idx]
            
            # Validate on this fold
            metrics = self.validate_dataset(test_dataset, max_workers=1)
            fold_metrics.append(metrics)
        
        # Aggregate results
        metric_names = ['accuracy', 'precision', 'recall', 'f1_score', 'auc_roc', 'auc_pr']
        aggregated = {}
        
        for metric_name in metric_names:
            values = [getattr(m, metric_name) for m in fold_metrics]
            aggregated[f"{metric_name}_mean"] = np.mean(values)
            aggregated[f"{metric_name}_std"] = np.std(values)
            aggregated[f"{metric_name}_values"] = values
        
        self.logger.info(f"Cross-validation completed: {aggregated['accuracy_mean']:.3f} ± {aggregated['accuracy_std']:.3f}")
        
        return {
            "k_folds": k_folds,
            "total_samples": len(dataset.samples),
            "metrics": aggregated,
            "fold_results": fold_metrics
        }
    
    def save_validation_report(self, 
                              metrics: ValidationMetrics,
                              dataset: ValidationDataset,
                              output_path: Path,
                              include_plots: bool = False) -> None:
        """Save comprehensive validation report.
        
        Args:
            metrics: Validation metrics
            dataset: Dataset used for validation
            output_path: Output file path
            include_plots: Whether to include plots (requires matplotlib)
        """
        try:
            report = {
                "validation_summary": {
                    "dataset_name": dataset.name,
                    "dataset_type": dataset.dataset_type.value,
                    "total_samples": metrics.total_samples,
                    "successful_samples": metrics.successful_samples,
                    "error_rate": metrics.error_rate,
                    "processing_speed": metrics.samples_per_second
                },
                "accuracy_metrics": {
                    "accuracy": metrics.accuracy,
                    "balanced_accuracy": metrics.balanced_accuracy,
                    "precision": metrics.precision,
                    "recall": metrics.recall,
                    "f1_score": metrics.f1_score,
                    "specificity": metrics.specificity,
                    "sensitivity": metrics.sensitivity,
                    "matthews_cc": metrics.matthews_cc
                },
                "auc_metrics": {
                    "auc_roc": metrics.auc_roc,
                    "auc_pr": metrics.auc_pr
                },
                "confusion_matrix": {
                    "true_positives": metrics.true_positives,
                    "true_negatives": metrics.true_negatives,
                    "false_positives": metrics.false_positives,
                    "false_negatives": metrics.false_negatives,
                    "optimal_threshold": metrics.optimal_threshold
                },
                "performance_metrics": {
                    "average_processing_time": metrics.average_processing_time,
                    "samples_per_second": metrics.samples_per_second
                },
                "error_analysis": {
                    "error_rate": metrics.error_rate,
                    "errors_by_type": metrics.errors_by_type
                },
                "algorithm_analysis": {
                    "algorithm_contributions": metrics.algorithm_contributions
                },
                "dataset_statistics": dataset.get_statistics()
            }
            
            # Save JSON report
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Validation report saved to {output_path}")
            
        except Exception as e:
            raise handle_processing_error(f"save validation report to {output_path}", e)


# Convenience functions
def create_validation_dataset(name: str, 
                            csv_path: Optional[Path] = None,
                            real_dir: Optional[Path] = None,
                            fake_dir: Optional[Path] = None,
                            dataset_type: DatasetType = DatasetType.CUSTOM) -> ValidationDataset:
    """Create a validation dataset from various sources.
    
    Args:
        name: Dataset name
        csv_path: Optional CSV file path
        real_dir: Optional directory with real samples
        fake_dir: Optional directory with fake samples
        dataset_type: Type of dataset
        
    Returns:
        ValidationDataset instance
    """
    dataset = ValidationDataset(name, dataset_type)
    
    if csv_path:
        dataset.load_from_csv(csv_path)
    elif real_dir and fake_dir:
        dataset.load_from_directory(real_dir, fake_dir)
    else:
        raise InputValidationError("Must provide either csv_path or both real_dir and fake_dir")
    
    return dataset


def quick_validate(file_list: List[Tuple[Path, float]], 
                  config: Optional[Any] = None) -> ValidationMetrics:
    """Quick validation on a list of files.
    
    Args:
        file_list: List of (file_path, ground_truth) tuples
        config: Optional configuration
        
    Returns:
        ValidationMetrics
    """
    # Create temporary dataset
    dataset = ValidationDataset("quick_validation")
    for file_path, ground_truth in file_list:
        dataset.add_sample(file_path, ground_truth)
    
    # Run validation
    framework = ValidationFramework(config)
    return framework.validate_dataset(dataset, max_workers=1)
