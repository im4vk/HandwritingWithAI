"""Test suite for deepfake detector."""
