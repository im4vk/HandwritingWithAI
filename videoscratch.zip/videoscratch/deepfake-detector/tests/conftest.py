"""Pytest configuration and shared fixtures for deepfake detector tests."""

import pytest
import numpy as np
import cv2
from pathlib import Path
from typing import List
import tempfile
import os


@pytest.fixture
def sample_face_crop():
    """Create a sample 224x224 BGR face crop for testing."""
    # Create a simple synthetic face-like image
    face = np.zeros((224, 224, 3), dtype=np.uint8)
    
    # Add some basic facial features
    # Face outline (circle)
    cv2.circle(face, (112, 112), 100, (200, 180, 160), -1)
    
    # Eyes
    cv2.circle(face, (85, 90), 15, (50, 50, 50), -1)
    cv2.circle(face, (139, 90), 15, (50, 50, 50), -1)
    
    # Nose
    cv2.circle(face, (112, 120), 8, (150, 130, 110), -1)
    
    # Mouth
    cv2.ellipse(face, (112, 150), (20, 10), 0, 0, 180, (100, 50, 50), -1)
    
    return face


@pytest.fixture
def sample_face_crops(sample_face_crop):
    """Create a list of sample face crops with slight variations."""
    crops = []
    for i in range(10):
        # Add slight noise variations
        noise = np.random.randint(-10, 10, sample_face_crop.shape, dtype=np.int16)
        noisy_face = np.clip(sample_face_crop.astype(np.int16) + noise, 0, 255).astype(np.uint8)
        crops.append(noisy_face)
    return crops


@pytest.fixture
def sample_landmarks():
    """Create sample facial landmarks (68 points)."""
    # Create a basic 68-point landmark set for a face
    landmarks = np.array([
        # Jaw line (17 points)
        [50, 180], [55, 185], [60, 190], [65, 195], [70, 198],
        [80, 200], [90, 201], [100, 202], [112, 202], [124, 202],
        [134, 201], [144, 200], [154, 198], [159, 195], [164, 190],
        [169, 185], [174, 180],
        
        # Right eyebrow (5 points)
        [75, 75], [85, 70], [95, 68], [105, 70], [115, 75],
        
        # Left eyebrow (5 points)
        [109, 75], [119, 70], [129, 68], [139, 70], [149, 75],
        
        # Nose (9 points)
        [112, 85], [112, 95], [112, 105], [112, 115],
        [100, 120], [106, 125], [112, 127], [118, 125], [124, 120],
        
        # Right eye (6 points)
        [70, 90], [80, 85], [90, 85], [95, 90], [90, 95], [80, 95],
        
        # Left eye (6 points)
        [129, 90], [134, 85], [144, 85], [154, 90], [144, 95], [134, 95],
        
        # Mouth outer (12 points)
        [92, 150], [100, 145], [108, 142], [112, 143], [116, 142],
        [124, 145], [132, 150], [124, 155], [116, 158], [112, 159],
        [108, 158], [100, 155],
        
        # Mouth inner (8 points)
        [100, 150], [108, 148], [112, 149], [116, 148], [124, 150],
        [116, 152], [112, 153], [108, 152]
    ], dtype=np.float32)
    
    return landmarks


@pytest.fixture
def sample_audio():
    """Create sample mono audio signal."""
    duration = 2.0  # seconds
    sr = 16000
    t = np.linspace(0, duration, int(sr * duration))
    
    # Create a simple audio signal with some frequency content
    signal = (
        0.3 * np.sin(2 * np.pi * 440 * t) +  # 440 Hz tone
        0.2 * np.sin(2 * np.pi * 880 * t) +  # 880 Hz harmonic
        0.1 * np.random.randn(len(t))        # Noise
    )
    
    return signal.astype(np.float32), sr


@pytest.fixture
def sample_timestamps():
    """Create sample frame timestamps."""
    fps = 15
    duration = 2.0
    num_frames = int(fps * duration)
    return [i / fps for i in range(num_frames)]


@pytest.fixture
def temp_image_file(sample_face_crop):
    """Create a temporary image file for testing."""
    with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
        cv2.imwrite(tmp.name, sample_face_crop)
        yield tmp.name
    os.unlink(tmp.name)


@pytest.fixture
def temp_video_file():
    """Create a temporary video file for testing."""
    with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as tmp:
        # Create a simple test video
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(tmp.name, fourcc, 15.0, (224, 224))
        
        for i in range(30):  # 2 seconds at 15fps
            frame = np.zeros((224, 224, 3), dtype=np.uint8)
            # Add some moving content
            cv2.circle(frame, (112 + i*2, 112), 50, (100, 150, 200), -1)
            out.write(frame)
        
        out.release()
        yield tmp.name
    os.unlink(tmp.name)


@pytest.fixture
def mock_face_track(sample_face_crops, sample_landmarks):
    """Create a mock FaceTrack object for testing."""
    from deepfake_detector.face import FaceTrack, FaceFrame
    
    frames = []
    for i, crop in enumerate(sample_face_crops):
        frame = FaceFrame(
            frame_index=i,
            face_crop=crop,
            landmarks_xy=sample_landmarks,
            mouth_open=0.1 + 0.05 * np.sin(i * 0.5),  # Varying mouth openness
            eye_open=0.3 + 0.02 * np.random.randn(),   # Varying eye openness
            center_xy=(112.0 + np.random.randn(), 112.0 + np.random.randn()),
            box_xywh=(50 + int(np.random.randn()), 50 + int(np.random.randn()), 124, 124)
        )
        frames.append(frame)
    
    return FaceTrack(frames)
