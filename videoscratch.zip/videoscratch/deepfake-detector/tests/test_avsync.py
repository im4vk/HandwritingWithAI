"""Unit tests for audio-visual synchronization analysis module."""

import pytest
import numpy as np
from pathlib import Path
import sys
from unittest.mock import patch

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from deepfake_detector.avsync import av_sync_fake_score


class TestAvSyncFakeScore:
    """Test the audio-visual synchronization fake score function."""
    
    @pytest.mark.unit
    def test_av_sync_fake_score_no_audio(self):
        """Test AV sync fake score when audio is not available."""
        mouth_series = [0.1, 0.2, 0.3, 0.2, 0.1] * 4  # 20 values
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        score = av_sync_fake_score(mouth_series, timestamps, None, None)
        assert score == 0.5  # Default neutral score
    
    @pytest.mark.unit
    def test_av_sync_fake_score_no_mouth_series(self):
        """Test AV sync fake score when mouth series is not available."""
        audio = np.random.randn(16000).astype(np.float32)  # 1 second at 16kHz
        timestamps = [i / 15.0 for i in range(15)]
        
        score = av_sync_fake_score(None, timestamps, audio, 16000)
        assert score == 0.5  # Default neutral score
        
        # Test with empty mouth series
        score = av_sync_fake_score([], timestamps, audio, 16000)
        assert score == 0.5
    
    @pytest.mark.unit
    def test_av_sync_fake_score_insufficient_data(self):
        """Test AV sync fake score with insufficient data points."""
        # Less than 10 mouth values should return default score
        mouth_series = [0.1, 0.2, 0.3]
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        audio = np.random.randn(1000).astype(np.float32)
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        assert score == 0.5
    
    @pytest.mark.unit
    def test_av_sync_fake_score_basic_functionality(self, sample_audio):
        """Test basic AV sync functionality with valid inputs."""
        audio, sr = sample_audio
        
        # Create mouth series that should correlate with audio envelope
        mouth_series = []
        for i in range(20):
            # Simple mouth movement pattern
            mouth_val = 0.1 + 0.05 * np.sin(2 * np.pi * i / 10.0)
            mouth_series.append(mouth_val)
        
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, sr)
        
        assert 0.0 <= score <= 1.0
        assert isinstance(score, float)
    
    @pytest.mark.unit
    def test_av_sync_fake_score_perfect_sync(self):
        """Test AV sync with perfectly synchronized audio and mouth movements."""
        # Create synthetic audio with clear envelope
        sr = 16000
        duration = 2.0
        t_audio = np.linspace(0, duration, int(sr * duration))
        
        # Audio signal with clear modulation
        envelope_freq = 2.0  # 2 Hz modulation
        carrier_freq = 440.0  # 440 Hz tone
        envelope = 0.5 + 0.5 * np.sin(2 * np.pi * envelope_freq * t_audio)
        audio = envelope * np.sin(2 * np.pi * carrier_freq * t_audio)
        audio = audio.astype(np.float32)
        
        # Create perfectly correlated mouth series
        fps = 15
        num_frames = int(fps * duration)
        mouth_series = []
        for i in range(num_frames):
            t = i / fps
            # Mouth movement perfectly correlated with audio envelope
            mouth_val = 0.1 + 0.1 * np.sin(2 * np.pi * envelope_freq * t)
            mouth_series.append(mouth_val)
        
        timestamps = [i / fps for i in range(num_frames)]
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, sr)
        
        # Perfect sync should result in low fake score (more real-like)
        assert 0.0 <= score <= 1.0
        assert score <= 0.6  # Should indicate more real-like
    
    @pytest.mark.unit
    def test_av_sync_fake_score_no_correlation(self):
        """Test AV sync with no correlation between audio and mouth movements."""
        # Create audio with one pattern
        sr = 16000
        duration = 1.5
        t_audio = np.linspace(0, duration, int(sr * duration))
        audio_freq = 3.0
        audio = np.sin(2 * np.pi * audio_freq * t_audio).astype(np.float32)
        
        # Create mouth series with completely different pattern
        fps = 15
        num_frames = int(fps * duration)
        mouth_series = []
        mouth_freq = 0.5  # Much different frequency
        for i in range(num_frames):
            t = i / fps
            mouth_val = 0.15 + 0.05 * np.sin(2 * np.pi * mouth_freq * t)
            mouth_series.append(mouth_val)
        
        timestamps = [i / fps for i in range(num_frames)]
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, sr)
        
        # No correlation should result in higher fake score
        assert 0.0 <= score <= 1.0
        assert score >= 0.4  # Should indicate more fake-like
    
    @pytest.mark.unit
    def test_av_sync_fake_score_mismatched_timestamps(self):
        """Test AV sync when timestamps don't match mouth series length."""
        mouth_series = [0.1 + 0.05 * np.sin(i * 0.1) for i in range(15)]
        timestamps = [i / 15.0 for i in range(10)]  # Fewer timestamps
        audio = np.random.randn(16000).astype(np.float32)
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Should handle gracefully with uniform fallback
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_av_sync_fake_score_zero_audio_window(self):
        """Test AV sync when audio window calculation results in zero size."""
        mouth_series = [0.1] * 15
        timestamps = [i / 15.0 for i in range(15)]
        
        # Very short audio that might cause issues
        audio = np.array([0.1, 0.2], dtype=np.float32)
        sr = 16000
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, sr)
        
        # Should handle gracefully (may return NaN due to correlation issues)
        assert 0.0 <= score <= 1.0 or np.isnan(score)
    
    @pytest.mark.unit
    def test_av_sync_fake_score_silent_audio(self):
        """Test AV sync with silent audio."""
        mouth_series = [0.1 + 0.05 * np.sin(i * 0.2) for i in range(20)]
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        # Silent audio
        audio = np.zeros(16000, dtype=np.float32)
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Silent audio with mouth movement (may return NaN due to zero variance)
        assert 0.0 <= score <= 1.0 or np.isnan(score)
    
    @pytest.mark.unit
    def test_av_sync_fake_score_constant_mouth(self):
        """Test AV sync with constant mouth openness."""
        # No mouth movement
        mouth_series = [0.15] * 25
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        # Audio with some variation
        audio = np.random.randn(24000).astype(np.float32) * 0.1
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Constant mouth with varying audio (may return NaN due to zero mouth variance)
        assert 0.0 <= score <= 1.0 or np.isnan(score)
    
    @pytest.mark.unit
    def test_av_sync_fake_score_different_sampling_rates(self):
        """Test AV sync with different audio sampling rates."""
        mouth_series = [0.1 + 0.03 * np.sin(i * 0.3) for i in range(20)]
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        # Test with different sampling rates
        for sr in [8000, 16000, 22050, 44100]:
            duration = 1.5
            audio = np.random.randn(int(sr * duration)).astype(np.float32)
            
            score = av_sync_fake_score(mouth_series, timestamps, audio, sr)
            
            assert 0.0 <= score <= 1.0
            assert isinstance(score, float)
    
    @pytest.mark.unit
    def test_av_sync_fake_score_normalization(self):
        """Test that AV sync handles signal normalization correctly."""
        # Create signals with different amplitude ranges
        mouth_series = [0.5 + 0.3 * np.sin(i * 0.2) for i in range(20)]  # Large amplitude
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        # Audio with small amplitude
        audio = 0.01 * np.random.randn(24000).astype(np.float32)
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Should handle amplitude differences via normalization
        assert 0.0 <= score <= 1.0
        assert not np.isnan(score)
        assert not np.isinf(score)
    
    @pytest.mark.unit
    def test_av_sync_fake_score_window_extraction(self):
        """Test audio window extraction at frame timestamps."""
        mouth_series = [0.1] * 15
        timestamps = [i / 15.0 for i in range(15)]
        
        # Create audio with specific pattern that we can verify
        sr = 16000
        audio = np.zeros(sr * 2, dtype=np.float32)  # 2 seconds
        
        # Add impulses at specific times that align with some timestamps
        for i in [0, 5, 10]:  # Align with some frame times
            sample_idx = int(timestamps[i] * sr)
            if sample_idx < len(audio) - 100:
                audio[sample_idx:sample_idx+100] = 0.5  # Add impulse
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, sr)
        
        # Should extract windows successfully (may return NaN in edge cases)
        assert 0.0 <= score <= 1.0 or np.isnan(score)
    
    @pytest.mark.unit
    def test_av_sync_fake_score_correlation_calculation(self):
        """Test correlation calculation with known signals."""
        # Create signals where we know the expected correlation
        mouth_series = []
        audio_envelope = []
        
        # Both signals follow same sinusoidal pattern
        for i in range(30):
            t = i / 15.0
            pattern = np.sin(2 * np.pi * 1.0 * t)  # 1 Hz
            mouth_series.append(0.15 + 0.05 * pattern)
            audio_envelope.append(0.1 + 0.1 * pattern)
        
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        # Create audio from envelope
        sr = 16000
        audio = np.zeros(int(sr * 2), dtype=np.float32)
        for i, env_val in enumerate(audio_envelope):
            if i < len(timestamps):
                start_idx = int(timestamps[i] * sr)
                end_idx = min(start_idx + int(0.02 * sr), len(audio))  # 20ms window
                if start_idx < len(audio):
                    audio[start_idx:end_idx] = env_val
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, sr)
        
        # Similar patterns should result in good correlation (low fake score)
        assert 0.0 <= score <= 1.0


class TestAvSyncEdgeCases:
    """Test edge cases and error conditions for AV sync analysis."""
    
    @pytest.mark.unit
    def test_av_sync_extreme_audio_values(self):
        """Test AV sync with extreme audio values."""
        mouth_series = [0.1] * 20
        timestamps = [i / 15.0 for i in range(20)]
        
        # Test with very loud audio
        loud_audio = np.ones(16000, dtype=np.float32) * 1000.0
        score_loud = av_sync_fake_score(mouth_series, timestamps, loud_audio, 16000)
        assert 0.0 <= score_loud <= 1.0 or np.isnan(score_loud)
        
        # Test with very quiet audio
        quiet_audio = np.ones(16000, dtype=np.float32) * 1e-6
        score_quiet = av_sync_fake_score(mouth_series, timestamps, quiet_audio, 16000)
        assert 0.0 <= score_quiet <= 1.0 or np.isnan(score_quiet)
    
    @pytest.mark.unit
    def test_av_sync_extreme_mouth_values(self):
        """Test AV sync with extreme mouth openness values."""
        timestamps = [i / 15.0 for i in range(15)]
        audio = np.random.randn(16000).astype(np.float32)
        
        # Test with very large mouth values
        large_mouth = [10.0] * 15
        score_large = av_sync_fake_score(large_mouth, timestamps, audio, 16000)
        assert 0.0 <= score_large <= 1.0 or np.isnan(score_large)
        
        # Test with negative mouth values
        negative_mouth = [-0.5] * 15
        score_negative = av_sync_fake_score(negative_mouth, timestamps, audio, 16000)
        assert 0.0 <= score_negative <= 1.0 or np.isnan(score_negative)
    
    @pytest.mark.unit
    def test_av_sync_numerical_stability(self):
        """Test numerical stability with edge case values."""
        # Create signals that could cause numerical issues
        mouth_series = [1e-8] * 20  # Very small values
        timestamps = [i / 15.0 for i in range(20)]
        
        # Audio with very small variations
        audio = np.ones(16000, dtype=np.float32) * 1e-10
        audio += np.random.randn(16000).astype(np.float32) * 1e-12
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Very small values may cause NaN in correlation calculation
        assert (0.0 <= score <= 1.0) or np.isnan(score)
        assert not np.isinf(score)
    
    @pytest.mark.unit
    def test_av_sync_zero_variance_signals(self):
        """Test AV sync with zero variance signals."""
        # Constant mouth series
        mouth_series = [0.2] * 25
        timestamps = [i / 15.0 for i in range(25)]
        
        # Constant audio
        audio = np.ones(24000, dtype=np.float32) * 0.1
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Zero variance signals will likely cause NaN in correlation
        assert (0.0 <= score <= 1.0) or np.isnan(score)
    
    @pytest.mark.unit
    def test_av_sync_irregular_timestamps(self):
        """Test AV sync with irregular timestamp patterns."""
        mouth_series = [0.1 + 0.05 * np.random.random() for _ in range(20)]
        
        # Create irregular timestamps
        timestamps = []
        t = 0.0
        for i in range(20):
            timestamps.append(t)
            t += 0.04 + 0.03 * np.random.random()  # Variable frame intervals
        
        audio = np.random.randn(int(16000 * 2)).astype(np.float32)
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Should handle irregular timing
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_av_sync_audio_boundaries(self):
        """Test AV sync when timestamps exceed audio boundaries."""
        mouth_series = [0.1] * 15
        
        # Timestamps that go beyond audio duration
        timestamps = [i * 0.2 for i in range(15)]  # Up to 2.8 seconds
        
        # Short audio (only 1 second)
        audio = np.random.randn(16000).astype(np.float32)
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Should handle out-of-bounds gracefully (may return NaN)
        assert (0.0 <= score <= 1.0) or np.isnan(score)
    
    @pytest.mark.unit
    def test_av_sync_nan_inf_handling(self):
        """Test AV sync handling of NaN and Inf values."""
        # Mouth series with potential problematic values
        mouth_series = [0.1, 0.2, np.nan, 0.15, np.inf, 0.12] + [0.1] * 14
        timestamps = [i / 15.0 for i in range(len(mouth_series))]
        
        # Normal audio
        audio = np.random.randn(16000).astype(np.float32)
        
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        
        # Input NaN/Inf may propagate through calculation
        assert (0.0 <= score <= 1.0) or np.isnan(score)
        assert not np.isinf(score)


class TestAvSyncIntegration:
    """Integration tests for AV sync analysis."""
    
    @pytest.mark.integration
    def test_av_sync_performance(self):
        """Test AV sync performance with longer sequences."""
        import time
        
        # Create longer sequences (5 seconds at 15 fps = 75 frames)
        mouth_series = []
        for i in range(75):
            mouth_val = 0.1 + 0.05 * np.sin(2 * np.pi * i / 30.0)
            mouth_series.append(mouth_val)
        
        timestamps = [i / 15.0 for i in range(75)]
        
        # 5 seconds of audio at 16kHz
        audio = np.random.randn(80000).astype(np.float32)
        
        start_time = time.time()
        score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
        end_time = time.time()
        
        # Should complete within reasonable time (1 second)
        assert end_time - start_time < 1.0
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.integration
    def test_av_sync_memory_usage(self):
        """Test AV sync memory usage doesn't grow excessively."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss
        
        # Process multiple sequences
        for _ in range(10):
            mouth_series = [0.1 + 0.03 * np.random.random() for _ in range(50)]
            timestamps = [i / 15.0 for i in range(50)]
            audio = np.random.randn(50000).astype(np.float32)
            
            score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
            assert 0.0 <= score <= 1.0
        
        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory
        
        # Should not use more than 20MB additional memory
        assert memory_increase < 20 * 1024 * 1024
    
    @pytest.mark.integration
    def test_av_sync_robustness(self):
        """Test AV sync robustness with various real-world scenarios."""
        test_scenarios = [
            # (mouth_pattern, audio_pattern, expected_range)
            ("constant", "constant", (0.4, 1.0)),      # Both constant - should indicate fake
            ("varying", "silent", (0.5, 1.0)),        # Moving mouth, no audio - fake
            ("constant", "varying", (0.5, 1.0)),      # No mouth movement, audio - fake
            ("varying", "varying", (0.0, 1.0)),       # Both varying - could be real or fake
        ]
        
        for mouth_pattern, audio_pattern, expected_range in test_scenarios:
            # Generate test data based on patterns
            if mouth_pattern == "constant":
                mouth_series = [0.15] * 25
            else:  # varying
                mouth_series = [0.1 + 0.05 * np.sin(i * 0.2) for i in range(25)]
            
            timestamps = [i / 15.0 for i in range(25)]
            
            if audio_pattern == "silent":
                audio = np.zeros(25000, dtype=np.float32)
            elif audio_pattern == "constant":
                audio = np.ones(25000, dtype=np.float32) * 0.1
            else:  # varying
                audio = np.random.randn(25000).astype(np.float32) * 0.1
            
            score = av_sync_fake_score(mouth_series, timestamps, audio, 16000)
            
            assert 0.0 <= score <= 1.0
            assert expected_range[0] <= score <= expected_range[1], \
                f"Score {score} not in expected range {expected_range} for {mouth_pattern}-{audio_pattern}"
