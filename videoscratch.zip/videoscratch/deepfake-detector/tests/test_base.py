"""Base test class and utilities for deepfake detector tests."""

import unittest
import numpy as np
import cv2
from pathlib import Path
from typing import Any, Dict, List, Optional


class DeepfakeDetectorTestBase(unittest.TestCase):
    """Base test class with common utilities for deepfake detector tests."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.test_data_dir = Path(__file__).parent / "data"
        self.test_data_dir.mkdir(exist_ok=True)
    
    def assertScoreInRange(self, score: float, min_val: float = 0.0, max_val: float = 1.0):
        """Assert that a score is within the expected range."""
        self.assertGreaterEqual(score, min_val, f"Score {score} is below minimum {min_val}")
        self.assertLessEqual(score, max_val, f"Score {score} is above maximum {max_val}")
    
    def assertArrayShape(self, array: np.ndarray, expected_shape: tuple):
        """Assert that an array has the expected shape."""
        self.assertEqual(array.shape, expected_shape, 
                        f"Array shape {array.shape} does not match expected {expected_shape}")
    
    def assertArrayNonEmpty(self, array: np.ndarray):
        """Assert that an array is not empty."""
        self.assertGreater(array.size, 0, "Array is empty")
    
    def assertValidFaceCoordinates(self, x: int, y: int, w: int, h: int, 
                                  frame_width: int = 224, frame_height: int = 224):
        """Assert that face coordinates are valid."""
        self.assertGreaterEqual(x, 0, "Face x coordinate is negative")
        self.assertGreaterEqual(y, 0, "Face y coordinate is negative")
        self.assertGreater(w, 0, "Face width is not positive")
        self.assertGreater(h, 0, "Face height is not positive")
        self.assertLessEqual(x + w, frame_width, "Face extends beyond frame width")
        self.assertLessEqual(y + h, frame_height, "Face extends beyond frame height")
    
    def create_test_scores(self, **kwargs) -> Dict[str, float]:
        """Create a test scores dictionary with default values."""
        default_scores = {
            "freq": 0.5,
            "rppg": 0.5,
            "av": 0.5,
            "geom": 0.5,
            "cnn": 0.5
        }
        default_scores.update(kwargs)
        return default_scores
    
    def assert_detection_report_valid(self, report):
        """Assert that a detection report has all required fields and valid values."""
        self.assertIsNotNone(report, "Detection report is None")
        self.assertIsInstance(report.input_path, str, "Input path is not a string")
        self.assertScoreInRange(report.final_probability)
        self.assertIn(report.label, ["real", "fake"], f"Invalid label: {report.label}")
        self.assertIsInstance(report.scores, dict, "Scores is not a dictionary")
        
        # Check that all expected score types are present
        expected_keys = {"freq", "rppg", "av", "geom"}
        for key in expected_keys:
            self.assertIn(key, report.scores, f"Missing score: {key}")
            self.assertScoreInRange(report.scores[key])


class MockComponent:
    """Base class for creating mock components in tests."""
    
    def __init__(self, return_value: Any = None, side_effect: Optional[Exception] = None):
        self.return_value = return_value
        self.side_effect = side_effect
        self.call_count = 0
        self.call_args = []
    
    def __call__(self, *args, **kwargs):
        self.call_count += 1
        self.call_args.append((args, kwargs))
        
        if self.side_effect:
            raise self.side_effect
        
        return self.return_value


def create_synthetic_frames(num_frames: int = 10, width: int = 224, height: int = 224) -> List[np.ndarray]:
    """Create synthetic video frames for testing."""
    frames = []
    for i in range(num_frames):
        frame = np.zeros((height, width, 3), dtype=np.uint8)
        # Add some variation to make frames different
        cv2.circle(frame, (width//2 + i*2, height//2), 30, (100 + i*5, 150, 200), -1)
        frames.append(frame)
    return frames
