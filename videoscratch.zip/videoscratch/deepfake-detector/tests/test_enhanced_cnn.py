"""Tests for enhanced CNN detector module."""

import pytest
import numpy as np
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

from deepfake_detector.enhanced_cnn import (
    ModelArchitecture,
    ExecutionProvider,
    PrecisionMode,
    ModelMetadata,
    ModelConfig,
    PredictionResult,
    ModelRegistry,
    ModelManager,
    EnhancedCNNDetector,
    list_available_models,
    create_model_config,
    download_model
)


class TestModelMetadata:
    """Test ModelMetadata class."""
    
    def test_create_metadata(self):
        """Test creating model metadata."""
        metadata = ModelMetadata(
            name="test_model",
            architecture=ModelArchitecture.XCEPTION,
            input_size=(224, 224),
            accuracy=0.92,
            description="Test model"
        )
        
        assert metadata.name == "test_model"
        assert metadata.architecture == ModelArchitecture.XCEPTION
        assert metadata.input_size == (224, 224)
        assert metadata.accuracy == 0.92
    
    def test_invalid_input_size(self):
        """Test validation of input size."""
        with pytest.raises(Exception):
            ModelMetadata(
                name="invalid",
                architecture=ModelArchitecture.XCEPTION,
                input_size=(0, 224)  # Invalid size
            )
    
    def test_invalid_channels(self):
        """Test validation of input channels."""
        with pytest.raises(Exception):
            ModelMetadata(
                name="invalid",
                architecture=ModelArchitecture.XCEPTION,
                input_channels=5  # Invalid channel count
            )


class TestModelConfig:
    """Test ModelConfig class."""
    
    def test_default_config(self):
        """Test default configuration."""
        config = ModelConfig()
        
        assert config.architecture == ModelArchitecture.XCEPTION
        assert config.batch_size == 32
        assert config.num_threads == 4
        assert config.enable_caching is True
        assert config.enable_ensemble is False
    
    def test_custom_config(self):
        """Test custom configuration."""
        config = ModelConfig(
            architecture=ModelArchitecture.EFFICIENTNET_B0,
            batch_size=16,
            execution_providers=[ExecutionProvider.CPU],
            enable_ensemble=True,
            ensemble_models=["efficientnet_b0", "resnet50"]
        )
        
        assert config.architecture == ModelArchitecture.EFFICIENTNET_B0
        assert config.batch_size == 16
        assert config.enable_ensemble is True
        assert len(config.ensemble_models) == 2
    
    def test_invalid_batch_size(self):
        """Test validation of batch size."""
        with pytest.raises(Exception):
            ModelConfig(batch_size=0)
    
    def test_invalid_ensemble_config(self):
        """Test validation of ensemble configuration."""
        with pytest.raises(Exception):
            ModelConfig(enable_ensemble=True, ensemble_models=[])


class TestPredictionResult:
    """Test PredictionResult class."""
    
    def test_create_result(self):
        """Test creating prediction result."""
        result = PredictionResult(
            probability=0.75,
            confidence=0.85,
            processing_time=0.123,
            model_used="xception",
            batch_size=4
        )
        
        assert result.probability == 0.75
        assert result.confidence == 0.85
        assert result.processing_time == 0.123
        assert result.model_used == "xception"
        assert result.batch_size == 4
    
    def test_invalid_probability(self):
        """Test validation of probability."""
        with pytest.raises(Exception):
            PredictionResult(
                probability=1.5,  # Invalid probability
                confidence=0.8,
                processing_time=0.1,
                model_used="test",
                batch_size=1
            )
    
    def test_invalid_confidence(self):
        """Test validation of confidence."""
        with pytest.raises(Exception):
            PredictionResult(
                probability=0.7,
                confidence=-0.1,  # Invalid confidence
                processing_time=0.1,
                model_used="test",
                batch_size=1
            )


class TestModelRegistry:
    """Test ModelRegistry class."""
    
    def test_get_model_metadata(self):
        """Test getting model metadata."""
        metadata = ModelRegistry.get_model_metadata(ModelArchitecture.XCEPTION)
        
        assert metadata is not None
        assert metadata.name == "xception_deepfake"
        assert metadata.architecture == ModelArchitecture.XCEPTION
        assert metadata.input_size == (224, 224)
    
    def test_list_available_models(self):
        """Test listing available models."""
        models = ModelRegistry.list_available_models()
        
        assert len(models) > 0
        assert "xception" in models
        assert isinstance(models["xception"], ModelMetadata)
    
    def test_register_custom_model(self):
        """Test registering custom model."""
        custom_metadata = ModelMetadata(
            name="custom_test",
            architecture=ModelArchitecture.CUSTOM,
            description="Test custom model"
        )
        
        ModelRegistry.register_custom_model("custom_test", custom_metadata)
        
        # Verify registration
        registered = ModelRegistry.get_model_metadata(ModelArchitecture.CUSTOM)
        assert registered is not None
        assert registered.name == "custom_test"


class TestModelManager:
    """Test ModelManager class."""
    
    def setup_method(self):
        """Set up test data."""
        self.config = ModelConfig(
            architecture=ModelArchitecture.XCEPTION,
            batch_size=4,
            enable_caching=True
        )
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    def test_create_manager(self):
        """Test creating model manager."""
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            manager = ModelManager(self.config)
            
            assert manager.config == self.config
            assert len(manager._session_cache) == 0
    
    def test_generate_cache_key(self):
        """Test cache key generation."""
        with patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True):
            with patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True):
                with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
                    mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
                    
                    manager = ModelManager(self.config)
                    
                    key1 = manager._generate_cache_key(ModelArchitecture.XCEPTION, None, None)
                    key2 = manager._generate_cache_key(ModelArchitecture.XCEPTION, None, None)
                    key3 = manager._generate_cache_key(ModelArchitecture.EFFICIENTNET_B0, None, None)
                    
                    assert key1 == key2
                    assert key1 != key3
                    assert len(key1) == 16  # MD5 hash truncated
    
    def test_clear_cache(self):
        """Test cache clearing."""
        with patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True):
            with patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True):
                with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
                    mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
                    
                    manager = ModelManager(self.config)
                    
                    # Add some dummy cache entries
                    manager._session_cache["test1"] = Mock()
                    manager._model_cache["test2"] = Mock()
                    
                    assert len(manager._session_cache) == 1
                    assert len(manager._model_cache) == 1
                    
                    manager.clear_cache()
                    
                    assert len(manager._session_cache) == 0
                    assert len(manager._model_cache) == 0
    
    def test_cache_stats(self):
        """Test cache statistics."""
        with patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True):
            with patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True):
                with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
                    mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
                    
                    manager = ModelManager(self.config)
                    
                    stats = manager.get_cache_stats()
                    
                    assert "cached_sessions" in stats
                    assert "cached_models" in stats
                    assert "prediction_stats" in stats
                    assert isinstance(stats["cached_sessions"], int)


class TestEnhancedCNNDetector:
    """Test EnhancedCNNDetector class."""
    
    def setup_method(self):
        """Set up test data."""
        self.config = ModelConfig(
            architecture=ModelArchitecture.XCEPTION,
            batch_size=4,
            enable_ensemble=False
        )
        
        # Create sample face crops
        self.face_crops = [
            np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
            for _ in range(3)
        ]
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    def test_create_detector_no_model(self):
        """Test creating detector without loading models."""
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            with patch.object(EnhancedCNNDetector, '_load_models') as mock_load:
                mock_load.return_value = None
                
                detector = EnhancedCNNDetector(self.config)
                
                assert detector.config == self.config
                assert detector.primary_session is None
                assert not detector.available()
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', False)
    def test_missing_dependencies(self):
        """Test handling missing dependencies."""
        with pytest.raises(Exception):  # Should raise DependencyError
            EnhancedCNNDetector(self.config)
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    def test_predict_no_model(self):
        """Test prediction without loaded model."""
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            with patch.object(EnhancedCNNDetector, '_load_models') as mock_load:
                mock_load.return_value = None
                
                detector = EnhancedCNNDetector(self.config)
                
                # Should return neutral prediction
                result = detector.predict(self.face_crops)
                assert result == 0.5
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    def test_predict_empty_input(self):
        """Test prediction with empty input."""
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            with patch.object(EnhancedCNNDetector, '_load_models') as mock_load:
                mock_load.return_value = None
                
                detector = EnhancedCNNDetector(self.config)
                
                result = detector.predict([])
                assert result == 0.5
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    @patch('deepfake_detector.enhanced_cnn.cv2')
    def test_preprocess_images(self, mock_cv2):
        """Test image preprocessing."""
        # Mock OpenCV functions
        mock_cv2.resize.side_effect = lambda img, size: np.random.randint(0, 255, (*size, 3), dtype=np.uint8)
        mock_cv2.cvtColor.side_effect = lambda img, code: img.copy()
        
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            with patch.object(EnhancedCNNDetector, '_load_models') as mock_load:
                mock_load.return_value = None
                
                detector = EnhancedCNNDetector(self.config)
                
                # Test preprocessing
                preprocessed = detector._preprocess_images(self.face_crops)
                
                assert preprocessed.shape[0] == len(self.face_crops)
                assert preprocessed.shape[1] == 3  # RGB channels
                assert preprocessed.shape[2:] == self.config.input_size
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    def test_model_info(self):
        """Test getting model information."""
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            with patch.object(EnhancedCNNDetector, '_load_models') as mock_load:
                mock_load.return_value = None
                
                detector = EnhancedCNNDetector(self.config)
                
                info = detector.get_model_info()
                
                assert "primary_model" in info
                assert "ensemble_models" in info
                assert "configuration" in info
                assert info["primary_model"]["architecture"] == "xception"
                assert info["configuration"]["batch_size"] == 4


class TestUtilityFunctions:
    """Test utility functions."""
    
    def test_list_available_models(self):
        """Test listing available models."""
        models_info = list_available_models()
        
        assert "models" in models_info
        assert "total_models" in models_info
        assert models_info["total_models"] > 0
        assert "xception" in models_info["models"]
    
    def test_create_model_config(self):
        """Test creating model configuration."""
        config = create_model_config("xception", batch_size=16)
        
        assert config.architecture == ModelArchitecture.XCEPTION
        assert config.batch_size == 16
    
    def test_create_model_config_invalid(self):
        """Test creating config with invalid architecture."""
        with pytest.raises(Exception):
            create_model_config("invalid_architecture")
    
    @patch('deepfake_detector.enhanced_cnn.ensure_model_file')
    def test_download_model(self, mock_ensure):
        """Test model download."""
        mock_path = Path("/tmp/test_model.onnx")
        mock_ensure.return_value = mock_path
        
        result = download_model("xception")
        
        assert result == mock_path
        mock_ensure.assert_called_once()
    
    def test_download_model_invalid(self):
        """Test downloading invalid model."""
        with pytest.raises(Exception):
            download_model("invalid_model")


class TestModelConfigValidation:
    """Test model configuration validation."""
    
    def test_execution_provider_validation(self):
        """Test execution provider validation."""
        config = ModelConfig(
            execution_providers=[ExecutionProvider.CPU, ExecutionProvider.CUDA]
        )
        
        assert len(config.execution_providers) == 2
        assert ExecutionProvider.CPU in config.execution_providers
        assert ExecutionProvider.CUDA in config.execution_providers
    
    def test_precision_mode_validation(self):
        """Test precision mode validation."""
        config = ModelConfig(precision_mode=PrecisionMode.FP16)
        
        assert config.precision_mode == PrecisionMode.FP16
    
    def test_ensemble_weights_validation(self):
        """Test ensemble weights validation."""
        config = ModelConfig(
            enable_ensemble=True,
            ensemble_models=["model1", "model2"],
            ensemble_weights=[0.6, 0.4]
        )
        
        assert config.enable_ensemble is True
        assert len(config.ensemble_weights) == 2
        assert sum(config.ensemble_weights) == 1.0


class TestBenchmarking:
    """Test benchmarking functionality."""
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    def test_benchmark_mock(self):
        """Test benchmarking with mocked detector."""
        config = ModelConfig(batch_size=4)
        
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            with patch.object(EnhancedCNNDetector, '_load_models') as mock_load:
                mock_load.return_value = None
                
                detector = EnhancedCNNDetector(config)
                
                # Mock the predict method to return consistent results
                def mock_predict(crops):
                    return 0.75
                
                detector.predict = Mock(side_effect=mock_predict)
                
                # Run benchmark
                results = detector.benchmark(num_samples=20)
                
                assert "batch_results" in results
                assert "summary" in results
                assert "model_architecture" in results


class TestErrorHandling:
    """Test error handling scenarios."""
    
    @patch('deepfake_detector.enhanced_cnn._HAS_ONNXRUNTIME', True)
    @patch('deepfake_detector.enhanced_cnn._HAS_OPENCV', True)
    def test_prediction_error_handling(self):
        """Test prediction error handling."""
        config = ModelConfig()
        
        with patch('deepfake_detector.enhanced_cnn.ort') as mock_ort:
            mock_ort.get_available_providers.return_value = ["CPUExecutionProvider"]
            
            with patch.object(EnhancedCNNDetector, '_load_models') as mock_load:
                mock_load.return_value = None
                
                detector = EnhancedCNNDetector(config)
                
                # Test with invalid input
                with pytest.raises(Exception):
                    detector.predict("invalid_input")  # Should be list
    
    def test_model_metadata_validation(self):
        """Test model metadata validation."""
        # Test with invalid input size
        with pytest.raises(Exception):
            ModelMetadata(
                name="test",
                architecture=ModelArchitecture.XCEPTION,
                input_size=(-1, 224)
            )
        
        # Test with invalid channels
        with pytest.raises(Exception):
            ModelMetadata(
                name="test",
                architecture=ModelArchitecture.XCEPTION,
                input_channels=0
            )


if __name__ == "__main__":
    pytest.main([__file__])
