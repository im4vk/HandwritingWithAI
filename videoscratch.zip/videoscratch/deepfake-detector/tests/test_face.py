"""Unit tests for face detection module."""

import pytest
import numpy as np
import cv2
from pathlib import Path
import sys
from unittest.mock import patch, MagicMock

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from deepfake_detector.face import (
    FaceFrame, FaceTrack, detect_face_track,
    _compute_face_crop_by_box, _mouth_metric, _eye_metric,
    _mediapipe_track, _haar_track
)


class TestFaceFrame:
    """Test FaceFrame dataclass."""
    
    @pytest.mark.unit
    def test_face_frame_creation(self, sample_face_crop, sample_landmarks):
        """Test FaceFrame creation with valid data."""
        face_frame = FaceFrame(
            frame_index=0,
            face_crop=sample_face_crop,
            landmarks_xy=sample_landmarks,
            mouth_open=0.5,
            eye_open=0.3,
            center_xy=(112.0, 112.0),
            box_xywh=(50, 50, 124, 124)
        )
        
        assert face_frame.frame_index == 0
        assert face_frame.face_crop.shape == (224, 224, 3)
        assert face_frame.landmarks_xy.shape == (68, 2)
        assert face_frame.mouth_open == 0.5
        assert face_frame.eye_open == 0.3
        assert face_frame.center_xy == (112.0, 112.0)
        assert face_frame.box_xywh == (50, 50, 124, 124)
    
    @pytest.mark.unit
    def test_face_frame_with_none_values(self, sample_face_crop):
        """Test FaceFrame creation with None optional values."""
        face_frame = FaceFrame(
            frame_index=0,
            face_crop=sample_face_crop,
            landmarks_xy=None,
            mouth_open=None,
            eye_open=None,
            center_xy=(112.0, 112.0),
            box_xywh=(50, 50, 124, 124)
        )
        
        assert face_frame.landmarks_xy is None
        assert face_frame.mouth_open is None
        assert face_frame.eye_open is None


class TestFaceTrack:
    """Test FaceTrack dataclass."""
    
    @pytest.mark.unit
    def test_face_track_creation(self, mock_face_track):
        """Test FaceTrack creation."""
        assert isinstance(mock_face_track, FaceTrack)
        assert len(mock_face_track.frames) == 10
        assert all(isinstance(frame, FaceFrame) for frame in mock_face_track.frames)
    
    @pytest.mark.unit
    def test_empty_face_track(self):
        """Test empty FaceTrack creation."""
        track = FaceTrack([])
        assert len(track.frames) == 0


class TestFaceCropComputation:
    """Test face crop computation utilities."""
    
    @pytest.mark.unit
    def test_compute_face_crop_normal(self):
        """Test face crop computation with normal parameters."""
        # Create a test frame
        frame = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        box = (100, 100, 200, 200)  # x, y, w, h
        
        crop = _compute_face_crop_by_box(frame, box, size=224)
        
        assert crop.shape == (224, 224, 3)
        assert crop.dtype == np.uint8
    
    @pytest.mark.unit
    def test_compute_face_crop_edge_cases(self):
        """Test face crop computation with edge cases."""
        frame = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
        
        # Test box at edge of frame
        box = (0, 0, 50, 50)
        crop = _compute_face_crop_by_box(frame, box)
        assert crop.shape == (224, 224, 3)
        
        # Test box extending beyond frame
        box = (200, 200, 100, 100)
        crop = _compute_face_crop_by_box(frame, box)
        assert crop.shape == (224, 224, 3)
        
        # Test negative coordinates (should be clipped)
        box = (-10, -10, 50, 50)
        crop = _compute_face_crop_by_box(frame, box)
        assert crop.shape == (224, 224, 3)
    
    @pytest.mark.unit
    def test_compute_face_crop_empty_roi(self):
        """Test face crop computation when ROI is empty."""
        frame = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        box = (50, 50, 0, 0)  # Zero width/height
        
        crop = _compute_face_crop_by_box(frame, box)
        # Should fallback to entire frame
        assert crop.shape == (224, 224, 3)
    
    @pytest.mark.unit
    def test_compute_face_crop_different_sizes(self):
        """Test face crop computation with different target sizes."""
        frame = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        box = (100, 100, 200, 200)
        
        for size in [112, 224, 256]:
            crop = _compute_face_crop_by_box(frame, box, size=size)
            assert crop.shape == (size, size, 3)


class TestMouthMetric:
    """Test mouth openness detection."""
    
    @pytest.mark.unit
    def test_mouth_metric_valid_input(self, sample_face_crop):
        """Test mouth metric with valid face crop."""
        metric = _mouth_metric(sample_face_crop)
        
        # Should return a float or None
        assert metric is None or isinstance(metric, float)
        if metric is not None:
            assert 0.0 <= metric <= 1.0
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_mouth_metric_cascade_loading_failure(self, mock_cascade, sample_face_crop):
        """Test mouth metric when cascade loading fails."""
        # Mock empty cascade
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = True
        mock_cascade.return_value = mock_cascade_instance
        
        metric = _mouth_metric(sample_face_crop)
        assert metric is None
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_mouth_metric_no_smiles_detected(self, mock_cascade, sample_face_crop):
        """Test mouth metric when no smiles are detected."""
        # Mock cascade that finds no smiles
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = False
        mock_cascade_instance.detectMultiScale.return_value = []
        mock_cascade.return_value = mock_cascade_instance
        
        metric = _mouth_metric(sample_face_crop)
        assert metric == 0.0
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_mouth_metric_smiles_detected(self, mock_cascade, sample_face_crop):
        """Test mouth metric when smiles are detected."""
        # Mock cascade that finds smiles
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = False
        mock_cascade_instance.detectMultiScale.return_value = np.array([[10, 10, 30, 20]])
        mock_cascade.return_value = mock_cascade_instance
        
        metric = _mouth_metric(sample_face_crop)
        assert isinstance(metric, float)
        assert 0.0 <= metric <= 1.0


class TestEyeMetric:
    """Test eye openness detection."""
    
    @pytest.mark.unit
    def test_eye_metric_valid_input(self, sample_face_crop):
        """Test eye metric with valid face crop."""
        metric = _eye_metric(sample_face_crop)
        
        # Should return a float or None
        assert metric is None or isinstance(metric, float)
        if metric is not None:
            assert 0.0 <= metric <= 1.0
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_eye_metric_cascade_loading_failure(self, mock_cascade, sample_face_crop):
        """Test eye metric when cascade loading fails."""
        # Mock empty cascade
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = True
        mock_cascade.return_value = mock_cascade_instance
        
        metric = _eye_metric(sample_face_crop)
        assert metric is None
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_eye_metric_no_eyes_detected(self, mock_cascade, sample_face_crop):
        """Test eye metric when no eyes are detected."""
        # Mock cascade that finds no eyes
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = False
        mock_cascade_instance.detectMultiScale.return_value = []
        mock_cascade.return_value = mock_cascade_instance
        
        metric = _eye_metric(sample_face_crop)
        assert metric == 0.0
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_eye_metric_eyes_detected(self, mock_cascade, sample_face_crop):
        """Test eye metric when eyes are detected."""
        # Mock cascade that finds eyes
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = False
        mock_cascade_instance.detectMultiScale.return_value = np.array([[30, 30, 25, 15], [80, 30, 25, 15]])
        mock_cascade.return_value = mock_cascade_instance
        
        metric = _eye_metric(sample_face_crop)
        assert isinstance(metric, float)
        assert 0.0 <= metric <= 1.0


class TestHaarTracking:
    """Test Haar cascade-based face tracking."""
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_haar_track_no_faces(self, mock_cascade):
        """Test Haar tracking when no faces are detected."""
        # Mock cascade that finds no faces
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = False
        mock_cascade_instance.detectMultiScale.return_value = []
        mock_cascade.return_value = mock_cascade_instance
        
        frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(5)]
        result = _haar_track(frames)
        
        assert result is None
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_haar_track_cascade_loading_failure(self, mock_cascade):
        """Test Haar tracking when cascade loading fails."""
        # Mock empty cascade
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = True
        mock_cascade.return_value = mock_cascade_instance
        
        frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(5)]
        result = _haar_track(frames)
        
        assert result is None
    
    @pytest.mark.unit
    @patch('deepfake_detector.face._eye_metric')
    @patch('deepfake_detector.face._mouth_metric')
    @patch('cv2.CascadeClassifier')
    def test_haar_track_faces_detected(self, mock_cascade, mock_mouth, mock_eye):
        """Test Haar tracking when faces are detected."""
        # Mock cascade that finds faces
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = False
        mock_cascade_instance.detectMultiScale.return_value = np.array([[50, 50, 124, 124]])
        mock_cascade.return_value = mock_cascade_instance
        
        # Mock metrics
        mock_mouth.return_value = 0.3
        mock_eye.return_value = 0.4
        
        frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(3)]
        result = _haar_track(frames)
        
        assert isinstance(result, FaceTrack)
        assert len(result.frames) == 3
        assert all(frame.mouth_open == 0.3 for frame in result.frames)
        assert all(frame.eye_open == 0.4 for frame in result.frames)
        assert all(frame.landmarks_xy is None for frame in result.frames)
    
    @pytest.mark.unit
    @patch('cv2.CascadeClassifier')
    def test_haar_track_multiple_faces_selects_largest(self, mock_cascade):
        """Test that Haar tracking selects the largest face when multiple are detected."""
        # Mock cascade that finds multiple faces
        mock_cascade_instance = MagicMock()
        mock_cascade_instance.empty.return_value = False
        # First face: 50x50, Second face: 100x100 (larger)
        mock_cascade_instance.detectMultiScale.return_value = np.array([[10, 10, 50, 50], [100, 100, 100, 100]])
        mock_cascade.return_value = mock_cascade_instance
        
        frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)]
        result = _haar_track(frames)
        
        assert isinstance(result, FaceTrack)
        assert len(result.frames) == 1
        # Should select the larger face (100, 100, 100, 100)
        assert result.frames[0].box_xywh == (100, 100, 100, 100)


class TestMediaPipeTracking:
    """Test MediaPipe-based face tracking."""
    
    @pytest.mark.unit
    def test_mediapipe_track_no_mediapipe(self):
        """Test MediaPipe tracking when MediaPipe is not available."""
        with patch('deepfake_detector.face._HAS_MEDIAPIPE', False):
            frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(3)]
            result = _mediapipe_track(frames)
            assert result is None
    
    @pytest.mark.unit
    @patch('deepfake_detector.face._HAS_MEDIAPIPE', True)
    @patch('deepfake_detector.face.mp')
    def test_mediapipe_track_no_faces(self, mock_mp):
        """Test MediaPipe tracking when no faces are detected."""
        # Mock MediaPipe that finds no faces
        mock_face_mesh = MagicMock()
        mock_result = MagicMock()
        mock_result.multi_face_landmarks = None
        mock_face_mesh.process.return_value = mock_result
        mock_mp.solutions.face_mesh.FaceMesh.return_value = mock_face_mesh
        
        frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(3)]
        result = _mediapipe_track(frames)
        
        assert result is None
    
    @pytest.mark.unit
    @patch('deepfake_detector.face._HAS_MEDIAPIPE', True)
    @patch('deepfake_detector.face.mp')
    def test_mediapipe_track_faces_detected(self, mock_mp):
        """Test MediaPipe tracking when faces are detected."""
        # Mock MediaPipe landmarks
        mock_landmark = MagicMock()
        mock_landmark.x = 0.5
        mock_landmark.y = 0.5
        
        mock_landmarks = [mock_landmark] * 468  # MediaPipe has 468 landmarks
        mock_face_landmarks = MagicMock()
        mock_face_landmarks.landmark = mock_landmarks
        
        mock_face_mesh = MagicMock()
        mock_result = MagicMock()
        mock_result.multi_face_landmarks = [mock_face_landmarks]
        mock_face_mesh.process.return_value = mock_result
        mock_mp.solutions.face_mesh.FaceMesh.return_value = mock_face_mesh
        
        frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(2)]
        result = _mediapipe_track(frames)
        
        assert isinstance(result, FaceTrack)
        assert len(result.frames) == 2
        # Check that landmarks are present
        assert all(frame.landmarks_xy is not None for frame in result.frames)
        assert all(frame.mouth_open is not None for frame in result.frames)


class TestDetectFaceTrack:
    """Test the main face detection function."""
    
    @pytest.mark.unit
    def test_detect_face_track_empty_frames(self):
        """Test face detection with empty frame list."""
        result = detect_face_track([])
        assert result is None
    
    @pytest.mark.unit
    def test_detect_face_track_mediapipe_success(self, mock_face_track):
        """Test face detection when MediaPipe succeeds."""
        with patch('deepfake_detector.face._HAS_MEDIAPIPE', True), \
             patch('deepfake_detector.face._mediapipe_track') as mock_mediapipe, \
             patch('deepfake_detector.face._haar_track') as mock_haar:
            
            mock_mediapipe.return_value = mock_face_track
            
            frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(3)]
            result = detect_face_track(frames)
            
            assert isinstance(result, FaceTrack)  # Just check type since mock comparison is complex
            mock_mediapipe.assert_called_once()
            mock_haar.assert_not_called()
    
    @pytest.mark.unit
    def test_detect_face_track_mediapipe_fallback_to_haar(self, mock_face_track):
        """Test face detection fallback from MediaPipe to Haar."""
        with patch('deepfake_detector.face._HAS_MEDIAPIPE', True), \
             patch('deepfake_detector.face._mediapipe_track') as mock_mediapipe, \
             patch('deepfake_detector.face._haar_track') as mock_haar:
            
            mock_mediapipe.return_value = None
            mock_haar.return_value = mock_face_track
            
            frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(3)]
            result = detect_face_track(frames)
            
            assert isinstance(result, FaceTrack)
            mock_mediapipe.assert_called_once()
            mock_haar.assert_called_once()
    
    @pytest.mark.unit
    def test_detect_face_track_both_fail(self):
        """Test face detection when both MediaPipe and Haar fail."""
        with patch('deepfake_detector.face._HAS_MEDIAPIPE', True), \
             patch('deepfake_detector.face._mediapipe_track') as mock_mediapipe, \
             patch('deepfake_detector.face._haar_track') as mock_haar:
            
            mock_mediapipe.return_value = None
            mock_haar.return_value = None
            
            frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(3)]
            result = detect_face_track(frames)
            
            assert result is None
    
    @pytest.mark.unit
    def test_detect_face_track_no_mediapipe(self, mock_face_track):
        """Test face detection when MediaPipe is not available."""
        with patch('deepfake_detector.face._HAS_MEDIAPIPE', False), \
             patch('deepfake_detector.face._haar_track') as mock_haar:
            
            mock_haar.return_value = mock_face_track
            
            frames = [np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8) for _ in range(3)]
            result = detect_face_track(frames)
            
            assert isinstance(result, FaceTrack)
            mock_haar.assert_called_once()


class TestIntegrationFaceDetection:
    """Integration tests for face detection."""
    
    @pytest.mark.integration
    @pytest.mark.slow
    def test_face_detection_real_cascade(self):
        """Test face detection with real OpenCV cascades (if available)."""
        # Create a synthetic face-like image
        frame = np.zeros((240, 320, 3), dtype=np.uint8)
        # Add a face-like oval
        cv2.ellipse(frame, (160, 120), (60, 80), 0, 0, 360, (200, 180, 160), -1)
        # Add eyes
        cv2.circle(frame, (140, 100), 8, (50, 50, 50), -1)
        cv2.circle(frame, (180, 100), 8, (50, 50, 50), -1)
        # Add mouth
        cv2.ellipse(frame, (160, 140), (15, 8), 0, 0, 180, (100, 50, 50), -1)
        
        frames = [frame] * 3
        result = detect_face_track(frames)
        
        # This might succeed or fail depending on cascade quality
        # Just verify it doesn't crash and returns expected type
        assert result is None or isinstance(result, FaceTrack)
    
    @pytest.mark.integration
    def test_face_detection_performance(self):
        """Test face detection performance with multiple frames."""
        import time
        
        # Create multiple synthetic frames
        frames = []
        for i in range(10):
            frame = np.random.randint(0, 255, (240, 320, 3), dtype=np.uint8)
            frames.append(frame)
        
        start_time = time.time()
        result = detect_face_track(frames)
        end_time = time.time()
        
        # Should complete within reasonable time (5 seconds for 10 frames)
        assert end_time - start_time < 5.0
        assert result is None or isinstance(result, FaceTrack)
