"""Unit tests for score fusion module."""

import pytest
import numpy as np
import math
from pathlib import Path
import sys
from typing import Dict, Optional, List, Any

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from deepfake_detector.fusion import fuse_scores, _sigmoid


class TestSigmoidFunction:
    """Test the sigmoid helper function."""
    
    @pytest.mark.unit
    def test_sigmoid_basic(self):
        """Test basic sigmoid function behavior."""
        # Test specific values
        assert abs(_sigmoid(0.0) - 0.5) < 1e-10  # sigmoid(0) = 0.5
        assert _sigmoid(-50) < 1e-10  # sigmoid(-large) ≈ 0 (avoid overflow)
        assert _sigmoid(50) > 0.999  # sigmoid(+large) ≈ 1 (avoid overflow)
        
        # Test monotonicity
        assert _sigmoid(-1) < _sigmoid(0) < _sigmoid(1)
    
    @pytest.mark.unit
    def test_sigmoid_edge_cases(self):
        """Test sigmoid with edge cases."""
        # Large positive values (safe range)
        result = _sigmoid(20)
        assert 0.99 < result <= 1.0
        
        # Large negative values (safe range)
        result = _sigmoid(-20)
        assert 0.0 <= result < 0.01
        
        # Zero
        assert abs(_sigmoid(0) - 0.5) < 1e-15
    
    @pytest.mark.unit
    def test_sigmoid_mathematical_properties(self):
        """Test mathematical properties of sigmoid."""
        # Symmetry: sigmoid(-x) = 1 - sigmoid(x)
        x = 2.0
        assert abs(_sigmoid(-x) + _sigmoid(x) - 1.0) < 1e-10
        
        # Range test
        for x in [-10, -1, 0, 1, 10]:
            result = _sigmoid(x)
            assert 0.0 <= result <= 1.0


class TestFuseScores:
    """Test the score fusion function."""
    
    @pytest.mark.unit
    def test_fuse_scores_empty_dict(self):
        """Test fusion with empty scores dictionary."""
        scores = {}
        result = fuse_scores(scores)
        assert abs(result - 0.5) < 1e-10  # sigmoid(0) = 0.5
    
    @pytest.mark.unit
    def test_fuse_scores_single_score_centered(self):
        """Test fusion with single score at center (0.5)."""
        # Note: actual keys are "freq", "rppg", "av", "geom"
        scores = {"freq": 0.5}
        result = fuse_scores(scores)
        # z = 1.0 * (0.5 - 0.5) = 0, sigmoid(0) = 0.5
        assert abs(result - 0.5) < 1e-10
    
    @pytest.mark.unit
    def test_fuse_scores_single_score_high(self):
        """Test fusion with single high score."""
        scores = {"freq": 0.8}
        result = fuse_scores(scores)
        # z = 1.0 * (0.8 - 0.5) = 0.3, sigmoid(0.3)
        expected = _sigmoid(0.3)
        assert abs(result - expected) < 1e-10
    
    @pytest.mark.unit
    def test_fuse_scores_single_score_low(self):
        """Test fusion with single low score."""
        scores = {"rppg": 0.2}
        result = fuse_scores(scores)
        # z = 1.0 * (0.2 - 0.5) = -0.3, sigmoid(-0.3)
        expected = _sigmoid(-0.3)
        assert abs(result - expected) < 1e-10
    
    @pytest.mark.unit
    def test_fuse_scores_multiple_balanced(self):
        """Test fusion with multiple balanced scores."""
        scores = {
            "freq": 0.6,    # +0.1
            "rppg": 0.4,    # -0.1
            "av": 0.5,      # 0.0
            "geom": 0.5     # 0.0
        }
        result = fuse_scores(scores)
        # z = 1.0*(0.6-0.5) + 1.0*(0.4-0.5) + 1.0*(0.5-0.5) + 1.0*(0.5-0.5) = 0.1 - 0.1 = 0
        expected = _sigmoid(0.0)
        assert abs(result - expected) < 1e-10
        assert abs(result - 0.5) < 1e-10
    
    @pytest.mark.unit
    def test_fuse_scores_all_high(self):
        """Test fusion with all high scores."""
        scores = {
            "freq": 0.9,    # +0.4
            "rppg": 0.8,    # +0.3
            "av": 0.7,      # +0.2
            "geom": 0.6     # +0.1
        }
        result = fuse_scores(scores)
        # z = 0.4 + 0.3 + 0.2 + 0.1 = 1.0
        expected = _sigmoid(1.0)
        assert abs(result - expected) < 1e-10
        assert result > 0.7  # Should be high probability
    
    @pytest.mark.unit
    def test_fuse_scores_all_low(self):
        """Test fusion with all low scores."""
        scores = {
            "freq": 0.1,    # -0.4
            "rppg": 0.2,    # -0.3
            "av": 0.3,      # -0.2
            "geom": 0.4     # -0.1
        }
        result = fuse_scores(scores)
        # z = -0.4 - 0.3 - 0.2 - 0.1 = -1.0
        expected = _sigmoid(-1.0)
        assert abs(result - expected) < 1e-10
        assert result < 0.3  # Should be low probability
    
    @pytest.mark.unit
    def test_fuse_scores_extreme_values(self):
        """Test fusion with extreme score values."""
        # All minimum scores
        scores = {
            "freq": 0.0,    # -0.5
            "rppg": 0.0,    # -0.5
            "av": 0.0,      # -0.5
            "geom": 0.0     # -0.5
        }
        result = fuse_scores(scores)
        # z = -0.5 * 4 = -2.0
        expected = _sigmoid(-2.0)
        assert abs(result - expected) < 1e-10
        assert result < 0.15
        
        # All maximum scores
        scores = {
            "freq": 1.0,    # +0.5
            "rppg": 1.0,    # +0.5
            "av": 1.0,      # +0.5
            "geom": 1.0     # +0.5
        }
        result = fuse_scores(scores)
        # z = 0.5 * 4 = 2.0
        expected = _sigmoid(2.0)
        assert abs(result - expected) < 1e-10
        assert result > 0.85
    
    @pytest.mark.unit
    def test_fuse_scores_unknown_keys_ignored(self):
        """Test that unknown keys are ignored."""
        scores = {
            "freq": 0.7,        # +0.2
            "unknown": 0.9,     # Should be ignored
            "rppg": 0.3,        # -0.2
            "extra_key": 1.0    # Should be ignored
        }
        result = fuse_scores(scores)
        # z = 0.2 + (-0.2) = 0.0
        expected = _sigmoid(0.0)
        assert abs(result - expected) < 1e-10
        assert abs(result - 0.5) < 1e-10
    
    @pytest.mark.unit
    def test_fuse_scores_partial_coverage(self):
        """Test fusion with only some expected keys."""
        # Only frequency and rppg
        scores = {
            "freq": 0.8,    # +0.3
            "rppg": 0.2     # -0.3
        }
        result = fuse_scores(scores)
        # z = 0.3 + (-0.3) = 0.0
        expected = _sigmoid(0.0)
        assert abs(result - expected) < 1e-10
        
        # Only one key
        scores = {"geom": 0.9}  # +0.4
        result = fuse_scores(scores)
        expected = _sigmoid(0.4)
        assert abs(result - expected) < 1e-10


class TestFuseScoresEdgeCases:
    """Test edge cases and error conditions."""
    
    @pytest.mark.unit
    def test_fuse_scores_key_mapping(self):
        """Test the correct key mapping in fusion."""
        # Test all expected keys map correctly
        scores = {
            "freq": 0.6,    # frequency -> freq
            "rppg": 0.7,    # rppg -> rppg  
            "av": 0.8,      # avsync -> av
            "geom": 0.9     # geometry -> geom
        }
        result = fuse_scores(scores)
        # z = 0.1 + 0.2 + 0.3 + 0.4 = 1.0
        expected = _sigmoid(1.0)
        assert abs(result - expected) < 1e-10
    
    @pytest.mark.unit
    def test_fuse_scores_weight_uniformity(self):
        """Test that all weights are uniform (1.0)."""
        # If weights are all 1.0, doubling all deviations should double z
        scores1 = {"freq": 0.6}  # z = 0.1
        scores2 = {"freq": 0.7}  # z = 0.2
        
        result1 = fuse_scores(scores1)
        result2 = fuse_scores(scores2)
        
        expected1 = _sigmoid(0.1)
        expected2 = _sigmoid(0.2)
        
        assert abs(result1 - expected1) < 1e-10
        assert abs(result2 - expected2) < 1e-10
        assert result2 > result1  # Higher score should yield higher probability
    
    @pytest.mark.unit
    def test_fuse_scores_floating_point_precision(self):
        """Test with high precision floating point values."""
        scores = {
            "freq": 0.123456789012345,
            "rppg": 0.987654321098765
        }
        result = fuse_scores(scores)
        
        # Calculate expected manually
        z = (0.123456789012345 - 0.5) + (0.987654321098765 - 0.5)
        expected = _sigmoid(z)
        
        assert abs(result - expected) < 1e-10
        assert 0.0 <= result <= 1.0
    
    @pytest.mark.unit
    def test_fuse_scores_consistency(self):
        """Test that repeated calls return consistent results."""
        scores = {"freq": 0.7, "rppg": 0.3, "av": 0.8}
        
        results = [fuse_scores(scores) for _ in range(10)]
        
        # All results should be identical
        for result in results[1:]:
            assert abs(result - results[0]) < 1e-15
    
    @pytest.mark.unit
    def test_fuse_scores_monotonicity(self):
        """Test monotonic behavior of fusion."""
        base_scores = {"freq": 0.5, "rppg": 0.5}
        
        # Gradually increase one score
        results = []
        for delta in [0.0, 0.1, 0.2, 0.3, 0.4]:
            scores = {"freq": 0.5 + delta, "rppg": 0.5}
            result = fuse_scores(scores)
            results.append(result)
        
        # Results should be monotonically increasing
        for i in range(1, len(results)):
            assert results[i] > results[i-1]
    
    @pytest.mark.unit
    def test_fuse_scores_symmetry(self):
        """Test symmetric behavior around 0.5."""
        # Positive deviation
        scores_pos = {"freq": 0.7}  # +0.2
        result_pos = fuse_scores(scores_pos)
        
        # Negative deviation
        scores_neg = {"freq": 0.3}  # -0.2
        result_neg = fuse_scores(scores_neg)
        
        # Should be symmetric around 0.5
        assert abs((result_pos - 0.5) + (result_neg - 0.5)) < 1e-10
        assert abs(result_pos + result_neg - 1.0) < 1e-10


class TestFuseScoresRealWorldScenarios:
    """Test realistic deepfake detection scenarios."""
    
    @pytest.mark.unit
    def test_fuse_scores_clearly_real_video(self):
        """Test fusion for clearly real video signals."""
        scores = {
            "freq": 0.1,    # Low frequency artifacts
            "rppg": 0.2,    # Good pulse signal
            "av": 0.15,     # Good lip sync
            "geom": 0.1     # Natural geometry
        }
        result = fuse_scores(scores)
        # All scores indicate real, should be low probability
        assert result < 0.3
    
    @pytest.mark.unit
    def test_fuse_scores_clearly_fake_video(self):
        """Test fusion for clearly fake video signals."""
        scores = {
            "freq": 0.9,    # High frequency artifacts
            "rppg": 0.85,   # Poor pulse signal
            "av": 0.8,      # Poor lip sync
            "geom": 0.9     # Unnatural geometry
        }
        result = fuse_scores(scores)
        # All scores indicate fake, should be high probability
        assert result > 0.7
    
    @pytest.mark.unit
    def test_fuse_scores_mixed_signals(self):
        """Test fusion with mixed signal quality."""
        scores = {
            "freq": 0.3,    # Good frequency
            "rppg": 0.7,    # Poor pulse
            "av": 0.4,      # Decent lip sync
            "geom": 0.6     # Somewhat unnatural
        }
        result = fuse_scores(scores)
        # Mixed signals should be around middle
        assert 0.3 <= result <= 0.7
    
    @pytest.mark.unit
    def test_fuse_scores_partial_detection_failure(self):
        """Test fusion when only some detectors provide scores."""
        # Only frequency and geometry work
        scores = {
            "freq": 0.8,    # High artifacts
            "geom": 0.2     # Natural geometry
        }
        result = fuse_scores(scores)
        # z = 0.3 + (-0.3) = 0.0, should be neutral
        assert abs(result - 0.5) < 1e-10
    
    @pytest.mark.unit
    def test_fuse_scores_single_strong_signal(self):
        """Test fusion with one very strong signal."""
        scores = {"freq": 0.95}  # Very strong fake indicator
        result = fuse_scores(scores)
        # z = 0.45, should be high but not extreme
        expected = _sigmoid(0.45)
        assert abs(result - expected) < 1e-10
        assert result > 0.6


class TestFuseScoresIntegration:
    """Integration tests for score fusion."""
    
    @pytest.mark.integration
    def test_fuse_scores_performance(self):
        """Test fusion performance with many operations."""
        import time
        
        scores = {"freq": 0.6, "rppg": 0.4, "av": 0.8, "geom": 0.3}
        
        start_time = time.time()
        
        # Run many fusion operations
        results = []
        for _ in range(10000):
            result = fuse_scores(scores)
            results.append(result)
        
        end_time = time.time()
        
        # Should complete quickly (< 0.1 seconds for 10k operations)
        assert end_time - start_time < 0.1
        
        # All results should be identical
        assert all(abs(r - results[0]) < 1e-15 for r in results)
    
    @pytest.mark.integration
    def test_fuse_scores_memory_efficiency(self):
        """Test that fusion doesn't leak memory."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss
        
        # Run many fusion operations with different score combinations
        for i in range(1000):
            scores = {}
            
            # Randomly add some scores
            if i % 2 == 0:
                scores["freq"] = np.random.random()
            if i % 3 == 0:
                scores["rppg"] = np.random.random()
            if i % 5 == 0:
                scores["av"] = np.random.random()
            if i % 7 == 0:
                scores["geom"] = np.random.random()
            
            result = fuse_scores(scores)
            assert 0.0 <= result <= 1.0
        
        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory
        
        # Should not use more than 1MB additional memory
        assert memory_increase < 1024 * 1024
    
    @pytest.mark.integration
    def test_fuse_scores_statistical_properties(self):
        """Test statistical properties over many random inputs."""
        results = []
        
        # Generate many random score combinations
        for _ in range(1000):
            scores = {}
            
            # Randomly include scores around 0.5 (neutral)
            for key in ["freq", "rppg", "av", "geom"]:
                if np.random.random() > 0.3:  # 70% chance to include
                    # Random score with bias toward center
                    scores[key] = 0.5 + np.random.normal(0, 0.2)
                    # Clamp to valid range
                    scores[key] = max(0.0, min(1.0, scores[key]))
            
            if scores:  # Only if we have at least one score
                result = fuse_scores(scores)
                results.append(result)
        
        if results:
            results = np.array(results)
            
            # All results should be in valid range
            assert np.all((results >= 0.0) & (results <= 1.0))
            
            # Should have reasonable distribution (not all the same)
            assert np.std(results) > 0.05
            
            # Mean should be around 0.5 for centered random inputs
            assert 0.4 <= np.mean(results) <= 0.6
    
    @pytest.mark.integration
    def test_fuse_scores_robustness_scenarios(self):
        """Test fusion robustness with various realistic scenarios."""
        
        scenarios = [
            # (description, scores, expected_range)
            ("perfect_real", {"freq": 0.0, "rppg": 0.0, "av": 0.0, "geom": 0.0}, (0.0, 0.2)),
            ("perfect_fake", {"freq": 1.0, "rppg": 1.0, "av": 1.0, "geom": 1.0}, (0.8, 1.0)),
            ("neutral_baseline", {"freq": 0.5, "rppg": 0.5, "av": 0.5, "geom": 0.5}, (0.49, 0.51)),
            ("strong_freq_only", {"freq": 0.9}, (0.6, 0.8)),
            ("weak_rppg_only", {"rppg": 0.1}, (0.2, 0.4)),
            ("mixed_strong", {"freq": 0.9, "rppg": 0.1, "av": 0.8, "geom": 0.2}, (0.4, 0.6)),
        ]
        
        for description, scores, expected_range in scenarios:
            result = fuse_scores(scores)
            
            assert 0.0 <= result <= 1.0, f"Invalid result for {description}"
            assert expected_range[0] <= result <= expected_range[1], \
                f"Result {result} not in expected range {expected_range} for {description}"