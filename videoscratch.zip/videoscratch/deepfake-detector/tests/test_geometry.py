"""Unit tests for geometry analysis module."""

import pytest
import numpy as np
from pathlib import Path
import sys
from typing import List, Optional, Union

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from deepfake_detector.geometry import geometry_fake_score


class TestGeometryFakeScore:
    """Test the geometry fake score function."""
    
    @pytest.mark.unit
    def test_geometry_fake_score_insufficient_data(self):
        """Test geometry fake score with insufficient data."""
        # Test with None inputs
        score = geometry_fake_score(None, 15.0)
        assert score == 0.5
        
        # Test with insufficient eye data
        short_eye_series = [0.1, 0.2]
        short_centers = [(100.0, 100.0), (101.0, 100.0)]
        score = geometry_fake_score(None, 15.0, eye_open_series=short_eye_series, centers_xy=short_centers)
        assert score == 0.5
        
        # Test with insufficient center data
        sufficient_eye_series = [0.1] * 15
        short_centers = [(100.0, 100.0), (101.0, 100.0)]
        score = geometry_fake_score(None, 15.0, eye_open_series=sufficient_eye_series, centers_xy=short_centers)
        assert score == 0.5
    
    @pytest.mark.unit
    def test_geometry_fake_score_basic_functionality(self):
        """Test basic geometry functionality with valid inputs."""
        # Create valid eye openness series with some variation
        eye_open_series = []
        for i in range(20):
            # Simulate blinking pattern
            if i % 15 == 0:  # Blink every 15 frames
                eye_val = 0.1  # Closed
            else:
                eye_val = 0.3 + 0.1 * np.random.random()  # Open with variation
            eye_open_series.append(eye_val)
        
        # Create face centers with natural movement
        centers_xy = []
        for i in range(20):
            # Small natural head movement
            x = 112.0 + 2.0 * np.sin(i * 0.1) + np.random.random() * 0.5
            y = 112.0 + 1.0 * np.cos(i * 0.15) + np.random.random() * 0.5
            centers_xy.append((x, y))
        
        score = geometry_fake_score(None, 15.0, eye_open_series=eye_open_series, centers_xy=centers_xy)
        
        assert 0.0 <= score <= 1.0
        assert isinstance(score, float)
    
    @pytest.mark.unit
    def test_geometry_fake_score_natural_blinking(self):
        """Test geometry score with natural blinking patterns."""
        # Create natural blinking pattern
        eye_open_series = []
        for i in range(30):
            if i % 20 == 0 or i % 20 == 1:  # Blink for 2 frames every 20 frames
                eye_val = 0.05  # Nearly closed
            else:
                eye_val = 0.25 + 0.1 * np.random.random()  # Normal variation
            eye_open_series.append(eye_val)
        
        # Natural head movement
        centers_xy = []
        for i in range(30):
            x = 112.0 + np.random.random() * 2.0 - 1.0  # ±1 pixel jitter
            y = 112.0 + np.random.random() * 2.0 - 1.0
            centers_xy.append((x, y))
        
        score = geometry_fake_score(None, 15.0, eye_open_series=eye_open_series, centers_xy=centers_xy)
        
        # Natural blinking should result in lower fake score
        assert 0.0 <= score <= 1.0
        assert score <= 0.7  # Should indicate more real-like
    
    @pytest.mark.unit
    def test_geometry_fake_score_no_blinking(self):
        """Test geometry score with no blinking (static eyes)."""
        # Constant eye openness (no blinking)
        eye_open_series = [0.3] * 25
        
        # Some head movement
        centers_xy = []
        for i in range(25):
            x = 112.0 + np.random.random() * 1.0
            y = 112.0 + np.random.random() * 1.0
            centers_xy.append((x, y))
        
        score = geometry_fake_score(None, 15.0, eye_open_series=eye_open_series, centers_xy=centers_xy)
        
        # No blinking should result in higher fake score
        assert 0.0 <= score <= 1.0
        assert score >= 0.5  # Should indicate fake-like
    
    @pytest.mark.unit
    def test_geometry_fake_score_over_stabilized(self):
        """Test geometry score with over-stabilized face centers."""
        # Natural eye blinking
        eye_open_series = []
        for i in range(25):
            if i % 12 == 0:
                eye_val = 0.1
            else:
                eye_val = 0.3 + 0.05 * np.random.random()
            eye_open_series.append(eye_val)
        
        # Over-stabilized centers (too little movement)
        centers_xy = [(112.0, 112.0)] * 25  # Perfectly static
        
        score = geometry_fake_score(None, 15.0, eye_open_series=eye_open_series, centers_xy=centers_xy)
        
        # Over-stabilization should indicate fake
        assert 0.0 <= score <= 1.0
        assert score >= 0.5  # Should indicate fake-like
    
    @pytest.mark.unit
    def test_geometry_fake_score_excessive_jitter(self):
        """Test geometry score with excessive head movement."""
        # Normal blinking
        eye_open_series = []
        for i in range(20):
            if i % 15 == 0:
                eye_val = 0.08
            else:
                eye_val = 0.28 + 0.05 * np.random.random()
            eye_open_series.append(eye_val)
        
        # Excessive jitter
        centers_xy = []
        for i in range(20):
            x = 112.0 + np.random.random() * 10.0 - 5.0  # ±5 pixel jitter
            y = 112.0 + np.random.random() * 10.0 - 5.0
            centers_xy.append((x, y))
        
        score = geometry_fake_score(None, 15.0, eye_open_series=eye_open_series, centers_xy=centers_xy)
        
        # Excessive jitter might indicate processing artifacts
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_geometry_fake_score_mixed_none_values(self):
        """Test geometry score with mixed None values in eye series."""
        # Eye series with some None values (detection failures)
        eye_open_series = [0.3, None, 0.25, 0.3, None, 0.28] + [0.3] * 14
        
        # Normal centers
        centers_xy = []
        for i in range(20):
            x = 112.0 + np.random.random() * 2.0
            y = 112.0 + np.random.random() * 2.0
            centers_xy.append((x, y))
        
        score = geometry_fake_score(None, 15.0, eye_open_series=eye_open_series, centers_xy=centers_xy)
        
        # Should handle None values gracefully
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_geometry_fake_score_different_fps(self):
        """Test geometry score with different frame rates."""
        eye_open_series = []
        for i in range(30):
            if i % 10 == 0:
                eye_val = 0.1
            else:
                eye_val = 0.3 + 0.05 * np.random.random()
            eye_open_series.append(eye_val)
        
        centers_xy = []
        for i in range(30):
            x = 112.0 + np.random.random() * 1.5
            y = 112.0 + np.random.random() * 1.5
            centers_xy.append((x, y))
        
        # Test different frame rates
        for fps in [10.0, 15.0, 24.0, 30.0]:
            score = geometry_fake_score(None, fps, eye_open_series=eye_open_series, centers_xy=centers_xy)
            assert 0.0 <= score <= 1.0
            assert isinstance(score, float)
    
    @pytest.mark.unit
    def test_geometry_fake_score_extreme_eye_values(self):
        """Test geometry score with extreme eye openness values."""
        # Test with very large eye values
        large_eye_series = [10.0] * 15
        normal_centers = [(112.0 + i * 0.1, 112.0) for i in range(15)]
        
        score_large = geometry_fake_score(None, 15.0, eye_open_series=large_eye_series, centers_xy=normal_centers)
        assert 0.0 <= score_large <= 1.0
        
        # Test with negative eye values
        negative_eye_series = [-0.1] * 15
        score_negative = geometry_fake_score(None, 15.0, eye_open_series=negative_eye_series, centers_xy=normal_centers)
        assert 0.0 <= score_negative <= 1.0
    
    @pytest.mark.unit
    def test_geometry_fake_score_extreme_center_values(self):
        """Test geometry score with extreme center coordinates."""
        normal_eye_series = [0.3 + 0.02 * np.sin(i) for i in range(15)]
        
        # Test with very large coordinates
        large_centers = [(1000.0, 1000.0)] * 15
        score_large = geometry_fake_score(None, 15.0, eye_open_series=normal_eye_series, centers_xy=large_centers)
        assert 0.0 <= score_large <= 1.0
        
        # Test with negative coordinates
        negative_centers = [(-50.0, -50.0)] * 15
        score_negative = geometry_fake_score(None, 15.0, eye_open_series=normal_eye_series, centers_xy=negative_centers)
        assert 0.0 <= score_negative <= 1.0
    
    @pytest.mark.unit
    def test_geometry_fake_score_eye_variance_calculation(self):
        """Test eye variance calculation with known patterns."""
        # High variance eye pattern (lots of blinking)
        high_variance_eyes = []
        for i in range(25):
            if i % 3 == 0:  # Frequent blinking
                high_variance_eyes.append(0.05)
            else:
                high_variance_eyes.append(0.35)
        
        normal_centers = [(112.0 + i * 0.1, 112.0) for i in range(25)]
        
        score_high_var = geometry_fake_score(None, 15.0, eye_open_series=high_variance_eyes, centers_xy=normal_centers)
        
        # Low variance eye pattern (no blinking)
        low_variance_eyes = [0.3] * 25
        score_low_var = geometry_fake_score(None, 15.0, eye_open_series=low_variance_eyes, centers_xy=normal_centers)
        
        # Low variance should result in higher fake score
        assert 0.0 <= score_high_var <= 1.0
        assert 0.0 <= score_low_var <= 1.0
        assert score_low_var >= score_high_var  # Low variance is more fake-like
    
    @pytest.mark.unit
    def test_geometry_fake_score_jitter_calculation(self):
        """Test jitter calculation with known movement patterns."""
        normal_eye_series = [0.3 + 0.02 * np.random.random() for _ in range(20)]
        
        # High jitter pattern
        high_jitter_centers = []
        for i in range(20):
            x = 112.0 + np.random.random() * 6.0 - 3.0  # ±3 pixel jitter
            y = 112.0 + np.random.random() * 6.0 - 3.0
            high_jitter_centers.append((x, y))
        
        score_high_jitter = geometry_fake_score(None, 15.0, eye_open_series=normal_eye_series, centers_xy=high_jitter_centers)
        
        # Low jitter pattern
        low_jitter_centers = []
        for i in range(20):
            x = 112.0 + np.random.random() * 0.2 - 0.1  # ±0.1 pixel jitter
            y = 112.0 + np.random.random() * 0.2 - 0.1
            low_jitter_centers.append((x, y))
        
        score_low_jitter = geometry_fake_score(None, 15.0, eye_open_series=normal_eye_series, centers_xy=low_jitter_centers)
        
        # Very low jitter should result in higher fake score
        assert 0.0 <= score_high_jitter <= 1.0
        assert 0.0 <= score_low_jitter <= 1.0
        assert score_low_jitter >= score_high_jitter  # Low jitter is more fake-like
    
    @pytest.mark.unit
    def test_geometry_fake_score_combined_weighting(self):
        """Test the combined weighting of eye and jitter components."""
        # Test case 1: Good eye variance, bad jitter
        good_eye_series = []
        for i in range(20):
            if i % 8 == 0:
                good_eye_series.append(0.1)
            else:
                good_eye_series.append(0.3 + 0.05 * np.random.random())
        
        bad_jitter_centers = [(112.0, 112.0)] * 20  # No movement at all
        
        score1 = geometry_fake_score(None, 15.0, eye_open_series=good_eye_series, centers_xy=bad_jitter_centers)
        
        # Test case 2: Bad eye variance, good jitter
        bad_eye_series = [0.3] * 20  # No blinking
        
        good_jitter_centers = []
        for i in range(20):
            x = 112.0 + np.random.random() * 2.0 - 1.0
            y = 112.0 + np.random.random() * 2.0 - 1.0
            good_jitter_centers.append((x, y))
        
        score2 = geometry_fake_score(None, 15.0, eye_open_series=bad_eye_series, centers_xy=good_jitter_centers)
        
        # Both should indicate some level of fake-ness
        assert 0.0 <= score1 <= 1.0
        assert 0.0 <= score2 <= 1.0
        assert score1 >= 0.3  # Bad jitter should contribute to fake score
        assert score2 >= 0.3  # Bad eye variance should contribute to fake score


class TestGeometryEdgeCases:
    """Test edge cases and error conditions for geometry analysis."""
    
    @pytest.mark.unit
    def test_geometry_numerical_stability(self):
        """Test numerical stability with edge case values."""
        # Very small eye variations
        small_eye_series = [0.3 + 1e-8 * i for i in range(20)]
        
        # Very small center variations
        small_centers = [(112.0 + 1e-6 * i, 112.0) for i in range(20)]
        
        score = geometry_fake_score(None, 15.0, eye_open_series=small_eye_series, centers_xy=small_centers)
        
        assert 0.0 <= score <= 1.0
        assert not np.isnan(score)
        assert not np.isinf(score)
    
    @pytest.mark.unit
    def test_geometry_zero_variance_signals(self):
        """Test geometry with exactly zero variance signals."""
        # Perfect zero variance
        zero_eye_series = [0.3] * 25
        zero_centers = [(112.0, 112.0)] * 25
        
        score = geometry_fake_score(None, 15.0, eye_open_series=zero_eye_series, centers_xy=zero_centers)
        
        # Should handle zero variance gracefully and indicate fake
        assert 0.0 <= score <= 1.0
        assert score >= 0.8  # Should strongly indicate fake
    
    @pytest.mark.unit
    def test_geometry_all_none_eye_values(self):
        """Test geometry with all None eye values."""
        all_none_eyes = [None] * 20
        normal_centers = [(112.0 + i * 0.1, 112.0) for i in range(20)]
        
        score = geometry_fake_score(None, 15.0, eye_open_series=all_none_eyes, centers_xy=normal_centers)
        
        # Should handle all None values and convert them to 0.0
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_geometry_mixed_data_types(self):
        """Test geometry with mixed data types in inputs."""
        # Mix of int and float values
        mixed_eye_series = [0.3, 1, 0.25, 2, 0.3] + [0.3] * 15
        mixed_centers = [(112, 112.0), (112.5, 112), (112.0, 112.0)] * 7  # Mix int/float coords
        
        score = geometry_fake_score(None, 15.0, eye_open_series=mixed_eye_series, centers_xy=mixed_centers[:20])
        
        # Should handle mixed types gracefully
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_geometry_very_high_fps(self):
        """Test geometry with very high frame rates."""
        eye_series = [0.3 + 0.01 * np.sin(i * 0.1) for i in range(15)]
        centers = [(112.0 + 0.1 * i, 112.0) for i in range(15)]
        
        # Test with very high FPS
        score = geometry_fake_score(None, 120.0, eye_open_series=eye_series, centers_xy=centers)
        
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_geometry_very_low_fps(self):
        """Test geometry with very low frame rates."""
        eye_series = [0.3 + 0.01 * np.sin(i * 0.1) for i in range(15)]
        centers = [(112.0 + 0.1 * i, 112.0) for i in range(15)]
        
        # Test with very low FPS
        score = geometry_fake_score(None, 1.0, eye_open_series=eye_series, centers_xy=centers)
        
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.unit
    def test_geometry_nan_inf_in_coordinates(self):
        """Test geometry handling of NaN and Inf in coordinates."""
        normal_eye_series = [0.3] * 20
        
        # Centers with NaN and Inf values
        problematic_centers = [
            (112.0, 112.0),
            (np.nan, 112.0),
            (112.0, np.inf),
            (np.nan, np.nan)
        ] + [(112.0, 112.0)] * 16
        
        score = geometry_fake_score(None, 15.0, eye_open_series=normal_eye_series, centers_xy=problematic_centers)
        
        # Should handle NaN/Inf gracefully
        assert 0.0 <= score <= 1.0 or np.isnan(score)
        assert not np.isinf(score)


class TestGeometryIntegration:
    """Integration tests for geometry analysis."""
    
    @pytest.mark.integration
    def test_geometry_performance(self):
        """Test geometry analysis performance with longer sequences."""
        import time
        
        # Create longer sequences (5 seconds at 30 fps = 150 frames)
        eye_open_series = []
        for i in range(150):
            if i % 45 == 0:  # Blink every 1.5 seconds
                eye_open_series.append(0.1)
            else:
                eye_open_series.append(0.3 + 0.05 * np.random.random())
        
        centers_xy = []
        for i in range(150):
            x = 112.0 + 2.0 * np.sin(i * 0.02) + np.random.random() * 0.5
            y = 112.0 + 1.0 * np.cos(i * 0.03) + np.random.random() * 0.5
            centers_xy.append((x, y))
        
        start_time = time.time()
        score = geometry_fake_score(None, 30.0, eye_open_series=eye_open_series, centers_xy=centers_xy)
        end_time = time.time()
        
        # Should complete within reasonable time (0.1 seconds for 150 frames)
        assert end_time - start_time < 0.1
        assert 0.0 <= score <= 1.0
    
    @pytest.mark.integration
    def test_geometry_memory_usage(self):
        """Test geometry analysis memory usage."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss
        
        # Process multiple long sequences
        for _ in range(20):
            eye_series = [0.3 + 0.02 * np.random.random() for _ in range(100)]
            centers = [(112.0 + np.random.random(), 112.0 + np.random.random()) for _ in range(100)]
            
            score = geometry_fake_score(None, 15.0, eye_open_series=eye_series, centers_xy=centers)
            assert 0.0 <= score <= 1.0
        
        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory
        
        # Should not use more than 10MB additional memory
        assert memory_increase < 10 * 1024 * 1024
    
    @pytest.mark.integration
    def test_geometry_robustness_scenarios(self):
        """Test geometry robustness with various realistic scenarios."""
        
        scenarios = [
            # (description, eye_pattern, movement_pattern, expected_fake_range)
            ("natural_human", "natural_blink", "natural_movement", (0.0, 0.5)),
            ("no_blinking", "no_blink", "natural_movement", (0.5, 1.0)),
            ("over_stabilized", "natural_blink", "no_movement", (0.5, 1.0)),
            ("synthetic_perfect", "no_blink", "no_movement", (0.7, 1.0)),
        ]
        
        for description, eye_pattern, movement_pattern, expected_range in scenarios:
            # Generate eye patterns
            if eye_pattern == "natural_blink":
                eye_series = []
                for i in range(30):
                    if i % 20 == 0 or i % 20 == 1:  # Blink for 2 frames every 20
                        eye_series.append(0.1)
                    else:
                        eye_series.append(0.25 + 0.1 * np.random.random())
            else:  # no_blink
                eye_series = [0.3] * 30
            
            # Generate movement patterns
            if movement_pattern == "natural_movement":
                centers = []
                for i in range(30):
                    x = 112.0 + np.random.random() * 2.0 - 1.0
                    y = 112.0 + np.random.random() * 2.0 - 1.0
                    centers.append((x, y))
            else:  # no_movement
                centers = [(112.0, 112.0)] * 30
            
            score = geometry_fake_score(None, 15.0, eye_open_series=eye_series, centers_xy=centers)
            
            assert 0.0 <= score <= 1.0, f"Invalid score for {description}"
            assert expected_range[0] <= score <= expected_range[1], \
                f"Score {score} not in expected range {expected_range} for {description}"
