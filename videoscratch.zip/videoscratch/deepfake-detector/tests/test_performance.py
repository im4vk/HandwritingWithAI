"""Tests for performance optimization module."""

import pytest
import tempfile
import time
import gc
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import numpy as np

from deepfake_detector.performance import (
    PerformanceConfig,
    PerformanceOptimizer,
    CacheManager,
    CacheKey,
    CacheItem,
    MemoryCache,
    DiskCache,
    StreamingProcessor,
    MemoryManager,
    ProcessingMode,
    cached,
    estimate_memory_requirements,
    optimize_opencv_performance
)


class TestCacheKey:
    """Test CacheKey class."""
    
    def test_create_cache_key(self):
        """Test creating a cache key."""
        key = CacheKey(
            file_path="test.mp4",
            algorithm="frequency",
            parameters_hash="abc123",
            file_mtime=1234567890.0,
            file_size=1024
        )
        
        assert key.file_path == "test.mp4"
        assert key.algorithm == "frequency"
        assert key.parameters_hash == "abc123"
        assert len(key.hash) == 16
        assert str(key) == key.hash
    
    def test_cache_key_equality(self):
        """Test cache key equality."""
        key1 = CacheKey("test.mp4", "freq", "abc", 123.0, 1024)
        key2 = CacheKey("test.mp4", "freq", "abc", 123.0, 1024)
        key3 = CacheKey("test.mp4", "freq", "def", 123.0, 1024)
        
        assert key1 == key2
        assert key1 != key3
        assert hash(key1) == hash(key2)
        assert hash(key1) != hash(key3)


class TestMemoryCache:
    """Test MemoryCache class."""
    
    def setup_method(self):
        """Set up test cache."""
        self.cache = MemoryCache(max_size=3, ttl_seconds=60)
    
    def test_put_and_get(self):
        """Test putting and getting items."""
        key = CacheKey("test.mp4", "freq", "abc", 123.0, 1024)
        value = {"score": 0.8}
        
        self.cache.put(key, value)
        retrieved = self.cache.get(key)
        
        assert retrieved == value
        assert self.cache.hits == 1
        assert self.cache.misses == 0
    
    def test_cache_miss(self):
        """Test cache miss."""
        key = CacheKey("nonexistent.mp4", "freq", "abc", 123.0, 1024)
        
        result = self.cache.get(key)
        
        assert result is None
        assert self.cache.hits == 0
        assert self.cache.misses == 1
    
    def test_ttl_expiration(self):
        """Test TTL expiration."""
        cache = MemoryCache(max_size=10, ttl_seconds=0.1)  # Very short TTL
        key = CacheKey("test.mp4", "freq", "abc", 123.0, 1024)
        
        cache.put(key, {"score": 0.8})
        
        # Should work immediately
        assert cache.get(key) is not None
        
        # Should expire after TTL
        time.sleep(0.2)
        assert cache.get(key) is None
    
    def test_lru_eviction(self):
        """Test LRU eviction."""
        # Fill cache to capacity
        for i in range(3):
            key = CacheKey(f"test{i}.mp4", "freq", "abc", 123.0, 1024)
            self.cache.put(key, {"score": 0.8})
        
        # Add one more item, should evict first
        key4 = CacheKey("test4.mp4", "freq", "abc", 123.0, 1024)
        self.cache.put(key4, {"score": 0.9})
        
        # First item should be evicted
        key0 = CacheKey("test0.mp4", "freq", "abc", 123.0, 1024)
        assert self.cache.get(key0) is None
        assert self.cache.evictions == 1
    
    def test_cache_stats(self):
        """Test cache statistics."""
        key = CacheKey("test.mp4", "freq", "abc", 123.0, 1024)
        self.cache.put(key, {"score": 0.8})
        self.cache.get(key)  # hit
        self.cache.get(CacheKey("missing.mp4", "freq", "abc", 123.0, 1024))  # miss
        
        stats = self.cache.get_stats()
        
        assert stats["size"] == 1
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate"] == 0.5


class TestDiskCache:
    """Test DiskCache class."""
    
    def test_put_and_get(self):
        """Test disk cache operations."""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = DiskCache(Path(temp_dir), max_size_mb=10)
            key = CacheKey("test.mp4", "freq", "abc", 123.0, 1024)
            value = {"score": 0.8, "data": list(range(100))}
            
            cache.put(key, value)
            retrieved = cache.get(key)
            
            assert retrieved == value
    
    def test_file_not_found(self):
        """Test handling of missing cache files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            cache = DiskCache(Path(temp_dir), max_size_mb=10)
            key = CacheKey("missing.mp4", "freq", "abc", 123.0, 1024)
            
            result = cache.get(key)
            assert result is None


class TestCacheManager:
    """Test CacheManager class."""
    
    def test_cache_hierarchy(self):
        """Test cache hierarchy (memory -> disk)."""
        config = PerformanceConfig(
            enable_caching=True,
            memory_cache_size=2,
            disk_cache_size_mb=10
        )
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config.disk_cache_dir = Path(temp_dir)
            manager = CacheManager(config)
            
            # Create cache key
            key = manager.create_key(
                Path("test.mp4"), 
                "frequency", 
                {"param1": "value1"}
            )
            
            # Put and get from cache
            manager.put(key, {"score": 0.8})
            result = manager.get(key)
            
            assert result == {"score": 0.8}
    
    def test_create_cache_key(self):
        """Test cache key creation."""
        config = PerformanceConfig()
        manager = CacheManager(config)
        
        # Create temporary file
        with tempfile.NamedTemporaryFile() as temp_file:
            path = Path(temp_file.name)
            
            key = manager.create_key(path, "frequency", {"fps": 30})
            
            assert key.file_path == str(path)
            assert key.algorithm == "frequency"
            assert key.file_size > 0
            assert key.file_mtime > 0
    
    def test_disabled_caching(self):
        """Test disabled caching."""
        config = PerformanceConfig(enable_caching=False)
        manager = CacheManager(config)
        
        key = manager.create_key(Path("test.mp4"), "freq", {})
        manager.put(key, {"score": 0.8})
        result = manager.get(key)
        
        assert result is None


class TestStreamingProcessor:
    """Test StreamingProcessor class."""
    
    @patch('cv2.VideoCapture')
    def test_streaming_processing(self, mock_cv2_cap):
        """Test streaming video processing."""
        # Mock video capture
        mock_cap = Mock()
        mock_cap.isOpened.return_value = True
        mock_cap.get.side_effect = lambda prop: {
            0: 100,  # CAP_PROP_FRAME_COUNT
            5: 30.0  # CAP_PROP_FPS
        }.get(prop, 0)
        
        # Mock frames
        frames = [np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8) for _ in range(10)]
        mock_cap.read.side_effect = [(True, frame) for frame in frames] + [(False, None)]
        mock_cv2_cap.return_value = mock_cap
        
        config = PerformanceConfig(streaming_chunk_size=5)
        processor = StreamingProcessor(config)
        
        def mock_processor_func(chunk_data):
            return len(chunk_data['frames'])
        
        # Process video
        results = list(processor.process_video_streaming(
            Path("test.mp4"), 
            mock_processor_func
        ))
        
        assert len(results) >= 1
        assert all(isinstance(result[0], int) for result in results)  # chunk indices
    
    def test_aggregate_streaming_results(self):
        """Test aggregating streaming results."""
        config = PerformanceConfig()
        processor = StreamingProcessor(config)
        
        # Test numeric aggregation
        numeric_results = [(0, 0.8), (1, 0.9), (2, 0.7)]
        aggregated = processor.aggregate_streaming_results(numeric_results)
        assert abs(aggregated - 0.8) < 0.1  # Average of 0.8, 0.9, 0.7
        
        # Test dictionary aggregation
        dict_results = [
            (0, {"score": 0.8, "confidence": 0.9}),
            (1, {"score": 0.7, "confidence": 0.8})
        ]
        aggregated = processor.aggregate_streaming_results(dict_results)
        assert abs(aggregated["score"] - 0.75) < 0.01
        assert abs(aggregated["confidence"] - 0.85) < 0.01


class TestMemoryManager:
    """Test MemoryManager class."""
    
    def test_memory_usage_tracking(self):
        """Test memory usage tracking."""
        config = PerformanceConfig()
        manager = MemoryManager(config)
        
        usage = manager.get_memory_usage()
        
        assert "rss_mb" in usage
        assert "vms_mb" in usage
        assert "percent" in usage
        assert "available_mb" in usage
        assert all(isinstance(v, (int, float)) for v in usage.values())
    
    def test_garbage_collection(self):
        """Test garbage collection."""
        config = PerformanceConfig()
        manager = MemoryManager(config)
        
        # Create some objects to collect
        large_list = [list(range(1000)) for _ in range(100)]
        del large_list
        
        gc_stats = manager.force_garbage_collection()
        
        assert "objects_collected" in gc_stats
        assert "memory_freed_mb" in gc_stats
        assert isinstance(gc_stats["objects_collected"], int)


class TestPerformanceOptimizer:
    """Test PerformanceOptimizer class."""
    
    def setup_method(self):
        """Set up test optimizer."""
        self.config = PerformanceConfig(
            enable_caching=True,
            memory_cache_size=10
        )
        self.optimizer = PerformanceOptimizer(self.config)
    
    def test_cached_analysis(self):
        """Test cached analysis."""
        def mock_analysis(file_path):
            return {"score": 0.8, "processed": True}
        
        with tempfile.NamedTemporaryFile() as temp_file:
            path = Path(temp_file.name)
            
            # First call should execute function
            result1 = self.optimizer.cached_analysis(
                "test_algo", mock_analysis, path, {}
            )
            
            # Second call should hit cache
            result2 = self.optimizer.cached_analysis(
                "test_algo", mock_analysis, path, {}
            )
            
            assert result1 == result2
            assert result1 == {"score": 0.8, "processed": True}
    
    def test_parallel_analysis(self):
        """Test parallel analysis."""
        def mock_analysis1(file_path):
            time.sleep(0.01)  # Simulate work
            return 0.8
        
        def mock_analysis2(file_path):
            time.sleep(0.01)  # Simulate work
            return 0.9
        
        with tempfile.NamedTemporaryFile() as temp_file:
            path = Path(temp_file.name)
            
            tasks = [
                ("algo1", mock_analysis1, path, {}),
                ("algo2", mock_analysis2, path, {})
            ]
            
            results = self.optimizer.parallel_analysis(tasks)
            
            assert len(results) == 2
            assert results[0] == 0.8
            assert results[1] == 0.9
    
    @patch('cv2.VideoCapture')
    def test_optimize_for_file(self, mock_cv2_cap):
        """Test file optimization mode selection."""
        # Mock short video
        mock_cap = Mock()
        mock_cap.isOpened.return_value = True
        mock_cap.get.side_effect = lambda prop: {
            0: 100,  # CAP_PROP_FRAME_COUNT (short)
            5: 30.0  # CAP_PROP_FPS
        }.get(prop, 0)
        mock_cv2_cap.return_value = mock_cap
        
        mode = self.optimizer.optimize_for_file(Path("short.mp4"))
        assert mode in [ProcessingMode.BATCH, ProcessingMode.PARALLEL]
        
        mock_cap.release.assert_called_once()
    
    def test_performance_stats(self):
        """Test performance statistics."""
        stats = self.optimizer.get_performance_stats()
        
        assert "cache" in stats
        assert "memory" in stats
        assert "streaming" in stats
        assert "processing" in stats
        
        assert "hit_rate" in stats["cache"]
        assert "current_usage" in stats["memory"]


class TestCachedDecorator:
    """Test cached decorator."""
    
    def test_cached_function(self):
        """Test cached decorator functionality."""
        call_count = 0
        
        @cached("test_algorithm", {"param": "value"})
        def test_function(file_path, extra_param=None):
            nonlocal call_count
            call_count += 1
            return {"score": 0.8, "calls": call_count}
        
        with tempfile.NamedTemporaryFile() as temp_file:
            path = Path(temp_file.name)
            
            # First call
            result1 = test_function(path, extra_param="test")
            assert result1["calls"] == 1
            
            # Second call should use cache (but decorator creates new optimizer)
            result2 = test_function(path, extra_param="test")
            assert call_count == 2  # New optimizer each time without global state
    
    def test_cached_without_file_path(self):
        """Test cached decorator without file path."""
        @cached("test_algorithm")
        def test_function(data):
            return {"processed": data}
        
        result = test_function("test_data")
        assert result == {"processed": "test_data"}


class TestUtilityFunctions:
    """Test utility functions."""
    
    @patch('cv2.VideoCapture')
    def test_estimate_memory_requirements(self, mock_cv2_cap):
        """Test memory requirement estimation."""
        mock_cap = Mock()
        mock_cap.isOpened.return_value = True
        mock_cap.get.side_effect = lambda prop: {
            3: 1920,  # CAP_PROP_FRAME_WIDTH
            4: 1080,  # CAP_PROP_FRAME_HEIGHT
            5: 30.0,  # CAP_PROP_FPS
            0: 900    # CAP_PROP_FRAME_COUNT
        }.get(prop, 0)
        mock_cv2_cap.return_value = mock_cap
        
        estimates = estimate_memory_requirements(Path("test.mp4"))
        
        assert "single_frame_mb" in estimates
        assert "all_frames_mb" in estimates
        assert "streaming_chunk_mb" in estimates
        assert "recommended_ram_mb" in estimates
        
        # Verify calculations make sense
        assert estimates["single_frame_mb"] > 0
        assert estimates["all_frames_mb"] > estimates["single_frame_mb"]
        
        mock_cap.release.assert_called_once()
    
    def test_optimize_opencv_performance(self):
        """Test OpenCV optimization."""
        # This function should run without errors
        optimize_opencv_performance()
        # No assertions needed - just ensure it doesn't crash


class TestPerformanceConfig:
    """Test PerformanceConfig class."""
    
    def test_default_config(self):
        """Test default configuration values."""
        config = PerformanceConfig()
        
        assert config.enable_caching is True
        assert config.memory_cache_size > 0
        assert config.enable_parallel is False  # Conservative default
        assert config.enable_streaming is False
        assert config.enable_gpu is False
    
    def test_custom_config(self):
        """Test custom configuration."""
        config = PerformanceConfig(
            enable_caching=False,
            enable_parallel=True,
            max_workers=8,
            memory_threshold_mb=4000
        )
        
        assert config.enable_caching is False
        assert config.enable_parallel is True
        assert config.max_workers == 8
        assert config.memory_threshold_mb == 4000


if __name__ == "__main__":
    pytest.main([__file__])
