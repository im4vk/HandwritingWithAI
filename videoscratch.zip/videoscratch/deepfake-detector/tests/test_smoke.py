"""Smoke tests to verify basic functionality and test framework."""

import pytest
import numpy as np
from pathlib import Path
import sys

# Add src to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


@pytest.mark.unit
def test_imports_work():
    """Test that all main modules can be imported."""
    from deepfake_detector import face, frequency, rppg, avsync, geometry, fusion, cnn_detector
    
    # Verify modules are not None
    assert face is not None
    assert frequency is not None
    assert rppg is not None
    assert avsync is not None
    assert geometry is not None
    assert fusion is not None
    assert cnn_detector is not None


@pytest.mark.unit
def test_fixtures_work(sample_face_crop, sample_landmarks, sample_audio):
    """Test that pytest fixtures work correctly."""
    # Test face crop fixture
    assert sample_face_crop.shape == (224, 224, 3)
    assert sample_face_crop.dtype == np.uint8
    
    # Test landmarks fixture
    assert sample_landmarks.shape == (68, 2)
    assert sample_landmarks.dtype == np.float32
    
    # Test audio fixture
    audio, sr = sample_audio
    assert isinstance(audio, np.ndarray)
    assert sr == 16000
    assert audio.dtype == np.float32


@pytest.mark.unit
def test_fusion_basic():
    """Test basic fusion functionality."""
    from deepfake_detector.fusion import fuse_scores
    
    scores = {"freq": 0.5, "rppg": 0.5, "av": 0.5, "geom": 0.5}
    result = fuse_scores(scores)
    
    assert 0.0 <= result <= 1.0
    assert isinstance(result, float)


@pytest.mark.unit
def test_frequency_analysis_basic(sample_face_crops):
    """Test basic frequency analysis."""
    from deepfake_detector.frequency import frequency_fake_score
    
    score = frequency_fake_score(sample_face_crops)
    
    assert 0.0 <= score <= 1.0
    assert isinstance(score, float)


@pytest.mark.unit
def test_empty_input_handling():
    """Test handling of empty inputs."""
    from deepfake_detector.frequency import frequency_fake_score
    from deepfake_detector.rppg import rppg_fake_score
    from deepfake_detector.avsync import av_sync_fake_score
    
    # Test empty face crops
    score = frequency_fake_score([])
    assert score == 0.5
    
    # Test empty timestamps for rPPG
    score = rppg_fake_score([], [])
    assert score == 0.5
    
    # Test None audio for AV sync
    score = av_sync_fake_score(None, [], None, None)
    assert score == 0.5
