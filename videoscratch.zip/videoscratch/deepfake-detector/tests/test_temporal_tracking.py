"""Tests for temporal face tracking module."""

import pytest
import numpy as np
import time
from unittest.mock import Mock, patch

from deepfake_detector.temporal_tracking import (
    MotionVector,
    KalmanState,
    TrackedFace,
    TemporalFaceTracker,
    detect_face_track_temporal,
    analyze_face_tracking_quality
)
from deepfake_detector.face import FaceFrame, FaceTrack


class TestMotionVector:
    """Test MotionVector class."""
    
    def test_create_motion_vector(self):
        """Test creating a motion vector."""
        motion = MotionVector.from_displacement(3.0, 4.0, 0.8)
        
        assert motion.dx == 3.0
        assert motion.dy == 4.0
        assert abs(motion.magnitude - 5.0) < 0.001  # sqrt(3^2 + 4^2) = 5
        assert motion.confidence == 0.8
        assert abs(motion.angle - np.arctan2(4.0, 3.0)) < 0.001
    
    def test_zero_motion(self):
        """Test zero motion vector."""
        motion = MotionVector.from_displacement(0.0, 0.0)
        
        assert motion.magnitude == 0.0
        assert motion.angle == 0.0
        assert motion.confidence == 1.0
    
    def test_negative_displacement(self):
        """Test negative displacement."""
        motion = MotionVector.from_displacement(-1.0, -1.0)
        
        assert motion.dx == -1.0
        assert motion.dy == -1.0
        assert abs(motion.magnitude - np.sqrt(2)) < 0.001
        assert motion.angle < 0  # Negative quadrant


class TestKalmanState:
    """Test KalmanState class."""
    
    def test_initialization(self):
        """Test Kalman filter initialization."""
        kalman = KalmanState()
        
        assert kalman.state.shape == (4,)
        assert kalman.covariance.shape == (4, 4)
        assert kalman.F.shape == (4, 4)
        assert kalman.H.shape == (2, 4)
        assert kalman.Q.shape == (4, 4)
        assert kalman.R.shape == (2, 2)
    
    def test_predict(self):
        """Test position prediction."""
        kalman = KalmanState()
        kalman.state = np.array([100.0, 100.0, 5.0, 3.0])  # position (100,100), velocity (5,3)
        
        # Predict after 1 second
        x, y = kalman.predict(1.0)
        
        assert abs(x - 105.0) < 0.001  # 100 + 5*1
        assert abs(y - 103.0) < 0.001  # 100 + 3*1
    
    def test_update(self):
        """Test measurement update."""
        kalman = KalmanState()
        kalman.state = np.array([100.0, 100.0, 0.0, 0.0])
        
        # Update with measurement
        kalman.update(105.0, 103.0, time.time())
        
        # Position should move toward measurement
        assert kalman.state[0] > 100.0
        assert kalman.state[1] > 100.0
        assert kalman.last_update_time > 0
    
    def test_get_velocity(self):
        """Test velocity extraction."""
        kalman = KalmanState()
        kalman.state = np.array([100.0, 100.0, 5.0, -3.0])
        
        dx, dy = kalman.get_velocity()
        assert dx == 5.0
        assert dy == -3.0
    
    def test_position_uncertainty(self):
        """Test position uncertainty calculation."""
        kalman = KalmanState()
        uncertainty = kalman.get_position_uncertainty()
        
        assert uncertainty > 0
        assert isinstance(uncertainty, float)


class TestTrackedFace:
    """Test TrackedFace class."""
    
    def setup_method(self):
        """Set up test data."""
        self.tracked_face = TrackedFace(track_id=1)
        
        # Create sample face frames
        self.face_frame1 = FaceFrame(
            frame_index=0,
            box_xywh=[100, 100, 50, 50],
            landmarks_xy=None,
            face_crop=None,
            confidence=0.9,
            center_xy=(125, 125),
            mouth_open=None,
            eye_open=0.5
        )
        
        self.face_frame2 = FaceFrame(
            frame_index=1,
            box_xywh=[102, 103, 50, 50],
            landmarks_xy=None,
            face_crop=None,
            confidence=0.85,
            center_xy=(127, 128),
            mouth_open=None,
            eye_open=0.6
        )
    
    def test_add_detection(self):
        """Test adding face detections."""
        timestamp = time.time()
        
        self.tracked_face.add_detection(self.face_frame1, timestamp)
        
        assert len(self.tracked_face.frames) == 1
        assert self.tracked_face.total_detections == 1
        assert self.tracked_face.first_seen == timestamp
        assert self.tracked_face.last_seen == timestamp
    
    def test_motion_tracking(self):
        """Test motion vector computation."""
        timestamp1 = time.time()
        timestamp2 = timestamp1 + 1.0
        
        self.tracked_face.add_detection(self.face_frame1, timestamp1)
        self.tracked_face.add_detection(self.face_frame2, timestamp2)
        
        assert len(self.tracked_face.motion_history) == 1
        motion = self.tracked_face.motion_history[0]
        
        assert abs(motion.dx - 2.0) < 0.001  # 127 - 125
        assert abs(motion.dy - 3.0) < 0.001  # 128 - 125
    
    def test_predict_next_position(self):
        """Test position prediction."""
        timestamp1 = time.time()
        timestamp2 = timestamp1 + 1.0
        
        self.tracked_face.add_detection(self.face_frame1, timestamp1)
        self.tracked_face.add_detection(self.face_frame2, timestamp2)
        
        # Predict next position
        x, y = self.tracked_face.predict_next_position(timestamp2 + 1.0)
        
        # Should predict continued motion
        assert x > 127  # Moving right
        assert y > 128  # Moving down
    
    def test_tracking_confidence(self):
        """Test tracking confidence calculation."""
        timestamp = time.time()
        
        # Initially no confidence
        assert self.tracked_face.get_tracking_confidence() == 0.0
        
        # Add detection
        self.tracked_face.add_detection(self.face_frame1, timestamp)
        confidence = self.tracked_face.get_tracking_confidence()
        
        assert 0.0 <= confidence <= 1.0
        assert confidence > 0.0
    
    def test_interpolated_frame(self):
        """Test frame interpolation."""
        timestamp1 = time.time()
        timestamp2 = timestamp1 + 2.0
        
        # Add frames at indices 0 and 2
        frame_0 = FaceFrame(
            frame_index=0, box_xywh=[100, 100, 50, 50], landmarks_xy=None,
            face_crop=None, confidence=0.9, center_xy=(100, 100), mouth_open=None, eye_open=0.5
        )
        frame_2 = FaceFrame(
            frame_index=2, box_xywh=[120, 120, 50, 50], landmarks_xy=None,
            face_crop=None, confidence=0.8, center_xy=(120, 120), mouth_open=None, eye_open=0.5
        )
        
        self.tracked_face.add_detection(frame_0, timestamp1)
        self.tracked_face.add_detection(frame_2, timestamp2)
        
        # Interpolate frame at index 1
        interpolated = self.tracked_face.get_interpolated_frame(1, 3)
        
        assert interpolated is not None
        assert interpolated.frame_index == 1
        
        # Position should be interpolated
        x, y = interpolated.center_xy
        assert 100 < x < 120  # Between start and end
        assert 100 < y < 120
        
        # Confidence should be reduced
        assert interpolated.confidence < min(frame_0.confidence, frame_2.confidence)


class TestTemporalFaceTracker:
    """Test TemporalFaceTracker class."""
    
    def setup_method(self):
        """Set up test data."""
        self.tracker = TemporalFaceTracker(
            max_missing_frames=5,
            min_track_length=3,
            iou_threshold=0.5,
            max_tracks=3
        )
        
        # Create sample frames
        self.frames = []
        for i in range(5):
            frame = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
            self.frames.append(frame)
    
    @patch('deepfake_detector.temporal_tracking.TemporalFaceTracker._detect_faces_in_frame')
    def test_track_faces_in_video(self, mock_detect):
        """Test face tracking across video."""
        # Mock face detections
        mock_detections = [
            [FaceFrame(
                frame_index=i, box_xywh=[100+i*2, 100+i, 50, 50],
                landmarks_xy=None, face_crop=None, confidence=0.9,
                center_xy=(125+i*2, 125+i), mouth_open=None, eye_open=0.5
            )] for i in range(5)
        ]
        
        mock_detect.side_effect = mock_detections
        
        # Track faces
        timestamps = [float(i) for i in range(5)]
        tracks = self.tracker.track_faces_in_video(self.frames, timestamps)
        
        assert len(tracks) >= 1  # Should create at least one track
        assert mock_detect.call_count == 5
    
    @patch('deepfake_detector.temporal_tracking.TemporalFaceTracker._detect_faces_in_frame')
    def test_track_association(self, mock_detect):
        """Test face detection association."""
        # Create detections that move consistently
        detections_frame_0 = [FaceFrame(
            frame_index=0, box_xywh=[100, 100, 50, 50],
            landmarks_xy=None, face_crop=None, confidence=0.9,
            center_xy=(125, 125), mouth_open=None, eye_open=0.5
        )]
        
        detections_frame_1 = [FaceFrame(
            frame_index=1, box_xywh=[105, 105, 50, 50],
            landmarks_xy=None, face_crop=None, confidence=0.85,
            center_xy=(130, 130), mouth_open=None, eye_open=0.5
        )]
        
        mock_detect.side_effect = [detections_frame_0, detections_frame_1, [], [], []]
        
        # Track faces
        tracks = self.tracker.track_faces_in_video(self.frames[:2])
        
        # Should create one track with two detections
        valid_tracks = [t for t in tracks if len(t.frames) >= 2]
        assert len(valid_tracks) >= 1
        
        if valid_tracks:
            track = valid_tracks[0]
            assert len(track.frames) == 2
            assert track.frames[0].frame_index == 0
            assert track.frames[1].frame_index == 1
    
    def test_get_best_track(self):
        """Test best track selection."""
        # Create tracks with different qualities
        track1 = TrackedFace(track_id=1)
        track1.frames = [Mock() for _ in range(3)]  # Short track
        track1.average_confidence = 0.7
        track1.stability_score = 0.6
        
        track2 = TrackedFace(track_id=2)
        track2.frames = [Mock() for _ in range(10)]  # Long track
        track2.average_confidence = 0.9
        track2.stability_score = 0.8
        
        self.tracker.completed_tracks = [track1, track2]
        
        best_track = self.tracker.get_best_track()
        
        assert best_track is not None
        # Should prefer track2 due to higher quality and length
        assert best_track.track_id == 2
    
    @patch('deepfake_detector.temporal_tracking.TemporalFaceTracker.track_faces_in_video')
    def test_create_enhanced_face_track(self, mock_track):
        """Test enhanced face track creation."""
        # Mock tracking results
        tracked_face = TrackedFace(track_id=1)
        
        # Add frames with gaps
        frames = [
            FaceFrame(0, [100, 100, 50, 50], None, None, 0.9, (125, 125), None, 0.5),
            FaceFrame(2, [110, 110, 50, 50], None, None, 0.8, (135, 135), None, 0.5),
            FaceFrame(4, [120, 120, 50, 50], None, None, 0.85, (145, 145), None, 0.5)
        ]
        
        for i, frame in enumerate(frames):
            tracked_face.add_detection(frame, float(i))
        
        mock_track.return_value = [tracked_face]
        self.tracker.completed_tracks = [tracked_face]
        
        # Create enhanced track
        enhanced_track = self.tracker.create_enhanced_face_track(fill_gaps=True)
        
        assert enhanced_track is not None
        assert len(enhanced_track.frames) >= len(frames)  # Should have filled gaps


class TestIntegrationFunctions:
    """Test integration functions."""
    
    @patch('deepfake_detector.temporal_tracking.TemporalFaceTracker')
    def test_detect_face_track_temporal(self, mock_tracker_class):
        """Test temporal face track detection."""
        # Mock tracker
        mock_tracker = Mock()
        mock_enhanced_track = Mock(spec=FaceTrack)
        mock_enhanced_track.frames = [Mock() for _ in range(5)]
        
        mock_tracker.track_faces_in_video.return_value = [Mock()]
        mock_tracker.create_enhanced_face_track.return_value = mock_enhanced_track
        mock_tracker_class.return_value = mock_tracker
        
        # Create test frames
        frames = [np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8) for _ in range(3)]
        timestamps = [0.0, 1.0, 2.0]
        
        # Test function
        result = detect_face_track_temporal(frames, timestamps, fill_gaps=True)
        
        assert result is not None
        assert hasattr(result, 'frames')
        mock_tracker.track_faces_in_video.assert_called_once_with(frames, timestamps)
        mock_tracker.create_enhanced_face_track.assert_called_once_with(fill_gaps=True)
    
    def test_analyze_face_tracking_quality(self):
        """Test face tracking quality analysis."""
        # Create sample tracked faces
        tracked_faces = []
        
        for i in range(3):
            track = TrackedFace(track_id=i+1)
            track.frames = [Mock() for _ in range(5 + i*2)]  # Different lengths
            track.average_confidence = 0.8 + i*0.05
            track.stability_score = 0.7 + i*0.1
            track.motion_history = [Mock(magnitude=1.0 + i) for _ in range(3)]
            tracked_faces.append(track)
        
        # Analyze quality
        analysis = analyze_face_tracking_quality(tracked_faces)
        
        assert analysis["total_tracks"] == 3
        assert "track_statistics" in analysis
        assert "quality_metrics" in analysis
        assert "motion_analysis" in analysis
        assert "best_track" in analysis
        
        # Check statistics
        assert analysis["track_statistics"]["average_length"] > 0
        assert analysis["quality_metrics"]["average_confidence"] > 0
        assert analysis["best_track"]["track_id"] > 0
    
    def test_analyze_empty_tracking(self):
        """Test quality analysis with empty tracking results."""
        analysis = analyze_face_tracking_quality([])
        
        assert analysis["total_tracks"] == 0
        assert "error" in analysis


class TestTrackedFaceQualityMetrics:
    """Test TrackedFace quality metric calculations."""
    
    def test_quality_metrics_update(self):
        """Test quality metrics calculation."""
        tracked_face = TrackedFace(track_id=1)
        
        # Add consistent detections
        timestamps = [0.0, 1.0, 2.0, 3.0]
        centers = [(100, 100), (102, 101), (104, 102), (106, 103)]
        
        for i, (timestamp, center) in enumerate(zip(timestamps, centers)):
            frame = FaceFrame(
                frame_index=i, box_xywh=[center[0]-25, center[1]-25, 50, 50],
                landmarks_xy=None, face_crop=None, confidence=0.9 - i*0.01,
                center_xy=center, mouth_open=None, eye_open=0.5
            )
            tracked_face.add_detection(frame, timestamp)
        
        # Check metrics
        assert tracked_face.average_confidence > 0
        assert tracked_face.stability_score > 0
        assert tracked_face.motion_consistency >= 0
        
        # Should have motion history
        assert len(tracked_face.motion_history) == 3  # One less than frames
    
    def test_motion_consistency(self):
        """Test motion consistency calculation."""
        tracked_face = TrackedFace(track_id=1)
        
        # Add detections with consistent motion
        positions = [(100, 100), (105, 105), (110, 110), (115, 115)]  # Diagonal movement
        
        for i, pos in enumerate(positions):
            frame = FaceFrame(
                frame_index=i, box_xywh=[pos[0]-25, pos[1]-25, 50, 50],
                landmarks_xy=None, face_crop=None, confidence=0.9,
                center_xy=pos, mouth_open=None, eye_open=0.5
            )
            tracked_face.add_detection(frame, float(i))
        
        # Motion should be consistent (all vectors in same direction)
        assert len(tracked_face.motion_history) == 3
        
        # All motion vectors should have similar angles
        angles = [mv.angle for mv in tracked_face.motion_history]
        angle_variance = np.var(angles)
        assert angle_variance < 0.1  # Should be very consistent


if __name__ == "__main__":
    pytest.main([__file__])
