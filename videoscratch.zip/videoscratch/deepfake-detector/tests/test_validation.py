"""Tests for validation framework."""

import pytest
import tempfile
import csv
import json
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import numpy as np

from deepfake_detector.validation import (
    ValidationDataset,
    ValidationFramework,
    ValidationSample,
    ValidationResult,
    ValidationMetrics,
    DatasetType,
    LabelFormat,
    create_validation_dataset,
    quick_validate
)
from deepfake_detector.exceptions import InputValidationError, ProcessingError


class TestValidationSample:
    """Test ValidationSample class."""
    
    def test_create_valid_sample(self):
        """Test creating a valid validation sample."""
        sample = ValidationSample(
            file_path=Path("test.mp4"),
            ground_truth=1.0,
            metadata={"quality": "high"}
        )
        
        assert sample.file_path == Path("test.mp4")
        assert sample.ground_truth == 1.0
        assert sample.metadata["quality"] == "high"
    
    def test_invalid_ground_truth(self):
        """Test validation sample with invalid ground truth."""
        with pytest.raises(InputValidationError):
            ValidationSample(file_path=Path("test.mp4"), ground_truth=1.5)
        
        with pytest.raises(InputValidationError):
            ValidationSample(file_path=Path("test.mp4"), ground_truth=-0.5)
    
    def test_path_conversion(self):
        """Test automatic path conversion."""
        sample = ValidationSample(file_path="test.mp4", ground_truth=0.0)
        assert isinstance(sample.file_path, Path)
        assert sample.file_path == Path("test.mp4")


class TestValidationDataset:
    """Test ValidationDataset class."""
    
    def test_create_dataset(self):
        """Test creating a validation dataset."""
        dataset = ValidationDataset("test_dataset", DatasetType.CUSTOM)
        
        assert dataset.name == "test_dataset"
        assert dataset.dataset_type == DatasetType.CUSTOM
        assert len(dataset.samples) == 0
    
    def test_add_sample(self):
        """Test adding samples to dataset."""
        dataset = ValidationDataset("test_dataset")
        
        dataset.add_sample(Path("real.mp4"), 0.0, {"type": "real"})
        dataset.add_sample(Path("fake.mp4"), 1.0, {"type": "fake"})
        
        assert len(dataset.samples) == 2
        assert dataset.samples[0].ground_truth == 0.0
        assert dataset.samples[1].ground_truth == 1.0
    
    def test_load_from_csv(self):
        """Test loading dataset from CSV."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            writer = csv.writer(f)
            writer.writerow(["file_path", "label", "quality"])
            writer.writerow(["real1.mp4", "0", "high"])
            writer.writerow(["fake1.mp4", "1", "medium"])
            writer.writerow(["real2.mp4", "real", "low"])
            writer.writerow(["fake2.mp4", "fake", "high"])
            csv_path = Path(f.name)
        
        try:
            dataset = ValidationDataset("csv_test")
            
            # Test binary format
            dataset.load_from_csv(csv_path, label_format=LabelFormat.BINARY)
            assert len(dataset.samples) == 2  # Only first two rows are binary
            
            # Test string format
            dataset.load_from_csv(csv_path, label_format=LabelFormat.STRING)
            assert len(dataset.samples) == 4
            assert dataset.samples[2].ground_truth == 0.0  # "real"
            assert dataset.samples[3].ground_truth == 1.0  # "fake"
            
        finally:
            csv_path.unlink()
    
    def test_load_from_directory(self):
        """Test loading dataset from directory structure."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            # Create directory structure
            real_dir = temp_path / "real"
            fake_dir = temp_path / "fake"
            real_dir.mkdir()
            fake_dir.mkdir()
            
            # Create sample files
            (real_dir / "real1.mp4").touch()
            (real_dir / "real2.avi").touch()
            (fake_dir / "fake1.mp4").touch()
            (fake_dir / "fake2.mov").touch()
            (fake_dir / "ignore.txt").touch()  # Should be ignored
            
            dataset = ValidationDataset("dir_test")
            dataset.load_from_directory(real_dir, fake_dir)
            
            assert len(dataset.samples) == 4  # txt file ignored
            real_samples = [s for s in dataset.samples if s.ground_truth == 0.0]
            fake_samples = [s for s in dataset.samples if s.ground_truth == 1.0]
            
            assert len(real_samples) == 2
            assert len(fake_samples) == 2
    
    def test_filter_samples(self):
        """Test sample filtering."""
        dataset = ValidationDataset("filter_test")
        dataset.add_sample(Path("real1.mp4"), 0.0, {"quality": "high"})
        dataset.add_sample(Path("real2.mp4"), 0.0, {"quality": "low"})
        dataset.add_sample(Path("fake1.mp4"), 1.0, {"quality": "high"})
        dataset.add_sample(Path("fake2.mp4"), 1.0, {"quality": "low"})
        
        # Filter for high quality only
        high_quality = dataset.filter_samples(
            lambda s: s.metadata.get("quality") == "high"
        )
        
        assert len(high_quality.samples) == 2
        assert all(s.metadata["quality"] == "high" for s in high_quality.samples)
    
    def test_split_dataset(self):
        """Test dataset splitting."""
        dataset = ValidationDataset("split_test")
        
        # Add balanced samples
        for i in range(10):
            dataset.add_sample(Path(f"real{i}.mp4"), 0.0)
            dataset.add_sample(Path(f"fake{i}.mp4"), 1.0)
        
        train, val, test = dataset.split_dataset(
            train_ratio=0.6, val_ratio=0.2, test_ratio=0.2, stratify=True
        )
        
        assert len(train.samples) == 12  # 60% of 20
        assert len(val.samples) == 4    # 20% of 20
        assert len(test.samples) == 4   # 20% of 20
        
        # Check stratification
        for split in [train, val, test]:
            real_count = sum(1 for s in split.samples if s.ground_truth == 0.0)
            fake_count = len(split.samples) - real_count
            assert abs(real_count - fake_count) <= 1  # Balanced within 1
    
    def test_get_statistics(self):
        """Test dataset statistics."""
        dataset = ValidationDataset("stats_test")
        dataset.add_sample(Path("test1.mp4"), 0.0, {"source": "camera"})
        dataset.add_sample(Path("test2.avi"), 1.0, {"source": "generated"})
        dataset.add_sample(Path("test3.jpg"), 0.0, {"source": "camera"})
        
        stats = dataset.get_statistics()
        
        assert stats["total_samples"] == 3
        assert stats["real_samples"] == 2
        assert stats["fake_samples"] == 1
        assert stats["class_balance"] == 1/3
        assert ".mp4" in stats["file_extensions"]
        assert ".avi" in stats["file_extensions"]
        assert ".jpg" in stats["file_extensions"]
        assert "source" in stats["metadata_keys"]


class TestValidationFramework:
    """Test ValidationFramework class."""
    
    def setup_method(self):
        """Set up test data."""
        self.framework = ValidationFramework()
        
        # Mock the analyze_video function
        self.mock_analyze_video = Mock()
        self.framework.analyze_video = self.mock_analyze_video
        
        # Create test dataset
        self.test_dataset = ValidationDataset("test")
        for i in range(5):
            self.test_dataset.add_sample(Path(f"real{i}.mp4"), 0.0)
            self.test_dataset.add_sample(Path(f"fake{i}.mp4"), 1.0)
    
    def test_validate_single_sample_success(self):
        """Test successful validation of single sample."""
        sample = ValidationSample(Path("test.mp4"), 1.0)
        
        # Mock successful analysis
        mock_report = Mock()
        mock_report.final_probability = 0.8
        mock_report.scores = {"freq": 0.7, "cnn": 0.9}
        self.mock_analyze_video.return_value = mock_report
        
        result = self.framework._validate_single_sample(sample, timeout=10.0)
        
        assert result.success is True
        assert result.prediction == 0.8
        assert result.algorithm_scores == {"freq": 0.7, "cnn": 0.9}
        assert result.processing_time > 0
    
    def test_validate_single_sample_failure(self):
        """Test failed validation of single sample."""
        sample = ValidationSample(Path("nonexistent.mp4"), 1.0)
        
        # Mock file not found error
        self.mock_analyze_video.side_effect = FileNotFoundError("File not found")
        
        result = self.framework._validate_single_sample(sample, timeout=10.0)
        
        assert result.success is False
        assert result.prediction == 0.5  # Neutral prediction
        assert "not found" in result.error_message.lower()
    
    @patch('deepfake_detector.validation.ValidationFramework._validate_single_sample')
    def test_validate_dataset(self, mock_validate):
        """Test dataset validation."""
        # Mock validation results
        mock_results = []
        for i, sample in enumerate(self.test_dataset.samples):
            result = ValidationResult(
                sample=sample,
                prediction=0.8 if sample.ground_truth == 1.0 else 0.2,
                processing_time=1.0,
                success=True,
                algorithm_scores={"freq": 0.5, "cnn": 0.7}
            )
            mock_results.append(result)
        
        mock_validate.side_effect = mock_results
        
        metrics = self.framework.validate_dataset(self.test_dataset, max_workers=1)
        
        assert isinstance(metrics, ValidationMetrics)
        assert metrics.total_samples == 10
        assert metrics.successful_samples == 10
        assert metrics.accuracy > 0.8  # Should be high with good predictions
    
    def test_compute_validation_metrics(self):
        """Test validation metrics computation."""
        # Create test results with known predictions
        results = []
        ground_truths = [0, 0, 1, 1]
        predictions = [0.2, 0.8, 0.7, 0.9]  # One FP, one FN
        
        for i, (gt, pred) in enumerate(zip(ground_truths, predictions)):
            sample = ValidationSample(Path(f"test{i}.mp4"), gt)
            result = ValidationResult(
                sample=sample,
                prediction=pred,
                processing_time=1.0,
                success=True
            )
            results.append(result)
        
        metrics = self.framework._compute_validation_metrics(results, total_time=4.0)
        
        # With threshold 0.5: TP=2, TN=1, FP=1, FN=0
        # Accuracy = (2+1)/(2+1+1+0) = 3/4 = 0.75
        assert abs(metrics.accuracy - 0.75) < 0.01
        assert metrics.total_samples == 4
        assert metrics.successful_samples == 4
    
    def test_confusion_matrix_elements(self):
        """Test confusion matrix computation."""
        y_true = np.array([0, 0, 1, 1])
        y_pred = np.array([0, 1, 0, 1])
        
        tn, fp, fn, tp = self.framework._confusion_matrix_elements(y_true, y_pred)
        
        assert tn == 1  # Predicted 0, actual 0
        assert fp == 1  # Predicted 1, actual 0
        assert fn == 1  # Predicted 0, actual 1
        assert tp == 1  # Predicted 1, actual 1
    
    def test_compute_auc_roc(self):
        """Test ROC AUC computation."""
        # Perfect classifier
        y_true = np.array([0, 0, 1, 1])
        y_scores = np.array([0.1, 0.2, 0.8, 0.9])
        
        auc = self.framework._compute_auc_roc(y_true, y_scores)
        assert abs(auc - 1.0) < 0.01
        
        # Random classifier
        y_true = np.array([0, 1, 0, 1])
        y_scores = np.array([0.1, 0.2, 0.8, 0.9])
        
        auc = self.framework._compute_auc_roc(y_true, y_scores)
        assert abs(auc - 0.5) < 0.3  # Should be around 0.5
    
    def test_cross_validate(self):
        """Test cross-validation."""
        # Mock successful validation for each fold
        with patch.object(self.framework, 'validate_dataset') as mock_validate:
            mock_metrics = ValidationMetrics(
                accuracy=0.85, precision=0.8, recall=0.9, f1_score=0.85,
                auc_roc=0.9, auc_pr=0.85, optimal_threshold=0.5,
                true_positives=4, true_negatives=4, false_positives=1, false_negatives=1,
                specificity=0.8, sensitivity=0.9, balanced_accuracy=0.85, matthews_cc=0.7,
                total_samples=10, successful_samples=10, average_processing_time=1.0,
                samples_per_second=10.0, error_rate=0.0, errors_by_type={}
            )
            mock_validate.return_value = mock_metrics
            
            cv_results = self.framework.cross_validate(self.test_dataset, k_folds=3)
            
            assert cv_results["k_folds"] == 3
            assert cv_results["total_samples"] == 10
            assert "accuracy_mean" in cv_results["metrics"]
            assert "accuracy_std" in cv_results["metrics"]
            assert len(cv_results["fold_results"]) == 3
    
    def test_save_validation_report(self):
        """Test saving validation report."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            report_path = Path(f.name)
        
        try:
            metrics = ValidationMetrics(
                accuracy=0.85, precision=0.8, recall=0.9, f1_score=0.85,
                auc_roc=0.9, auc_pr=0.85, optimal_threshold=0.5,
                true_positives=4, true_negatives=4, false_positives=1, false_negatives=1,
                specificity=0.8, sensitivity=0.9, balanced_accuracy=0.85, matthews_cc=0.7,
                total_samples=10, successful_samples=10, average_processing_time=1.0,
                samples_per_second=10.0, error_rate=0.0, errors_by_type={}
            )
            
            self.framework.save_validation_report(
                metrics, self.test_dataset, report_path
            )
            
            # Verify report was saved
            assert report_path.exists()
            
            with open(report_path, 'r') as f:
                report = json.load(f)
            
            assert "validation_summary" in report
            assert "accuracy_metrics" in report
            assert "confusion_matrix" in report
            assert report["accuracy_metrics"]["accuracy"] == 0.85
            
        finally:
            if report_path.exists():
                report_path.unlink()


class TestConvenienceFunctions:
    """Test convenience functions."""
    
    def test_create_validation_dataset_csv(self):
        """Test creating dataset from CSV."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            writer = csv.writer(f)
            writer.writerow(["file_path", "label"])
            writer.writerow(["real1.mp4", "0"])
            writer.writerow(["fake1.mp4", "1"])
            csv_path = Path(f.name)
        
        try:
            dataset = create_validation_dataset("test", csv_path=csv_path)
            assert len(dataset.samples) == 2
            assert dataset.name == "test"
        finally:
            csv_path.unlink()
    
    def test_create_validation_dataset_directories(self):
        """Test creating dataset from directories."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            real_dir = temp_path / "real"
            fake_dir = temp_path / "fake"
            real_dir.mkdir()
            fake_dir.mkdir()
            
            (real_dir / "real1.mp4").touch()
            (fake_dir / "fake1.mp4").touch()
            
            dataset = create_validation_dataset(
                "test", real_dir=real_dir, fake_dir=fake_dir
            )
            assert len(dataset.samples) == 2
    
    def test_create_validation_dataset_invalid(self):
        """Test creating dataset with invalid parameters."""
        with pytest.raises(InputValidationError):
            create_validation_dataset("test")  # No sources provided
    
    @patch('deepfake_detector.validation.ValidationFramework')
    def test_quick_validate(self, mock_framework_class):
        """Test quick validation function."""
        # Mock the framework and its methods
        mock_framework = Mock()
        mock_metrics = ValidationMetrics(
            accuracy=0.85, precision=0.8, recall=0.9, f1_score=0.85,
            auc_roc=0.9, auc_pr=0.85, optimal_threshold=0.5,
            true_positives=4, true_negatives=4, false_positives=1, false_negatives=1,
            specificity=0.8, sensitivity=0.9, balanced_accuracy=0.85, matthews_cc=0.7,
            total_samples=10, successful_samples=10, average_processing_time=1.0,
            samples_per_second=10.0, error_rate=0.0, errors_by_type={}
        )
        mock_framework.validate_dataset.return_value = mock_metrics
        mock_framework_class.return_value = mock_framework
        
        file_list = [
            (Path("real1.mp4"), 0.0),
            (Path("fake1.mp4"), 1.0)
        ]
        
        metrics = quick_validate(file_list)
        
        assert isinstance(metrics, ValidationMetrics)
        mock_framework.validate_dataset.assert_called_once()


class TestValidationMetrics:
    """Test ValidationMetrics dataclass."""
    
    def test_create_metrics(self):
        """Test creating validation metrics."""
        metrics = ValidationMetrics(
            accuracy=0.85, precision=0.8, recall=0.9, f1_score=0.85,
            auc_roc=0.9, auc_pr=0.85, optimal_threshold=0.5,
            true_positives=4, true_negatives=4, false_positives=1, false_negatives=1,
            specificity=0.8, sensitivity=0.9, balanced_accuracy=0.85, matthews_cc=0.7,
            total_samples=10, successful_samples=10, average_processing_time=1.0,
            samples_per_second=10.0, error_rate=0.0, errors_by_type={}
        )
        
        assert metrics.accuracy == 0.85
        assert metrics.total_samples == 10
        assert metrics.error_rate == 0.0
        assert isinstance(metrics.errors_by_type, dict)


if __name__ == "__main__":
    pytest.main([__file__])
