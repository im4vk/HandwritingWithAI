# EternalBlue Defense & Mitigation Guide
## Comprehensive Protection Strategy

### Table of Contents
1. [Executive Summary](#executive-summary)
2. [Immediate Actions](#immediate-actions)
3. [Prevention Strategies](#prevention-strategies)
4. [Detection & Monitoring](#detection--monitoring)
5. [Incident Response](#incident-response)
6. [Network Hardening](#network-hardening)
7. [Host Hardening](#host-hardening)
8. [Validation & Testing](#validation--testing)

---

## Executive Summary

EternalBlue (CVE-2017-0144) remains a critical threat vector despite being patched in 2017. This guide provides comprehensive defense strategies to protect against EternalBlue and similar SMB-based attacks.

### Key Risk Factors
- **Unpatched Windows systems** (XP through Server 2012)
- **SMBv1 protocol enabled** on networks
- **Open port 445** to untrusted networks
- **Inadequate network segmentation**
- **Lack of monitoring** for SMB anomalies

---

## Immediate Actions

### 1. Emergency Patching Assessment
```bash
# PowerShell script to check patch status
Get-HotFix -Id KB4012212, KB4012217, KB4012215, KB4012213, KB4012214, KB4012216, KB4012220, KB4012218, KB4012219 | Format-Table -AutoSize

# Alternative registry check
Get-ItemProperty "HKLM:SOFTWARE\Microsoft\Windows NT\CurrentVersion\Hotfix\KB4012*"
```

### 2. SMBv1 Immediate Disable
```powershell
# Disable SMBv1 Server
Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force

# Disable SMBv1 Client
sc.exe config lanmanworkstation depend= bowser/mrxsmb20/nsi
sc.exe config mrxsmb10 start= disabled

# Remove SMBv1 feature (Windows 10/Server 2016+)
Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -Remove
```

### 3. Network Isolation
```bash
# Block SMB at firewall immediately
# Example iptables rules
iptables -A INPUT -p tcp --dport 445 -j DROP
iptables -A OUTPUT -p tcp --dport 445 -j DROP

# Windows Firewall
netsh advfirewall firewall add rule name="Block SMB Inbound" dir=in action=block protocol=tcp localport=445
netsh advfirewall firewall add rule name="Block SMB Outbound" dir=out action=block protocol=tcp remoteport=445
```

---

## Prevention Strategies

### 1. Patch Management Program

#### Automated Patching Pipeline
```yaml
# Example Azure DevOps pipeline for patch deployment
trigger: none
schedules:
- cron: "0 2 * * 2"  # Every Tuesday at 2 AM
  displayName: Weekly Patch Tuesday
  branches:
    include:
    - main

stages:
- stage: TestEnvironment
  jobs:
  - job: DeployPatches
    steps:
    - task: PowerShell@2
      inputs:
        targetType: 'inline'
        script: |
          # Install Windows Updates
          Install-Module PSWindowsUpdate -Force
          Get-WindowsUpdate -AcceptAll -AutoReboot
```

#### Patch Verification Script
```powershell
# patch_verification.ps1
function Test-MS17010Patch {
    $kb_numbers = @("KB4012212", "KB4012217", "KB4012215", "KB4012213", "KB4012214", "KB4012216", "KB4012220", "KB4012218", "KB4012219")
    
    $installed_patches = Get-HotFix | Select-Object -ExpandProperty HotFixID
    $missing_patches = @()
    
    foreach ($kb in $kb_numbers) {
        if ($kb -notin $installed_patches) {
            $missing_patches += $kb
        }
    }
    
    if ($missing_patches.Count -eq 0) {
        Write-Host "✓ All MS17-010 patches installed" -ForegroundColor Green
        return $true
    } else {
        Write-Host "✗ Missing patches: $($missing_patches -join ', ')" -ForegroundColor Red
        return $false
    }
}

# SMBv1 Status Check
function Test-SMBv1Status {
    $smb1_server = Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSMB1Protocol
    $smb1_client = Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol | Select-Object -ExpandProperty State
    
    Write-Host "SMBv1 Server: $smb1_server" -ForegroundColor $(if($smb1_server) {"Red"} else {"Green"})
    Write-Host "SMBv1 Client: $smb1_client" -ForegroundColor $(if($smb1_client -eq "Enabled") {"Red"} else {"Green"})
}

# Run checks
Test-MS17010Patch
Test-SMBv1Status
```

### 2. Attack Surface Reduction

#### Group Policy Configuration
```xml
<!-- SMBv1 Disable GPO -->
<GroupPolicyObject>
    <Computer>
        <Policies>
            <Administrative Templates>
                <Windows Components>
                    <Network Provider>
                        <Hardened SMB Security>
                            <setting name="EnableSMB1" value="Disabled"/>
                            <setting name="RequireSMBSigning" value="Enabled"/>
                            <setting name="EnableSMBEncryption" value="Enabled"/>
                        </Hardened SMB Security>
                    </Network Provider>
                </Windows Components>
            </Administrative Templates>
        </Policies>
    </Computer>
</GroupPolicyObject>
```

#### Registry Hardening
```powershell
# Disable SMBv1 via registry
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SMB1" -Value 0 -PropertyType DWORD -Force

# Enable SMB signing
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "RequireSecuritySignature" -Value 1 -PropertyType DWORD -Force
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "RequireSecuritySignature" -Value 1 -PropertyType DWORD -Force
```

---

## Detection & Monitoring

### 1. Network Monitoring Setup

#### Zeek SMB Monitoring Configuration
```zeek
# /opt/zeek/share/zeek/site/local.zeek
@load policy/protocols/smb
@load frameworks/notice

# Custom SMB monitoring
@load ./eternalblue-detect.zeek

# Log all SMB activity
redef SMB::default_max_pending_messages = 100;
redef SMB::max_files_per_connection = 1000;

# Alert on SMBv1 usage
hook Notice::policy(n: Notice::Info) {
    if (n$note == EternalBlue::SMBv1_Negotiate) {
        # Send alert to SIEM
        system(fmt("logger -p local0.alert 'EternalBlue Alert: %s'", n$msg));
    }
}
```

#### Suricata Configuration
```yaml
# suricata.yaml additions
af-packet:
  - interface: eth0
    threads: auto
    cluster-id: 99
    cluster-type: cluster_flow

rule-files:
  - /etc/suricata/rules/eternalblue.rules
  - /etc/suricata/rules/emerging-exploit.rules

outputs:
  - eve-log:
      enabled: yes
      filetype: regular
      filename: eve.json
      types:
        - alert:
            tagged-packets: yes
        - smb:
            enabled: yes
```

### 2. Windows Event Monitoring

#### Advanced Audit Configuration
```powershell
# Enable detailed SMB logging
auditpol /set /subcategory:"File Share" /success:enable /failure:enable
auditpol /set /subcategory:"Other Object Access Events" /success:enable /failure:enable

# Enable SMB client auditing
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "AuditBaseHandles" -Value 1 -PropertyType DWORD -Force
```

#### Sysmon Configuration for EternalBlue
```xml
<Sysmon schemaversion="4.82">
  <EventFiltering>
    <!-- Network connections to SMB -->
    <NetworkConnect onmatch="include">
      <DestinationPort>445</DestinationPort>
    </NetworkConnect>
    
    <!-- Process creation from services.exe (DoublePulsar indicator) -->
    <ProcessCreate onmatch="include">
      <ParentImage>C:\Windows\System32\services.exe</ParentImage>
    </ProcessCreate>
    
    <!-- File creation in system directories -->
    <FileCreate onmatch="include">
      <TargetFilename>C:\Windows\System32\*.dll</TargetFilename>
    </FileCreate>
  </EventFiltering>
</Sysmon>
```

### 3. SIEM Integration

#### Splunk Detection Dashboards
```spl
# EternalBlue Detection Dashboard

# Panel 1: SMBv1 Usage Trends
index=network sourcetype=zeek_smb 
| eval smb_version=if(match(version, "1\."), "SMBv1", "SMBv2+")
| timechart span=1h count by smb_version

# Panel 2: Suspicious SMB Transaction Sizes
index=network sourcetype=zeek_conn service=smb 
| where resp_bytes > 4000 OR orig_bytes > 4000
| eval size_category=case(
    resp_bytes > 10000 OR orig_bytes > 10000, "Very Large",
    resp_bytes > 4000 OR orig_bytes > 4000, "Large",
    1==1, "Normal"
)
| stats count by size_category, id.orig_h

# Panel 3: Top SMB Connection Sources
index=network sourcetype=zeek_conn service=smb 
| stats count by id.orig_h 
| sort -count 
| head 20
```

#### Elastic Stack Queries
```json
{
  "query": {
    "bool": {
      "must": [
        {"term": {"destination.port": 445}},
        {"range": {"network.bytes": {"gte": 4000}}},
        {"term": {"network.protocol": "smb"}}
      ],
      "filter": [
        {"range": {"@timestamp": {"gte": "now-1h"}}}
      ]
    }
  },
  "aggs": {
    "source_ips": {
      "terms": {"field": "source.ip", "size": 10}
    }
  }
}
```

---

## Incident Response

### 1. EternalBlue Incident Response Playbook

#### Phase 1: Detection & Initial Response
```bash
#!/bin/bash
# incident_response.sh - EternalBlue Response Script

echo "=== EternalBlue Incident Response ==="

# 1. Isolate affected systems
echo "Step 1: Network Isolation"
read -p "Affected IP address: " AFFECTED_IP
iptables -A INPUT -s $AFFECTED_IP -j DROP
iptables -A OUTPUT -d $AFFECTED_IP -j DROP

# 2. Preserve evidence
echo "Step 2: Evidence Collection"
INCIDENT_DIR="/tmp/incident_$(date +%Y%m%d_%H%M%S)"
mkdir -p $INCIDENT_DIR

# Collect network connections
netstat -an > $INCIDENT_DIR/netstat.txt
ss -tulpn > $INCIDENT_DIR/ss.txt

# Collect process information
ps aux > $INCIDENT_DIR/processes.txt
lsof -i :445 > $INCIDENT_DIR/smb_connections.txt

# 3. Memory dump (if tools available)
if command -v volatility &> /dev/null; then
    echo "Collecting memory dump..."
    volatility -f /dev/mem imageinfo > $INCIDENT_DIR/memory_info.txt
fi

echo "Evidence collected in: $INCIDENT_DIR"
```

#### Phase 2: Analysis & Containment
```powershell
# Windows Incident Response Script
# eternalblue_response.ps1

param(
    [string]$AffectedSystem,
    [string]$OutputDir = "C:\Incident_Response"
)

# Create incident directory
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$incidentDir = "$OutputDir\EternalBlue_$timestamp"
New-Item -ItemType Directory -Path $incidentDir -Force

# Collect system information
Get-ComputerInfo > "$incidentDir\system_info.txt"
Get-Process > "$incidentDir\processes.txt"
Get-NetTCPConnection -State Established | Where-Object {$_.LocalPort -eq 445 -or $_.RemotePort -eq 445} > "$incidentDir\smb_connections.txt"

# Check for DoublePulsar indicators
$services = Get-WmiObject -Class Win32_Service
$suspicious_services = $services | Where-Object {$_.PathName -like "*svcctl*"}
$suspicious_services > "$incidentDir\suspicious_services.txt"

# Collect event logs
$events = Get-WinEvent -FilterHashtable @{LogName='Security'; ID=4624,4625,4648} -MaxEvents 1000
$events > "$incidentDir\security_events.txt"

# Registry analysis
$smb_config = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
$smb_config > "$incidentDir\smb_registry.txt"

Write-Host "Incident response data collected in: $incidentDir"
```

### 2. Forensic Analysis

#### Memory Analysis with Volatility
```bash
# Volatility analysis for EternalBlue indicators
volatility -f memory.dump --profile=Win7SP1x64 pslist
volatility -f memory.dump --profile=Win7SP1x64 netscan | grep ":445"
volatility -f memory.dump --profile=Win7SP1x64 malfind
volatility -f memory.dump --profile=Win7SP1x64 ldrmodules | grep srv.sys
```

#### Registry Forensics
```powershell
# Check for persistence mechanisms
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" | Format-List
Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\*" | Where-Object {$_.ImagePath -like "*svcctl*"}

# Check SMB configuration changes
Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" | Format-List
```

---

## Network Hardening

### 1. Firewall Configuration

#### pfSense Rules
```php
# pfSense rule configuration
# Block SMB from WAN
pass out on $wan_if inet proto tcp from any to any port 445 keep state label "BLOCK_SMB_WAN"
block in on $wan_if inet proto tcp from any to any port 445 label "BLOCK_SMB_WAN_IN"

# Allow SMB only on specific LAN segments
pass in on $lan_if inet proto tcp from 192.168.10.0/24 to 192.168.20.0/24 port 445 keep state label "ALLOW_SMB_INTERNAL"
```

#### Cisco ASA Configuration
```cisco
! Block SMB traffic from external networks
access-list OUTSIDE_IN deny tcp any any eq 445
access-list OUTSIDE_IN deny udp any any eq 445

! Allow SMB only between specific internal subnets
access-list INSIDE_IN permit tcp 192.168.10.0 255.255.255.0 192.168.20.0 255.255.255.0 eq 445
access-list INSIDE_IN deny tcp any any eq 445
```

### 2. Network Segmentation

#### VLAN Configuration
```cisco
! Create isolated VLANs for different security zones
vlan 10
 name SERVERS
vlan 20
 name WORKSTATIONS
vlan 30
 name DMZ

! Configure inter-VLAN routing with ACLs
interface vlan 10
 ip address 192.168.10.1 255.255.255.0
 ip access-group SERVER_ACL in

ip access-list extended SERVER_ACL
 permit tcp 192.168.20.0 0.0.0.255 192.168.10.0 0.0.0.255 eq 445
 deny tcp any any eq 445
 permit ip any any
```

### 3. Monitoring Points

#### Network TAP Configuration
```yaml
# ntopng configuration for SMB monitoring
ntopng:
  interfaces:
    - eth0
    - eth1
  http_port: 3000
  data_dir: /var/lib/ntopng
  local_networks: "192.168.0.0/16,10.0.0.0/8"
  
  # SMB-specific monitoring
  protocol_presets:
    smb:
      port: 445
      alert_threshold: 100  # packets per minute
      
security_monitoring:
  protocols:
    - name: smb
      ports: [445]
      alerts:
        - type: "version_downgrade"
          pattern: "SMB.*1\."
        - type: "large_transaction"
          size_threshold: 4000
```

---

## Host Hardening

### 1. Windows Hardening

#### Security Baseline Configuration
```powershell
# Apply Microsoft Security Baseline
# Download from: https://www.microsoft.com/en-us/download/details.aspx?id=55319

# Apply via PowerShell DSC
Configuration SecureWindows {
    param(
        [string[]]$ComputerName = 'localhost'
    )
    
    Import-DscResource -ModuleName SecurityPolicyDsc
    Import-DscResource -ModuleName AuditPolicyDsc
    
    Node $ComputerName {
        # Disable SMBv1
        Registry DisableSMBv1Server {
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
            ValueName = 'SMB1'
            ValueData = '0'
            ValueType = 'Dword'
        }
        
        # Enable SMB signing
        Registry EnableSMBSigning {
            Key = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
            ValueName = 'RequireSecuritySignature'
            ValueData = '1'
            ValueType = 'Dword'
        }
        
        # Configure audit policy
        AuditPolicySubcategory FileShare {
            Name = 'File Share'
            AuditFlag = 'Success'
            Ensure = 'Present'
        }
    }
}

# Apply configuration
SecureWindows -ComputerName $env:COMPUTERNAME
Start-DscConfiguration -Path .\SecureWindows -Wait -Verbose
```

#### Advanced Threat Protection
```powershell
# Enable Windows Defender Advanced Threat Protection
Set-MpPreference -DisableRealtimeMonitoring $false
Set-MpPreference -SubmitSamplesConsent SendAllSamples
Set-MpPreference -MAPSReporting Advanced

# Configure exploit protection
Set-ProcessMitigation -System -Enable DEP,SEHOP,ASLR,HighEntropy,StrictHandle
Set-ProcessMitigation -Name "services.exe" -Enable DEP,SEHOP,ASLR,HighEntropy

# Enable EMET/Exploit Guard
# (For older systems with EMET)
emet_conf.exe --import emet_config.xml
```

### 2. Linux Hardening (for Linux SMB servers)

#### Samba Security Configuration
```ini
# /etc/samba/smb.conf
[global]
# Disable SMBv1
min protocol = SMB2_02
max protocol = SMB3_11

# Enable signing
server signing = mandatory
client signing = mandatory

# Restrict access
hosts allow = 192.168.10.0/24 192.168.20.0/24
hosts deny = ALL

# Logging
log level = 2
log file = /var/log/samba/smbd.log
max log size = 1000

# Security enhancements
unix password sync = no
encrypt passwords = yes
passdb backend = tdbsam
```

---

## Validation & Testing

### 1. Vulnerability Assessment

#### Nessus Scan Configuration
```xml
<!-- EternalBlue specific scan policy -->
<Policy>
    <policyName>EternalBlue Assessment</policyName>
    <policyDescription>Comprehensive MS17-010 vulnerability scan</policyDescription>
    
    <PluginSelection>
        <PluginFamily name="Windows">
            <Plugin id="97737" status="enabled"/>  <!-- MS17-010 -->
            <Plugin id="97833" status="enabled"/>  <!-- SMBv1 detection -->
        </PluginFamily>
    </PluginSelection>
    
    <ServerPreferences>
        <preference name="port_range" value="1-65535"/>
        <preference name="consider_unscanned_ports_as_closed" value="yes"/>
    </ServerPreferences>
</Policy>
```

#### Custom Python Scanner
```python
#!/usr/bin/env python3
# ms17010_scanner.py - EternalBlue vulnerability scanner

import socket
import struct
import sys
from datetime import datetime

def check_ms17010(target_ip, port=445):
    """Check if target is vulnerable to MS17-010"""
    try:
        # Connect to SMB
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((target_ip, port))
        
        # SMBv1 negotiate request
        negotiate_packet = (
            b"\x00\x00\x00\x2f"  # NetBIOS Session Service
            b"\xff\x53\x4d\x42"  # SMB Header
            b"\x72\x00\x00\x00"  # Command: Negotiate Protocol
            b"\x00\x18\x01\x20"  # Flags
            b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
            b"\x00\x00\x00\x2f\x4b\x00"
            b"\x02\x4c\x41\x4e\x4d\x41\x4e\x31\x2e\x30\x00"  # LANMAN1.0
            b"\x02\x4c\x4d\x31\x2e\x32\x58\x30\x30\x32\x00"  # LM1.2X002
        )
        
        sock.send(negotiate_packet)
        response = sock.recv(1024)
        
        # Check for SMBv1 response
        if b"\xff\x53\x4d\x42" in response and response[9] == 0x72:
            print(f"[VULNERABLE] {target_ip} - SMBv1 enabled, potential MS17-010")
            return True
        else:
            print(f"[SAFE] {target_ip} - SMBv1 disabled or patched")
            return False
            
    except Exception as e:
        print(f"[ERROR] {target_ip} - {str(e)}")
        return False
    finally:
        sock.close()

def scan_network(network_range):
    """Scan network range for MS17-010 vulnerability"""
    import ipaddress
    
    network = ipaddress.IPv4Network(network_range, strict=False)
    vulnerable_hosts = []
    
    print(f"Scanning {network_range} for MS17-010 vulnerability...")
    print(f"Timestamp: {datetime.now()}")
    print("-" * 60)
    
    for ip in network.hosts():
        if check_ms17010(str(ip)):
            vulnerable_hosts.append(str(ip))
    
    print("\n" + "=" * 60)
    print(f"Scan complete. Found {len(vulnerable_hosts)} vulnerable hosts:")
    for host in vulnerable_hosts:
        print(f"  - {host}")
    
    return vulnerable_hosts

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 ms17010_scanner.py <network_range>")
        print("Example: python3 ms17010_scanner.py 192.168.1.0/24")
        sys.exit(1)
    
    scan_network(sys.argv[1])
```

### 2. Penetration Testing

#### Safe Testing Framework
```python
#!/usr/bin/env python3
# eternalblue_test_framework.py - Safe testing framework

class EternalBlueTestFramework:
    """Safe testing framework for EternalBlue defenses"""
    
    def __init__(self, target_network):
        self.target_network = target_network
        self.test_results = {}
    
    def test_smb_configuration(self):
        """Test SMB configuration security"""
        print("Testing SMB configuration...")
        
        tests = {
            'smbv1_disabled': self.check_smbv1_disabled,
            'smb_signing_enabled': self.check_smb_signing,
            'smb_encryption_enabled': self.check_smb_encryption,
            'patch_status': self.check_patch_status
        }
        
        for test_name, test_func in tests.items():
            result = test_func()
            self.test_results[test_name] = result
            print(f"  {test_name}: {'PASS' if result else 'FAIL'}")
    
    def test_network_controls(self):
        """Test network security controls"""
        print("Testing network controls...")
        
        # Test firewall rules
        # Test network segmentation
        # Test monitoring capabilities
        pass
    
    def generate_report(self):
        """Generate security assessment report"""
        print("\n" + "="*50)
        print("ETERNALBLUE SECURITY ASSESSMENT REPORT")
        print("="*50)
        
        for test, result in self.test_results.items():
            status = "✓ PASS" if result else "✗ FAIL"
            print(f"{test}: {status}")
        
        # Calculate overall score
        passed_tests = sum(self.test_results.values())
        total_tests = len(self.test_results)
        score = (passed_tests / total_tests) * 100
        
        print(f"\nOverall Security Score: {score:.1f}%")
        
        if score < 80:
            print("❌ CRITICAL: Immediate action required")
        elif score < 90:
            print("⚠️  WARNING: Security improvements needed")
        else:
            print("✅ GOOD: Security posture acceptable")
```

---

## Continuous Monitoring

### 1. Automated Health Checks

#### PowerShell Health Check Script
```powershell
# eternalblue_health_check.ps1
# Automated daily health check for EternalBlue defenses

param(
    [string]$LogPath = "C:\Logs\EternalBlue_HealthCheck.log",
    [switch]$EmailReport
)

function Write-LogEntry {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"
    Write-Host $logEntry
    Add-Content -Path $LogPath -Value $logEntry
}

function Test-PatchStatus {
    Write-LogEntry "Checking MS17-010 patch status..."
    $patches = @("KB4012212", "KB4012217", "KB4012215", "KB4012213", "KB4012214", "KB4012216", "KB4012220", "KB4012218", "KB4012219")
    
    $installed = Get-HotFix | Select-Object -ExpandProperty HotFixID
    $missing = $patches | Where-Object {$_ -notin $installed}
    
    if ($missing.Count -eq 0) {
        Write-LogEntry "✓ All MS17-010 patches installed" "SUCCESS"
        return $true
    } else {
        Write-LogEntry "✗ Missing patches: $($missing -join ', ')" "ERROR"
        return $false
    }
}

function Test-SMBv1Status {
    Write-LogEntry "Checking SMBv1 status..."
    
    try {
        $serverConfig = Get-SmbServerConfiguration -ErrorAction Stop
        $smbv1Enabled = $serverConfig.EnableSMB1Protocol
        
        if (-not $smbv1Enabled) {
            Write-LogEntry "✓ SMBv1 server disabled" "SUCCESS"
            return $true
        } else {
            Write-LogEntry "✗ SMBv1 server still enabled" "ERROR"
            return $false
        }
    } catch {
        Write-LogEntry "⚠ Could not determine SMBv1 status: $($_.Exception.Message)" "WARNING"
        return $false
    }
}

function Test-FirewallRules {
    Write-LogEntry "Checking Windows Firewall rules..."
    
    $smbRules = Get-NetFirewallRule | Where-Object {
        $_.DisplayName -like "*SMB*" -or 
        $_.DisplayName -like "*445*"
    }
    
    if ($smbRules.Count -gt 0) {
        Write-LogEntry "✓ SMB firewall rules configured" "SUCCESS"
        return $true
    } else {
        Write-LogEntry "⚠ No specific SMB firewall rules found" "WARNING"
        return $false
    }
}

function Send-HealthReport {
    param([hashtable]$Results)
    
    if (-not $EmailReport) { return }
    
    $passed = ($Results.Values | Where-Object {$_ -eq $true}).Count
    $total = $Results.Count
    $score = [math]::Round(($passed / $total) * 100, 1)
    
    $subject = "EternalBlue Health Check - Score: $score%"
    $body = @"
EternalBlue Defense Health Check Report
Generated: $(Get-Date)
Computer: $env:COMPUTERNAME

Results:
$(foreach ($test in $Results.GetEnumerator()) {
    $status = if ($test.Value) { "✓ PASS" } else { "✗ FAIL" }
    "  $($test.Key): $status"
})

Overall Score: $score% ($passed/$total tests passed)

$(if ($score -lt 80) { "❌ CRITICAL: Immediate action required" }
  elseif ($score -lt 90) { "⚠️ WARNING: Security improvements needed" }
  else { "✅ GOOD: Security posture acceptable" })
"@

    # Send email (configure SMTP settings)
    Send-MailMessage -To "security@company.com" -From "healthcheck@company.com" -Subject $subject -Body $body -SmtpServer "smtp.company.com"
}

# Main execution
Write-LogEntry "Starting EternalBlue health check..." "INFO"

$results = @{
    "MS17-010 Patches" = Test-PatchStatus
    "SMBv1 Disabled" = Test-SMBv1Status
    "Firewall Rules" = Test-FirewallRules
}

Write-LogEntry "Health check completed" "INFO"
Send-HealthReport -Results $results
```

### 2. Metrics and Dashboards

#### Grafana Dashboard Configuration
```json
{
  "dashboard": {
    "title": "EternalBlue Defense Monitoring",
    "panels": [
      {
        "title": "SMB Connection Volume",
        "type": "graph",
        "targets": [
          {
            "expr": "sum(rate(network_connections_total{port=\"445\"}[5m]))",
            "legendFormat": "SMB Connections/sec"
          }
        ]
      },
      {
        "title": "SMBv1 Usage Detection",
        "type": "stat",
        "targets": [
          {
            "expr": "sum(smb_version_1_connections_total)",
            "legendFormat": "SMBv1 Connections"
          }
        ]
      },
      {
        "title": "Patch Compliance",
        "type": "gauge",
        "targets": [
          {
            "expr": "(sum(ms17010_patched_hosts) / sum(total_windows_hosts)) * 100",
            "legendFormat": "% Patched"
          }
        ]
      }
    ]
  }
}
```

---

## Conclusion

This comprehensive defense guide provides multiple layers of protection against EternalBlue attacks:

1. **Prevention** through patching and attack surface reduction
2. **Detection** through comprehensive monitoring
3. **Response** through well-defined incident procedures
4. **Validation** through regular testing and assessment

### Key Takeaways:
- ✅ **Patch immediately** - MS17-010 patches are critical
- ✅ **Disable SMBv1** - No legitimate need for legacy protocol
- ✅ **Monitor actively** - Deploy detection rules and monitoring
- ✅ **Segment networks** - Limit blast radius
- ✅ **Test regularly** - Validate defenses continuously

Regular review and updates of these defenses ensure continued protection against EternalBlue and similar threats.
