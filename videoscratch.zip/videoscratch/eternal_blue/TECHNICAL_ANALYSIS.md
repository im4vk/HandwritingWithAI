# EternalBlue (MS17-010) Technical Analysis
## Educational/Defense-Focused Walkthrough

### Executive Summary
EternalBlue exploits CVE-2017-0144, a critical vulnerability in Windows SMBv1 server implementation (`srv.sys` driver). This document provides deep technical analysis for defensive understanding.

## 1. Vulnerability Deep Dive

### 1.1 Root Cause Analysis
- **Location**: `srv.sys` kernel driver, specifically in `SrvOs2FeaListToNt()` function
- **Bug Type**: Integer overflow leading to heap buffer overflow in kernel nonpaged pool
- **Trigger**: Malformed SMBv1 Transaction/Transaction2 requests with crafted FEA (File Extended Attributes) lists

### 1.2 Memory Corruption Mechanics
```
SMBv1 Transaction Request Structure:
┌─────────────────┬─────────────────┬─────────────────┐
│   SMB Header    │   Trans Params  │   Trans Data    │
│   (32 bytes)    │                 │   (FEA List)    │
└─────────────────┴─────────────────┴─────────────────┘

FEA List Structure (OS/2 Format):
┌─────────────────┬─────────────────┬─────────────────┐
│  NextEntryOff   │   Flags/Size    │   Name + Value  │
│   (4 bytes)     │   (varies)      │   (variable)    │
└─────────────────┴─────────────────┴─────────────────┘
```

**The Vulnerability**:
1. SMB server receives Transaction2 request with FEA list
2. `SrvOs2FeaListToNt()` allocates buffer based on calculated size
3. Size calculation uses attacker-controlled values without proper validation
4. Integer overflow causes smaller allocation than needed
5. Subsequent copy operations overflow the allocated buffer
6. Adjacent kernel structures in nonpaged pool get corrupted

### 1.3 Kernel Pool Exploitation
```
Nonpaged Pool Layout (Before Exploitation):
┌─────────────────┬─────────────────┬─────────────────┐
│   Pool Header   │  Allocated Obj  │   Pool Header   │
│   (metadata)    │   (srv.sys)     │   (next alloc)  │
└─────────────────┴─────────────────┴─────────────────┘

After Buffer Overflow:
┌─────────────────┬─────────────────┬─────────────────┐
│   Pool Header   │  Overflowed     │ CORRUPTED DATA  │
│   (metadata)    │   Buffer        │ (attacker ctrl) │
└─────────────────┴─────────────────┴─────────────────┘
```

## 2. Exploitation Phases

### 2.1 Phase 1: Target Discovery & Fingerprinting
```python
# Pseudo-code for reconnaissance
def scan_targets():
    # Port 445 scanning
    # SMB version enumeration
    # OS version detection
    # Patch level assessment
```

### 2.2 Phase 2: SMBv1 Negotiation
- Force downgrade to SMBv1 protocol
- Establish multiple sessions for heap grooming
- Create tree connections to target shares

### 2.3 Phase 3: Heap Grooming
- Spray nonpaged pool with predictable allocations
- Create "holes" and "islands" for controlled layout
- Position target buffer adjacent to controllable data

### 2.4 Phase 4: Trigger Exploitation
- Send crafted Transaction2 request
- Overflow target buffer to corrupt adjacent structures
- Redirect kernel execution flow

### 2.5 Phase 5: Payload Delivery
- Execute shellcode in kernel context (SYSTEM)
- Install backdoor (typically DoublePulsar)
- Inject user-mode payload into legitimate process

## 3. Technical Indicators & Artifacts

### 3.1 Network-Level Indicators
```
SMB Protocol Anomalies:
- Forced SMBv1 dialect negotiation
- Unusual Transaction/Transaction2 request patterns
- Oversized or malformed FEA list structures
- Repeated session establishments from same source
- Fragmented SMB packets with suspicious reassembly
```

### 3.2 Host-Level Indicators
```
Kernel-Level:
- srv.sys crashes or BSOD with specific error codes
- Unexpected kernel pool allocations
- New kernel-mode code execution

Process-Level:
- services.exe process injection
- Unusual network connections from system processes
- Named pipe creation (DoublePulsar communication)
```

### 3.3 Memory Forensics Indicators
```
Pool Tags to Monitor:
- "SrvN" (SMB nonpaged allocations)
- "Nb**" (NetBIOS related)
- Unusual pool chunk patterns in srv.sys context
```

## 4. Attack Flow Diagram

```
[Attacker] ──(1)──> [Port 445 Scan] ──(2)──> [SMBv1 Negotiate]
     │                                              │
     │                                              ▼
     │                                     [Heap Grooming]
     │                                              │
     │                                              ▼
     └─(6)─< [Payload Delivery] <─(5)─< [Code Execution] <─(4)─< [Buffer Overflow]
                     │                                              ▲
                     ▼                                              │
            [DoublePulsar Install]                         [Crafted Trans2]
                     │                                              │
                     ▼                                              │
              [Lateral Movement] ──────────────────────────────────┘
```

## 5. Defensive Countermeasures

### 5.1 Prevention (Primary)
1. **Patch Management**
   - Apply MS17-010 immediately
   - Verify all systems including air-gapped networks
   - Test patch deployment in staging environments

2. **Attack Surface Reduction**
   - Disable SMBv1 protocol entirely
   - Block TCP/445 at network perimeter
   - Implement network segmentation

### 5.2 Detection (Secondary)
1. **Network Monitoring**
   - IDS rules for MS17-010 exploitation attempts
   - SMB protocol analysis and baseline deviations
   - Unusual port 445 traffic patterns

2. **Host Monitoring**
   - EDR solutions monitoring srv.sys behavior
   - Kernel driver integrity checking
   - Process injection detection

### 5.3 Response (Tertiary)
1. **Incident Response**
   - Isolate affected systems immediately
   - Preserve memory dumps for forensic analysis
   - Rebuild from known-good backups

## 6. Lab Environment Setup

### 6.1 Safe Testing Environment
- Isolated virtual network
- Vulnerable Windows VMs (pre-MS17-010)
- Network monitoring tools
- Packet capture capabilities

### 6.2 Detection Tool Testing
- Suricata/Snort with EternalBlue rules
- Zeek SMB analyzers
- Custom detection scripts
- PCAP replay capabilities

## 7. References & Further Reading
- CVE-2017-0144 (Microsoft Security Bulletin MS17-010)
- Shadow Brokers leak analysis
- WannaCry & NotPetya incident reports
- SMBv1 protocol specifications
- Windows kernel pool exploitation techniques

---
**DISCLAIMER**: This analysis is for educational and defensive purposes only. 
Do not use this information for unauthorized access or malicious activities.
