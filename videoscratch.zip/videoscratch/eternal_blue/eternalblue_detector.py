#!/usr/bin/env python3
"""
EternalBlue Detection Tool
Educational/Defense-Focused Network Traffic Analyzer

This tool analyzes network traffic for EternalBlue (MS17-010) exploitation patterns.
Designed for defensive cybersecurity education and detection tuning.

Requirements: pip install scapy pandas colorama
"""

import struct
import socket
import sys
import time
from datetime import datetime
from collections import defaultdict, deque
import argparse
import json

try:
    from scapy.all import *
    import pandas as pd
    from colorama import init, Fore, Back, Style
    init()  # Initialize colorama
except ImportError as e:
    print(f"Missing required packages: {e}")
    print("Install with: pip install scapy pandas colorama")
    sys.exit(1)

class EternalBlueDetector:
    """Detects EternalBlue exploitation patterns in network traffic"""
    
    def __init__(self, interface=None, pcap_file=None, verbose=False):
        self.interface = interface
        self.pcap_file = pcap_file
        self.verbose = verbose
        
        # Detection counters and state
        self.smb_sessions = defaultdict(dict)
        self.alerts = []
        self.stats = {
            'total_packets': 0,
            'smb_packets': 0,
            'smb1_packets': 0,
            'suspicious_trans': 0,
            'alerts_generated': 0
        }
        
        # Timing windows for correlation
        self.timing_window = deque(maxlen=1000)
        
        # Known EternalBlue signatures
        self.signatures = {
            'smb1_dialects': [b'PC NETWORK PROGRAM 1.0', b'LANMAN1.0', b'LM1.2X002'],
            'suspicious_trans_sizes': range(4000, 5000),  # Common EB payload sizes
            'kernel_shellcode_patterns': [
                b'\x48\x31\xc0',  # XOR RAX, RAX (common in x64 shellcode)
                b'\x48\x89\xe5',  # MOV RBP, RSP
                b'\x48\x83\xec',  # SUB RSP, immediate
            ]
        }
        
    def print_banner(self):
        """Print tool banner"""
        banner = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════════════╗
║                    EternalBlue Detector                     ║
║              Educational Defense Tool v1.0                  ║
║                                                              ║
║  Analyzes network traffic for MS17-010 exploitation         ║
║  patterns. For educational and defensive purposes only.      ║
╚══════════════════════════════════════════════════════════════╝{Style.RESET_ALL}
"""
        print(banner)
    
    def analyze_smb_negotiate(self, packet):
        """Analyze SMB negotiate requests for SMBv1 downgrade attempts"""
        if not packet.haslayer(TCP) or (packet[TCP].dport != 445 and packet[TCP].sport != 445):
            return
            
        # Get payload data
        raw_data = None
        if packet.haslayer(Raw):
            raw_data = bytes(packet[Raw])
        elif hasattr(packet, 'load') and packet.load:
            raw_data = bytes(packet.load)
        elif packet.haslayer(TCP) and hasattr(packet[TCP], 'load') and packet[TCP].load:
            raw_data = bytes(packet[TCP].load)
            
        if not raw_data:
            return
            
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst
        
        # Check for SMB header signature
        if len(raw_data) < 8:
            return
            
        # Look for SMBv1 header (0xFF + "SMB")
        if b'\xff\x53\x4d\x42' in raw_data:
            smb_offset = raw_data.find(b'\xff\x53\x4d\x42')
            if smb_offset != -1 and len(raw_data) > smb_offset + 8:
                # Extract command byte
                command = raw_data[smb_offset + 4]
                
                # Check for negotiate command (0x72)
                if command == 0x72:
                    # Look for SMBv1 dialects in the payload
                    for dialect in self.signatures['smb1_dialects']:
                        if dialect in raw_data:
                            self.generate_alert(
                                'SMBv1_NEGOTIATE',
                                f"SMBv1 dialect negotiation detected: {src_ip} -> {dst_ip}",
                                packet,
                                severity='MEDIUM'
                            )
                            self.stats['smb1_packets'] += 1
                            break
    
    def analyze_smb_transaction(self, packet):
        """Analyze SMB Transaction/Transaction2 requests for EternalBlue patterns"""
        if not packet.haslayer(TCP) or (packet[TCP].dport != 445 and packet[TCP].sport != 445):
            return
            
        # Get payload data
        raw_data = None
        if packet.haslayer(Raw):
            raw_data = bytes(packet[Raw])
        elif hasattr(packet, 'load') and packet.load:
            raw_data = bytes(packet.load)
        elif packet.haslayer(TCP) and hasattr(packet[TCP], 'load') and packet[TCP].load:
            raw_data = bytes(packet[TCP].load)
            
        if not raw_data:
            return
            
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst
        
        # Look for SMBv1 header
        if b'\xff\x53\x4d\x42' in raw_data:
            smb_offset = raw_data.find(b'\xff\x53\x4d\x42')
            if smb_offset != -1 and len(raw_data) > smb_offset + 8:
                # Extract command byte
                command = raw_data[smb_offset + 4]
                
                # Check for Transaction/Transaction2 commands
                if command in [0x25, 0x32]:  # SMB_COM_TRANSACTION, SMB_COM_TRANSACTION2
                    try:
                        # Look for suspicious transaction sizes
                        if len(raw_data) in self.signatures['suspicious_trans_sizes']:
                            self.generate_alert(
                                'SUSPICIOUS_TRANSACTION_SIZE',
                                f"Suspicious SMB transaction size {len(raw_data)} bytes: {src_ip} -> {dst_ip}",
                                packet,
                                severity='HIGH'
                            )
                            self.stats['suspicious_trans'] += 1
                        
                        # Look for FEA list patterns (EternalBlue specific)
                        if self.detect_fea_list_anomaly(raw_data):
                            self.generate_alert(
                                'ETERNALBLUE_FEA_PATTERN',
                                f"Potential EternalBlue FEA list pattern detected: {src_ip} -> {dst_ip}",
                                packet,
                                severity='CRITICAL'
                            )
                        
                        # Check for kernel shellcode patterns
                        for pattern in self.signatures['kernel_shellcode_patterns']:
                            if pattern in raw_data:
                                self.generate_alert(
                                    'KERNEL_SHELLCODE_PATTERN',
                                    f"Potential kernel shellcode pattern in SMB transaction: {src_ip} -> {dst_ip}",
                                    packet,
                                    severity='CRITICAL'
                                )
                                break
                                
                    except Exception as e:
                        if self.verbose:
                            print(f"Error analyzing transaction: {e}")
    
    def detect_fea_list_anomaly(self, data):
        """Detect malformed FEA list structures characteristic of EternalBlue"""
        try:
            # Look for FEA list structure patterns
            # FEA lists start with size fields that can indicate overflow attempts
            
            if len(data) < 8:
                return False
                
            # Check for suspicious size calculations
            # EternalBlue often uses specific size values that cause integer overflow
            for i in range(len(data) - 4):
                try:
                    # Extract potential size field (little-endian DWORD)
                    size_field = struct.unpack('<I', data[i:i+4])[0]
                    
                    # Known EternalBlue size patterns
                    if size_field in [0x1000, 0x2000, 0x3000]:  # Common sizes used
                        # Check if following data doesn't match declared size
                        remaining_data = len(data) - i - 4
                        if remaining_data != size_field and abs(remaining_data - size_field) > 100:
                            return True
                            
                except struct.error:
                    continue
                    
            return False
            
        except Exception:
            return False
    
    def detect_heap_grooming(self, src_ip):
        """Detect potential heap grooming through repeated SMB operations"""
        if src_ip not in self.smb_sessions:
            self.smb_sessions[src_ip] = {
                'connection_count': 0,
                'last_activity': time.time(),
                'transaction_sizes': []
            }
        
        session = self.smb_sessions[src_ip]
        session['connection_count'] += 1
        session['last_activity'] = time.time()
        
        # Alert on excessive connections (potential grooming)
        if session['connection_count'] > 10:  # Threshold for suspicious activity
            self.generate_alert(
                'POTENTIAL_HEAP_GROOMING',
                f"Excessive SMB connections from {src_ip} (count: {session['connection_count']})",
                None,
                severity='MEDIUM'
            )
    
    def generate_alert(self, alert_type, message, packet=None, severity='LOW'):
        """Generate security alert"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        alert = {
            'timestamp': timestamp,
            'type': alert_type,
            'severity': severity,
            'message': message,
            'src_ip': packet[IP].src if packet and packet.haslayer(IP) else 'N/A',
            'dst_ip': packet[IP].dst if packet and packet.haslayer(IP) else 'N/A',
            'protocol': 'SMB'
        }
        
        self.alerts.append(alert)
        self.stats['alerts_generated'] += 1
        
        # Color-coded output based on severity
        colors = {
            'LOW': Fore.GREEN,
            'MEDIUM': Fore.YELLOW,
            'HIGH': Fore.RED,
            'CRITICAL': Fore.RED + Back.YELLOW
        }
        
        color = colors.get(severity, Fore.WHITE)
        print(f"{color}[{severity}] {timestamp} - {alert_type}: {message}{Style.RESET_ALL}")
    
    def packet_handler(self, packet):
        """Main packet processing function"""
        self.stats['total_packets'] += 1
        
        # Only process TCP packets on port 445 (SMB)
        if not (packet.haslayer(TCP) and (packet[TCP].dport == 445 or packet[TCP].sport == 445)):
            return
            
        # Check for SMB traffic by looking for SMB signatures in packet payload
        raw_data = None
        
        # Try multiple ways to get payload data
        if packet.haslayer(Raw):
            raw_data = bytes(packet[Raw])
        elif hasattr(packet, 'load') and packet.load:
            raw_data = bytes(packet.load)
        elif packet.haslayer(TCP) and hasattr(packet[TCP], 'load') and packet[TCP].load:
            raw_data = bytes(packet[TCP].load)
        
        if raw_data:
            # Check for SMBv1 (\xff\x53\x4d\x42) or SMBv2 (\xfe\x53\x4d\x42) signatures
            if b'\xff\x53\x4d\x42' in raw_data or b'\xfe\x53\x4d\x42' in raw_data:
                self.stats['smb_packets'] += 1
                
                if self.verbose:
                    smb_type = "SMBv1" if b'\xff\x53\x4d\x42' in raw_data else "SMBv2"
                    print(f"Found {smb_type} packet from {packet[IP].src} to {packet[IP].dst}")
                
                # Track potential heap grooming
                if packet.haslayer(IP):
                    self.detect_heap_grooming(packet[IP].src)
                
                # Analyze specific SMB operations
                self.analyze_smb_negotiate(packet)
                self.analyze_smb_transaction(packet)
    
    def print_statistics(self):
        """Print detection statistics"""
        print(f"\n{Fore.CYAN}═══ DETECTION STATISTICS ═══{Style.RESET_ALL}")
        print(f"Total Packets Processed: {self.stats['total_packets']}")
        print(f"SMB Packets: {self.stats['smb_packets']}")
        print(f"SMBv1 Packets: {self.stats['smb1_packets']}")
        print(f"Suspicious Transactions: {self.stats['suspicious_trans']}")
        print(f"Alerts Generated: {self.stats['alerts_generated']}")
    
    def export_alerts(self, filename):
        """Export alerts to JSON file"""
        with open(filename, 'w') as f:
            json.dump(self.alerts, f, indent=2)
        print(f"\n{Fore.GREEN}Alerts exported to: {filename}{Style.RESET_ALL}")
    
    def run(self):
        """Main execution function"""
        self.print_banner()
        
        try:
            if self.pcap_file:
                print(f"Analyzing PCAP file: {self.pcap_file}")
                packets = rdpcap(self.pcap_file)
                for packet in packets:
                    self.packet_handler(packet)
            else:
                print(f"Starting live capture on interface: {self.interface or 'default'}")
                print("Press Ctrl+C to stop...")
                sniff(
                    iface=self.interface,
                    prn=self.packet_handler,
                    filter="tcp port 445",
                    store=0
                )
                
        except KeyboardInterrupt:
            print(f"\n{Fore.YELLOW}Capture stopped by user{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error: {e}{Style.RESET_ALL}")
        finally:
            self.print_statistics()
            if self.alerts:
                self.export_alerts(f"eternalblue_alerts_{int(time.time())}.json")


def main():
    parser = argparse.ArgumentParser(
        description="EternalBlue Detection Tool - Educational/Defense Focused",
        epilog="Example: python3 eternalblue_detector.py -r traffic.pcap -v"
    )
    
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-i', '--interface', help='Network interface for live capture')
    group.add_argument('-r', '--read', help='PCAP file to analyze')
    
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    # Create and run detector
    detector = EternalBlueDetector(
        interface=args.interface,
        pcap_file=args.read,
        verbose=args.verbose
    )
    
    detector.run()


if __name__ == "__main__":
    main()
