#!/usr/bin/env python3
"""
EternalBlue Detection Rules Integration Test
Tests integration with various SIEM and security platforms
"""

import json
import yaml
import re
import subprocess
import os
from datetime import datetime

class IntegrationTest:
    """Test integration with various security platforms"""
    
    def __init__(self):
        self.test_results = {}
        
    def test_json_alerts_format(self):
        """Test JSON alert format compatibility"""
        print("Testing JSON alert format...")
        
        # Generate test alerts
        cmd = ["python3", "eternalblue_detector.py", "-r", "test_smb_packets.pcap"]
        result = subprocess.run(cmd, capture_output=True, text=True, env=os.environ.copy())
        
        # Find generated JSON file
        json_files = [f for f in os.listdir('.') if f.startswith('eternalblue_alerts_') and f.endswith('.json')]
        
        if not json_files:
            return {"status": "FAIL", "error": "No JSON alerts file generated"}
        
        json_file = json_files[-1]  # Use most recent
        
        try:
            with open(json_file, 'r') as f:
                alerts = json.load(f)
            
            # Validate JSON structure
            required_fields = ['timestamp', 'type', 'severity', 'message', 'src_ip', 'dst_ip', 'protocol']
            
            for alert in alerts:
                for field in required_fields:
                    if field not in alert:
                        return {"status": "FAIL", "error": f"Missing field: {field}"}
                
                # Validate severity levels
                if alert['severity'] not in ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']:
                    return {"status": "FAIL", "error": f"Invalid severity: {alert['severity']}"}
            
            return {
                "status": "PASS",
                "alerts_count": len(alerts),
                "file": json_file,
                "sample_alert": alerts[0] if alerts else None
            }
            
        except json.JSONDecodeError as e:
            return {"status": "FAIL", "error": f"Invalid JSON: {e}"}
    
    def test_suricata_rules_syntax(self):
        """Test Suricata rules syntax validation"""
        print("Testing Suricata rules syntax...")
        
        try:
            # Load detection rules
            with open('detection_rules.yaml', 'r') as f:
                rules_data = yaml.safe_load(f)
            
            suricata_rules = rules_data.get('suricata_rules', '')
            if not suricata_rules:
                return {"status": "FAIL", "error": "No Suricata rules found"}
            
            # Extract individual rules
            rules = [line.strip() for line in suricata_rules.strip().split('\n') 
                    if line.strip() and not line.strip().startswith('#')]
            
            valid_rules = 0
            rule_errors = []
            
            for rule in rules:
                # Basic Suricata rule syntax validation
                if not rule.startswith('alert '):
                    rule_errors.append(f"Rule doesn't start with 'alert': {rule[:50]}...")
                    continue
                
                # Check for required components
                required_components = ['alert', 'tcp', 'any', 'any', '->', 'any', '445']
                if not all(comp in rule for comp in required_components):
                    rule_errors.append(f"Missing required components: {rule[:50]}...")
                    continue
                
                # Check for msg field
                if 'msg:' not in rule:
                    rule_errors.append(f"Missing msg field: {rule[:50]}...")
                    continue
                
                # Check for sid field
                if 'sid:' not in rule:
                    rule_errors.append(f"Missing sid field: {rule[:50]}...")
                    continue
                
                valid_rules += 1
            
            return {
                "status": "PASS" if len(rule_errors) == 0 else "PARTIAL",
                "total_rules": len(rules),
                "valid_rules": valid_rules,
                "errors": rule_errors[:5]  # Show first 5 errors
            }
            
        except Exception as e:
            return {"status": "FAIL", "error": str(e)}
    
    def test_elastic_queries_syntax(self):
        """Test Elastic query syntax validation"""
        print("Testing Elastic SIEM queries...")
        
        try:
            with open('detection_rules.yaml', 'r') as f:
                rules_data = yaml.safe_load(f)
            
            elastic_rules = rules_data.get('elastic_rules')
            if not elastic_rules:
                return {"status": "FAIL", "error": "No Elastic rules found"}
            
            # Parse YAML-formatted rules
            if isinstance(elastic_rules, str):
                # Try to parse as YAML
                elastic_data = yaml.safe_load(elastic_rules)
            else:
                elastic_data = elastic_rules
            
            if not isinstance(elastic_data, list):
                return {"status": "FAIL", "error": "Elastic rules not in list format"}
            
            valid_rules = 0
            rule_errors = []
            
            for rule in elastic_data:
                # Check required fields
                required_fields = ['name', 'description', 'type', 'query']
                missing_fields = [field for field in required_fields if field not in rule]
                
                if missing_fields:
                    rule_errors.append(f"Missing fields {missing_fields} in rule: {rule.get('name', 'unnamed')}")
                    continue
                
                # Validate query syntax (basic check)
                query = rule['query']
                if not isinstance(query, str) or len(query.strip()) == 0:
                    rule_errors.append(f"Invalid query in rule: {rule['name']}")
                    continue
                
                # Check for suspicious query patterns
                if 'network.protocol:smb' not in query.lower() and 'smb' not in query.lower():
                    rule_errors.append(f"Rule may not target SMB traffic: {rule['name']}")
                    continue
                
                valid_rules += 1
            
            return {
                "status": "PASS" if len(rule_errors) == 0 else "PARTIAL",
                "total_rules": len(elastic_data),
                "valid_rules": valid_rules,
                "errors": rule_errors
            }
            
        except Exception as e:
            return {"status": "FAIL", "error": str(e)}
    
    def test_splunk_queries_syntax(self):
        """Test Splunk query syntax validation"""
        print("Testing Splunk queries...")
        
        try:
            with open('detection_rules.yaml', 'r') as f:
                rules_data = yaml.safe_load(f)
            
            splunk_queries = rules_data.get('splunk_queries', '')
            if not splunk_queries:
                return {"status": "FAIL", "error": "No Splunk queries found"}
            
            # Extract individual queries (each query starts with 'index=')
            lines = splunk_queries.strip().split('\n')
            queries = []
            current_query = []
            
            for line in lines:
                line = line.strip()
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                    
                # New query starts with 'index='
                if line.startswith('index='):
                    if current_query:
                        queries.append(' '.join(current_query))
                    current_query = [line]
                else:
                    # Continuation of current query
                    current_query.append(line)
            
            # Add the last query
            if current_query:
                queries.append(' '.join(current_query))
            
            valid_queries = 0
            query_errors = []
            
            for i, query in enumerate(queries):
                # Basic Splunk syntax validation
                if not query.startswith('index='):
                    query_errors.append(f"Query {i+1} doesn't start with index=")
                    continue
                
                # Check for pipe operations
                if '|' not in query:
                    query_errors.append(f"Query {i+1} missing pipe operations")
                    continue
                
                # Check for SMB-related content
                if 'smb' not in query.lower() and '445' not in query:
                    query_errors.append(f"Query {i+1} may not target SMB traffic")
                    continue
                
                valid_queries += 1
            
            return {
                "status": "PASS" if len(query_errors) == 0 else "PARTIAL",
                "total_queries": len(queries),
                "valid_queries": valid_queries,
                "errors": query_errors
            }
            
        except Exception as e:
            return {"status": "FAIL", "error": str(e)}
    
    def test_yara_rules_syntax(self):
        """Test YARA rules syntax validation"""
        print("Testing YARA rules...")
        
        try:
            with open('detection_rules.yaml', 'r') as f:
                rules_data = yaml.safe_load(f)
            
            yara_rules = rules_data.get('yara_rules', '')
            if not yara_rules:
                return {"status": "FAIL", "error": "No YARA rules found"}
            
            # Write YARA rules to temporary file for validation
            temp_yara_file = 'temp_eternalblue.yar'
            with open(temp_yara_file, 'w') as f:
                f.write(yara_rules)
            
            # Try to compile YARA rules (if yara-python is available)
            try:
                import yara
                
                rules = yara.compile(filepath=temp_yara_file)
                rule_count = len(rules)
                
                # Clean up
                os.remove(temp_yara_file)
                
                return {
                    "status": "PASS",
                    "compiled_rules": rule_count,
                    "yara_available": True
                }
                
            except ImportError:
                # Manual syntax validation
                with open(temp_yara_file, 'r') as f:
                    content = f.read()
                
                # Basic syntax checks
                if 'rule ' not in content:
                    os.remove(temp_yara_file)
                    return {"status": "FAIL", "error": "No rule definitions found"}
                
                # Count rules
                rule_count = content.count('rule ')
                
                # Check for required sections
                required_sections = ['meta:', 'strings:', 'condition:']
                missing_sections = [section for section in required_sections 
                                  if section not in content]
                
                # Clean up
                os.remove(temp_yara_file)
                
                if missing_sections:
                    return {
                        "status": "PARTIAL",
                        "rule_count": rule_count,
                        "missing_sections": missing_sections,
                        "yara_available": False
                    }
                else:
                    return {
                        "status": "PASS",
                        "rule_count": rule_count,
                        "yara_available": False
                    }
            
        except Exception as e:
            # Clean up temp file if it exists
            if os.path.exists('temp_eternalblue.yar'):
                os.remove('temp_eternalblue.yar')
            return {"status": "FAIL", "error": str(e)}
    
    def test_sigma_rules_syntax(self):
        """Test Sigma rules syntax validation"""
        print("Testing Sigma rules...")
        
        try:
            with open('detection_rules.yaml', 'r') as f:
                rules_data = yaml.safe_load(f)
            
            sigma_rules = rules_data.get('sigma_rules', '')
            if not sigma_rules:
                return {"status": "FAIL", "error": "No Sigma rules found"}
            
            # Parse Sigma rules (YAML format)
            try:
                # Split multiple rules (separated by ---)
                rule_docs = sigma_rules.split('---')
                rules = []
                
                for doc in rule_docs:
                    doc = doc.strip()
                    if doc:
                        rule = yaml.safe_load(doc)
                        if rule:
                            rules.append(rule)
                
                valid_rules = 0
                rule_errors = []
                
                # Validate each rule
                for i, rule in enumerate(rules):
                    required_fields = ['title', 'description', 'detection', 'level']
                    missing_fields = [field for field in required_fields if field not in rule]
                    
                    if missing_fields:
                        rule_errors.append(f"Rule {i+1} missing fields: {missing_fields}")
                        continue
                    
                    # Check detection section
                    detection = rule.get('detection', {})
                    if not isinstance(detection, dict):
                        rule_errors.append(f"Rule {i+1} has invalid detection section")
                        continue
                    
                    if 'condition' not in detection:
                        rule_errors.append(f"Rule {i+1} missing condition in detection")
                        continue
                    
                    valid_rules += 1
                
                return {
                    "status": "PASS" if len(rule_errors) == 0 else "PARTIAL",
                    "total_rules": len(rules),
                    "valid_rules": valid_rules,
                    "errors": rule_errors
                }
                
            except yaml.YAMLError as e:
                return {"status": "FAIL", "error": f"YAML parsing error: {e}"}
            
        except Exception as e:
            return {"status": "FAIL", "error": str(e)}
    
    def generate_integration_report(self):
        """Generate comprehensive integration test report"""
        print("\n" + "="*60)
        print("ETERNALBLUE DETECTION RULES INTEGRATION TEST")
        print("="*60)
        
        # Run all tests
        tests = {
            "JSON Alerts Format": self.test_json_alerts_format,
            "Suricata Rules": self.test_suricata_rules_syntax,
            "Elastic SIEM Queries": self.test_elastic_queries_syntax,
            "Splunk Queries": self.test_splunk_queries_syntax,
            "YARA Rules": self.test_yara_rules_syntax,
            "Sigma Rules": self.test_sigma_rules_syntax
        }
        
        results = {}
        passed_tests = 0
        total_tests = len(tests)
        
        for test_name, test_func in tests.items():
            print(f"\n🔍 {test_name}:")
            try:
                result = test_func()
                results[test_name] = result
                
                status = result['status']
                if status == "PASS":
                    print(f"  ✅ PASS")
                    passed_tests += 1
                elif status == "PARTIAL":
                    print(f"  ⚠️  PARTIAL")
                    passed_tests += 0.5
                else:
                    print(f"  ❌ FAIL")
                
                # Print details
                if 'error' in result:
                    print(f"    Error: {result['error']}")
                if 'total_rules' in result:
                    print(f"    Rules: {result['valid_rules']}/{result['total_rules']} valid")
                if 'alerts_count' in result:
                    print(f"    Alerts: {result['alerts_count']} generated")
                if 'errors' in result and result['errors']:
                    print(f"    Issues: {len(result['errors'])} found")
                    for error in result['errors'][:2]:  # Show first 2 errors
                        print(f"      - {error}")
                        
            except Exception as e:
                results[test_name] = {"status": "ERROR", "error": str(e)}
                print(f"  💥 ERROR: {e}")
        
        # Generate summary
        print(f"\n" + "="*60)
        print("INTEGRATION TEST SUMMARY")
        print("="*60)
        
        success_rate = (passed_tests / total_tests) * 100
        print(f"Success Rate: {success_rate:.1f}% ({passed_tests}/{total_tests})")
        
        if success_rate >= 90:
            print("🎉 EXCELLENT: Rules are ready for production deployment")
        elif success_rate >= 75:
            print("✅ GOOD: Rules are mostly compatible, minor fixes needed")
        elif success_rate >= 50:
            print("⚠️  MODERATE: Some compatibility issues need attention")
        else:
            print("❌ POOR: Significant issues need to be resolved")
        
        # Platform-specific recommendations
        print(f"\n📋 DEPLOYMENT RECOMMENDATIONS:")
        
        for platform, result in results.items():
            status = result['status']
            if status == "PASS":
                print(f"  ✅ {platform}: Ready for deployment")
            elif status == "PARTIAL":
                print(f"  ⚠️  {platform}: Review and fix identified issues")
            else:
                print(f"  ❌ {platform}: Requires significant fixes")
        
        return results

def main():
    # Ensure we have test data
    if not os.path.exists('test_smb_packets.pcap'):
        print("Generating test data...")
        subprocess.run(['python3', 'test_smb_generation.py'], 
                      capture_output=True, env=os.environ.copy())
    
    # Run integration tests
    integration_test = IntegrationTest()
    results = integration_test.generate_integration_report()
    
    # Save results to file
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    report_file = f"integration_test_report_{timestamp}.json"
    
    with open(report_file, 'w') as f:
        json.dump({
            'timestamp': timestamp,
            'results': results,
            'summary': {
                'total_tests': len(results),
                'passed': sum(1 for r in results.values() if r['status'] == 'PASS'),
                'partial': sum(1 for r in results.values() if r['status'] == 'PARTIAL'),
                'failed': sum(1 for r in results.values() if r['status'] == 'FAIL')
            }
        }, f, indent=2)
    
    print(f"\n📄 Detailed report saved to: {report_file}")

if __name__ == "__main__":
    main()
