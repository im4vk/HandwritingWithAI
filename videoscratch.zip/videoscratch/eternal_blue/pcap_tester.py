#!/usr/bin/env python3
"""
EternalBlue PCAP Testing Framework
Safe testing environment for detection rule validation

This tool creates synthetic network traffic patterns for testing EternalBlue
detection capabilities without using actual exploits.
"""

import struct
import random
import time
from datetime import datetime
import argparse
import os

try:
    from scapy.all import *
    import pandas as pd
    from colorama import init, Fore, Style
    init()
except ImportError as e:
    print(f"Missing required packages: {e}")
    print("Install with: pip install scapy pandas colorama")
    sys.exit(1)

class EternalBluePCAPTester:
    """Creates test traffic patterns for EternalBlue detection validation"""
    
    def __init__(self, output_file="test_traffic.pcap"):
        self.output_file = output_file
        self.packets = []
        
        # Test scenarios
        self.scenarios = {
            'normal_smb': self.create_normal_smb_traffic,
            'smb1_negotiate': self.create_smb1_negotiate,
            'suspicious_transaction': self.create_suspicious_transaction,
            'heap_grooming': self.create_heap_grooming_pattern,
            'eternalblue_simulation': self.create_eternalblue_simulation
        }
    
    def create_normal_smb_traffic(self, src_ip="192.168.1.100", dst_ip="192.168.1.10"):
        """Create normal SMBv2/3 traffic for baseline"""
        print(f"{Fore.GREEN}Creating normal SMB traffic...{Style.RESET_ALL}")
        
        # SMBv2/3 negotiate
        ip = IP(src=src_ip, dst=dst_ip)
        tcp = TCP(sport=random.randint(1024, 65535), dport=445, flags="PA")
        
        # SMBv2 header (simplified)
        smb2_header = (
            b'\xfeSMB'  # Protocol ID
            b'\x00\x00'  # Structure Size
            b'\x00\x00'  # Credit Charge
            b'\x00\x00'  # Status
            b'\x00\x00'  # Command (Negotiate)
            b'\x00\x00\x00\x00'  # Credits
            b'\x00\x00\x00\x00'  # Flags
            b'\x00\x00\x00\x00'  # Next Command
            b'\x00\x00\x00\x00\x00\x00\x00\x00'  # Message ID
            b'\x00\x00\x00\x00'  # Process ID
            b'\x00\x00\x00\x00'  # Tree ID
            b'\x00\x00\x00\x00\x00\x00\x00\x00'  # Session ID
            b'\x00' * 16  # Signature
        )
        
        packet = ip / tcp / Raw(load=smb2_header)
        self.packets.append(packet)
        
        return [packet]
    
    def create_smb1_negotiate(self, src_ip="192.168.1.100", dst_ip="192.168.1.10"):
        """Create SMBv1 negotiate request (suspicious but not malicious)"""
        print(f"{Fore.YELLOW}Creating SMBv1 negotiate request...{Style.RESET_ALL}")
        
        ip = IP(src=src_ip, dst=dst_ip)
        tcp = TCP(sport=random.randint(1024, 65535), dport=445, flags="PA")
        
        # NetBIOS Session Service header (raw bytes)
        netbios_header = b'\x00\x00\x00\x44'  # TYPE=0x00, LENGTH=0x44
        
        # SMBv1 header
        smb_header = struct.pack('<4sBBBBBBBBHHHHH',
            b'\xffSMB',  # Protocol
            0x72,        # Command (Negotiate)
            0x00,        # Error class
            0x00,        # Reserved
            0x00,        # Error code
            0x18,        # Flags
            0x0000,      # Flags2
            0x0000,      # PID High
            0x00000000,  # Signature
            0x0000,      # Reserved
            0x0000,      # TID
            0x0000,      # PID
            0x0000,      # UID
            0x0000       # MID
        )
        
        # SMBv1 negotiate request with old dialects
        dialects = (
            b'\x02PC NETWORK PROGRAM 1.0\x00'
            b'\x02LANMAN1.0\x00'
            b'\x02LM1.2X002\x00'
        )
        
        negotiate_params = struct.pack('<BH', 0x00, len(dialects)) + dialects
        
        packet = ip / tcp / Raw(load=netbios_header + smb_header + negotiate_params)
        self.packets.append(packet)
        
        return [packet]
    
    def create_suspicious_transaction(self, src_ip="192.168.1.100", dst_ip="192.168.1.10"):
        """Create suspicious SMB transaction with unusual size"""
        print(f"{Fore.RED}Creating suspicious transaction...{Style.RESET_ALL}")
        
        ip = IP(src=src_ip, dst=dst_ip)
        tcp = TCP(sport=random.randint(1024, 65535), dport=445, flags="PA")
        
        # NetBIOS header (raw bytes)
        netbios_header = b'\x00\x00\x10\x00'  # TYPE=0x00, LENGTH=0x1000
        
        # SMBv1 header for Transaction2
        smb_header = struct.pack('<4sBBBBBBBBHHHHH',
            b'\xffSMB',  # Protocol
            0x32,        # Command (Transaction2)
            0x00,        # Error class
            0x00,        # Reserved
            0x00,        # Error code
            0x18,        # Flags
            0x0000,      # Flags2
            0x0000,      # PID High
            0x00000000,  # Signature
            0x0000,      # Reserved
            0x0000,      # TID
            0x0000,      # PID
            0x0000,      # UID
            0x0000       # MID
        )
        
        # Transaction2 parameters with suspicious size (4096 bytes)
        trans2_params = struct.pack('<HHHHHHHHHH',
            0x0F,    # Word Count
            0x1000,  # Total Parameter Count (suspicious size)
            0x1000,  # Total Data Count
            0x40,    # Max Parameter Count
            0x1000,  # Max Data Count
            0x00,    # Max Setup Count
            0x00,    # Reserved
            0x0000,  # Flags
            0x00000000,  # Timeout
            0x0000   # Reserved2
        )
        
        # Add suspicious payload (simulated, not actual exploit)
        suspicious_payload = b'A' * 4096  # Large payload
        
        packet = ip / tcp / Raw(load=netbios_header + smb_header + trans2_params + suspicious_payload)
        self.packets.append(packet)
        
        return [packet]
    
    def create_heap_grooming_pattern(self, src_ip="192.168.1.100", dst_ip="192.168.1.10"):
        """Create multiple connections simulating heap grooming"""
        print(f"{Fore.RED}Creating heap grooming pattern...{Style.RESET_ALL}")
        
        packets = []
        
        # Create multiple rapid connections
        for i in range(15):  # Suspicious number of connections
            ip = IP(src=src_ip, dst=dst_ip)
            tcp = TCP(sport=random.randint(1024, 65535), dport=445, flags="S")  # SYN
            
            packet = ip / tcp
            packets.append(packet)
            self.packets.append(packet)
            
            # Add corresponding ACK
            tcp_ack = TCP(sport=tcp.sport, dport=445, flags="A")
            ack_packet = ip / tcp_ack
            packets.append(ack_packet)
            self.packets.append(ack_packet)
        
        return packets
    
    def create_eternalblue_simulation(self, src_ip="192.168.1.100", dst_ip="192.168.1.10"):
        """Create EternalBlue-like traffic pattern (simulation only)"""
        print(f"{Fore.RED}Creating EternalBlue simulation pattern...{Style.RESET_ALL}")
        
        packets = []
        
        # Step 1: SMBv1 negotiate
        packets.extend(self.create_smb1_negotiate(src_ip, dst_ip))
        
        # Step 2: Multiple sessions (grooming)
        packets.extend(self.create_heap_grooming_pattern(src_ip, dst_ip))
        
        # Step 3: Suspicious transaction with FEA-like structure
        ip = IP(src=src_ip, dst=dst_ip)
        tcp = TCP(sport=random.randint(1024, 65535), dport=445, flags="PA")
        
        # Craft a packet that looks like EternalBlue without being functional
        netbios_header = b'\x00\x00\x12\x00'  # TYPE=0x00, LENGTH=0x1200
        
        smb_header = struct.pack('<4sBBBBBBBBHHHHH',
            b'\xffSMB',  # Protocol
            0x32,        # Command (Transaction2)
            0x00, 0x00, 0x00, 0x18,
            0x0000, 0x0000, 0x00000000, 0x0000,
            0x0000, 0x0000, 0x0000, 0x0000
        )
        
        # Simulate FEA list structure (non-functional)
        fea_list = struct.pack('<II', 0x1000, 0x2000)  # Suspicious size values
        fea_list += b'AAAA' * 1000  # Padding to trigger size detection
        
        # Add potential shellcode patterns (non-functional)
        fake_shellcode = b'\x48\x31\xc0\x48\x89\xe5\x48\x83\xec'  # x64 patterns
        fea_list += fake_shellcode
        
        packet = ip / tcp / Raw(load=netbios_header + smb_header + fea_list)
        packets.append(packet)
        self.packets.append(packet)
        
        return packets
    
    def create_test_scenarios(self):
        """Create all test scenarios"""
        print(f"\n{Fore.CYAN}═══ CREATING TEST SCENARIOS ═══{Style.RESET_ALL}")
        
        # Normal traffic
        self.create_normal_smb_traffic("192.168.1.100", "192.168.1.10")
        
        # Suspicious patterns
        self.create_smb1_negotiate("192.168.1.101", "192.168.1.10")
        self.create_suspicious_transaction("192.168.1.102", "192.168.1.10")
        self.create_heap_grooming_pattern("192.168.1.103", "192.168.1.10")
        
        # EternalBlue simulation
        self.create_eternalblue_simulation("192.168.1.104", "192.168.1.10")
        
        print(f"\n{Fore.GREEN}Created {len(self.packets)} test packets{Style.RESET_ALL}")
    
    def save_pcap(self):
        """Save packets to PCAP file"""
        if self.packets:
            wrpcap(self.output_file, self.packets)
            print(f"{Fore.GREEN}PCAP saved to: {self.output_file}{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}No packets to save{Style.RESET_ALL}")
    
    def run_test_suite(self):
        """Run complete test suite"""
        print(f"{Fore.CYAN}╔══════════════════════════════════════════════════════════════╗")
        print(f"║                EternalBlue PCAP Test Suite                  ║")
        print(f"║              Safe Detection Rule Testing                     ║")
        print(f"╚══════════════════════════════════════════════════════════════╝{Style.RESET_ALL}")
        
        self.create_test_scenarios()
        self.save_pcap()
        
        print(f"\n{Fore.YELLOW}═══ TEST INSTRUCTIONS ═══{Style.RESET_ALL}")
        print(f"1. Run the detector against this PCAP:")
        print(f"   python3 eternalblue_detector.py -r {self.output_file} -v")
        print(f"2. Verify detection of suspicious patterns")
        print(f"3. Tune detection rules based on results")
        print(f"4. Test with real network traffic for false positives")


def main():
    parser = argparse.ArgumentParser(
        description="EternalBlue PCAP Testing Framework",
        epilog="Creates synthetic traffic for testing detection rules"
    )
    
    parser.add_argument('-o', '--output', default='eternalblue_test.pcap',
                       help='Output PCAP file (default: eternalblue_test.pcap)')
    
    args = parser.parse_args()
    
    # Create and run test suite
    tester = EternalBluePCAPTester(output_file=args.output)
    tester.run_test_suite()


if __name__ == "__main__":
    main()
