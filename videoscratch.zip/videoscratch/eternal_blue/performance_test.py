#!/usr/bin/env python3
"""
EternalBlue Detection Performance Test
Tests performance with high-volume traffic
"""

import time
import subprocess
import os
from scapy.all import *
import struct
import random

class PerformanceTest:
    """Performance testing for EternalBlue detector"""
    
    def __init__(self):
        self.packets = []
        
    def generate_high_volume_traffic(self, num_packets=1000):
        """Generate high-volume mixed traffic"""
        print(f"Generating {num_packets} packets for performance testing...")
        
        # Generate mix of traffic types
        benign_ratio = 0.7  # 70% benign traffic
        smb1_ratio = 0.2    # 20% SMBv1 traffic
        malicious_ratio = 0.1  # 10% potentially malicious
        
        for i in range(num_packets):
            packet_type = random.random()
            
            if packet_type < benign_ratio:
                # Generate benign SMBv2 traffic
                self.packets.append(self.create_benign_smb2(i))
            elif packet_type < benign_ratio + smb1_ratio:
                # Generate SMBv1 negotiate (suspicious but not malicious)
                self.packets.append(self.create_smb1_negotiate(i))
            else:
                # Generate malicious-looking traffic
                self.packets.append(self.create_suspicious_transaction(i))
                
            if i % 100 == 0:
                print(f"  Generated {i}/{num_packets} packets...")
    
    def create_benign_smb2(self, seq):
        """Create benign SMBv2 traffic"""
        src_ip = f"192.168.1.{50 + (seq % 50)}"
        dst_ip = "192.168.1.10"
        
        ip = IP(src=src_ip, dst=dst_ip)
        tcp = TCP(sport=20000 + seq, dport=445, flags="PA")
        
        # SMBv2 negotiate
        smb2_payload = (
            b'\x00\x00\x00\x40'  # NetBIOS
            b'\xfe\x53\x4d\x42'  # SMBv2
            b'\x00\x00\x00\x00\x00\x00\x00\x00'
            b'\x00\x00\x00\x00\x00\x00\x00\x00'
            + b'\x00' * 32
        )
        
        return ip / tcp / Raw(load=smb2_payload)
    
    def create_smb1_negotiate(self, seq):
        """Create SMBv1 negotiate (triggers alerts)"""
        src_ip = f"192.168.2.{10 + (seq % 10)}"
        dst_ip = "192.168.1.10"
        
        ip = IP(src=src_ip, dst=dst_ip)
        tcp = TCP(sport=30000 + seq, dport=445, flags="PA")
        
        # SMBv1 negotiate with legacy dialects
        netbios_header = struct.pack('>BBI', 0x00, 0x00, 0x44)
        
        smb_header = struct.pack('<4sBBBBBBBBHHHHH',
            b'\xff\x53\x4d\x42',  # SMBv1
            0x72,                 # Negotiate
            0x00, 0x00, 0x00, 0x18,
            0x0000, 0x0000, 0x00000000, 0x0000,
            0x0000, 0x0000, 0x0000, seq & 0xFFFF
        )
        
        param_block = struct.pack('<B', 0x00)
        dialects = b'\x02PC NETWORK PROGRAM 1.0\x00\x02LANMAN1.0\x00'
        data_block = struct.pack('<H', len(dialects)) + dialects
        
        payload = netbios_header + smb_header + param_block + data_block
        
        return ip / tcp / Raw(load=payload)
    
    def create_suspicious_transaction(self, seq):
        """Create suspicious Transaction2 (triggers multiple alerts)"""
        src_ip = f"192.168.3.{5 + (seq % 5)}"
        dst_ip = "192.168.1.10"
        
        ip = IP(src=src_ip, dst=dst_ip)
        tcp = TCP(sport=40000 + seq, dport=445, flags="PA")
        
        # Large Transaction2 with EternalBlue patterns
        netbios_header = struct.pack('>BBI', 0x00, 0x00, 0x1200)
        
        smb_header = struct.pack('<4sBBBBBBBBHHHHH',
            b'\xff\x53\x4d\x42',  # SMBv1
            0x32,                 # Transaction2
            0x00, 0x00, 0x00, 0x18,
            0x0000, 0x0000, 0x00000000, 0x0000,
            0x0000, 0x0000, 0x0000, seq & 0xFFFF
        )
        
        # Transaction2 parameters
        trans2_params = struct.pack('<B', 0x0F)
        trans2_words = struct.pack('<HHHHHHHIHHHHHBB',
            0x1000, 0x1000, 0x40, 0x1000, 0x00, 0x00, 0x0000,
            0x00000000, 0x0000, 0x00, 0x00, 0x1000, 0x40, 0x01, 0x00
        )
        
        # EternalBlue patterns
        fea_pattern = struct.pack('<II', 0x1000, 0x2000)
        buffer_data = b'A' * 4000
        shellcode = b'\x48\x31\xc0\x48\x89\xe5\x48\x83\xec'
        
        setup_word = struct.pack('<H', 0x0000)
        byte_count = struct.pack('<H', 0x1000)
        
        payload = (netbios_header + smb_header + trans2_params + 
                  trans2_words + setup_word + byte_count + 
                  fea_pattern + buffer_data + shellcode)
        
        return ip / tcp / Raw(load=payload)
    
    def save_traffic(self, filename):
        """Save generated traffic to PCAP"""
        wrpcap(filename, self.packets)
        print(f"Saved {len(self.packets)} packets to {filename}")
        return filename
    
    def run_performance_test(self, pcap_file):
        """Run detector and measure performance"""
        print(f"Running performance test on {pcap_file}...")
        
        # Run detector with timing
        start_time = time.time()
        
        cmd = ["python3", "eternalblue_detector.py", "-r", pcap_file]
        env = os.environ.copy()
        result = subprocess.run(cmd, capture_output=True, text=True, env=env)
        
        end_time = time.time()
        processing_time = end_time - start_time
        
        # Parse results
        output_lines = result.stdout.split('\n')
        stats = {}
        
        for line in output_lines:
            if 'Total Packets Processed:' in line:
                stats['total_packets'] = int(line.split(':')[1].strip())
            elif 'SMB Packets:' in line:
                stats['smb_packets'] = int(line.split(':')[1].strip())
            elif 'Alerts Generated:' in line:
                stats['alerts_generated'] = int(line.split(':')[1].strip())
        
        # Calculate performance metrics
        packets_per_second = stats.get('total_packets', 0) / processing_time
        
        return {
            'processing_time': processing_time,
            'packets_per_second': packets_per_second,
            'stats': stats,
            'output': result.stdout
        }
    
    def run_memory_usage_test(self, pcap_file):
        """Test memory usage during processing"""
        print("Running memory usage test...")
        
        # Use memory profiling if available
        try:
            import psutil
            import subprocess
            
            # Start detector process
            cmd = ["python3", "eternalblue_detector.py", "-r", pcap_file]
            env = os.environ.copy()
            
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE, env=env)
            
            # Monitor memory usage
            max_memory = 0
            memory_samples = []
            
            try:
                ps_process = psutil.Process(process.pid)
                while process.poll() is None:
                    try:
                        memory_info = ps_process.memory_info()
                        memory_mb = memory_info.rss / 1024 / 1024  # Convert to MB
                        memory_samples.append(memory_mb)
                        max_memory = max(max_memory, memory_mb)
                        time.sleep(0.1)
                    except psutil.NoSuchProcess:
                        break
                        
                process.wait()
                
                return {
                    'max_memory_mb': max_memory,
                    'avg_memory_mb': sum(memory_samples) / len(memory_samples) if memory_samples else 0,
                    'memory_samples': len(memory_samples)
                }
                
            except Exception as e:
                print(f"Memory monitoring error: {e}")
                process.wait()
                return {'error': str(e)}
                
        except ImportError:
            print("psutil not available for memory testing")
            return {'error': 'psutil not available'}
    
    def run_scaling_test(self):
        """Test performance with different packet volumes"""
        print("\n" + "="*60)
        print("SCALING PERFORMANCE TEST")
        print("="*60)
        
        packet_counts = [100, 500, 1000, 2000]
        results = []
        
        for count in packet_counts:
            print(f"\nTesting with {count} packets...")
            
            # Generate traffic
            self.packets = []
            self.generate_high_volume_traffic(count)
            
            # Save to PCAP
            pcap_file = f"perf_test_{count}.pcap"
            self.save_traffic(pcap_file)
            
            # Run performance test
            perf_result = self.run_performance_test(pcap_file)
            perf_result['packet_count'] = count
            results.append(perf_result)
            
            # Print results
            print(f"  Processing time: {perf_result['processing_time']:.2f}s")
            print(f"  Packets/second: {perf_result['packets_per_second']:.1f}")
            print(f"  Alerts generated: {perf_result['stats'].get('alerts_generated', 0)}")
            
            # Clean up
            os.remove(pcap_file)
        
        return results
    
    def print_performance_summary(self, results):
        """Print performance test summary"""
        print("\n" + "="*60)
        print("PERFORMANCE TEST SUMMARY")
        print("="*60)
        
        print(f"{'Packets':<10} {'Time(s)':<10} {'Pkt/s':<10} {'Alerts':<10} {'Memory(MB)':<12}")
        print("-" * 60)
        
        for result in results:
            packet_count = result['packet_count']
            proc_time = result['processing_time']
            pkt_per_sec = result['packets_per_second']
            alerts = result['stats'].get('alerts_generated', 0)
            
            print(f"{packet_count:<10} {proc_time:<10.2f} {pkt_per_sec:<10.1f} {alerts:<10}")
        
        # Performance analysis
        print("\n📊 PERFORMANCE ANALYSIS:")
        
        if len(results) >= 2:
            linear_scaling = results[-1]['packets_per_second'] / results[0]['packets_per_second']
            print(f"  Scaling efficiency: {linear_scaling:.2f} (1.0 = perfect linear scaling)")
            
            avg_pps = sum(r['packets_per_second'] for r in results) / len(results)
            print(f"  Average throughput: {avg_pps:.1f} packets/second")
            
            if avg_pps > 1000:
                print("  ✅ EXCELLENT: High-performance detection capability")
            elif avg_pps > 500:
                print("  ✅ GOOD: Suitable for moderate traffic volumes")
            elif avg_pps > 100:
                print("  ⚠️  MODERATE: May need optimization for high-volume environments")
            else:
                print("  ❌ SLOW: Requires performance optimization")

def main():
    test = PerformanceTest()
    
    print("EternalBlue Detection Performance Test Suite")
    print("=" * 50)
    
    # Run scaling tests
    results = test.run_scaling_test()
    
    # Print summary
    test.print_performance_summary(results)
    
    # Test with realistic mixed traffic
    print(f"\n📈 REALISTIC TRAFFIC TEST (1000 packets, mixed types)")
    test.packets = []
    test.generate_high_volume_traffic(1000)
    pcap_file = "realistic_traffic_test.pcap"
    test.save_traffic(pcap_file)
    
    # Performance test
    perf_result = test.run_performance_test(pcap_file)
    print(f"  Processing time: {perf_result['processing_time']:.2f}s")
    print(f"  Throughput: {perf_result['packets_per_second']:.1f} packets/second")
    print(f"  SMB packets detected: {perf_result['stats'].get('smb_packets', 0)}")
    print(f"  Security alerts: {perf_result['stats'].get('alerts_generated', 0)}")
    
    # Memory test
    memory_result = test.run_memory_usage_test(pcap_file)
    if 'error' not in memory_result:
        print(f"  Peak memory usage: {memory_result['max_memory_mb']:.1f} MB")
        print(f"  Average memory usage: {memory_result['avg_memory_mb']:.1f} MB")
    
    # Clean up
    os.remove(pcap_file)
    
    print(f"\n✅ Performance testing completed successfully!")

if __name__ == "__main__":
    main()
