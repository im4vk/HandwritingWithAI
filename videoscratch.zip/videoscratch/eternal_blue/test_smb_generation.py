#!/usr/bin/env python3
"""
Test SMB packet generation to ensure proper format
"""

from scapy.all import *
import struct

def create_test_smb_packet():
    """Create a proper SMBv1 packet for testing"""
    
    # Create IP and TCP layers
    ip = IP(src="192.168.1.100", dst="192.168.1.10")
    tcp = TCP(sport=12345, dport=445, flags="PA")
    
    # NetBIOS Session Service header
    netbios_header = struct.pack('>BBI', 0x00, 0x00, 0x44)  # Message type=0, flags=0, length=68
    
    # SMBv1 header structure
    smb_header = struct.pack('<4sBBBBBBBBHHHHH',
        b'\xff\x53\x4d\x42',  # Protocol: 0xFF + "SMB"
        0x72,                 # Command: SMB_COM_NEGOTIATE (0x72)
        0x00,                 # Error Class
        0x00,                 # Reserved
        0x00,                 # Error Code (low)
        0x18,                 # Flags: Case insensitive, canonicalized paths
        0x0000,               # Flags2
        0x0000,               # Process ID High
        0x00000000,           # Signature (8 bytes, split into 2 DWORDs)
        0x0000,               # Reserved
        0x0000,               # Tree ID
        0x0000,               # Process ID
        0x0000,               # User ID
        0x0001                # Multiplex ID
    )
    
    # SMB negotiate parameter block
    param_words = 0  # Word count
    param_block = struct.pack('<B', param_words)
    
    # SMB data (dialects)
    dialects = (
        b'\x02PC NETWORK PROGRAM 1.0\x00'
        b'\x02LANMAN1.0\x00'
        b'\x02LM1.2X002\x00'
        b'\x02LANMAN2.1\x00'
        b'\x02NT LM 0.12\x00'
    )
    
    data_length = len(dialects)
    data_block = struct.pack('<H', data_length) + dialects
    
    # Complete SMB payload
    smb_payload = netbios_header + smb_header + param_block + data_block
    
    # Create packet
    packet = ip / tcp / Raw(load=smb_payload)
    
    return packet

def create_transaction2_packet():
    """Create a Transaction2 packet with suspicious characteristics"""
    
    ip = IP(src="192.168.1.101", dst="192.168.1.10")
    tcp = TCP(sport=12346, dport=445, flags="PA")
    
    # NetBIOS header for larger transaction
    netbios_header = struct.pack('>BBI', 0x00, 0x00, 0x1000)  # 4096 bytes
    
    # SMBv1 header for Transaction2
    smb_header = struct.pack('<4sBBBBBBBBHHHHH',
        b'\xff\x53\x4d\x42',  # Protocol
        0x32,                 # Command: SMB_COM_TRANSACTION2
        0x00, 0x00, 0x00,     # Error fields
        0x18,                 # Flags
        0x0000,               # Flags2
        0x0000,               # PID High
        0x00000000,           # Signature
        0x0000,               # Reserved
        0x0000,               # TID
        0x0000,               # PID
        0x0000,               # UID
        0x0002                # MID
    )
    
    # Transaction2 parameters (simplified)
    # Word count for Trans2 is typically 15 (0x0F)
    word_count = 0x0F
    trans2_params = struct.pack('<B', word_count)
    
    # Trans2 parameter structure
    total_param_count = 0x1000  # Suspicious large size
    total_data_count = 0x1000   # Suspicious large size
    max_param_count = 0x40
    max_data_count = 0x1000
    max_setup_count = 0x00
    reserved = 0x00
    flags = 0x0000
    timeout = 0x00000000
    reserved2 = 0x0000
    param_count = 0x00
    param_offset = 0x00
    data_count = 0x1000  # Large data
    data_offset = 0x40
    setup_count = 0x01
    reserved3 = 0x00
    
    trans2_words = struct.pack('<HHHHHHHIHHHHHBB',
        total_param_count, total_data_count, max_param_count, max_data_count,
        max_setup_count, reserved, flags, timeout, reserved2,
        param_count, param_offset, data_count, data_offset,
        setup_count, reserved3
    )
    
    # Setup word (Trans2 subcommand)
    setup_word = struct.pack('<H', 0x0000)  # TRANS2_OPEN2
    
    # Byte count
    byte_count = struct.pack('<H', 0x1000)
    
    # Large data payload with patterns
    # Include FEA-like structures
    fea_pattern = struct.pack('<II', 0x1000, 0x2000)  # Suspicious size values
    large_payload = fea_pattern + b'A' * (0x1000 - len(fea_pattern) - 9)
    
    # Add shellcode pattern
    shellcode_pattern = b'\x48\x31\xc0\x48\x89\xe5\x48\x83\xec'
    large_payload += shellcode_pattern
    
    # Complete SMB payload
    smb_payload = (netbios_header + smb_header + trans2_params + 
                   trans2_words + setup_word + byte_count + large_payload)
    
    packet = ip / tcp / Raw(load=smb_payload)
    
    return packet

def main():
    print("Creating test SMB packets...")
    
    # Create test packets
    negotiate_packet = create_test_smb_packet()
    trans2_packet = create_transaction2_packet()
    
    # Save to PCAP
    test_packets = [negotiate_packet, trans2_packet]
    wrpcap("test_smb_packets.pcap", test_packets)
    
    print(f"Created {len(test_packets)} test packets")
    print("Saved to: test_smb_packets.pcap")
    
    # Analyze what we created
    for i, pkt in enumerate(test_packets):
        print(f"\nPacket {i}:")
        if pkt.haslayer(Raw):
            raw_data = bytes(pkt[Raw])
            print(f"  Raw data length: {len(raw_data)}")
            print(f"  First 16 bytes: {raw_data[:16].hex()}")
            if b'\xff\x53\x4d\x42' in raw_data:
                smb_offset = raw_data.find(b'\xff\x53\x4d\x42')
                command = raw_data[smb_offset + 4] if len(raw_data) > smb_offset + 4 else None
                print(f"  SMBv1 found at offset {smb_offset}, command: 0x{command:02x}")

if __name__ == "__main__":
    main()
