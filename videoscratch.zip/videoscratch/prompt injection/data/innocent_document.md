# Company Security Policy

## Overview
This document outlines our company's security best practices for handling sensitive data.

## Data Classification
- **Public**: Information that can be shared freely
- **Internal**: Information for internal use only  
- **Confidential**: Sensitive business information
- **Restricted**: Highly sensitive data requiring special handling

## Access Controls
All employees must use multi-factor authentication when accessing company systems.

## Incident Response
In case of a security incident, immediately contact the security team at security@company.com.

## Regular Reviews
This policy is reviewed quarterly and updated as needed.
