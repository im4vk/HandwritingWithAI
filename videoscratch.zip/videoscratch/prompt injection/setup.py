#!/usr/bin/env python3
"""
Setup script for the Prompt Injection Security Demo
Creates necessary directories and validates the environment
"""
import os
import sys
import subprocess
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Error: Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version}")
    return True

def install_requirements():
    """Install required packages"""
    try:
        print("📦 Installing requirements...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Requirements installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("❌ Failed to install requirements")
        return False

def setup_directories():
    """Create necessary directories"""
    base_dir = Path("/prompt injection")
    directories = [
        base_dir / "logs",
        base_dir / "results", 
        base_dir / "reports"
    ]
    
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
        print(f"✅ Created directory: {directory}")

def check_models():
    """Check if local models are available"""
    models_dir = Path("/prompt injection/models")
    
    if not models_dir.exists():
        print("⚠️  Models directory not found")
        return False
    
    required_models = ["DialoGPT-small", "distilbert-base-uncased"]
    available_models = []
    
    for model in required_models:
        model_path = models_dir / model
        if model_path.exists():
            available_models.append(model)
            print(f"✅ Found model: {model}")
        else:
            print(f"⚠️  Model not found: {model}")
    
    if available_models:
        print(f"✅ {len(available_models)} models available for testing")
        return True
    else:
        print("⚠️  No models found - demo will use simulated responses")
        return False

def validate_setup():
    """Validate the complete setup"""
    print("\n🔍 Validating setup...")
    
    # Check required files
    required_files = [
        "simulated_tools.py",
        "vulnerable_agent.py", 
        "secure_agent.py",
        "run_demo.py",
        "data/innocent_document.md",
        "data/malicious_document.md",
        "data/jailbreak_prompts.json"
    ]
    
    base_dir = Path("/prompt injection")
    
    for file_path in required_files:
        full_path = base_dir / file_path
        if full_path.exists():
            print(f"✅ Found: {file_path}")
        else:
            print(f"❌ Missing: {file_path}")
            return False
    
    print("✅ All required files present")
    return True

def create_env_file():
    """Create a .env file template"""
    env_content = """# Prompt Injection Demo Configuration

# Optional: Use real OpenAI models (requires API key)
# OPENAI_API_KEY=your-api-key-here
# USE_REAL_LLM=false

# Model configuration
VULNERABLE_MODEL_PATH=models/DialoGPT-small
SECURE_MODEL_PATH=models/DialoGPT-small

# Logging level
LOG_LEVEL=INFO

# Demo settings
INTERACTIVE_MODE=true
AUTO_CONFIRM=false
"""
    
    env_file = Path("/prompt injection/.env")
    if not env_file.exists():
        with open(env_file, 'w') as f:
            f.write(env_content)
        print("✅ Created .env configuration file")
    else:
        print("✅ .env file already exists")

def run_quick_test():
    """Run a quick test to verify everything works"""
    print("\n🧪 Running quick test...")
    
    try:
        # Test imports
        sys.path.insert(0, "/prompt injection")
        
        import simulated_tools
        print("✅ simulated_tools module imported")
        
        import vulnerable_agent
        print("✅ vulnerable_agent module imported")
        
        import secure_agent
        print("✅ secure_agent module imported")
        
        # Quick functionality test
        from simulated_tools import attack_logger, AVAILABLE_TOOLS
        print(f"✅ Found {len(AVAILABLE_TOOLS)} available tools")
        
        print("✅ Quick test passed - setup is working!")
        return True
        
    except Exception as e:
        print(f"❌ Quick test failed: {e}")
        return False

def main():
    """Main setup function"""
    print("🛡️  Prompt Injection Security Demo Setup")
    print("=" * 50)
    
    success = True
    
    # Check Python version
    if not check_python_version():
        success = False
    
    # Setup directories
    setup_directories()
    
    # Install requirements
    if not install_requirements():
        success = False
    
    # Check models
    check_models()
    
    # Create environment file
    create_env_file()
    
    # Validate setup
    if not validate_setup():
        success = False
    
    # Run quick test
    if not run_quick_test():
        success = False
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 Setup completed successfully!")
        print("\nTo start the demo, run:")
        print("  python run_demo.py")
    else:
        print("❌ Setup encountered issues. Please review the errors above.")
        print("\nFor help, check:")
        print("  - README.md for detailed instructions")
        print("  - requirements.txt for dependencies")
        print("  - Python version compatibility (3.8+)")
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
