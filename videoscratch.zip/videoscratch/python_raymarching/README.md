# Python Raymarching Engine

A complete Python implementation of the Unity Black Hole Raymarching project with real-time volumetric rendering, gravitational lensing, and accretion disk physics.

![gif](./black_hole_closeup.gif)

## Features

- **Real-time Raymarching**: Sphere tracing with Signed Distance Fields (SDFs)
- **Volumetric Rendering**: Cloud simulation with physically-based light transport
- **Black Hole Physics**: Gravitational lensing and Keplerian orbital mechanics
- **4 Demo Scenes**: Progressive complexity from basic raymarching to complex black holes
- **3D Noise Generation**: Fractal Brownian Motion with custom Perlin noise
- **Performance Optimized**: Numba JIT compilation for real-time performance

## Installation

```bash
cd python_raymarching
pip install -r requirements.txt
```

## Usage

```bash
# Run the main demo
python main.py

# Run specific demo scenes
python main.py --scene basic_raymarching
python main.py --scene volumetric_clouds  
python main.py --scene simple_blackhole
python main.py --scene complex_blackhole
```

## Controls

- **WASD**: Move camera
- **Mouse**: Look around
- **Space/Shift**: Up/Down movement
- **R**: Reset camera position
- **1-4**: Switch between demo scenes
- **ESC**: Exit

## Project Structure

- `main.py` - Entry point and main application
- `core/` - Core raymarching engine
- `math/` - Mathematical utilities and SDF primitives
- `rendering/` - Volumetric rendering and lighting systems
- `physics/` - Black hole physics and gravitational effects
- `noise/` - 3D noise generation
- `scenes/` - Demo scene implementations
- `utils/` - Utility functions and helpers

## Technical Details

This implementation faithfully recreates the Unity raymarching techniques including:

- Sphere tracing algorithm with adaptive step sizing
- Volumetric scattering using Henyey-Greenstein phase functions
- Beer-Lambert law for light attenuation
- Gravitational ray bending using simplified General Relativity
- Doppler shift effects in accretion disks
- Real-time 3D noise generation with octave blending

## Performance Notes

- Uses Numba JIT compilation for CPU optimization
- Supports adaptive level-of-detail for distant objects
- Blue noise dithering for temporal coherence
- Early ray termination for performance
