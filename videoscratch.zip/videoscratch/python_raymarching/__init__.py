"""
Python Raymarching Engine

A complete Python implementation of the Unity Black Hole Raymarching project 
with real-time volumetric rendering, gravitational lensing, and accretion disk physics.
"""

__version__ = "1.0.0"
__author__ = "Raymarching Engine Team"

from .scenes.demo_scenes import create_scene, SceneBase
from .rmath.vector_math import *
from .rmath.sdf_primitives import *
from .core.raymarching import *
from .rendering.volumetric import *
from .noise_gen.noise3d import *
