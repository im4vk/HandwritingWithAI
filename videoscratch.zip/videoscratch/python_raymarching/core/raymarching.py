"""
Core raymarching engine implementing sphere tracing algorithm.
Based on Unity raymarching implementation with Python optimization.
"""

import numpy as np
from numba import njit
from typing import Tuple, Optional, Callable
from ..rmath.vector_math import *
from ..rmath.sdf_primitives import *

@njit
def calculate_normal(position: np.ndarray, sdf_func, epsilon: float = 0.001) -> np.ndarray:
    """
    Calculate surface normal using finite differences.
    Uses 6-point gradient calculation for accuracy.
    """
    offset = np.array([epsilon, 0.0, 0.0])
    
    # Sample SDF at 6 points around position
    grad_x = sdf_func(position + offset)[3] - sdf_func(position - offset)[3]
    
    offset = np.array([0.0, epsilon, 0.0])
    grad_y = sdf_func(position + offset)[3] - sdf_func(position - offset)[3]
    
    offset = np.array([0.0, 0.0, epsilon])
    grad_z = sdf_func(position + offset)[3] - sdf_func(position - offset)[3]
    
    normal = np.array([grad_x, grad_y, grad_z])
    return normalize(normal)

@njit
def soft_shadow(ray_origin: np.ndarray, ray_direction: np.ndarray, 
               min_distance: float, max_distance: float, 
               sdf_func, shadow_strength: float = 16.0) -> float:
    """
    Calculate soft shadows using raymarching.
    
    Args:
        ray_origin: Shadow ray start position
        ray_direction: Shadow ray direction (toward light)
        min_distance: Minimum distance to start checking
        max_distance: Maximum shadow ray distance
        sdf_func: Scene SDF function
        shadow_strength: Controls shadow softness (higher = softer)
    
    Returns:
        Shadow factor (0 = full shadow, 1 = no shadow)
    """
    result = 1.0
    traveled = min_distance
    
    while traveled < max_distance:
        h = sdf_func(ray_origin + ray_direction * traveled)[3]
        
        if h < 0.001:
            return 0.0  # Hard shadow
        
        # Penumbra calculation
        result = min(result, shadow_strength * h / traveled)
        traveled += h
        
        if result < 0.001:
            break
    
    return clamp(result, 0.0, 1.0)

@njit
def calculate_lighting(position: np.ndarray, normal: np.ndarray, material_color: np.ndarray,
                      light_direction: np.ndarray, light_color: np.ndarray, light_intensity: float,
                      view_direction: np.ndarray, sdf_func,
                      shadow_enabled: bool = True, shadow_distance: Tuple[float, float] = (0.1, 50.0),
                      shadow_intensity: float = 1.0, shadow_penumbra: float = 16.0) -> np.ndarray:
    """
    Calculate Phong lighting with soft shadows.
    
    Args:
        position: Surface position
        normal: Surface normal
        material_color: Base material color
        light_direction: Direction to light (normalized)
        light_color: Light color
        light_intensity: Light intensity multiplier
        view_direction: Direction to camera (normalized)
        sdf_func: Scene SDF function for shadow calculation
        shadow_enabled: Whether to calculate shadows
        shadow_distance: (min, max) distances for shadow rays
        shadow_intensity: Shadow strength multiplier
        shadow_penumbra: Shadow softness factor
    
    Returns:
        Final lit color
    """
    # Lambertian diffuse lighting
    n_dot_l = dot(-light_direction, normal)
    diffuse = max(0.0, n_dot_l * 0.5 + 0.5)  # Half-Lambert for softer lighting
    
    # Calculate shadows
    shadow_factor = 1.0
    if shadow_enabled:
        shadow_factor = soft_shadow(
            position, -light_direction, 
            shadow_distance[0], shadow_distance[1],
            sdf_func, shadow_penumbra
        )
        shadow_factor = max(0.0, shadow_factor ** shadow_intensity)
    
    # Combine lighting
    light = light_color * diffuse * light_intensity * shadow_factor
    result = material_color * light
    
    return result

@njit
def raymarch_scene(ray_origin: np.ndarray, ray_direction: np.ndarray, 
                  sdf_func, max_distance: float = 100.0, max_iterations: int = 128,
                  accuracy: float = 0.001, background_color: np.ndarray = None) -> Tuple[np.ndarray, bool, float, np.ndarray]:
    """
    Core raymarching algorithm using sphere tracing.
    
    Args:
        ray_origin: Ray starting position
        ray_direction: Ray direction (normalized)
        sdf_func: Scene SDF function
        max_distance: Maximum ray travel distance
        max_iterations: Maximum raymarching steps
        accuracy: Hit accuracy threshold
        background_color: Color when ray doesn't hit anything
    
    Returns:
        (final_color, hit_surface, travel_distance, hit_position)
    """
    if background_color is None:
        background_color = np.array([0.01, 0.01, 0.01])
    
    traveled = 0.0
    position = ray_origin.copy()
    
    # Glow accumulation for distance-based effects
    glow_strength = 2.0
    glow_width = 0.5
    glow_color = np.array([0.0, 0.0, 0.0])
    
    for i in range(max_iterations):
        if traveled > max_distance:
            break
        
        position = ray_origin + ray_direction * traveled
        sdf_result = sdf_func(position)
        distance = sdf_result[3]
        material_color = sdf_result[:3]
        
        # Hit detection
        if distance < accuracy:
            return (material_color, True, traveled, position)
        
        # Accumulate glow effect for missed rays
        glow = np.exp(-distance / glow_width) * glow_strength
        glow_color += material_color * glow * 0.01
        
        # Step forward by safe distance
        traveled += distance
    
    # Ray missed - return background with glow
    final_color = background_color + glow_color
    return (final_color, False, traveled, position)

@njit  
def raymarch_with_lighting(ray_origin: np.ndarray, ray_direction: np.ndarray,
                          sdf_func, light_direction: np.ndarray, light_color: np.ndarray,
                          light_intensity: float = 1.0, max_distance: float = 100.0,
                          max_iterations: int = 128, accuracy: float = 0.001,
                          shadow_enabled: bool = True, color_enabled: bool = True,
                          background_enabled: bool = True) -> np.ndarray:
    """
    Complete raymarching with lighting and shadows.
    Matches Unity RaymarchShader behavior.
    
    Args:
        ray_origin: Camera position
        ray_direction: Ray direction (normalized)
        sdf_func: Scene SDF function
        light_direction: Light direction
        light_color: Light color
        light_intensity: Light intensity
        max_distance: Maximum ray distance
        max_iterations: Maximum steps
        accuracy: Hit threshold
        shadow_enabled: Enable shadow calculation
        color_enabled: Enable material colors
        background_enabled: Transparent background if True
    
    Returns:
        Final pixel color [r, g, b]
    """
    # Background color setup
    if background_enabled:
        background = np.array([0.01, 0.01, 0.01])  # Transparent
    else:
        background = np.array([0.01, 0.01, 0.01])  # Dark background
    
    # Perform raymarching
    color, hit, travel_distance, hit_position = raymarch_scene(
        ray_origin, ray_direction, sdf_func, 
        max_distance, max_iterations, accuracy, background
    )
    
    if not hit:
        return color
    
    # Calculate surface normal
    normal = calculate_normal(hit_position, sdf_func, accuracy)
    
    # Apply material color setting
    if not color_enabled:
        color = np.array([0.01, 0.01, 0.01])
    
    # Calculate lighting
    if shadow_enabled:
        lit_color = calculate_lighting(
            hit_position, normal, color,
            light_direction, light_color, light_intensity,
            -ray_direction, sdf_func,
            shadow_enabled=True
        )
    else:
        # Simple diffuse without shadows
        n_dot_l = dot(-light_direction, normal)
        diffuse = max(0.0, n_dot_l * 0.5 + 0.5)
        lit_color = color * light_color * diffuse * light_intensity
    
    return lit_color

# Camera and viewport utilities
@njit
def generate_camera_ray(pixel_x: int, pixel_y: int, screen_width: int, screen_height: int,
                       camera_position: np.ndarray, camera_target: np.ndarray, 
                       camera_up: np.ndarray, fov: float) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate camera ray for given pixel.
    
    Args:
        pixel_x, pixel_y: Pixel coordinates
        screen_width, screen_height: Screen dimensions
        camera_position: Camera world position
        camera_target: Camera look-at target
        camera_up: Camera up vector
        fov: Field of view in degrees
    
    Returns:
        (ray_origin, ray_direction)
    """
    # Convert pixel to normalized device coordinates (-1 to 1)
    ndc_x = (2.0 * pixel_x / screen_width) - 1.0
    ndc_y = 1.0 - (2.0 * pixel_y / screen_height)  # Flip Y
    
    # Calculate camera basis vectors
    forward = normalize(camera_target - camera_position)
    right = normalize(cross(forward, camera_up))
    up = cross(right, forward)
    
    # Calculate ray direction
    aspect_ratio = screen_width / screen_height
    fov_rad = np.deg2rad(fov)
    tan_half_fov = np.tan(fov_rad * 0.5)
    
    ray_direction = normalize(
        forward + 
        right * ndc_x * tan_half_fov * aspect_ratio +
        up * ndc_y * tan_half_fov
    )
    
    return (camera_position.copy(), ray_direction)

@njit
def render_pixel(pixel_x: int, pixel_y: int, screen_width: int, screen_height: int,
                camera_position: np.ndarray, camera_target: np.ndarray, camera_up: np.ndarray,
                fov: float, sdf_func, light_direction: np.ndarray, light_color: np.ndarray,
                light_intensity: float, max_distance: float, max_iterations: int,
                accuracy: float, shadow_enabled: bool, color_enabled: bool,
                background_enabled: bool) -> np.ndarray:
    """
    Render single pixel using raymarching.
    
    Returns:
        Pixel color [r, g, b]
    """
    ray_origin, ray_direction = generate_camera_ray(
        pixel_x, pixel_y, screen_width, screen_height,
        camera_position, camera_target, camera_up, fov
    )
    
    return raymarch_with_lighting(
        ray_origin, ray_direction, sdf_func,
        light_direction, light_color, light_intensity,
        max_distance, max_iterations, accuracy,
        shadow_enabled, color_enabled, background_enabled
    )
