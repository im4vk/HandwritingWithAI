#!/usr/bin/env python3
"""
Black Hole Animation Creator
Generates a rotating view animation of the black hole with accretion disk.
"""

import numpy as np
import time
from PIL import Image, ImageDraw, ImageFont
from numba import njit, prange
import os
import argparse

# ============================================================================
# OPTIMIZED MATH FUNCTIONS
# ============================================================================

@njit
def length_3d(x, y, z):
    return np.sqrt(x*x + y*y + z*z)

@njit
def length_2d(x, z):
    return np.sqrt(x*x + z*z)

@njit
def normalize_3d(x, y, z):
    norm = length_3d(x, y, z)
    if norm < 1e-8:
        return x, y, z
    return x/norm, y/norm, z/norm

@njit
def clamp(value, min_val, max_val):
    return max(min_val, min(max_val, value))

# ============================================================================
# STAR FIELD BACKGROUND
# ============================================================================

@njit
def generate_stars(dx, dy, dz):
    """Generate beautiful star field background."""
    # Multiple noise layers for variety
    ix = int(dx * 50) & 0xFF
    iy = int(dy * 50) & 0xFF  
    iz = int(dz * 50) & 0xFF
    
    # Primary star hash
    h1 = (ix * 73 + iy * 151 + iz * 211) & 0x7FF
    
    # Secondary star hash (different scale)
    ix2 = int(dx * 20) & 0xFF
    iy2 = int(dy * 20) & 0xFF  
    iz2 = int(dz * 20) & 0xFF
    h2 = (ix2 * 127 + iy2 * 311 + iz2 * 97) & 0x3FF
    
    # Nebula hash
    ix3 = int(dx * 5) & 0xFF
    iy3 = int(dy * 5) & 0xFF  
    iz3 = int(dz * 5) & 0xFF
    h3 = (ix3 * 17 + iy3 * 43 + iz3 * 89) & 0xFF
    
    # Bright stars
    if h1 > 2000:
        brightness = (h1 - 2000) * 0.0008
        return brightness, brightness * 0.95, brightness * 0.85
    
    # Medium stars
    elif h2 > 950:
        brightness = (h2 - 950) * 0.002
        return brightness * 0.8, brightness * 0.8, brightness
    
    # Nebula background
    nebula_strength = h3 * 0.0008
    return (nebula_strength * 0.2, 
            nebula_strength * 0.4, 
            nebula_strength * 0.8)

# ============================================================================
# BLACK HOLE WITH ACCRETION DISK
# ============================================================================

@njit
def render_black_hole_accretion(ray_ox, ray_oy, ray_oz, ray_dx, ray_dy, ray_dz,
                                bh_x, bh_y, bh_z, bh_radius, bh_mass, time_factor):
    """
    Render black hole with beautiful accretion disk.
    """
    px, py, pz = ray_ox, ray_oy, ray_oz
    dx, dy, dz = ray_dx, ray_dy, ray_dz
    
    accumulated_light_r = 0.0
    accumulated_light_g = 0.0
    accumulated_light_b = 0.0
    transmittance = 1.0
    
    step_size = 0.15
    max_steps = 80
    
    for i in range(max_steps):
        to_bh_x = px - bh_x
        to_bh_y = py - bh_y
        to_bh_z = pz - bh_z
        dist_bh = length_3d(to_bh_x, to_bh_y, to_bh_z)
        
        # Hit black hole event horizon
        if dist_bh < bh_radius:
            return accumulated_light_r, accumulated_light_g, accumulated_light_b
        
        # Accretion disk region
        disk_radius = length_2d(to_bh_x, to_bh_z)
        
        if 1.8 < disk_radius < 8.0 and abs(to_bh_y) < 0.8:
            # Disk thickness varies with radius (physically accurate)
            thickness_factor = 0.3 + 0.5 * np.sqrt(disk_radius / 8.0)
            
            if abs(to_bh_y) < thickness_factor:
                # Temperature gradient (inner=hot white, outer=cool red)
                temp_norm = (8.0 - disk_radius) / 6.2
                temp_norm = clamp(temp_norm, 0.0, 1.0)
                
                # Orbital motion for realistic disk structure
                angle = np.arctan2(to_bh_z, to_bh_x)
                orbital_speed = 2.0 / (disk_radius ** 1.5)  # Keplerian motion
                rotation_angle = angle + orbital_speed * time_factor
                
                # Turbulence noise using orbital motion
                noise_x = px + np.cos(rotation_angle) * disk_radius * 0.1
                noise_z = pz + np.sin(rotation_angle) * disk_radius * 0.1
                
                turbulence = abs(np.sin(noise_x * 4.0) * np.cos(noise_z * 4.0) * 
                               np.sin(py * 12.0))
                
                # Density based on temperature and turbulence
                base_density = temp_norm * 0.4
                density = base_density * (0.7 + 0.6 * turbulence)
                
                if density > 0.05:
                    # Temperature-based colors
                    if temp_norm > 0.8:  # Very hot inner region
                        color_r = 1.2 * temp_norm
                        color_g = 1.1 * temp_norm
                        color_b = 0.9 * temp_norm
                    elif temp_norm > 0.5:  # Hot middle region
                        color_r = 1.3 * temp_norm
                        color_g = 0.9 * temp_norm
                        color_b = 0.4 * temp_norm
                    else:  # Cooler outer region
                        color_r = 1.5 * temp_norm
                        color_g = 0.6 * temp_norm
                        color_b = 0.2 * temp_norm
                    
                    # Light attenuation based on distance to black hole
                    distance_factor = 1.0 / (1.0 + dist_bh * 0.1)
                    
                    # Add Doppler boost effect
                    doppler_factor = 1.0 + 0.3 * np.cos(rotation_angle)
                    
                    scattering = density * step_size * 4.0 * distance_factor * doppler_factor
                    
                    accumulated_light_r += transmittance * color_r * scattering
                    accumulated_light_g += transmittance * color_g * scattering
                    accumulated_light_b += transmittance * color_b * scattering
                    
                    # Absorption
                    absorption = density * step_size * 0.8
                    transmittance *= np.exp(-absorption)
                    
                    if transmittance < 0.02:
                        return accumulated_light_r, accumulated_light_g, accumulated_light_b
        
        # Gravitational lensing
        if dist_bh > 0.3:
            inv_dist3 = 1.0 / (dist_bh * dist_bh * dist_bh)
            gravity_strength = bh_mass * inv_dist3 * step_size * 0.06
            
            dx -= to_bh_x * gravity_strength
            dy -= to_bh_y * gravity_strength
            dz -= to_bh_z * gravity_strength
            dx, dy, dz = normalize_3d(dx, dy, dz)
        
        # Step forward
        px += dx * step_size
        py += dy * step_size
        pz += dz * step_size
        
        # Exit if too far from origin
        if length_3d(px - ray_ox, py - ray_oy, pz - ray_oz) > 100.0:
            break
    
    # Add beautiful star field background
    bg_r, bg_g, bg_b = generate_stars(dx, dy, dz)
    accumulated_light_r += bg_r * transmittance
    accumulated_light_g += bg_g * transmittance
    accumulated_light_b += bg_b * transmittance
    
    return accumulated_light_r, accumulated_light_g, accumulated_light_b

@njit(parallel=True)
def render_frame(buffer, width, height, cam_x, cam_y, cam_z,
                target_x, target_y, target_z, bh_x, bh_y, bh_z,
                bh_radius, bh_mass, time_factor):
    """Render a complete frame of the black hole."""
    
    # Camera setup
    fw_x = target_x - cam_x
    fw_y = target_y - cam_y
    fw_z = target_z - cam_z
    fw_x, fw_y, fw_z = normalize_3d(fw_x, fw_y, fw_z)
    
    # Right vector
    rt_x = fw_z
    rt_y = 0.0
    rt_z = -fw_x
    rt_x, rt_y, rt_z = normalize_3d(rt_x, rt_y, rt_z)
    
    # Up vector
    up_x = rt_y * fw_z - rt_z * fw_y
    up_y = rt_z * fw_x - rt_x * fw_z
    up_z = rt_x * fw_y - rt_y * fw_x
    
    aspect = width / height
    fov_scale = 0.6  # Field of view
    
    for y in prange(height):
        for x in prange(width):
            # Screen to world ray
            ndc_x = (2.0 * x / width) - 1.0
            ndc_y = 1.0 - (2.0 * y / height)
            
            ray_dx = fw_x + rt_x * ndc_x * fov_scale * aspect + up_x * ndc_y * fov_scale
            ray_dy = fw_y + rt_y * ndc_x * fov_scale * aspect + up_y * ndc_y * fov_scale
            ray_dz = fw_z + rt_z * ndc_x * fov_scale * aspect + up_z * ndc_y * fov_scale
            ray_dx, ray_dy, ray_dz = normalize_3d(ray_dx, ray_dy, ray_dz)
            
            # Render pixel
            r, g, b = render_black_hole_accretion(
                cam_x, cam_y, cam_z, ray_dx, ray_dy, ray_dz,
                bh_x, bh_y, bh_z, bh_radius, bh_mass, time_factor
            )
            
            # Tone mapping and gamma correction
            r = min(1.5, r)  # Allow some overbright
            g = min(1.5, g)
            b = min(1.5, b)
            
            # Gamma correction
            r = r ** 0.45
            g = g ** 0.45
            b = b ** 0.45
            
            buffer[y, x, 0] = int(clamp(r * 255, 0, 255))
            buffer[y, x, 1] = int(clamp(g * 255, 0, 255))
            buffer[y, x, 2] = int(clamp(b * 255, 0, 255))

# ============================================================================
# ANIMATION GENERATOR
# ============================================================================

def create_camera_path(num_frames, radius=15.0, height_variation=3.0):
    """Create smooth camera path around black hole."""
    frames = []
    
    for i in range(num_frames):
        # Circular orbit with some height variation
        angle = (i / num_frames) * 2 * np.pi
        
        # Camera position
        cam_x = radius * np.cos(angle)
        cam_y = height_variation * np.sin(angle * 2) + 2.0  # Up/down motion
        cam_z = radius * np.sin(angle)
        
        # Always look at black hole center
        target_x, target_y, target_z = 0.0, 0.0, 0.0
        
        # Time for orbital motion in accretion disk
        time_factor = i * 0.2
        
        frames.append({
            'cam_pos': (cam_x, cam_y, cam_z),
            'target': (target_x, target_y, target_z),
            'time': time_factor
        })
    
    return frames

def generate_animation_frames(width=400, height=300, num_frames=48, output_dir="frames"):
    """Generate all animation frames."""
    
    print(f"Generating {num_frames} frames at {width}x{height}...")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Black hole parameters
    bh_x, bh_y, bh_z = 0.0, 0.0, 0.0
    bh_radius = 1.2
    bh_mass = 8.0
    
    # Create camera path
    camera_frames = create_camera_path(num_frames)
    
    # Generate frames
    for i, frame_data in enumerate(camera_frames):
        start_time = time.time()
        
        # Create buffer
        buffer = np.zeros((height, width, 3), dtype=np.uint8)
        
        # Render frame
        cam_x, cam_y, cam_z = frame_data['cam_pos']
        target_x, target_y, target_z = frame_data['target']
        time_factor = frame_data['time']
        
        render_frame(buffer, width, height, cam_x, cam_y, cam_z,
                    target_x, target_y, target_z, bh_x, bh_y, bh_z,
                    bh_radius, bh_mass, time_factor)
        
        # Save frame
        image = Image.fromarray(buffer, 'RGB')
        
        # Add frame number overlay
        draw = ImageDraw.Draw(image)
        try:
            font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 16)
        except:
            font = ImageFont.load_default()
        
        draw.text((10, 10), f"Frame {i+1}/{num_frames}", fill=(255, 255, 255), font=font)
        draw.text((10, height-30), f"Black Hole Simulation", fill=(255, 255, 255), font=font)
        
        filename = os.path.join(output_dir, f"frame_{i:03d}.png")
        image.save(filename)
        
        render_time = time.time() - start_time
        print(f"Frame {i+1}/{num_frames} rendered in {render_time:.2f}s")
    
    print(f"All frames saved to {output_dir}/")
    return output_dir

def create_gif(frame_dir, output_file="black_hole_animation.gif", duration=100):
    """Create GIF from frames."""
    print("Creating GIF animation...")
    
    # Get all frame files
    frame_files = sorted([f for f in os.listdir(frame_dir) if f.startswith("frame_") and f.endswith(".png")])
    
    if not frame_files:
        print("No frame files found!")
        return
    
    # Load images
    images = []
    for filename in frame_files:
        img = Image.open(os.path.join(frame_dir, filename))
        images.append(img)
    
    # Save as GIF
    images[0].save(
        output_file,
        save_all=True,
        append_images=images[1:],
        duration=duration,
        loop=0,
        optimize=True
    )
    
    print(f"GIF saved as {output_file}")
    
    # Get file size
    size_mb = os.path.getsize(output_file) / (1024 * 1024)
    print(f"File size: {size_mb:.2f} MB")

def main():
    parser = argparse.ArgumentParser(description="Black Hole Animation Generator")
    parser.add_argument("--width", type=int, default=400, help="Frame width")
    parser.add_argument("--height", type=int, default=300, help="Frame height")
    parser.add_argument("--frames", type=int, default=48, help="Number of frames")
    parser.add_argument("--fps", type=int, default=10, help="Frames per second for GIF")
    parser.add_argument("--output", default="black_hole_animation.gif", help="Output GIF file")
    parser.add_argument("--keep-frames", action="store_true", help="Keep individual frame files")
    
    args = parser.parse_args()
    
    try:
        print("Black Hole Animation Generator")
        print("=" * 40)
        
        # Generate frames
        frame_dir = generate_animation_frames(args.width, args.height, args.frames)
        
        # Create GIF
        duration = int(1000 / args.fps)  # Convert FPS to milliseconds
        create_gif(frame_dir, args.output, duration)
        
        # Clean up frames unless requested to keep
        if not args.keep_frames:
            import shutil
            shutil.rmtree(frame_dir)
            print("Cleaned up temporary frames")
        
        print(f"\n✅ Animation complete: {args.output}")
        
    except KeyboardInterrupt:
        print("\nAnimation generation cancelled")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
