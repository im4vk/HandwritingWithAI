#!/usr/bin/env python3
"""
Black Hole Close-up Animation
Creates a dramatic close-up view showing gravitational lensing effects.
"""

import numpy as np
import time
from PIL import Image, ImageDraw, ImageFont
from numba import njit, prange
import os
from create_blackhole_animation import (
    length_3d, length_2d, normalize_3d, clamp, generate_stars, 
    render_black_hole_accretion, render_frame
)

def create_closeup_camera_path(num_frames, start_radius=12.0, end_radius=4.0):
    """Create dramatic camera path approaching the black hole."""
    frames = []
    
    for i in range(num_frames):
        t = i / (num_frames - 1)  # 0 to 1
        
        # Smooth approach using easing
        ease_t = 1 - (1 - t) ** 2  # Ease out quadratic
        
        # Camera approaches the black hole
        radius = start_radius + (end_radius - start_radius) * ease_t
        
        # Slight orbital motion for dynamic view
        angle = t * np.pi * 0.5  # Quarter rotation
        height_offset = 2.0 * np.sin(t * np.pi)  # Up and down motion
        
        cam_x = radius * np.cos(angle)
        cam_y = height_offset + 1.0
        cam_z = radius * np.sin(angle)
        
        # Always look at black hole center
        target_x, target_y, target_z = 0.0, 0.0, 0.0
        
        # Accelerating time for orbital motion effect
        time_factor = t * t * 10.0
        
        frames.append({
            'cam_pos': (cam_x, cam_y, cam_z),
            'target': (target_x, target_y, target_z),
            'time': time_factor,
            'progress': t
        })
    
    return frames

def generate_closeup_animation(width=500, height=400, num_frames=30):
    """Generate dramatic close-up animation."""
    
    print(f"Generating close-up animation: {num_frames} frames at {width}x{height}")
    print("This will show dramatic gravitational lensing effects!")
    
    # Create output directory
    output_dir = "closeup_frames"
    os.makedirs(output_dir, exist_ok=True)
    
    # Black hole parameters - more dramatic
    bh_x, bh_y, bh_z = 0.0, 0.0, 0.0
    bh_radius = 1.0  # Smaller for more dramatic lensing
    bh_mass = 12.0   # Stronger gravity
    
    # Create dramatic camera path
    camera_frames = create_closeup_camera_path(num_frames)
    
    # Generate frames
    for i, frame_data in enumerate(camera_frames):
        start_time = time.time()
        
        # Create buffer
        buffer = np.zeros((height, width, 3), dtype=np.uint8)
        
        # Render frame
        cam_x, cam_y, cam_z = frame_data['cam_pos']
        target_x, target_y, target_z = frame_data['target']
        time_factor = frame_data['time']
        progress = frame_data['progress']
        
        render_frame(buffer, width, height, cam_x, cam_y, cam_z,
                    target_x, target_y, target_z, bh_x, bh_y, bh_z,
                    bh_radius, bh_mass, time_factor)
        
        # Save frame
        image = Image.fromarray(buffer, 'RGB')
        
        # Add overlay text
        draw = ImageDraw.Draw(image)
        try:
            font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 14)
            big_font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 18)
        except:
            font = ImageFont.load_default()
            big_font = ImageFont.load_default()
        
        # Distance indicator
        distance = np.sqrt(cam_x**2 + cam_y**2 + cam_z**2)
        draw.text((10, 10), f"Distance: {distance:.1f}", fill=(255, 255, 255), font=font)
        draw.text((10, 30), f"Gravitational Lensing", fill=(255, 200, 100), font=font)
        
        # Progress indicator
        progress_text = f"Approaching Event Horizon... {progress*100:.0f}%"
        draw.text((10, height-40), progress_text, fill=(255, 100, 100), font=font)
        
        # Title
        draw.text((width//2 - 80, height-25), "Black Hole Close-Up", fill=(255, 255, 255), font=big_font)
        
        filename = os.path.join(output_dir, f"closeup_{i:03d}.png")
        image.save(filename)
        
        render_time = time.time() - start_time
        print(f"Frame {i+1}/{num_frames} - Distance: {distance:.1f} - Rendered in {render_time:.2f}s")
    
    return output_dir

def create_closeup_gif(frame_dir, output_file="black_hole_closeup.gif"):
    """Create dramatic close-up GIF."""
    print("Creating close-up GIF animation...")
    
    # Get all frame files
    frame_files = sorted([f for f in os.listdir(frame_dir) if f.startswith("closeup_") and f.endswith(".png")])
    
    # Load images
    images = []
    for filename in frame_files:
        img = Image.open(os.path.join(frame_dir, filename))
        images.append(img)
    
    # Create dramatic GIF with variable timing
    durations = []
    for i in range(len(images)):
        # Slow down as we approach the black hole
        t = i / (len(images) - 1)
        duration = int(150 + 100 * t)  # 150ms to 250ms
        durations.append(duration)
    
    # Save as GIF
    images[0].save(
        output_file,
        save_all=True,
        append_images=images[1:],
        duration=durations,
        loop=0,
        optimize=True
    )
    
    print(f"Dramatic close-up GIF saved as {output_file}")
    
    # Get file size
    size_mb = os.path.getsize(output_file) / (1024 * 1024)
    print(f"File size: {size_mb:.2f} MB")

def main():
    try:
        print("Black Hole Close-Up Animation Generator")
        print("=" * 45)
        print("🕳️  Prepare for extreme gravitational lensing!")
        
        # Generate frames
        frame_dir = generate_closeup_animation(width=500, height=400, num_frames=24)
        
        # Create GIF
        create_closeup_gif(frame_dir, "black_hole_closeup.gif")
        
        # Clean up frames
        import shutil
        shutil.rmtree(frame_dir)
        print("Cleaned up temporary frames")
        
        print(f"\n🌟 Dramatic close-up animation complete!")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
