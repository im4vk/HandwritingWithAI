#!/usr/bin/env python3
"""
Fast Black Hole Raymarching Demo - Optimized for Performance
Creates a black hole with gravitational lensing effects.
"""

import pygame
import numpy as np
import time
import sys
from numba import njit, prange
from PIL import Image

# ============================================================================
# OPTIMIZED VECTOR MATH
# ============================================================================

@njit
def length(v):
    return np.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2])

@njit
def normalize(v):
    norm = length(v)
    if norm < 1e-8:
        return v
    return v / norm

@njit
def dot(a, b):
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

@njit
def clamp(value, min_val, max_val):
    return max(min_val, min(max_val, value))

# ============================================================================
# FAST NOISE FUNCTION
# ============================================================================

@njit
def simple_noise(x, y, z):
    """Fast simple noise for star field."""
    n = int(x*127.1 + y*311.7 + z*74.7) & 0x7FFFFFFF
    n = (n ^ (n >> 13)) * 1234567
    n = n ^ (n >> 16)
    return (n & 0xFFFF) / 65536.0

@njit
def star_field(direction):
    """Generate star field background."""
    # Sample noise at different scales
    noise1 = simple_noise(direction[0]*8, direction[1]*8, direction[2]*8)
    noise2 = simple_noise(direction[0]*20, direction[1]*20, direction[2]*20)
    
    # Stars
    if noise1 > 0.92:
        star_brightness = (noise1 - 0.92) * 12.0
        return np.array([1.0, 0.9, 0.8]) * star_brightness
    
    # Nebula
    nebula = simple_noise(direction[0]*3, direction[1]*3, direction[2]*3) * 0.3
    return np.array([0.1*nebula, 0.2*nebula, 0.5*nebula])

# ============================================================================
# BLACK HOLE PHYSICS
# ============================================================================

@njit
def black_hole_raymarch(ray_origin, ray_direction, bh_center, bh_radius, bh_mass):
    """
    Optimized black hole raymarching with gravitational lensing.
    Uses fewer steps and simplified physics for performance.
    """
    position = ray_origin.copy()
    direction = ray_direction.copy()
    
    max_steps = 50  # Reduced from 100 for performance
    step_size = 0.2  # Larger steps for performance
    
    for i in range(max_steps):
        # Check if ray hits black hole
        distance_to_bh = length(position - bh_center)
        if distance_to_bh < bh_radius:
            return np.array([0.0, 0.0, 0.0])  # Black hole
        
        # Gravitational lensing (simplified)
        to_bh = position - bh_center
        dist_bh = length(to_bh)
        if dist_bh > 0.1:  # Avoid singularity
            gravity_strength = bh_mass / (dist_bh * dist_bh * dist_bh)
            gravity = to_bh * (step_size * gravity_strength * 0.1)
            direction = normalize(direction - gravity)
        
        # Step forward
        position += direction * step_size
        
        # Exit if too far
        if length(position - ray_origin) > 100.0:
            break
    
    # Return background star field
    return star_field(direction)

@njit
def accretion_disk_raymarch(ray_origin, ray_direction, bh_center, bh_radius, bh_mass):
    """
    Black hole with simple accretion disk for more visual interest.
    """
    position = ray_origin.copy()
    direction = ray_direction.copy()
    
    max_steps = 60
    step_size = 0.15
    
    accumulated_light = np.array([0.0, 0.0, 0.0])
    transmittance = 1.0
    
    for i in range(max_steps):
        distance_to_bh = length(position - bh_center)
        
        # Check if ray hits black hole
        if distance_to_bh < bh_radius:
            return accumulated_light
        
        # Simple accretion disk (torus around black hole)
        local_pos = position - bh_center
        disk_radius = length(np.array([local_pos[0], local_pos[2]]))
        
        # Disk density
        if 2.0 < disk_radius < 6.0 and abs(local_pos[1]) < 0.5:
            # Temperature gradient (inner hot, outer cool)
            temp_factor = (6.0 - disk_radius) / 4.0
            
            # Hot inner region (white/yellow)
            if disk_radius < 3.5:
                disk_color = np.array([1.0, 0.8, 0.4]) * temp_factor
            else:
                # Cooler outer region (orange/red)
                disk_color = np.array([1.0, 0.4, 0.1]) * temp_factor * 0.7
            
            # Simple noise for turbulence
            noise = simple_noise(position[0]*2, position[1]*8, position[2]*2)
            density = noise * 0.3 * temp_factor
            
            if density > 0.05:
                # Add light contribution
                scattering = density * step_size * 2.0
                accumulated_light += transmittance * disk_color * scattering
                
                # Absorb light
                transmittance *= np.exp(-density * step_size * 0.5)
                
                if transmittance < 0.01:
                    return accumulated_light
        
        # Gravitational lensing
        to_bh = position - bh_center
        dist_bh = length(to_bh)
        if dist_bh > 0.1:
            gravity_strength = bh_mass / (dist_bh * dist_bh * dist_bh)
            gravity = to_bh * (step_size * gravity_strength * 0.08)
            direction = normalize(direction - gravity)
        
        position += direction * step_size
        
        if length(position - ray_origin) > 80.0:
            break
    
    # Composite with background
    background = star_field(direction)
    return accumulated_light + background * transmittance

@njit
def generate_ray(pixel_x, pixel_y, screen_width, screen_height, 
                camera_pos, camera_target, fov=70.0):
    """Generate camera ray."""
    ndc_x = (2.0 * pixel_x / screen_width) - 1.0
    ndc_y = 1.0 - (2.0 * pixel_y / screen_height)
    
    forward = normalize(camera_target - camera_pos)
    right = normalize(np.array([
        forward[2], 0.0, -forward[0]
    ]))
    up = np.array([
        right[1]*forward[2] - right[2]*forward[1],
        right[2]*forward[0] - right[0]*forward[2], 
        right[0]*forward[1] - right[1]*forward[0]
    ])
    
    aspect = screen_width / screen_height
    fov_rad = np.deg2rad(fov)
    tan_half_fov = np.tan(fov_rad * 0.5)
    
    ray_dir = normalize(
        forward + 
        right * ndc_x * tan_half_fov * aspect +
        up * ndc_y * tan_half_fov
    )
    
    return camera_pos, ray_dir

@njit(parallel=True)
def render_frame_parallel(buffer, width, height, camera_pos, camera_target, 
                         bh_center, bh_radius, bh_mass, render_mode=1):
    """Parallel rendering for better performance."""
    for y in prange(height):
        for x in prange(width):
            ray_origin, ray_direction = generate_ray(
                x, y, width, height, camera_pos, camera_target
            )
            
            if render_mode == 0:
                color = black_hole_raymarch(ray_origin, ray_direction, 
                                          bh_center, bh_radius, bh_mass)
            else:
                color = accretion_disk_raymarch(ray_origin, ray_direction,
                                              bh_center, bh_radius, bh_mass)
            
            # Gamma correction and tone mapping
            color = np.power(np.clip(color, 0.0, 1.0), 1.0/2.2)
            
            buffer[y, x, 0] = int(color[0] * 255)
            buffer[y, x, 1] = int(color[1] * 255)
            buffer[y, x, 2] = int(color[2] * 255)

# ============================================================================
# STATIC IMAGE GENERATOR
# ============================================================================

def generate_black_hole_image(width=800, height=600, filename="black_hole.png"):
    """Generate a static black hole image."""
    print(f"Generating {width}x{height} black hole image...")
    
    buffer = np.zeros((height, width, 3), dtype=np.uint8)
    
    # Camera setup for dramatic view
    camera_pos = np.array([0.0, 3.0, 12.0])
    camera_target = np.array([0.0, 0.0, 0.0])
    
    # Black hole parameters
    bh_center = np.array([0.0, 0.0, 0.0])
    bh_radius = 1.0
    bh_mass = 5.0
    
    # Render with accretion disk
    start_time = time.time()
    render_frame_parallel(buffer, width, height, camera_pos, camera_target,
                         bh_center, bh_radius, bh_mass, render_mode=1)
    render_time = time.time() - start_time
    
    print(f"Rendered in {render_time:.2f} seconds")
    
    # Save image
    image = Image.fromarray(buffer, 'RGB')
    image.save(filename)
    print(f"Saved image: {filename}")
    
    return buffer

# ============================================================================
# INTERACTIVE DEMO
# ============================================================================

class FastBlackHoleDemo:
    """Fast black hole demo with optimizations."""
    
    def __init__(self, width=800, height=600):
        self.width = width
        self.height = height
        
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Fast Black Hole Demo")
        
        # Render at lower resolution for performance
        self.render_scale = 0.3  # Much lower for speed
        self.render_width = int(width * self.render_scale)
        self.render_height = int(height * self.render_scale)
        
        self.buffer = np.zeros((self.render_height, self.render_width, 3), dtype=np.uint8)
        self.display_buffer = np.zeros((height, width, 3), dtype=np.uint8)
        
        self.clock = pygame.time.Clock()
        
        # Camera
        self.camera_pos = np.array([0.0, 2.0, 10.0])
        self.camera_target = np.array([0.0, 0.0, 0.0])
        self.camera_speed = 3.0
        self.mouse_sensitivity = 0.003
        self.yaw = 0.0
        self.pitch = 0.2
        
        # Black hole
        self.bh_center = np.array([0.0, 0.0, 0.0])
        self.bh_radius = 1.0
        self.bh_mass = 6.0
        self.render_mode = 1  # 0=simple black hole, 1=with accretion disk
        
        # Input
        self.keys = set()
        self.mouse_locked = False
        
        # Performance tracking
        self.frame_times = []
        
        print("Fast Black Hole Demo")
        print("=" * 30)
        print("Controls:")
        print("  WASD - Move camera")
        print("  Mouse - Look around (click to lock)")
        print("  Space/Shift - Up/Down")
        print("  R - Reset camera")
        print("  1/2 - Switch render modes")
        print("  S - Save screenshot")
        print("  ESC - Exit")
        print(f"Render resolution: {self.render_width}x{self.render_height}")
    
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_r:
                    self.reset_camera()
                elif event.key == pygame.K_1:
                    self.render_mode = 0
                    print("Switched to simple black hole")
                elif event.key == pygame.K_2:
                    self.render_mode = 1
                    print("Switched to accretion disk")
                elif event.key == pygame.K_s:
                    self.save_screenshot()
                self.keys.add(event.key)
            elif event.type == pygame.KEYUP:
                self.keys.discard(event.key)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self.mouse_locked = not self.mouse_locked
                    pygame.mouse.set_visible(not self.mouse_locked)
                    if self.mouse_locked:
                        pygame.mouse.set_pos(self.width // 2, self.height // 2)
        return True
    
    def reset_camera(self):
        self.camera_pos = np.array([0.0, 2.0, 10.0])
        self.camera_target = np.array([0.0, 0.0, 0.0])
        self.yaw = 0.0
        self.pitch = 0.2
        print("Camera reset")
    
    def save_screenshot(self):
        """Save high-resolution screenshot."""
        print("Rendering high-resolution image...")
        buffer = generate_black_hole_image(1200, 900, "black_hole_screenshot.png")
        print("Screenshot saved!")
    
    def update_camera(self, dt):
        # Mouse look
        if self.mouse_locked:
            mx, my = pygame.mouse.get_pos()
            cx, cy = self.width // 2, self.height // 2
            
            if mx != cx or my != cy:
                dx = mx - cx
                dy = my - cy
                
                self.yaw += dx * self.mouse_sensitivity
                self.pitch -= dy * self.mouse_sensitivity
                self.pitch = clamp(self.pitch, -np.pi/2 + 0.1, np.pi/2 - 0.1)
                
                pygame.mouse.set_pos(cx, cy)
        
        # Calculate direction
        forward = np.array([
            np.cos(self.pitch) * np.sin(self.yaw),
            np.sin(self.pitch),
            np.cos(self.pitch) * np.cos(self.yaw)
        ])
        
        right = np.array([forward[2], 0.0, -forward[0]])
        right = right / length(right)
        up = np.array([
            right[1]*forward[2] - right[2]*forward[1],
            right[2]*forward[0] - right[0]*forward[2], 
            right[0]*forward[1] - right[1]*forward[0]
        ])
        
        # Movement
        movement = np.array([0.0, 0.0, 0.0])
        speed = self.camera_speed * dt
        
        if pygame.K_w in self.keys:
            movement += forward * speed
        if pygame.K_s in self.keys:
            movement -= forward * speed
        if pygame.K_a in self.keys:
            movement -= right * speed
        if pygame.K_d in self.keys:
            movement += right * speed
        if pygame.K_SPACE in self.keys:
            movement += up * speed
        if pygame.K_LSHIFT in self.keys:
            movement -= up * speed
        
        self.camera_pos += movement
        self.camera_target = self.camera_pos + forward
    
    def render_frame(self):
        start_time = time.time()
        
        # Render at low resolution
        render_frame_parallel(
            self.buffer, self.render_width, self.render_height,
            self.camera_pos, self.camera_target,
            self.bh_center, self.bh_radius, self.bh_mass,
            self.render_mode
        )
        
        # Upscale using nearest neighbor
        scale_factor = int(1.0 / self.render_scale)
        for y in range(self.height):
            for x in range(self.width):
                src_x = min(x // scale_factor, self.render_width - 1)
                src_y = min(y // scale_factor, self.render_height - 1)
                self.display_buffer[y, x] = self.buffer[src_y, src_x]
        
        # Display
        surface = pygame.surfarray.make_surface(self.display_buffer.swapaxes(0, 1))
        self.screen.blit(surface, (0, 0))
        
        # HUD
        render_time = time.time() - start_time
        self.frame_times.append(render_time)
        if len(self.frame_times) > 30:
            self.frame_times.pop(0)
        
        avg_frame_time = np.mean(self.frame_times)
        fps = 1.0 / avg_frame_time if avg_frame_time > 0 else 0
        
        font = pygame.font.Font(None, 24)
        fps_text = font.render(f"FPS: {fps:.1f}", True, (255, 255, 255))
        self.screen.blit(fps_text, (10, 10))
        
        mode_text = font.render(f"Mode: {'Simple' if self.render_mode == 0 else 'Accretion Disk'}", 
                               True, (255, 255, 255))
        self.screen.blit(mode_text, (10, 35))
        
        if not self.mouse_locked:
            help_text = font.render("Click to lock mouse | S - Screenshot", True, (255, 255, 0))
            self.screen.blit(help_text, (10, self.height - 30))
        
        pygame.display.flip()
    
    def run(self):
        print("Starting fast black hole demo...")
        
        running = True
        while running:
            dt = self.clock.tick(30) / 1000.0  # 30 FPS target
            
            running = self.handle_events()
            self.update_camera(dt)
            
            try:
                self.render_frame()
            except Exception as e:
                print(f"Render error: {e}")
                break
        
        pygame.quit()

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Fast Black Hole Demo")
    parser.add_argument("--static", action="store_true", 
                       help="Generate static image instead of interactive demo")
    parser.add_argument("--width", type=int, default=800, help="Image width")
    parser.add_argument("--height", type=int, default=600, help="Image height")
    parser.add_argument("--output", default="black_hole.png", help="Output filename")
    
    args = parser.parse_args()
    
    try:
        if args.static:
            generate_black_hole_image(args.width, args.height, args.output)
        else:
            demo = FastBlackHoleDemo(args.width, args.height)
            demo.run()
    except KeyboardInterrupt:
        print("\nDemo stopped by user")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
