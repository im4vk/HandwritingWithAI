"""
3D Noise generation for volumetric effects.
Implements Perlin noise and Fractal Brownian Motion matching Unity compute shader.
"""

import numpy as np
from numba import njit
from typing import Tuple
from ..rmath.vector_math import *

@njit
def perlin_hash(coord: np.ndarray, period: int) -> np.ndarray:
    """
    Generate pseudorandom gradient vector for Perlin noise.
    Implements tileable hash function for seamless noise.
    """
    # Wrap coordinates to period
    x = int(coord[0]) % period
    y = int(coord[1]) % period
    z = int(coord[2]) % period
    
    # Hash function (simplified version of Unity's approach)
    h = (x * 374761393 + y * 668265263 + z * 1274126177) & 0x7FFFFFFF
    h = (h ^ (h >> 13)) * 1274126177
    h = h ^ (h >> 16)
    
    # Convert to gradient vector on unit sphere
    theta = (h & 0xFFFF) * (2.0 * np.pi / 65536.0)
    phi = ((h >> 16) & 0xFFFF) * (np.pi / 65536.0)
    
    sin_phi = np.sin(phi)
    return np.array([
        sin_phi * np.cos(theta),
        sin_phi * np.sin(theta),
        np.cos(phi)
    ])

@njit
def quintic_fade(t: float) -> float:
    """Quintic interpolation for smooth C² continuous noise."""
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)

@njit
def trilinear_interpolate(values: np.ndarray, weights: np.ndarray) -> float:
    """Trilinear interpolation of 8 corner values."""
    # Interpolate along X axis
    c00 = lerp(values[0], values[1], weights[0])
    c01 = lerp(values[2], values[3], weights[0])
    c10 = lerp(values[4], values[5], weights[0])
    c11 = lerp(values[6], values[7], weights[0])
    
    # Interpolate along Y axis
    c0 = lerp(c00, c01, weights[1])
    c1 = lerp(c10, c11, weights[1])
    
    # Interpolate along Z axis
    return lerp(c0, c1, weights[2])

@njit
def perlin_noise_3d(position: np.ndarray, period: int) -> float:
    """
    High-quality 3D Perlin noise implementation.
    Matches Unity compute shader implementation.
    
    Args:
        position: 3D position to sample
        period: Tiling period for seamless noise
    
    Returns:
        Noise value in range [-1, 1]
    """
    # Grid coordinates
    grid_pos = np.floor(position)
    local_pos = position - grid_pos
    
    # Calculate 8 corner gradients and dot products
    dots = np.zeros(8)
    
    for i in range(8):
        # Corner offset (binary representation of i gives x,y,z offsets)
        corner_offset = np.array([
            float(i & 1),
            float((i >> 1) & 1), 
            float((i >> 2) & 1)
        ])
        
        corner_grid = grid_pos + corner_offset
        gradient = perlin_hash(corner_grid, period)
        offset = local_pos - corner_offset
        dots[i] = dot(gradient, offset)
    
    # Quintic interpolation weights
    fade_weights = np.array([
        quintic_fade(local_pos[0]),
        quintic_fade(local_pos[1]),
        quintic_fade(local_pos[2])
    ])
    
    # Trilinear interpolation
    return trilinear_interpolate(dots, fade_weights)

@njit
def fbm_3d(position: np.ndarray, octaves: int = 6, lacunarity: float = 2.0,
          persistence: float = 0.5, base_period: int = 256) -> float:
    """
    Fractal Brownian Motion using multiple octaves of Perlin noise.
    
    Args:
        position: 3D position to sample
        octaves: Number of noise octaves (1-10)
        lacunarity: Frequency multiplier between octaves
        persistence: Amplitude multiplier between octaves  
        base_period: Base tiling period
    
    Returns:
        Noise value in range [0, 1]
    """
    value = 0.0
    amplitude = 1.0
    frequency = 1.0
    total_amplitude = 0.0
    
    for i in range(octaves):
        period = int(base_period * frequency)
        noise_value = perlin_noise_3d(position * frequency, period)
        value += noise_value * amplitude
        total_amplitude += amplitude
        
        frequency *= lacunarity
        amplitude *= persistence
    
    # Normalize to [0, 1] range
    if total_amplitude > 0:
        value = value / total_amplitude
    
    return saturate(value * 0.5 + 0.5)

@njit
def noise_3d_tileable(position: np.ndarray, scale: float = 1.0, octaves: int = 6,
                     lacunarity: float = 2.0, persistence: float = 0.5,
                     tile_size: int = 256, boost: float = 1.0) -> float:
    """
    Generate tileable 3D noise matching Unity compute shader.
    
    Args:
        position: 3D position in [0, 1] range
        scale: Noise scale multiplier
        octaves: Number of noise octaves
        lacunarity: Frequency multiplier 
        persistence: Amplitude decay
        tile_size: Tiling period
        boost: Final amplitude boost
    
    Returns:
        Noise value in [0, 1] range
    """
    scaled_pos = position * scale
    noise_value = fbm_3d(scaled_pos, octaves, lacunarity, persistence, tile_size)
    
    # Apply boost and clamp
    return saturate(noise_value * boost)

# Specialized noise functions for different effects
@njit
def cloud_noise(position: np.ndarray, time: float = 0.0, 
               cloud_speed: float = 1.0, cloud_direction: np.ndarray = None) -> float:
    """
    Specialized noise for volumetric clouds with animation.
    
    Args:
        position: 3D world position
        time: Animation time
        cloud_speed: Animation speed
        cloud_direction: Wind direction
    
    Returns:
        Cloud density value [0, 1]
    """
    if cloud_direction is None:
        cloud_direction = np.array([1.0, 0.0, 0.5])
    
    # Animate position
    animated_pos = position + normalize(cloud_direction) * time * cloud_speed
    
    # Multi-octave noise for natural cloud appearance
    base_noise = fbm_3d(animated_pos * 0.5, octaves=4, persistence=0.6)
    detail_noise = fbm_3d(animated_pos * 2.0, octaves=3, persistence=0.4) * 0.3
    
    # Combine base and detail
    cloud_density = base_noise + detail_noise
    
    # Apply cloud-specific shaping
    cloud_density = saturate(cloud_density - 0.1) * 1.2
    
    return cloud_density

@njit
def accretion_disk_noise(position: np.ndarray, center: np.ndarray, 
                        inner_radius: float, outer_radius: float,
                        rotation_speed: float, time: float) -> float:
    """
    Specialized noise for black hole accretion disk.
    Implements Keplerian orbital motion and turbulence.
    
    Args:
        position: 3D world position
        center: Black hole center
        inner_radius: Inner edge of accretion disk
        outer_radius: Outer edge of accretion disk
        rotation_speed: Orbital rotation speed
        time: Animation time
    
    Returns:
        Accretion disk density [0, 1]
    """
    local_pos = position - center
    
    # Convert to cylindrical coordinates
    xz = np.array([local_pos[0], local_pos[2]])
    radius = length(xz) + 0.001  # Avoid division by zero
    theta = np.arctan2(xz[1], xz[0])
    
    # Keplerian orbital motion: v ∝ r^(-1.5)
    orbital_speed = rotation_speed / (radius ** 1.5)
    angle_offset = theta + orbital_speed * time
    
    # Create rotating coordinate system for noise sampling
    u = np.cos(angle_offset) * (radius / outer_radius) * 0.5 + 0.5
    w = np.sin(angle_offset) * (radius / outer_radius) * 0.5 + 0.5
    v = (local_pos[1] + outer_radius * 0.1) / (outer_radius * 0.2)
    
    disk_uvw = np.array([u, v, w])
    
    # Generate turbulent noise
    base_noise = fbm_3d(disk_uvw * 4.0, octaves=6, persistence=0.5)
    spiral_noise = fbm_3d(disk_uvw * np.array([8.0, 2.0, 8.0]), octaves=3, persistence=0.4)
    
    # Combine noise layers
    disk_density = base_noise * 0.7 + spiral_noise * 0.3
    
    return saturate(disk_density)

# Texture generation utilities
@njit
def generate_3d_noise_texture(resolution: int, scale: float = 1.0,
                             octaves: int = 6, lacunarity: float = 2.0,
                             persistence: float = 0.5, boost: float = 1.0) -> np.ndarray:
    """
    Generate 3D noise texture matching Unity compute shader output.
    
    Args:
        resolution: Texture resolution (cubic)
        scale: Noise scale
        octaves: Number of octaves
        lacunarity: Frequency multiplier
        persistence: Amplitude decay
        boost: Final boost multiplier
    
    Returns:
        3D texture array [resolution, resolution, resolution]
    """
    texture = np.zeros((resolution, resolution, resolution), dtype=np.float32)
    
    for z in range(resolution):
        for y in range(resolution):
            for x in range(resolution):
                # Convert to [0, 1] coordinates
                uvw = np.array([
                    (x + 0.5) / resolution,
                    (y + 0.5) / resolution, 
                    (z + 0.5) / resolution
                ])
                
                # Generate noise
                noise_value = noise_3d_tileable(
                    uvw, scale, octaves, lacunarity, persistence, resolution, boost
                )
                
                texture[z, y, x] = noise_value
    
    return texture

@njit
def sample_3d_texture_trilinear(texture: np.ndarray, uvw: np.ndarray) -> float:
    """
    Sample 3D texture with trilinear interpolation.
    
    Args:
        texture: 3D texture array
        uvw: Sample coordinates in [0, 1] range
    
    Returns:
        Interpolated texture value
    """
    resolution = texture.shape[0]
    
    # Convert to texture coordinates
    coords = uvw * (resolution - 1)
    
    # Integer coordinates
    x0 = int(np.floor(coords[0]))
    y0 = int(np.floor(coords[1]))
    z0 = int(np.floor(coords[2]))
    
    x1 = min(x0 + 1, resolution - 1)
    y1 = min(y0 + 1, resolution - 1)
    z1 = min(z0 + 1, resolution - 1)
    
    # Fractional parts
    fx = coords[0] - x0
    fy = coords[1] - y0
    fz = coords[2] - z0
    
    # Sample 8 corners
    c000 = texture[z0, y0, x0]
    c001 = texture[z0, y0, x1]
    c010 = texture[z0, y1, x0]
    c011 = texture[z0, y1, x1]
    c100 = texture[z1, y0, x0]
    c101 = texture[z1, y0, x1]
    c110 = texture[z1, y1, x0]
    c111 = texture[z1, y1, x1]
    
    # Trilinear interpolation
    c00 = lerp(c000, c001, fx)
    c01 = lerp(c010, c011, fx)
    c10 = lerp(c100, c101, fx)
    c11 = lerp(c110, c111, fx)
    
    c0 = lerp(c00, c01, fy)
    c1 = lerp(c10, c11, fy)
    
    return lerp(c0, c1, fz)
