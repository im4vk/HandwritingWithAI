"""
Volumetric rendering system implementing physically-based light transport.
Includes scattering, absorption, and multiple scattering approximation.
"""

import numpy as np
from numba import njit
from typing import Tuple, Callable, Optional
from ..rmath.vector_math import *
from ..noise_gen.noise3d import *

@njit
def henyey_greenstein_phase(cos_theta: float, g: float) -> float:
    """
    Henyey-Greenstein phase function for scattering.
    
    Args:
        cos_theta: Cosine of angle between light and view directions
        g: Anisotropy parameter (-1 to 1)
           g > 0: forward scattering
           g < 0: backward scattering  
           g = 0: isotropic scattering
    
    Returns:
        Phase function value
    """
    d = 1.0 + g * g - 2.0 * g * cos_theta
    return (1.0 - g * g) / (4.0 * np.pi * (d ** 1.5))

@njit
def double_lobed_henyey_greenstein(cos_theta: float, g_forward: float, 
                                  g_backward: float, lobe_weight: float) -> float:
    """
    Double-lobed Henyey-Greenstein phase function.
    Combines forward and backward scattering for more realistic clouds.
    
    Args:
        cos_theta: Cosine of scattering angle
        g_forward: Forward scattering parameter (typically 0.6)
        g_backward: Backward scattering parameter (typically -0.3)
        lobe_weight: Weight between lobes (typically 0.75)
    
    Returns:
        Combined phase function value
    """
    forward_phase = henyey_greenstein_phase(cos_theta, g_forward)
    backward_phase = henyey_greenstein_phase(cos_theta, g_backward)
    
    return lobe_weight * forward_phase + (1.0 - lobe_weight) * backward_phase

@njit
def compute_transmittance(position: np.ndarray, light_direction: np.ndarray,
                         density_func: Callable, shadow_step_size: float,
                         max_shadow_steps: int, extinction_coefficient: float) -> float:
    """
    Compute transmittance (shadow) from position toward light.
    Uses Beer-Lambert law: T = exp(-∫ σ(s) ds)
    
    Args:
        position: Starting position
        light_direction: Direction toward light (normalized)
        density_func: Function to sample volume density
        shadow_step_size: Step size for shadow ray
        max_shadow_steps: Maximum steps for shadow ray
        extinction_coefficient: How much light is absorbed/scattered
    
    Returns:
        Transmittance value [0, 1] (0 = full shadow, 1 = no shadow)
    """
    optical_depth = 0.0
    
    for i in range(max_shadow_steps):
        sample_pos = position - light_direction * (i * shadow_step_size)
        density = density_func(sample_pos)
        optical_depth += density * extinction_coefficient * shadow_step_size
    
    # Beer-Lambert law
    return np.exp(-optical_depth)

@njit
def sample_volume_density_clouds(position: np.ndarray, bounds_min: np.ndarray, 
                                bounds_max: np.ndarray, density_scale: float,
                                time: float, cloud_speed: float, 
                                cloud_direction: np.ndarray) -> float:
    """
    Sample cloud density using 3D noise.
    Matches Unity BoundedCloudShader implementation.
    
    Args:
        position: 3D world position
        bounds_min: Volume bounding box minimum
        bounds_max: Volume bounding box maximum
        density_scale: Overall density multiplier
        time: Animation time
        cloud_speed: Cloud movement speed
        cloud_direction: Cloud movement direction
    
    Returns:
        Density value [0, 1]
    """
    # Animate position
    animated_pos = position + cloud_direction * (time * cloud_speed)
    
    # Convert to UVW coordinates [0, 1]
    uvw = (animated_pos - bounds_min) / (bounds_max - bounds_min)
    
    # Sample 3D noise (simplified version)
    noise = cloud_noise(uvw, time, cloud_speed, cloud_direction)
    
    return density_scale * noise

@njit
def volumetric_raymarching_clouds(ray_origin: np.ndarray, ray_direction: np.ndarray,
                                 bounds_min: np.ndarray, bounds_max: np.ndarray,
                                 step_size: float, max_iterations: int,
                                 density_scale: float, extinction_factor: float,
                                 light_direction: np.ndarray, light_color: np.ndarray,
                                 light_intensity: float, shadow_step_size: float,
                                 anisotropy_forward: float, anisotropy_backward: float,
                                 lobe_weight: float, cloud_brightness: float,
                                 time: float, cloud_speed: float, 
                                 cloud_direction: np.ndarray) -> Tuple[np.ndarray, float]:
    """
    Volumetric raymarching for clouds.
    Implements physically-based light transport with multiple scattering.
    
    Args:
        ray_origin: Ray starting position
        ray_direction: Ray direction (normalized)
        bounds_min, bounds_max: Volume bounding box
        step_size: Raymarching step size
        max_iterations: Maximum raymarching steps
        density_scale: Overall density multiplier
        extinction_factor: Light extinction exponent
        light_direction: Light direction (normalized)
        light_color: Light color
        light_intensity: Light intensity
        shadow_step_size: Shadow ray step size
        anisotropy_forward: Forward scattering parameter
        anisotropy_backward: Backward scattering parameter
        lobe_weight: Phase function lobe weight
        cloud_brightness: Cloud appearance brightness
        time: Animation time
        cloud_speed: Cloud animation speed
        cloud_direction: Cloud movement direction
    
    Returns:
        (scattered_light_color, transmittance)
    """
    # Calculate ray-box intersection
    entry_dist, box_distance = ray_box_distance(bounds_min, bounds_max, ray_origin, ray_direction)
    
    if box_distance <= 0.0:
        return (np.array([0.0, 0.0, 0.0]), 1.0)
    
    # Initialize raymarching
    traveled = entry_dist
    max_traveled = entry_dist + box_distance
    
    scattered_light = np.array([0.0, 0.0, 0.0])
    transmittance = 1.0
    
    # Raymarching loop
    for i in range(max_iterations):
        if traveled >= max_traveled or transmittance < 0.01:
            break
        
        position = ray_origin + ray_direction * traveled
        
        # Sample density
        density = sample_volume_density_clouds(
            position, bounds_min, bounds_max, density_scale,
            time, cloud_speed, cloud_direction
        )
        
        if density > 0.01:
            # Calculate lighting
            light_dir = normalize(-light_direction)
            view_dir = -ray_direction
            cos_theta = dot(light_dir, view_dir)
            
            # Phase function
            phase = double_lobed_henyey_greenstein(
                cos_theta, anisotropy_forward, anisotropy_backward, lobe_weight
            )
            
            # Shadow ray (transmittance toward light)
            shadow_transmittance = compute_transmittance(
                position, light_dir,
                lambda pos: sample_volume_density_clouds(
                    pos, bounds_min, bounds_max, density_scale,
                    time, cloud_speed, cloud_direction
                ),
                shadow_step_size, 8, extinction_factor
            )
            
            # Scattering calculation
            softened_density = density ** cloud_brightness
            scattering = softened_density * step_size
            
            # Accumulate scattered light
            scattered_light += (transmittance * shadow_transmittance * 
                              light_color * light_intensity * phase * scattering)
            
            # Update transmittance (Beer-Lambert law)
            absorption = (density ** extinction_factor) * step_size
            transmittance *= np.exp(-absorption)
        
        traveled += step_size
    
    return (scattered_light, transmittance)

@njit
def sample_accretion_disk_density(position: np.ndarray, black_hole_center: np.ndarray,
                                 inner_radius: float, outer_radius: float, height: float,
                                 density_scale: float, rotation_speed: float, 
                                 base_rotation_speed: float, initial_rotation: float,
                                 vertical_fade_start: float, vertical_fade_end: float,
                                 inner_fade_radius: float, inner_fade_width: float,
                                 outer_fade_start: float, outer_fade_end: float,
                                 time: float) -> float:
    """
    Sample accretion disk density with Keplerian orbital motion.
    Matches Unity BlackholeVolumetric shader implementation.
    """
    local_pos = position - black_hole_center
    
    # Cylindrical coordinates
    xz = np.array([local_pos[0], local_pos[2]])
    radius = length(xz) + 0.001  # Avoid division by zero
    theta = np.arctan2(xz[1], xz[0])
    
    # Keplerian orbital mechanics
    orbital_speed = rotation_speed / (radius ** 1.5) + base_rotation_speed
    start_rotation = initial_rotation / (radius ** 1.5)
    angle_offset = start_rotation + theta + orbital_speed * time
    
    # Polar coordinates for noise sampling
    polar_r = radius / outer_radius
    polar_y = (local_pos[1] + height * 0.5) / height
    
    # Create rotating UVW coordinates
    u = np.cos(angle_offset) * polar_r * 0.5 + 0.5
    w = np.sin(angle_offset) * polar_r * 0.5 + 0.5
    disk_uvw = np.array([u, polar_y, w])
    
    # Sample noise
    noise = accretion_disk_noise(disk_uvw, np.array([0, 0, 0]), 0.0, 1.0, 1.0, 0.0)
    
    # Flared disk geometry (thickness increases with radius)
    radius_norm = radius / outer_radius
    thickness_at_r = height * (1.0 + np.sqrt(radius_norm) * 0.5)
    
    # Vertical fade
    y_norm = abs(local_pos[1]) / thickness_at_r
    vertical_fade = 1.0 - smoothstep(vertical_fade_start, vertical_fade_end, y_norm)
    
    # Radial fades
    inner_fade = smoothstep(inner_fade_radius, inner_fade_radius + inner_fade_width, radius_norm)
    outer_fade = 1.0 - smoothstep(outer_fade_start, outer_fade_end, radius_norm)
    radial_fade = inner_fade * outer_fade
    
    # Combine all factors
    main_density = noise * density_scale * vertical_fade * radial_fade
    
    return main_density

@njit
def volumetric_raymarching_accretion_disk(ray_origin: np.ndarray, ray_direction: np.ndarray,
                                         bounds_min: np.ndarray, bounds_max: np.ndarray,
                                         black_hole_center: np.ndarray, black_hole_radius: float,
                                         black_hole_mass: float, step_size: float, max_iterations: int,
                                         disk_params: np.ndarray, lighting_params: np.ndarray,
                                         time: float) -> Tuple[np.ndarray, float]:
    """
    Volumetric raymarching for black hole accretion disk.
    Includes gravitational lensing and Doppler effects.
    
    Args:
        ray_origin: Ray starting position
        ray_direction: Ray direction (normalized)
        bounds_min, bounds_max: Volume bounding box
        black_hole_center: Black hole position
        black_hole_radius: Black hole radius
        black_hole_mass: Black hole mass (for lensing)
        step_size: Raymarching step size
        max_iterations: Maximum raymarching steps
        disk_params: [inner_radius, outer_radius, height, density, ...]
        lighting_params: [anisotropy_forward, anisotropy_backward, lobe_weight, ...]
        time: Animation time
    
    Returns:
        (scattered_light_color, transmittance)
    """
    # Unpack parameters
    inner_radius = disk_params[0]
    outer_radius = disk_params[1]
    height = disk_params[2]
    density_scale = disk_params[3]
    
    anisotropy_forward = lighting_params[0]
    anisotropy_backward = lighting_params[1]
    lobe_weight = lighting_params[2]
    light_intensity = lighting_params[3]
    
    # Calculate ray-box intersection
    entry_dist, box_distance = ray_box_distance(bounds_min, bounds_max, ray_origin, ray_direction)
    
    if box_distance <= 0.0:
        return (np.array([0.0, 0.0, 0.0]), 1.0)
    
    # Initialize raymarching
    traveled = entry_dist
    max_traveled = entry_dist + box_distance
    position = ray_origin + ray_direction * traveled
    current_direction = ray_direction.copy()
    
    scattered_light = np.array([0.0, 0.0, 0.0])
    transmittance = 1.0
    
    # Raymarching loop with gravitational lensing
    for i in range(max_iterations):
        if traveled >= max_traveled or transmittance < 0.01:
            break
        
        # Check if inside black hole
        distance_to_bh = length(position - black_hole_center)
        if distance_to_bh < black_hole_radius:
            break
        
        # Sample density
        density = sample_accretion_disk_density(
            position, black_hole_center, inner_radius, outer_radius, height,
            density_scale, 1.0, 0.1, 1.0, 0.5, 1.0, 0.1, 0.1, 0.8, 1.0, time
        )
        
        if density > 0.01:
            # Calculate lighting toward black hole center
            light_dir = normalize(black_hole_center - position)
            view_dir = -current_direction
            cos_theta = dot(light_dir, view_dir)
            
            # Phase function
            phase = double_lobed_henyey_greenstein(
                cos_theta, anisotropy_forward, anisotropy_backward, lobe_weight
            )
            
            # Distance-based light attenuation
            light_distance_sq = distance_to_bh ** 2
            attenuation = light_intensity / (max(light_distance_sq, 0.001) * 0.06)
            
            # Temperature-based color (inner hot, outer cool)
            radius_from_center = length(position - black_hole_center)
            temp_ratio = saturate((radius_from_center - inner_radius) / (outer_radius - inner_radius))
            hot_color = np.array([2.0, 2.0, 2.0])  # White-hot
            cool_color = np.array([6.0, 12.0, 24.0])  # Blue-shifted
            sample_color = lerp_vec3(hot_color, cool_color, temp_ratio)
            
            # Doppler shift effects (simplified)
            local_pos = position - black_hole_center
            tangent_dir = normalize(np.array([-local_pos[2], 0.0, local_pos[0]]))
            orbital_velocity = 1.0 / (radius_from_center ** 1.5)
            velocity_vector = tangent_dir * orbital_velocity
            
            camera_dir = normalize(ray_origin - position)
            relative_velocity = -dot(normalize(velocity_vector), camera_dir)
            doppler_boost = max(0.0, 1.0 + 0.5 * relative_velocity)
            sample_color *= doppler_boost
            
            # Scattering calculation
            scattering = density * step_size
            
            # Accumulate scattered light
            scattered_light += (transmittance * attenuation * sample_color * 
                              phase * scattering * np.array([1.0, 0.8, 0.6]))
            
            # Update transmittance
            absorption = (density ** 1.0) * step_size
            transmittance *= np.exp(-absorption)
        
        # Gravitational lensing (simplified)
        to_black_hole = position - black_hole_center
        distance_to_bh = length(to_black_hole)
        gravity = to_black_hole * (step_size / (distance_to_bh ** 3) * black_hole_mass)
        current_direction = normalize(current_direction - gravity)
        
        # Step forward
        position += current_direction * step_size
        traveled += step_size
    
    return (scattered_light, transmittance)
