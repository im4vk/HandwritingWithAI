"""
Signed Distance Function (SDF) primitives for raymarching.
Based on Unity shader implementations with Python/Numba optimization.
"""

import numpy as np
from numba import njit
from typing import Tuple
from .vector_math import *

# SDF result structure: [color_r, color_g, color_b, distance]
SDFResult = np.ndarray  # shape (4,) - [r, g, b, distance]

@njit
def sdf_sphere(position: np.ndarray, center: np.ndarray, radius: float) -> float:
    """SDF for sphere primitive."""
    return length(position - center) - radius

@njit
def sdf_box(position: np.ndarray, center: np.ndarray, bounds: np.ndarray) -> float:
    """SDF for box primitive."""
    q = abs_vec3(position - center) - bounds
    return length(max_vec3(q, 0.0)) + min(max_component(q), 0.0)

@njit
def sdf_box_rotated(position: np.ndarray, center: np.ndarray, bounds: np.ndarray, angle_y: float) -> float:
    """SDF for rotated box primitive."""
    # Rotate position around Y axis
    cos_a = np.cos(-np.deg2rad(angle_y))
    sin_a = np.sin(-np.deg2rad(angle_y))
    
    local_pos = position - center
    rotated_pos = np.array([
        cos_a * local_pos[0] - sin_a * local_pos[2],
        local_pos[1],
        sin_a * local_pos[0] + cos_a * local_pos[2]
    ])
    
    q = abs_vec3(rotated_pos) - bounds
    return length(max_vec3(q, 0.0)) + min(max_component(q), 0.0)

@njit
def sdf_torus(position: np.ndarray, center: np.ndarray, major_radius: float, minor_radius: float) -> float:
    """SDF for torus primitive."""
    local_pos = position - center
    q_x = length(np.array([local_pos[0], local_pos[2]])) - major_radius
    q = np.array([q_x, local_pos[1]])
    return length(q) - minor_radius

@njit
def sdf_cylinder(position: np.ndarray, center: np.ndarray, radius: float, height: float) -> float:
    """SDF for cylinder primitive."""
    local_pos = position - center
    d_xz = length(np.array([local_pos[0], local_pos[2]])) - radius
    d_y = abs(local_pos[1]) - height * 0.5
    
    # Handle inside/outside cases
    return length(np.array([max(d_xz, 0.0), max(d_y, 0.0)])) + min(max(d_xz, d_y), 0.0)

@njit
def sdf_hollow_cylinder(position: np.ndarray, center: np.ndarray, 
                       inner_radius: float, outer_radius: float, height: float) -> float:
    """SDF for hollow cylinder (like accretion disk)."""
    local_pos = position - center
    radial_dist = length(np.array([local_pos[0], local_pos[2]]))
    
    dist_outer = radial_dist - outer_radius
    dist_inner = inner_radius - radial_dist
    dist_y = abs(local_pos[1]) - height * 0.5
    
    d2 = np.array([max(dist_outer, dist_inner), dist_y])
    return min(max(d2[0], d2[1]), 0.0) + length(max_vec3(np.append(d2, 0.0), 0.0))

@njit
def sdf_flared_hollow_cylinder(position: np.ndarray, center: np.ndarray,
                              inner_radius: float, outer_radius: float, base_height: float) -> float:
    """SDF for flared hollow cylinder with thickness varying by radius."""
    local_pos = position - center
    radial_dist = length(np.array([local_pos[0], local_pos[2]]))
    
    # Calculate normalized radius position
    radius_norm = saturate((radial_dist - inner_radius) / (outer_radius - inner_radius))
    
    # Flared disk: thickness increases with radius (astrophysically accurate)
    dynamic_height = base_height * (1.0 + np.sqrt(radius_norm) * 0.5)
    
    dist_outer = radial_dist - outer_radius
    dist_inner = inner_radius - radial_dist
    dist_y = abs(local_pos[1]) - dynamic_height * 0.5
    
    d2 = np.array([max(dist_outer, dist_inner), dist_y])
    return min(max(d2[0], d2[1]), 0.0) + length(max_vec3(np.append(d2, 0.0), 0.0))

@njit
def sdf_plane(position: np.ndarray, normal: np.ndarray, distance: float) -> float:
    """SDF for infinite plane."""
    return dot(position, normalize(normal)) + distance

# Boolean operations on SDFs
@njit
def sdf_union(d1: float, d2: float) -> float:
    """SDF union operation (minimum)."""
    return min(d1, d2)

@njit
def sdf_subtraction(d1: float, d2: float) -> float:
    """SDF subtraction operation."""
    return max(-d1, d2)

@njit
def sdf_intersection(d1: float, d2: float) -> float:
    """SDF intersection operation."""
    return max(d1, d2)

@njit
def sdf_smooth_min(a: float, b: float, k: float) -> float:
    """Smooth minimum for blending SDFs."""
    if k < 0.1:
        return min(a, b)
    
    h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0)
    return lerp(b, a, h) - k * h * (1.0 - h)

@njit
def sdf_smooth_min_color(sdf_a: np.ndarray, sdf_b: np.ndarray, k: float) -> np.ndarray:
    """
    Smooth minimum with color blending.
    Input: sdf_a = [r, g, b, distance], sdf_b = [r, g, b, distance]
    Output: [blended_r, blended_g, blended_b, blended_distance]
    """
    if k < 0.1:
        return sdf_a if sdf_a[3] < sdf_b[3] else sdf_b
    
    da = sdf_a[3]
    db = sdf_b[3]
    
    # Exponential weighting for smooth blending
    wa = np.exp2(-da / k)
    wb = np.exp2(-db / k)
    w_sum = wa + wb
    
    if w_sum < 1e-8:
        return sdf_a if da < db else sdf_b
    
    # Blend colors
    color = (sdf_a[:3] * wa + sdf_b[:3] * wb) / w_sum
    
    # Blend distance
    distance = -k * np.log2(w_sum)
    
    return np.array([color[0], color[1], color[2], distance])

# Complex SDF compositions
@njit
def create_sdf_result(color: np.ndarray, distance: float) -> np.ndarray:
    """Create SDF result with color and distance."""
    return np.array([color[0], color[1], color[2], distance])

@njit
def sdf_morph(sdf_a: np.ndarray, sdf_b: np.ndarray, t: float) -> np.ndarray:
    """Morph between two SDF results."""
    distance = lerp(sdf_a[3], sdf_b[3], t)
    color = lerp_vec3(sdf_a[:3], sdf_b[:3], t)
    return create_sdf_result(color, distance)

# Domain operations (position modifications)
@njit
def domain_repeat(position: np.ndarray, cell_size: float) -> np.ndarray:
    """Repeat domain for infinite patterns."""
    return mod(position + cell_size * 0.5, cell_size) - cell_size * 0.5

@njit
def domain_rotate_y(position: np.ndarray, angle: float) -> np.ndarray:
    """Rotate position around Y axis."""
    cos_a = np.cos(angle)
    sin_a = np.sin(angle)
    return np.array([
        cos_a * position[0] - sin_a * position[2],
        position[1],
        sin_a * position[0] + cos_a * position[2]
    ])

@njit
def domain_twist(position: np.ndarray, strength: float) -> np.ndarray:
    """Apply twist deformation to position."""
    angle = strength * position[1]
    cos_a = np.cos(angle)
    sin_a = np.sin(angle)
    return np.array([
        cos_a * position[0] - sin_a * position[2],
        position[1],
        sin_a * position[0] + cos_a * position[2]
    ])

# Utility functions for scene composition
@njit
def evaluate_scene_sdf(position: np.ndarray, objects: np.ndarray, colors: np.ndarray, 
                      primitives: np.ndarray) -> np.ndarray:
    """
    Evaluate complete scene SDF with multiple objects.
    
    Args:
        position: 3D position to evaluate
        objects: Array of object parameters [type, center_x, center_y, center_z, param1, param2, param3]
        colors: Array of object colors [r, g, b] 
        primitives: Array of primitive type indices
    
    Returns:
        SDF result [r, g, b, distance]
    """
    if len(objects) == 0:
        return create_sdf_result(np.array([0.0, 0.0, 0.0]), 1000.0)
    
    # Start with first object
    obj = objects[0]
    color = colors[0]
    primitive_type = int(primitives[0])
    
    if primitive_type == 0:  # Sphere
        distance = sdf_sphere(position, obj[:3], obj[3])
    elif primitive_type == 1:  # Box
        distance = sdf_box(position, obj[:3], obj[3:6])
    elif primitive_type == 2:  # Cylinder
        distance = sdf_cylinder(position, obj[:3], obj[3], obj[4])
    else:
        distance = 1000.0
    
    result = create_sdf_result(color, distance)
    
    # Combine with remaining objects
    for i in range(1, len(objects)):
        obj = objects[i]
        color = colors[i]
        primitive_type = int(primitives[i])
        
        if primitive_type == 0:  # Sphere
            distance = sdf_sphere(position, obj[:3], obj[3])
        elif primitive_type == 1:  # Box
            distance = sdf_box(position, obj[:3], obj[3:6])
        elif primitive_type == 2:  # Cylinder
            distance = sdf_cylinder(position, obj[:3], obj[3], obj[4])
        else:
            distance = 1000.0
        
        other = create_sdf_result(color, distance)
        result = sdf_smooth_min_color(result, other, 0.0)  # Hard union
    
    return result
