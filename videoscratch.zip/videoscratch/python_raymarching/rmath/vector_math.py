"""
Vector mathematics utilities for raymarching engine.
Provides core mathematical operations used throughout the raymarching system.
"""

import numpy as np
from numba import njit
from typing import Tuple, Union

# Type aliases for better readability
Vec3 = np.ndarray  # 3D vector [x, y, z]
Vec4 = np.ndarray  # 4D vector [x, y, z, w] or color [r, g, b, a]
Mat4 = np.ndarray  # 4x4 matrix

@njit
def normalize(v: np.ndarray) -> np.ndarray:
    """Normalize a vector to unit length."""
    norm = np.sqrt(np.sum(v * v))
    if norm < 1e-8:
        return v
    return v / norm

@njit
def length(v: np.ndarray) -> float:
    """Calculate the length of a vector."""
    return np.sqrt(np.sum(v * v))

@njit
def dot(a: np.ndarray, b: np.ndarray) -> float:
    """Calculate dot product of two vectors."""
    return np.sum(a * b)

@njit
def cross(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Calculate cross product of two 3D vectors."""
    return np.array([
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    ])

@njit
def reflect(incident: np.ndarray, normal: np.ndarray) -> np.ndarray:
    """Reflect a vector off a surface with given normal."""
    return incident - 2.0 * dot(incident, normal) * normal

@njit
def lerp(a: float, b: float, t: float) -> float:
    """Linear interpolation between two values."""
    return a + t * (b - a)

@njit
def lerp_vec3(a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
    """Linear interpolation between two 3D vectors."""
    return a + t * (b - a)

@njit
def clamp(value: float, min_val: float, max_val: float) -> float:
    """Clamp value between min and max."""
    return max(min_val, min(max_val, value))

@njit
def saturate(value: float) -> float:
    """Clamp value between 0 and 1."""
    return clamp(value, 0.0, 1.0)

@njit
def smoothstep(edge0: float, edge1: float, x: float) -> float:
    """Smooth interpolation between 0 and 1."""
    t = saturate((x - edge0) / (edge1 - edge0))
    return t * t * (3.0 - 2.0 * t)

@njit
def step(edge: float, x: float) -> float:
    """Step function: 0 if x < edge, 1 if x >= edge."""
    return 1.0 if x >= edge else 0.0

@njit
def fract(x: float) -> float:
    """Return fractional part of x."""
    return x - np.floor(x)

@njit
def mod(x: float, y: float) -> float:
    """Modulo operation."""
    return x - y * np.floor(x / y)

@njit
def sign(x: float) -> float:
    """Sign function: -1, 0, or 1."""
    if x > 0:
        return 1.0
    elif x < 0:
        return -1.0
    else:
        return 0.0

@njit
def abs_vec3(v: np.ndarray) -> np.ndarray:
    """Component-wise absolute value of 3D vector."""
    return np.array([abs(v[0]), abs(v[1]), abs(v[2])])

@njit
def max_vec3(v: np.ndarray, scalar: float) -> np.ndarray:
    """Component-wise maximum with scalar."""
    return np.array([max(v[0], scalar), max(v[1], scalar), max(v[2], scalar)])

@njit
def min_vec3(v: np.ndarray, scalar: float) -> np.ndarray:
    """Component-wise minimum with scalar."""
    return np.array([min(v[0], scalar), min(v[1], scalar), min(v[2], scalar)])

@njit
def max_component(v: np.ndarray) -> float:
    """Maximum component of vector."""
    return max(max(v[0], v[1]), v[2])

@njit
def min_component(v: np.ndarray) -> float:
    """Minimum component of vector."""
    return min(min(v[0], v[1]), v[2])

# Matrix operations
@njit
def mat4_identity() -> np.ndarray:
    """Create 4x4 identity matrix."""
    return np.eye(4)

@njit
def mat4_translate(translation: np.ndarray) -> np.ndarray:
    """Create translation matrix."""
    mat = np.eye(4)
    mat[0, 3] = translation[0]
    mat[1, 3] = translation[1]
    mat[2, 3] = translation[2]
    return mat

@njit
def mat4_rotate_y(angle: float) -> np.ndarray:
    """Create rotation matrix around Y axis."""
    cos_a = np.cos(angle)
    sin_a = np.sin(angle)
    mat = np.eye(4)
    mat[0, 0] = cos_a
    mat[0, 2] = sin_a
    mat[2, 0] = -sin_a
    mat[2, 2] = cos_a
    return mat

@njit
def mat4_rotate_x(angle: float) -> np.ndarray:
    """Create rotation matrix around X axis."""
    cos_a = np.cos(angle)
    sin_a = np.sin(angle)
    mat = np.eye(4)
    mat[1, 1] = cos_a
    mat[1, 2] = -sin_a
    mat[2, 1] = sin_a
    mat[2, 2] = cos_a
    return mat

@njit
def mat4_scale(scale: np.ndarray) -> np.ndarray:
    """Create scale matrix."""
    mat = np.eye(4)
    mat[0, 0] = scale[0]
    mat[1, 1] = scale[1]
    mat[2, 2] = scale[2]
    return mat

@njit
def mat4_multiply(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Multiply two 4x4 matrices."""
    return np.dot(a, b)

@njit
def mat4_transform_point(mat: np.ndarray, point: np.ndarray) -> np.ndarray:
    """Transform 3D point by 4x4 matrix."""
    p4 = np.array([point[0], point[1], point[2], 1.0])
    result = np.dot(mat, p4)
    return result[:3] / result[3]

@njit
def mat4_transform_vector(mat: np.ndarray, vector: np.ndarray) -> np.ndarray:
    """Transform 3D vector by 4x4 matrix (w=0)."""
    v4 = np.array([vector[0], vector[1], vector[2], 0.0])
    result = np.dot(mat, v4)
    return result[:3]

# Camera frustum calculations
@njit
def calculate_frustum_corners(fov: float, aspect: float) -> np.ndarray:
    """Calculate the four corners of camera frustum."""
    fov_rad = np.deg2rad(fov * 0.5)
    tan_fov = np.tan(fov_rad)
    
    # Calculate frustum vectors
    up = np.array([0.0, 1.0, 0.0]) * tan_fov
    right = np.array([1.0, 0.0, 0.0]) * tan_fov * aspect
    forward = np.array([0.0, 0.0, -1.0])
    
    # Four corners of frustum
    corners = np.zeros((4, 3))
    corners[0] = forward - right + up    # top left
    corners[1] = forward + right + up    # top right  
    corners[2] = forward + right - up    # bottom right
    corners[3] = forward - right - up    # bottom left
    
    return corners

# Color utilities
@njit
def rgb_to_vec3(r: int, g: int, b: int) -> np.ndarray:
    """Convert RGB integers (0-255) to float vector (0-1)."""
    return np.array([r / 255.0, g / 255.0, b / 255.0])

@njit
def vec3_to_rgb(color: np.ndarray) -> Tuple[int, int, int]:
    """Convert float color vector to RGB integers."""
    r = int(clamp(color[0], 0.0, 1.0) * 255)
    g = int(clamp(color[1], 0.0, 1.0) * 255)
    b = int(clamp(color[2], 0.0, 1.0) * 255)
    return (r, g, b)

@njit
def gamma_correct(color: np.ndarray, gamma: float = 2.2) -> np.ndarray:
    """Apply gamma correction to color."""
    return np.power(color, 1.0 / gamma)

@njit
def tone_map_reinhard(color: np.ndarray) -> np.ndarray:
    """Apply Reinhard tone mapping."""
    return color / (1.0 + color)

# Ray-box intersection
@njit
def ray_box_distance(box_min: np.ndarray, box_max: np.ndarray, 
                    ray_origin: np.ndarray, ray_direction: np.ndarray) -> Tuple[float, float]:
    """
    Calculate ray-box intersection distances.
    Returns (entry_distance, exit_distance).
    """
    # Avoid division by zero
    inv_dir = np.where(np.abs(ray_direction) < 1e-8, 
                      np.full(3, 1e8), 1.0 / ray_direction)
    
    t0 = (box_min - ray_origin) * inv_dir
    t1 = (box_max - ray_origin) * inv_dir
    
    t_min = np.minimum(t0, t1)
    t_max = np.maximum(t0, t1)
    
    entry = max(max(t_min[0], t_min[1]), t_min[2])
    exit = min(min(t_max[0], t_max[1]), t_max[2])
    
    # Check if ray is inside box
    inside = np.all(ray_origin >= box_min) and np.all(ray_origin <= box_max)
    if inside:
        entry = 0.0
    
    distance_in_box = max(0.0, exit - entry)
    return (max(0.0, entry), distance_in_box)
