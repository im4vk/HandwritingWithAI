#!/usr/bin/env python3
"""
Standalone runner for Python Raymarching Engine.
This version can be run directly without module imports.
"""

import pygame
import numpy as np
import argparse
import time
import sys
import os
from typing import Tuple, Optional
from numba import njit, prange

# Add current directory to path for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Import our modules (absolute imports for standalone)
from rmath.vector_math import *

# Import scene classes individually to avoid relative import issues
from scenes.demo_scenes import (
    BasicRaymarchingScene, VolumetricCloudsScene, 
    SimpleBlackHoleScene, ComplexBlackHoleScene, create_scene
)

class RaymarchingApp:
    """Main application class for raymarching demos."""
    
    def __init__(self, width: int = 800, height: int = 600, scene_name: str = "basic_raymarching"):
        self.width = width
        self.height = height
        self.scene_name = scene_name
        
        # Initialize pygame
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(f"Python Raymarching - {scene_name}")
        
        # Create render buffer
        self.buffer = np.zeros((height, width, 3), dtype=np.uint8)
        
        # Load scene
        self.scene = create_scene(scene_name)
        print(f"Loaded scene: {self.scene.name}")
        
        # Camera controls
        self.camera_speed = 2.0
        self.mouse_sensitivity = 0.002
        self.camera_yaw = 0.0
        self.camera_pitch = 0.0
        
        # Timing
        self.clock = pygame.time.Clock()
        self.start_time = time.time()
        self.frame_count = 0
        self.last_fps_time = time.time()
        
        # Input state
        self.keys_pressed = set()
        self.mouse_locked = False
        
        # Rendering parameters
        self.render_scale = 1.0  # Can reduce for performance
        self.max_fps = 60
        
        print("Controls:")
        print("  WASD - Move camera")
        print("  Mouse - Look around")
        print("  Space/Shift - Up/Down")
        print("  R - Reset camera")
        print("  1-4 - Switch scenes")
        print("  ESC - Exit")
        print("  Click to lock/unlock mouse")
    
    def handle_events(self) -> bool:
        """Handle pygame events. Returns False if should quit."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_r:
                    self.reset_camera()
                elif event.key == pygame.K_1:
                    self.switch_scene("basic_raymarching")
                elif event.key == pygame.K_2:
                    self.switch_scene("volumetric_clouds")
                elif event.key == pygame.K_3:
                    self.switch_scene("simple_blackhole")
                elif event.key == pygame.K_4:
                    self.switch_scene("complex_blackhole")
                else:
                    self.keys_pressed.add(event.key)
            
            elif event.type == pygame.KEYUP:
                self.keys_pressed.discard(event.key)
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left click
                    self.toggle_mouse_lock()
        
        return True
    
    def toggle_mouse_lock(self):
        """Toggle mouse lock for camera control."""
        self.mouse_locked = not self.mouse_locked
        pygame.mouse.set_visible(not self.mouse_locked)
        if self.mouse_locked:
            pygame.mouse.set_pos(self.width // 2, self.height // 2)
    
    def switch_scene(self, scene_name: str):
        """Switch to a different demo scene."""
        try:
            self.scene = create_scene(scene_name)
            self.scene_name = scene_name
            pygame.display.set_caption(f"Python Raymarching - {scene_name}")
            print(f"Switched to scene: {self.scene.name}")
            self.reset_camera()
        except ValueError as e:
            print(f"Error switching scene: {e}")
    
    def reset_camera(self):
        """Reset camera to default position."""
        if hasattr(self.scene, 'camera_position'):
            # Reset camera to scene defaults
            pass
        self.camera_yaw = 0.0
        self.camera_pitch = 0.0
        print("Camera reset")
    
    def update_camera(self, dt: float):
        """Update camera position and orientation."""
        # Mouse look
        if self.mouse_locked:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            center_x, center_y = self.width // 2, self.height // 2
            
            if mouse_x != center_x or mouse_y != center_y:
                dx = mouse_x - center_x
                dy = mouse_y - center_y
                
                self.camera_yaw += dx * self.mouse_sensitivity
                self.camera_pitch -= dy * self.mouse_sensitivity
                
                # Clamp pitch
                self.camera_pitch = clamp(self.camera_pitch, -np.pi/2 + 0.1, np.pi/2 - 0.1)
                
                pygame.mouse.set_pos(center_x, center_y)
        
        # Calculate camera direction vectors
        forward = np.array([
            np.cos(self.camera_pitch) * np.sin(self.camera_yaw),
            np.sin(self.camera_pitch),
            np.cos(self.camera_pitch) * np.cos(self.camera_yaw)
        ])
        
        right = cross(forward, np.array([0.0, 1.0, 0.0]))
        up = cross(right, forward)
        
        # Movement
        movement = np.array([0.0, 0.0, 0.0])
        speed = self.camera_speed * dt
        
        if pygame.K_w in self.keys_pressed:
            movement += forward * speed
        if pygame.K_s in self.keys_pressed:
            movement -= forward * speed
        if pygame.K_a in self.keys_pressed:
            movement -= right * speed
        if pygame.K_d in self.keys_pressed:
            movement += right * speed
        if pygame.K_SPACE in self.keys_pressed:
            movement += up * speed
        if pygame.K_LSHIFT in self.keys_pressed:
            movement -= up * speed
        
        # Apply movement
        self.scene.camera_position += movement
        self.scene.camera_target = self.scene.camera_position + forward
    
    def render_frame(self):
        """Render a single frame."""
        current_time = time.time() - self.start_time
        
        # Choose appropriate render function based on scene
        if isinstance(self.scene, VolumetricCloudsScene):
            render_func = lambda x, y, w, h, t: self.scene.render_pixel_volumetric(x, y, w, h, t)
        elif isinstance(self.scene, SimpleBlackHoleScene):
            render_func = lambda x, y, w, h, t: self.scene.render_pixel_gravitational(x, y, w, h)
        elif isinstance(self.scene, ComplexBlackHoleScene):
            render_func = lambda x, y, w, h, t: self.scene.render_pixel_complex_blackhole(x, y, w, h, t)
        else:
            render_func = lambda x, y, w, h, t: self.scene.render_pixel(x, y, w, h)
        
        # Render with reduced resolution for performance if needed
        render_width = int(self.width * self.render_scale)
        render_height = int(self.height * self.render_scale)
        
        if self.render_scale < 1.0:
            render_buffer = np.zeros((render_height, render_width, 3), dtype=np.uint8)
        else:
            render_buffer = self.buffer
        
        # Render each pixel
        # For performance in first version, use simple loop
        # This could be optimized with threading or numba parallel processing
        for y in range(render_height):
            for x in range(render_width):
                try:
                    color = render_func(x, y, render_width, render_height, current_time)
                    
                    # Gamma correction and tone mapping
                    color = gamma_correct(color, 2.2)
                    color = np.clip(color, 0.0, 1.0)
                    
                    # Convert to RGB
                    r, g, b = vec3_to_rgb(color)
                    render_buffer[y, x, 0] = r
                    render_buffer[y, x, 1] = g
                    render_buffer[y, x, 2] = b
                    
                except Exception as e:
                    # Fallback to magenta for errors
                    render_buffer[y, x] = [255, 0, 255]
        
        # Scale up if needed
        if self.render_scale < 1.0:
            # Simple nearest-neighbor upscaling
            for y in range(self.height):
                for x in range(self.width):
                    src_x = int(x * self.render_scale)
                    src_y = int(y * self.render_scale)
                    src_x = min(src_x, render_width - 1)
                    src_y = min(src_y, render_height - 1)
                    self.buffer[y, x] = render_buffer[src_y, src_x]
        
        # Convert to pygame surface and display
        surface = pygame.surfarray.make_surface(self.buffer.swapaxes(0, 1))
        self.screen.blit(surface, (0, 0))
        
        # Display FPS and scene info
        self.display_hud()
        
        pygame.display.flip()
        self.frame_count += 1
    
    def display_hud(self):
        """Display HUD information."""
        current_time = time.time()
        if current_time - self.last_fps_time >= 1.0:
            fps = self.frame_count / (current_time - self.last_fps_time)
            self.last_fps_time = current_time
            self.frame_count = 0
            
            # Simple text overlay (basic approach)
            font_size = 20
            try:
                font = pygame.font.Font(None, font_size)
                
                # FPS
                fps_text = font.render(f"FPS: {fps:.1f}", True, (255, 255, 255))
                self.screen.blit(fps_text, (10, 10))
                
                # Scene name
                scene_text = font.render(f"Scene: {self.scene.name}", True, (255, 255, 255))
                self.screen.blit(scene_text, (10, 35))
                
                # Instructions
                if not self.mouse_locked:
                    help_text = font.render("Click to lock mouse for camera control", True, (255, 255, 0))
                    self.screen.blit(help_text, (10, self.height - 25))
                
            except:
                # If font rendering fails, just skip HUD
                pass
    
    def run(self):
        """Main application loop."""
        print(f"Starting raymarching engine...")
        print(f"Resolution: {self.width}x{self.height}")
        print(f"Scene: {self.scene.name}")
        
        running = True
        while running:
            dt = self.clock.tick(self.max_fps) / 1000.0  # Delta time in seconds
            
            # Handle events
            running = self.handle_events()
            
            # Update
            self.update_camera(dt)
            
            # Render
            try:
                self.render_frame()
            except Exception as e:
                print(f"Render error: {e}")
                # Continue running but with error indication
        
        pygame.quit()
        print("Raymarching engine stopped.")

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Python Raymarching Engine")
    parser.add_argument("--scene", choices=["basic_raymarching", "volumetric_clouds", 
                                          "simple_blackhole", "complex_blackhole"],
                       default="basic_raymarching", help="Demo scene to load")
    parser.add_argument("--width", type=int, default=800, help="Window width")
    parser.add_argument("--height", type=int, default=600, help="Window height")
    parser.add_argument("--scale", type=float, default=0.5, 
                       help="Render scale (0.5 = half resolution for performance)")
    
    args = parser.parse_args()
    
    try:
        app = RaymarchingApp(args.width, args.height, args.scene)
        app.render_scale = args.scale
        app.run()
    except KeyboardInterrupt:
        print("\nInterrupted by user")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
