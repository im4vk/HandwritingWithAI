"""
Demo scenes matching Unity raymarching project.
Four progressive demos: Basic raymarching → Clouds → Simple black hole → Complex black hole
"""

import numpy as np
from numba import njit
from typing import Tuple, Callable
from ..rmath.vector_math import *
from ..rmath.sdf_primitives import *
from ..core.raymarching import *
from ..rendering.volumetric import *
from ..noise_gen.noise3d import *

class SceneBase:
    """Base class for all demo scenes."""
    
    def __init__(self, name: str):
        self.name = name
        self.camera_position = np.array([0.0, 0.0, 5.0])
        self.camera_target = np.array([0.0, 0.0, 0.0])
        self.camera_up = np.array([0.0, 1.0, 0.0])
        self.fov = 60.0
        
        # Raymarching parameters
        self.max_distance = 100.0
        self.max_iterations = 128
        self.accuracy = 0.001
        
        # Lighting
        self.light_direction = normalize(np.array([0.0, -1.0, -1.0]))
        self.light_color = np.array([1.0, 1.0, 1.0])
        self.light_intensity = 1.0
        
        # Render settings
        self.color_enabled = True
        self.shadow_enabled = True
        self.background_enabled = True
    
    def get_sdf_function(self):
        """Override in subclasses to define scene geometry."""
        raise NotImplementedError
    
    def render_pixel(self, pixel_x: int, pixel_y: int, screen_width: int, screen_height: int) -> np.ndarray:
        """Render a single pixel for this scene."""
        return render_pixel(
            pixel_x, pixel_y, screen_width, screen_height,
            self.camera_position, self.camera_target, self.camera_up, self.fov,
            self.get_sdf_function(), self.light_direction, self.light_color,
            self.light_intensity, self.max_distance, self.max_iterations,
            self.accuracy, self.shadow_enabled, self.color_enabled, self.background_enabled
        )

class BasicRaymarchingScene(SceneBase):
    """Demo 1: Basic raymarching with simple primitives."""
    
    def __init__(self):
        super().__init__("Basic Raymarching")
        
        # Scene objects
        self.sphere1_pos = np.array([0.0, 0.0, 0.0])
        self.sphere1_radius = 1.0
        self.sphere1_color = np.array([1.0, 0.3, 0.3])
        
        self.sphere2_pos = np.array([2.5, 0.5, -1.0])
        self.sphere2_radius = 0.8
        self.sphere2_color = np.array([0.3, 1.0, 0.3])
        
        self.box1_pos = np.array([-2.0, 0.0, 0.0])
        self.box1_bounds = np.array([0.8, 1.2, 0.6])
        self.box1_color = np.array([0.3, 0.3, 1.0])
        
        self.box2_pos = np.array([0.0, -1.5, 1.5])
        self.box2_bounds = np.array([1.5, 0.3, 1.0])
        self.box2_rotation = 200.0
        self.box2_color = np.array([1.0, 1.0, 0.3])
        
        self.ground_y = -2.0
        self.ground_color = np.array([0.6, 0.6, 0.6])
    
    @njit
    def scene_sdf(self, position: np.ndarray) -> np.ndarray:
        """SDF function for basic raymarching scene."""
        # Sphere 1
        sphere1 = create_sdf_result(
            np.array([1.0, 0.3, 0.3]),
            sdf_sphere(position, np.array([0.0, 0.0, 0.0]), 1.0)
        )
        
        # Sphere 2  
        sphere2 = create_sdf_result(
            np.array([0.3, 1.0, 0.3]),
            sdf_sphere(position, np.array([2.5, 0.5, -1.0]), 0.8)
        )
        
        # Box 1
        box1 = create_sdf_result(
            np.array([0.3, 0.3, 1.0]),
            sdf_box(position, np.array([-2.0, 0.0, 0.0]), np.array([0.8, 1.2, 0.6]))
        )
        
        # Box 2 (rotated)
        box2 = create_sdf_result(
            np.array([1.0, 1.0, 0.3]),
            sdf_box_rotated(position, np.array([0.0, -1.5, 1.5]), 
                           np.array([1.5, 0.3, 1.0]), 200.0)
        )
        
        # Ground plane
        ground = create_sdf_result(
            np.array([0.6, 0.6, 0.6]),
            sdf_plane(position, np.array([0.0, 1.0, 0.0]), 2.0)
        )
        
        # Combine all objects
        result = sdf_smooth_min_color(sphere1, sphere2, 0.0)
        result = sdf_smooth_min_color(result, box1, 0.0)
        result = sdf_smooth_min_color(result, box2, 0.0)
        result = sdf_smooth_min_color(result, ground, 0.0)
        
        return result
    
    def get_sdf_function(self):
        return self.scene_sdf

class VolumetricCloudsScene(SceneBase):
    """Demo 2: Volumetric cloud rendering."""
    
    def __init__(self):
        super().__init__("Volumetric Clouds")
        
        # Position camera for good cloud view
        self.camera_position = np.array([0.0, 0.0, 8.0])
        
        # Cloud volume bounds
        self.bounds_min = np.array([-4.0, -2.0, -4.0])
        self.bounds_max = np.array([4.0, 2.0, 4.0])
        
        # Cloud parameters
        self.density = 1.0
        self.step_size = 0.1
        self.max_iterations = 64
        self.extinction_factor = 1.0
        
        # Lighting for clouds
        self.light_direction = normalize(np.array([0.3, -0.7, -0.5]))
        self.light_color = np.array([1.0, 0.95, 0.8])
        self.light_intensity = 2.0
        self.shadow_step_size = 0.3
        
        # Scattering parameters
        self.anisotropy_forward = 0.6
        self.anisotropy_backward = -0.3
        self.lobe_weight = 0.75
        self.cloud_brightness = 1.0
        
        # Animation
        self.cloud_speed = 0.5
        self.cloud_direction = normalize(np.array([1.0, 0.0, 0.3]))
    
    def render_pixel_volumetric(self, pixel_x: int, pixel_y: int, 
                               screen_width: int, screen_height: int, time: float) -> np.ndarray:
        """Render pixel with volumetric clouds."""
        ray_origin, ray_direction = generate_camera_ray(
            pixel_x, pixel_y, screen_width, screen_height,
            self.camera_position, self.camera_target, self.camera_up, self.fov
        )
        
        # Volumetric raymarching
        scattered_light, transmittance = volumetric_raymarching_clouds(
            ray_origin, ray_direction, self.bounds_min, self.bounds_max,
            self.step_size, self.max_iterations, self.density, self.extinction_factor,
            self.light_direction, self.light_color, self.light_intensity,
            self.shadow_step_size, self.anisotropy_forward, self.anisotropy_backward,
            self.lobe_weight, self.cloud_brightness, time, self.cloud_speed, self.cloud_direction
        )
        
        # Background (sky gradient)
        background = np.array([0.2, 0.4, 0.8]) * (1.0 - abs(ray_direction[1]) * 0.5)
        
        # Composite
        final_color = background * transmittance + scattered_light
        
        return final_color

class SimpleBlackHoleScene(SceneBase):
    """Demo 3: Simple black hole with gravitational lensing (no accretion disk)."""
    
    def __init__(self):
        super().__init__("Simple Black Hole")
        
        # Position camera
        self.camera_position = np.array([0.0, 0.0, 10.0])
        
        # Black hole parameters
        self.black_hole_center = np.array([0.0, 0.0, 0.0])
        self.black_hole_radius = 1.0
        self.black_hole_mass = 5.0
        self.black_hole_color = np.array([0.0, 0.0, 0.0])
        
        # Background stars/nebula (simulated with noise)
        self.use_background_stars = True
    
    @njit
    def scene_sdf_blackhole(self, position: np.ndarray) -> np.ndarray:
        """SDF for simple black hole scene."""
        # Black hole sphere
        black_hole = create_sdf_result(
            np.array([0.0, 0.0, 0.0]),
            sdf_sphere(position, np.array([0.0, 0.0, 0.0]), 1.0)
        )
        
        return black_hole
    
    def render_pixel_gravitational(self, pixel_x: int, pixel_y: int,
                                 screen_width: int, screen_height: int) -> np.ndarray:
        """Render pixel with gravitational lensing."""
        ray_origin, ray_direction = generate_camera_ray(
            pixel_x, pixel_y, screen_width, screen_height,
            self.camera_position, self.camera_target, self.camera_up, self.fov
        )
        
        # Gravitational lensing raymarching
        position = ray_origin.copy()
        direction = ray_direction.copy()
        traveled = 0.0
        
        for i in range(self.max_iterations):
            if traveled > self.max_distance:
                break
            
            # Check if ray hits black hole
            distance_to_bh = length(position - self.black_hole_center)
            if distance_to_bh < self.black_hole_radius:
                return self.black_hole_color
            
            # Gravitational lensing
            to_bh = position - self.black_hole_center
            dist_bh = length(to_bh)
            gravity = to_bh * (0.1 / (dist_bh ** 3) * self.black_hole_mass)
            direction = normalize(direction - gravity)
            
            # Step forward
            step_size = 0.1
            position += direction * step_size
            traveled += step_size
        
        # Background: simple star field simulation
        if self.use_background_stars:
            # Use final ray direction for background sampling
            star_noise = fbm_3d(direction * 10.0, octaves=4, persistence=0.6)
            if star_noise > 0.8:
                star_brightness = (star_noise - 0.8) * 5.0
                return np.array([1.0, 1.0, 1.0]) * star_brightness
            else:
                # Nebula colors
                nebula_noise = fbm_3d(direction * 5.0, octaves=3, persistence=0.4)
                nebula_color = np.array([0.1, 0.2, 0.6]) * nebula_noise
                return nebula_color
        
        return np.array([0.01, 0.01, 0.05])  # Dark space
    
    def get_sdf_function(self):
        return self.scene_sdf_blackhole

class ComplexBlackHoleScene(SceneBase):
    """Demo 4: Complex black hole with volumetric accretion disk."""
    
    def __init__(self):
        super().__init__("Complex Black Hole with Accretion Disk")
        
        # Position camera
        self.camera_position = np.array([0.0, 2.0, 8.0])
        
        # Black hole parameters
        self.black_hole_center = np.array([0.0, 0.0, 0.0])
        self.black_hole_radius = 1.0
        self.black_hole_mass = 8.0
        self.black_hole_color = np.array([0.0, 0.0, 0.0])
        
        # Accretion disk parameters
        self.disk_inner_radius = 2.0
        self.disk_outer_radius = 8.0
        self.disk_height = 1.0
        self.disk_density = 0.5
        
        # Disk bounds for volumetric rendering
        self.bounds_min = np.array([-10.0, -2.0, -10.0])
        self.bounds_max = np.array([10.0, 2.0, 10.0])
        
        # Volumetric parameters
        self.step_size = 0.05  # Smaller steps for quality
        self.max_iterations = 256  # More steps for complexity
        
        # Scattering parameters
        self.anisotropy_forward = 0.6
        self.anisotropy_backward = -0.2
        self.lobe_weight = 0.8
        self.light_intensity = 3.0
        
        # Animation parameters
        self.rotation_speed = 1.0
        self.base_rotation_speed = 0.1
        self.initial_rotation = 1.0
        
        # Fade parameters for realistic disk structure
        self.vertical_fade_start = 0.5
        self.vertical_fade_end = 1.0
        self.inner_fade_radius = 0.1
        self.inner_fade_width = 0.1
        self.outer_fade_start = 0.8
        self.outer_fade_end = 1.0
        
        # Temperature and Doppler effects
        self.light_falloff = 2.0
        self.doppler_strength = 0.5
    
    @njit
    def scene_sdf_complex_blackhole(self, position: np.ndarray) -> np.ndarray:
        """SDF for complex black hole scene with accretion disk."""
        # Black hole
        black_hole = create_sdf_result(
            np.array([0.0, 0.0, 0.0]),
            sdf_sphere(position, np.array([0.0, 0.0, 0.0]), 1.0)
        )
        
        # Accretion disk geometry (for SDF intersection testing)
        disk = create_sdf_result(
            np.array([1.0, 0.5, 0.2]),  # Orange-ish color
            sdf_flared_hollow_cylinder(position, np.array([0.0, 0.0, 0.0]), 
                                     2.0, 8.0, 1.0)
        )
        
        return sdf_smooth_min_color(black_hole, disk, 0.0)
    
    def render_pixel_complex_blackhole(self, pixel_x: int, pixel_y: int,
                                     screen_width: int, screen_height: int, 
                                     time: float) -> np.ndarray:
        """Render pixel with complex black hole and accretion disk."""
        ray_origin, ray_direction = generate_camera_ray(
            pixel_x, pixel_y, screen_width, screen_height,
            self.camera_position, self.camera_target, self.camera_up, self.fov
        )
        
        # Parameters for volumetric rendering
        disk_params = np.array([
            self.disk_inner_radius, self.disk_outer_radius, self.disk_height, self.disk_density,
            self.rotation_speed, self.base_rotation_speed, self.initial_rotation,
            self.vertical_fade_start, self.vertical_fade_end,
            self.inner_fade_radius, self.inner_fade_width,
            self.outer_fade_start, self.outer_fade_end,
            self.light_falloff, self.doppler_strength
        ])
        
        lighting_params = np.array([
            self.anisotropy_forward, self.anisotropy_backward, 
            self.lobe_weight, self.light_intensity
        ])
        
        # Volumetric raymarching with gravitational effects
        scattered_light, transmittance = volumetric_raymarching_accretion_disk(
            ray_origin, ray_direction, self.bounds_min, self.bounds_max,
            self.black_hole_center, self.black_hole_radius, self.black_hole_mass,
            self.step_size, self.max_iterations, disk_params, lighting_params, time
        )
        
        # Background (star field with lensing)
        if transmittance > 0.01:
            # Simple star field
            star_noise = fbm_3d(ray_direction * 8.0, octaves=3, persistence=0.5)
            if star_noise > 0.85:
                star_brightness = (star_noise - 0.85) * 6.0
                background = np.array([1.0, 0.9, 0.8]) * star_brightness
            else:
                # Distant nebula
                nebula_noise = fbm_3d(ray_direction * 3.0, octaves=2, persistence=0.3)
                background = np.array([0.05, 0.1, 0.3]) * nebula_noise
        else:
            background = np.array([0.0, 0.0, 0.0])
        
        # Composite final image
        final_color = background * transmittance + scattered_light
        
        # Tone mapping for HDR-like appearance
        final_color = tone_map_reinhard(final_color)
        
        return final_color
    
    def get_sdf_function(self):
        return self.scene_sdf_complex_blackhole

# Scene factory
def create_scene(scene_name: str) -> SceneBase:
    """Create a scene by name."""
    scenes = {
        "basic_raymarching": BasicRaymarchingScene,
        "volumetric_clouds": VolumetricCloudsScene,
        "simple_blackhole": SimpleBlackHoleScene,
        "complex_blackhole": ComplexBlackHoleScene
    }
    
    if scene_name not in scenes:
        raise ValueError(f"Unknown scene: {scene_name}. Available: {list(scenes.keys())}")
    
    return scenes[scene_name]()
