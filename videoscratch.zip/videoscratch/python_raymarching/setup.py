#!/usr/bin/env python3
"""
Setup and installation script for Python Raymarching Engine.
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages."""
    print("Installing required packages...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✓ Requirements installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"✗ Error installing requirements: {e}")
        return False

def test_imports():
    """Test if all modules can be imported."""
    print("Testing module imports...")
    
    test_modules = [
        ("numpy", "NumPy"),
        ("pygame", "Pygame"),
        ("numba", "Numba"),
        ("PIL", "Pillow"),
        ("noise", "Noise"),
        ("scipy", "SciPy"),
        ("matplotlib", "Matplotlib")
    ]
    
    all_good = True
    for module_name, display_name in test_modules:
        try:
            __import__(module_name)
            print(f"  ✓ {display_name}")
        except ImportError:
            print(f"  ✗ {display_name} - Not found")
            all_good = False
    
    return all_good

def test_numba_compilation():
    """Test if Numba JIT compilation works."""
    print("Testing Numba JIT compilation...")
    try:
        from numba import njit
        import numpy as np
        
        @njit
        def test_function(x):
            return x * 2 + 1
        
        # Trigger compilation
        result = test_function(5.0)
        if abs(result - 11.0) < 1e-6:
            print("  ✓ Numba JIT compilation working")
            return True
        else:
            print("  ✗ Numba JIT compilation - unexpected result")
            return False
    except Exception as e:
        print(f"  ✗ Numba JIT compilation - Error: {e}")
        return False

def create_launch_script():
    """Create convenience launch script."""
    script_content = """#!/usr/bin/env python3
\"\"\"Convenience launcher for Python Raymarching Engine.\"\"\"

import sys
import os

# Add current directory to path so we can import our modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import main

if __name__ == "__main__":
    main()
"""
    
    try:
        with open("run.py", "w") as f:
            f.write(script_content)
        
        # Make executable on Unix systems
        if hasattr(os, 'chmod'):
            os.chmod("run.py", 0o755)
        
        print("✓ Created launch script 'run.py'")
        return True
    except Exception as e:
        print(f"✗ Error creating launch script: {e}")
        return False

def main():
    """Main setup function."""
    print("=" * 60)
    print("Python Raymarching Engine - Setup")
    print("=" * 60)
    
    success = True
    
    # Install requirements
    if not install_requirements():
        success = False
    
    print()
    
    # Test imports
    if not test_imports():
        success = False
    
    print()
    
    # Test Numba
    if not test_numba_compilation():
        success = False
    
    print()
    
    # Create launch script
    if not create_launch_script():
        success = False
    
    print()
    print("=" * 60)
    
    if success:
        print("✓ Setup completed successfully!")
        print()
        print("Usage:")
        print("  python main.py                    # Run basic raymarching demo")
        print("  python main.py --scene volumetric_clouds")
        print("  python main.py --scene simple_blackhole") 
        print("  python main.py --scene complex_blackhole")
        print("  python run.py                     # Use convenience launcher")
        print()
        print("  python main.py --help             # Show all options")
    else:
        print("✗ Setup encountered some issues.")
        print("Please check the error messages above and resolve them.")
        sys.exit(1)

if __name__ == "__main__":
    main()
