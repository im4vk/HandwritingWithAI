#!/usr/bin/env python3
"""
Simple self-contained raymarching demo.
Contains essential functionality without complex imports.
"""

import pygame
import numpy as np
import time
import sys
from numba import njit

# ============================================================================
# VECTOR MATH UTILITIES
# ============================================================================

@njit
def length(v):
    """Calculate vector length."""
    return np.sqrt(np.sum(v * v))

@njit
def normalize(v):
    """Normalize vector to unit length."""
    norm = length(v)
    if norm < 1e-8:
        return v
    return v / norm

@njit
def dot(a, b):
    """Dot product."""
    return np.sum(a * b)

@njit
def cross(a, b):
    """Cross product."""
    return np.array([
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    ])

@njit
def clamp(value, min_val, max_val):
    """Clamp value between min and max."""
    return max(min_val, min(max_val, value))

@njit
def smoothstep(edge0, edge1, x):
    """Smooth interpolation."""
    t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)

# ============================================================================
# SDF PRIMITIVES
# ============================================================================

@njit
def sdf_sphere(position, center, radius):
    """SDF for sphere."""
    return length(position - center) - radius

@njit
def sdf_box(position, center, bounds):
    """SDF for box."""
    q = np.abs(position - center) - bounds
    return length(np.maximum(q, 0.0)) + min(max(max(q[0], q[1]), q[2]), 0.0)

@njit
def sdf_plane(position, normal, distance):
    """SDF for plane."""
    return dot(position, normalize(normal)) + distance

@njit
def sdf_union(d1, d2):
    """Union of two SDFs."""
    return min(d1, d2)

# ============================================================================
# BASIC RAYMARCHING SCENE
# ============================================================================

@njit
def scene_sdf(position):
    """
    Scene SDF function.
    Returns: [color_r, color_g, color_b, distance]
    """
    # Red sphere
    sphere1 = sdf_sphere(position, np.array([0.0, 0.0, 0.0]), 1.0)
    
    # Green sphere
    sphere2 = sdf_sphere(position, np.array([2.5, 0.5, -1.0]), 0.8)
    
    # Blue box
    box1 = sdf_box(position, np.array([-2.0, 0.0, 0.0]), np.array([0.8, 1.2, 0.6]))
    
    # Ground plane
    ground = sdf_plane(position, np.array([0.0, 1.0, 0.0]), 2.0)
    
    # Find closest object and assign color
    distances = np.array([sphere1, sphere2, box1, ground])
    colors = np.array([
        [1.0, 0.3, 0.3],  # Red
        [0.3, 1.0, 0.3],  # Green  
        [0.3, 0.3, 1.0],  # Blue
        [0.6, 0.6, 0.6]   # Gray
    ])
    
    min_idx = np.argmin(distances)
    min_distance = distances[min_idx]
    color = colors[min_idx]
    
    return np.array([color[0], color[1], color[2], min_distance])

@njit
def calculate_normal(position, epsilon=0.001):
    """Calculate surface normal."""
    offset = np.array([epsilon, 0.0, 0.0])
    
    grad_x = scene_sdf(position + offset)[3] - scene_sdf(position - offset)[3]
    
    offset = np.array([0.0, epsilon, 0.0])
    grad_y = scene_sdf(position + offset)[3] - scene_sdf(position - offset)[3]
    
    offset = np.array([0.0, 0.0, epsilon])
    grad_z = scene_sdf(position + offset)[3] - scene_sdf(position - offset)[3]
    
    normal = np.array([grad_x, grad_y, grad_z])
    return normalize(normal)

@njit
def raymarch(ray_origin, ray_direction, max_distance=50.0, max_steps=100, accuracy=0.001):
    """
    Core raymarching algorithm.
    Returns: [color_r, color_g, color_b, hit_distance]
    """
    traveled = 0.0
    
    for i in range(max_steps):
        if traveled > max_distance:
            break
        
        position = ray_origin + ray_direction * traveled
        sdf_result = scene_sdf(position)
        distance = sdf_result[3]
        
        if distance < accuracy:
            # Hit surface - calculate lighting
            normal = calculate_normal(position)
            material_color = sdf_result[:3]
            
            # Simple lighting
            light_direction = normalize(np.array([0.5, -1.0, -0.5]))
            diffuse = max(0.0, dot(-light_direction, normal) * 0.5 + 0.5)
            
            lit_color = material_color * diffuse * 0.8 + material_color * 0.2  # Ambient
            return np.array([lit_color[0], lit_color[1], lit_color[2], traveled])
        
        traveled += distance
    
    # Miss - return background
    return np.array([0.1, 0.2, 0.4, max_distance])  # Sky blue

@njit
def generate_ray(pixel_x, pixel_y, screen_width, screen_height, 
                camera_pos, camera_target, fov=60.0):
    """Generate camera ray for pixel."""
    # Convert to NDC
    ndc_x = (2.0 * pixel_x / screen_width) - 1.0
    ndc_y = 1.0 - (2.0 * pixel_y / screen_height)
    
    # Camera basis
    forward = normalize(camera_target - camera_pos)
    right = normalize(cross(forward, np.array([0.0, 1.0, 0.0])))
    up = cross(right, forward)
    
    # Ray direction
    aspect = screen_width / screen_height
    fov_rad = np.deg2rad(fov)
    tan_half_fov = np.tan(fov_rad * 0.5)
    
    ray_dir = normalize(
        forward + 
        right * ndc_x * tan_half_fov * aspect +
        up * ndc_y * tan_half_fov
    )
    
    return camera_pos, ray_dir

def render_pixel(x, y, width, height, camera_pos, camera_target):
    """Render single pixel."""
    ray_origin, ray_direction = generate_ray(x, y, width, height, camera_pos, camera_target)
    result = raymarch(ray_origin, ray_direction)
    return result[:3]  # Return just color

# ============================================================================
# MAIN APPLICATION
# ============================================================================

class SimpleDemoApp:
    """Simple raymarching demo application."""
    
    def __init__(self, width=800, height=600):
        self.width = width
        self.height = height
        
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Python Raymarching - Simple Demo")
        
        self.buffer = np.zeros((height, width, 3), dtype=np.uint8)
        self.clock = pygame.time.Clock()
        
        # Camera
        self.camera_pos = np.array([0.0, 0.0, 5.0])
        self.camera_target = np.array([0.0, 0.0, 0.0])
        self.camera_speed = 2.0
        self.mouse_sensitivity = 0.002
        self.yaw = 0.0
        self.pitch = 0.0
        
        # Render settings
        self.render_scale = 0.5  # Render at half resolution for performance
        
        # Input
        self.keys = set()
        self.mouse_locked = False
        
        print("Controls:")
        print("  WASD - Move camera")
        print("  Mouse - Look around (click to lock)")
        print("  Space/Shift - Up/Down")
        print("  ESC - Exit")
    
    def handle_events(self):
        """Handle events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                self.keys.add(event.key)
            elif event.type == pygame.KEYUP:
                self.keys.discard(event.key)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self.mouse_locked = not self.mouse_locked
                    pygame.mouse.set_visible(not self.mouse_locked)
                    if self.mouse_locked:
                        pygame.mouse.set_pos(self.width // 2, self.height // 2)
        return True
    
    def update_camera(self, dt):
        """Update camera."""
        # Mouse look
        if self.mouse_locked:
            mx, my = pygame.mouse.get_pos()
            cx, cy = self.width // 2, self.height // 2
            
            if mx != cx or my != cy:
                dx = mx - cx
                dy = my - cy
                
                self.yaw += dx * self.mouse_sensitivity
                self.pitch -= dy * self.mouse_sensitivity
                self.pitch = clamp(self.pitch, -np.pi/2 + 0.1, np.pi/2 - 0.1)
                
                pygame.mouse.set_pos(cx, cy)
        
        # Calculate direction
        forward = np.array([
            np.cos(self.pitch) * np.sin(self.yaw),
            np.sin(self.pitch),
            np.cos(self.pitch) * np.cos(self.yaw)
        ])
        
        right = cross(forward, np.array([0.0, 1.0, 0.0]))
        up = cross(right, forward)
        
        # Movement
        movement = np.array([0.0, 0.0, 0.0])
        speed = self.camera_speed * dt
        
        if pygame.K_w in self.keys:
            movement += forward * speed
        if pygame.K_s in self.keys:
            movement -= forward * speed
        if pygame.K_a in self.keys:
            movement -= right * speed
        if pygame.K_d in self.keys:
            movement += right * speed
        if pygame.K_SPACE in self.keys:
            movement += up * speed
        if pygame.K_LSHIFT in self.keys:
            movement -= up * speed
        
        self.camera_pos += movement
        self.camera_target = self.camera_pos + forward
    
    def render_frame(self):
        """Render frame."""
        render_width = int(self.width * self.render_scale)
        render_height = int(self.height * self.render_scale)
        
        # Render at reduced resolution
        for y in range(render_height):
            for x in range(render_width):
                color = render_pixel(x, y, render_width, render_height, 
                                   self.camera_pos, self.camera_target)
                
                # Gamma correction
                color = np.power(np.clip(color, 0.0, 1.0), 1.0/2.2)
                
                # Convert to RGB
                r = int(color[0] * 255)
                g = int(color[1] * 255)
                b = int(color[2] * 255)
                
                # Upscale to full resolution
                for dy in range(int(1/self.render_scale)):
                    for dx in range(int(1/self.render_scale)):
                        px = x * int(1/self.render_scale) + dx
                        py = y * int(1/self.render_scale) + dy
                        if px < self.width and py < self.height:
                            self.buffer[py, px] = [r, g, b]
        
        # Display
        surface = pygame.surfarray.make_surface(self.buffer.swapaxes(0, 1))
        self.screen.blit(surface, (0, 0))
        
        # FPS
        fps = self.clock.get_fps()
        font = pygame.font.Font(None, 24)
        fps_text = font.render(f"FPS: {fps:.1f}", True, (255, 255, 255))
        self.screen.blit(fps_text, (10, 10))
        
        if not self.mouse_locked:
            help_text = font.render("Click to lock mouse", True, (255, 255, 0))
            self.screen.blit(help_text, (10, self.height - 30))
        
        pygame.display.flip()
    
    def run(self):
        """Main loop."""
        print("Starting simple raymarching demo...")
        print(f"Render resolution: {int(self.width * self.render_scale)}x{int(self.height * self.render_scale)}")
        
        running = True
        while running:
            dt = self.clock.tick(60) / 1000.0
            
            running = self.handle_events()
            self.update_camera(dt)
            
            try:
                self.render_frame()
            except Exception as e:
                print(f"Render error: {e}")
                break
        
        pygame.quit()

def main():
    """Entry point."""
    print("Python Raymarching Engine - Simple Demo")
    print("=" * 50)
    
    try:
        app = SimpleDemoApp(800, 600)
        app.run()
    except KeyboardInterrupt:
        print("\nDemo stopped by user")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
