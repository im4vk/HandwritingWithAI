#!/usr/bin/env python3
"""
Ultra-Fast Black Hole Demo - Maximum Performance
Optimized for real-time interaction with 10+ FPS.
"""

import pygame
import numpy as np
import time
from numba import njit, prange

# ============================================================================
# ULTRA-OPTIMIZED MATH
# ============================================================================

@njit
def fast_length(x, y, z):
    return np.sqrt(x*x + y*y + z*z)

@njit
def fast_length_2d(x, z):
    return np.sqrt(x*x + z*z)

@njit
def fast_normalize(x, y, z):
    norm = fast_length(x, y, z)
    if norm < 1e-8:
        return x, y, z
    return x/norm, y/norm, z/norm

@njit
def fast_dot(ax, ay, az, bx, by, bz):
    return ax*bx + ay*by + az*bz

@njit
def clamp(value, min_val, max_val):
    return max(min_val, min(max_val, value))

# ============================================================================
# ULTRA-FAST STAR FIELD
# ============================================================================

@njit
def ultra_fast_stars(dx, dy, dz):
    """Ultra-fast star field using integer operations."""
    # Convert to integers for fast hashing
    ix = int(dx * 100) & 0xFF
    iy = int(dy * 100) & 0xFF  
    iz = int(dz * 100) & 0xFF
    
    # Fast hash
    h = (ix * 73 + iy * 151 + iz * 211) & 0x3FF
    
    # Stars
    if h > 1000:
        brightness = (h - 1000) * 0.001
        return brightness, brightness * 0.9, brightness * 0.8
    
    # Background
    bg = h * 0.00005
    return bg * 0.1, bg * 0.2, bg * 0.4

# ============================================================================
# ULTRA-FAST BLACK HOLE
# ============================================================================

@njit
def ultra_fast_black_hole(ray_ox, ray_oy, ray_oz, ray_dx, ray_dy, ray_dz,
                          bh_x, bh_y, bh_z, bh_radius, bh_mass):
    """Ultra-optimized black hole raymarching."""
    # Start position
    px, py, pz = ray_ox, ray_oy, ray_oz
    dx, dy, dz = ray_dx, ray_dy, ray_dz
    
    # Only 25 steps for maximum speed
    step_size = 0.4
    
    for i in range(25):
        # Distance to black hole
        to_bh_x = px - bh_x
        to_bh_y = py - bh_y  
        to_bh_z = pz - bh_z
        dist_bh = fast_length(to_bh_x, to_bh_y, to_bh_z)
        
        # Hit black hole
        if dist_bh < bh_radius:
            return 0.0, 0.0, 0.0
        
        # Simple gravitational bending
        if dist_bh > 0.5:
            inv_dist3 = 1.0 / (dist_bh * dist_bh * dist_bh)
            gravity_strength = bh_mass * inv_dist3 * step_size * 0.05
            
            dx -= to_bh_x * gravity_strength
            dy -= to_bh_y * gravity_strength
            dz -= to_bh_z * gravity_strength
            
            # Re-normalize direction
            dx, dy, dz = fast_normalize(dx, dy, dz)
        
        # Step forward
        px += dx * step_size
        py += dy * step_size
        pz += dz * step_size
        
        # Early exit if too far
        if fast_length(px - ray_ox, py - ray_oy, pz - ray_oz) > 60.0:
            break
    
    # Return background stars
    return ultra_fast_stars(dx, dy, dz)

@njit
def ultra_fast_accretion_disk(ray_ox, ray_oy, ray_oz, ray_dx, ray_dy, ray_dz,
                             bh_x, bh_y, bh_z, bh_radius, bh_mass):
    """Ultra-fast accretion disk rendering."""
    px, py, pz = ray_ox, ray_oy, ray_oz
    dx, dy, dz = ray_dx, ray_dy, ray_dz
    
    acc_r, acc_g, acc_b = 0.0, 0.0, 0.0
    transmittance = 1.0
    step_size = 0.3
    
    for i in range(30):
        to_bh_x = px - bh_x
        to_bh_y = py - bh_y
        to_bh_z = pz - bh_z
        dist_bh = fast_length(to_bh_x, to_bh_y, to_bh_z)
        
        if dist_bh < bh_radius:
            return acc_r, acc_g, acc_b
        
        # Simple disk check
        disk_radius = fast_length_2d(to_bh_x, to_bh_z)
        if 2.0 < disk_radius < 7.0 and abs(to_bh_y) < 0.6:
            # Temperature based on radius
            temp = (7.0 - disk_radius) * 0.2
            
            # Simple noise using position
            noise_val = abs(np.sin(px * 3.0) * np.cos(pz * 3.0)) * temp
            
            if noise_val > 0.1:
                # Hot colors
                if disk_radius < 4.0:
                    color_r, color_g, color_b = 1.0 * temp, 0.8 * temp, 0.4 * temp
                else:
                    color_r, color_g, color_b = 1.0 * temp, 0.4 * temp, 0.1 * temp
                
                scattering = noise_val * step_size * 3.0
                acc_r += transmittance * color_r * scattering
                acc_g += transmittance * color_g * scattering  
                acc_b += transmittance * color_b * scattering
                
                transmittance *= np.exp(-noise_val * step_size)
                
                if transmittance < 0.05:
                    return acc_r, acc_g, acc_b
        
        # Gravity
        if dist_bh > 0.5:
            inv_dist3 = 1.0 / (dist_bh * dist_bh * dist_bh)
            gravity_strength = bh_mass * inv_dist3 * step_size * 0.04
            
            dx -= to_bh_x * gravity_strength
            dy -= to_bh_y * gravity_strength
            dz -= to_bh_z * gravity_strength
            dx, dy, dz = fast_normalize(dx, dy, dz)
        
        px += dx * step_size
        py += dy * step_size
        pz += dz * step_size
        
        if fast_length(px - ray_ox, py - ray_oy, pz - ray_oz) > 50.0:
            break
    
    # Add background
    bg_r, bg_g, bg_b = ultra_fast_stars(dx, dy, dz)
    acc_r += bg_r * transmittance
    acc_g += bg_g * transmittance
    acc_b += bg_b * transmittance
    
    return acc_r, acc_g, acc_b

@njit(parallel=True)
def ultra_fast_render(buffer, width, height, cam_x, cam_y, cam_z,
                     target_x, target_y, target_z, bh_x, bh_y, bh_z,
                     bh_radius, bh_mass, render_mode):
    """Ultra-fast parallel rendering."""
    # Camera setup
    fw_x = target_x - cam_x
    fw_y = target_y - cam_y
    fw_z = target_z - cam_z
    fw_x, fw_y, fw_z = fast_normalize(fw_x, fw_y, fw_z)
    
    # Right vector (simplified)
    rt_x = fw_z
    rt_y = 0.0
    rt_z = -fw_x
    rt_x, rt_y, rt_z = fast_normalize(rt_x, rt_y, rt_z)
    
    # Up vector
    up_x = rt_y * fw_z - rt_z * fw_y
    up_y = rt_z * fw_x - rt_x * fw_z
    up_z = rt_x * fw_y - rt_y * fw_x
    
    aspect = width / height
    fov_scale = 0.7  # tan(35 degrees)
    
    for y in prange(height):
        for x in prange(width):
            # NDC coordinates
            ndc_x = (2.0 * x / width) - 1.0
            ndc_y = 1.0 - (2.0 * y / height)
            
            # Ray direction
            ray_dx = fw_x + rt_x * ndc_x * fov_scale * aspect + up_x * ndc_y * fov_scale
            ray_dy = fw_y + rt_y * ndc_x * fov_scale * aspect + up_y * ndc_y * fov_scale
            ray_dz = fw_z + rt_z * ndc_x * fov_scale * aspect + up_z * ndc_y * fov_scale
            ray_dx, ray_dy, ray_dz = fast_normalize(ray_dx, ray_dy, ray_dz)
            
            # Render pixel
            if render_mode == 0:
                r, g, b = ultra_fast_black_hole(cam_x, cam_y, cam_z, ray_dx, ray_dy, ray_dz,
                                               bh_x, bh_y, bh_z, bh_radius, bh_mass)
            else:
                r, g, b = ultra_fast_accretion_disk(cam_x, cam_y, cam_z, ray_dx, ray_dy, ray_dz,
                                                   bh_x, bh_y, bh_z, bh_radius, bh_mass)
            
            # Gamma correction and clipping
            r = min(1.0, r) ** 0.45
            g = min(1.0, g) ** 0.45
            b = min(1.0, b) ** 0.45
            
            buffer[y, x, 0] = int(r * 255)
            buffer[y, x, 1] = int(g * 255)
            buffer[y, x, 2] = int(b * 255)

# ============================================================================
# ULTRA-FAST DEMO APP
# ============================================================================

class UltraFastDemo:
    """Ultra-fast black hole demo prioritizing FPS."""
    
    def __init__(self, width=600, height=400):
        self.width = width
        self.height = height
        
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Ultra-Fast Black Hole Demo")
        
        # Render at very low resolution for maximum speed
        self.render_scale = 0.25  # Quarter resolution
        self.render_width = max(int(width * self.render_scale), 50)
        self.render_height = max(int(height * self.render_scale), 50)
        
        self.buffer = np.zeros((self.render_height, self.render_width, 3), dtype=np.uint8)
        self.display_buffer = np.zeros((height, width, 3), dtype=np.uint8)
        
        self.clock = pygame.time.Clock()
        
        # Camera
        self.cam_x, self.cam_y, self.cam_z = 0.0, 3.0, 12.0
        self.target_x, self.target_y, self.target_z = 0.0, 0.0, 0.0
        self.camera_speed = 4.0
        self.yaw = 0.0
        self.pitch = 0.15
        
        # Black hole
        self.bh_x, self.bh_y, self.bh_z = 0.0, 0.0, 0.0
        self.bh_radius = 1.0
        self.bh_mass = 6.0
        self.render_mode = 1  # Start with accretion disk
        
        # Input
        self.keys = set()
        self.mouse_locked = False
        
        # Performance
        self.frame_count = 0
        self.start_time = time.time()
        
        print("Ultra-Fast Black Hole Demo")
        print("=" * 35)
        print("Maximum performance optimization!")
        print(f"Render resolution: {self.render_width}x{self.render_height}")
        print()
        print("Controls:")
        print("  WASD - Move camera")
        print("  Mouse - Look around (click to lock)")
        print("  Space/Shift - Up/Down")
        print("  1/2 - Simple/Accretion disk")
        print("  R - Reset")
        print("  ESC - Exit")
    
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_r:
                    self.reset_camera()
                elif event.key == pygame.K_1:
                    self.render_mode = 0
                    print("Simple black hole mode")
                elif event.key == pygame.K_2:
                    self.render_mode = 1
                    print("Accretion disk mode")
                self.keys.add(event.key)
            elif event.type == pygame.KEYUP:
                self.keys.discard(event.key)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self.mouse_locked = not self.mouse_locked
                    pygame.mouse.set_visible(not self.mouse_locked)
                    if self.mouse_locked:
                        pygame.mouse.set_pos(self.width // 2, self.height // 2)
        return True
    
    def reset_camera(self):
        self.cam_x, self.cam_y, self.cam_z = 0.0, 3.0, 12.0
        self.target_x, self.target_y, self.target_z = 0.0, 0.0, 0.0
        self.yaw = 0.0
        self.pitch = 0.15
        print("Camera reset")
    
    def update_camera(self, dt):
        # Mouse look
        if self.mouse_locked:
            mx, my = pygame.mouse.get_pos()
            cx, cy = self.width // 2, self.height // 2
            
            if mx != cx or my != cy:
                dx = (mx - cx) * 0.003
                dy = (my - cy) * 0.003
                
                self.yaw += dx
                self.pitch -= dy
                self.pitch = clamp(self.pitch, -1.5, 1.5)
                
                pygame.mouse.set_pos(cx, cy)
        
        # Calculate forward direction
        fw_x = np.cos(self.pitch) * np.sin(self.yaw)
        fw_y = np.sin(self.pitch)
        fw_z = np.cos(self.pitch) * np.cos(self.yaw)
        
        # Right and up vectors (simplified)
        rt_x = fw_z
        rt_y = 0.0
        rt_z = -fw_x
        norm = fast_length(rt_x, rt_y, rt_z)
        rt_x, rt_y, rt_z = rt_x/norm, rt_y/norm, rt_z/norm
        
        up_x = rt_y * fw_z - rt_z * fw_y
        up_y = rt_z * fw_x - rt_x * fw_z
        up_z = rt_x * fw_y - rt_y * fw_x
        
        # Movement
        speed = self.camera_speed * dt
        
        if pygame.K_w in self.keys:
            self.cam_x += fw_x * speed
            self.cam_y += fw_y * speed
            self.cam_z += fw_z * speed
        if pygame.K_s in self.keys:
            self.cam_x -= fw_x * speed
            self.cam_y -= fw_y * speed
            self.cam_z -= fw_z * speed
        if pygame.K_a in self.keys:
            self.cam_x -= rt_x * speed
            self.cam_y -= rt_y * speed
            self.cam_z -= rt_z * speed
        if pygame.K_d in self.keys:
            self.cam_x += rt_x * speed
            self.cam_y += rt_y * speed
            self.cam_z += rt_z * speed
        if pygame.K_SPACE in self.keys:
            self.cam_x += up_x * speed
            self.cam_y += up_y * speed
            self.cam_z += up_z * speed
        if pygame.K_LSHIFT in self.keys:
            self.cam_x -= up_x * speed
            self.cam_y -= up_y * speed
            self.cam_z -= up_z * speed
        
        # Update target
        self.target_x = self.cam_x + fw_x
        self.target_y = self.cam_y + fw_y
        self.target_z = self.cam_z + fw_z
    
    def render_frame(self):
        # Render at ultra-low resolution
        ultra_fast_render(
            self.buffer, self.render_width, self.render_height,
            self.cam_x, self.cam_y, self.cam_z,
            self.target_x, self.target_y, self.target_z,
            self.bh_x, self.bh_y, self.bh_z,
            self.bh_radius, self.bh_mass, self.render_mode
        )
        
        # Ultra-fast upscaling (block-based)
        scale = int(1.0 / self.render_scale)
        for y in range(self.height):
            src_y = min(y // scale, self.render_height - 1)
            for x in range(self.width):
                src_x = min(x // scale, self.render_width - 1)
                self.display_buffer[y, x] = self.buffer[src_y, src_x]
        
        # Display
        surface = pygame.surfarray.make_surface(self.display_buffer.swapaxes(0, 1))
        self.screen.blit(surface, (0, 0))
        
        # FPS counter
        self.frame_count += 1
        elapsed = time.time() - self.start_time
        if elapsed > 0:
            avg_fps = self.frame_count / elapsed
        else:
            avg_fps = 0
        
        # HUD
        font = pygame.font.Font(None, 24)
        fps_text = font.render(f"FPS: {avg_fps:.1f}", True, (0, 255, 0))
        self.screen.blit(fps_text, (10, 10))
        
        res_text = font.render(f"Render: {self.render_width}x{self.render_height}", True, (255, 255, 255))
        self.screen.blit(res_text, (10, 35))
        
        mode_text = font.render(f"Mode: {'Simple' if self.render_mode == 0 else 'Accretion'}", True, (255, 255, 255))
        self.screen.blit(mode_text, (10, 60))
        
        if not self.mouse_locked:
            help_text = font.render("Click to lock mouse for camera control", True, (255, 255, 0))
            self.screen.blit(help_text, (10, self.height - 25))
        
        pygame.display.flip()
    
    def run(self):
        print("Starting ultra-fast demo...")
        
        running = True
        while running:
            dt = self.clock.tick(60) / 1000.0  # Target 60 FPS
            
            running = self.handle_events()
            self.update_camera(dt)
            
            try:
                self.render_frame()
            except Exception as e:
                print(f"Error: {e}")
                break
        
        pygame.quit()

def main():
    try:
        demo = UltraFastDemo(800, 600)
        demo.run()
    except KeyboardInterrupt:
        print("\nDemo stopped")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
