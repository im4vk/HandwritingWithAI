//! Integration tests for edge cases and comprehensive functionality

#[cfg(test)]
mod integration_tests {
    use crate::*;
    use std::f32::consts::PI;

    #[test]
    fn test_extreme_camera_positions() {
        let mut camera = Camera::default();
        
        // Test very close to black hole (near minimum radius)
        camera.radius = camera.min_radius;
        let pos = camera.position();
        assert!(pos[0].is_finite() && pos[1].is_finite() && pos[2].is_finite());
        
        // Test very far from black hole (at maximum radius)
        camera.radius = camera.max_radius;
        let pos = camera.position();
        assert!(pos[0].is_finite() && pos[1].is_finite() && pos[2].is_finite());
        
        // Test extreme elevation angles
        camera.elevation = 0.01; // Near north pole
        let pos = camera.position();
        assert!(pos[0].is_finite() && pos[1].is_finite() && pos[2].is_finite());
        
        camera.elevation = PI - 0.01; // Near south pole
        let pos = camera.position();
        assert!(pos[0].is_finite() && pos[1].is_finite() && pos[2].is_finite());
    }

    #[test]
    fn test_massive_object_interaction() {
        let mut app = AppState::default();
        
        // Test with black hole mass objects
        app.objects = vec![
            ObjectData { 
                pos_radius: [0.0, 0.0, 0.0, 1.269e10], 
                color: [0.0, 0.0, 0.0, 1.0], 
                mass: 8.54e36, // Sagittarius A* mass
                _pad_align_before_vec3: [0.0; 3], 
                _pad_vec3: [0.0; 3], 
                _pad_end: 0.0 
            },
            ObjectData { 
                pos_radius: [1e12, 0.0, 0.0, 1e10], 
                color: [1.0, 1.0, 0.0, 1.0], 
                mass: 1.98892e30, // Solar mass
                _pad_align_before_vec3: [0.0; 3], 
                _pad_vec3: [0.0; 3], 
                _pad_end: 0.0 
            },
        ];
        app.physics = vec![
            PhysicsBody { velocity: [0.0; 3], _pad: 0.0 },
            PhysicsBody { velocity: [0.0; 3], _pad: 0.0 },
        ];

        // Test that gravity calculation doesn't panic with extreme masses
        for _ in 0..10 {
            newtonian_gravity_step(&mut app);
            
            // Verify positions remain finite
            for obj in &app.objects {
                assert!(obj.pos_radius[0].is_finite());
                assert!(obj.pos_radius[1].is_finite());
                assert!(obj.pos_radius[2].is_finite());
            }
            
            // Verify velocities remain finite
            for phys in &app.physics {
                assert!(phys.velocity[0].is_finite());
                assert!(phys.velocity[1].is_finite());
                assert!(phys.velocity[2].is_finite());
            }
        }
    }

    #[test]
    fn test_grid_warping_edge_cases() {
        // Test grid warping with objects at event horizon
        let g = 6.67430e-11f64;
        let c = 299792458.0f64;
        let mass = 8.54e36f64;
        let rs = 2.0 * g * mass / (c * c);
        
        // Test exactly at event horizon
        let distance = rs;
        let delta_y = 2.0 * (rs * rs).sqrt();
        assert!(delta_y.is_finite());
        assert!(delta_y > 0.0);
        
        // Test just inside event horizon (should handle gracefully)
        let distance = rs * 0.5;
        let delta_y = 2.0 * (rs * rs).sqrt(); // Same formula as used in code
        assert!(delta_y.is_finite());
        assert!(delta_y > 0.0);
        
        // Test very far from black hole
        let distance = rs * 1000.0;
        let delta_y = 2.0 * (rs * (distance - rs)).sqrt();
        assert!(delta_y.is_finite());
        assert!(delta_y > 0.0);
    }

    #[test]
    fn test_memory_layout_consistency() {
        use std::mem::{size_of, align_of};
        
        // Verify all data structures have consistent layout
        assert_eq!(size_of::<CameraData>(), 80); // Expected size based on layout
        assert_eq!(align_of::<CameraData>(), 4);
        
        assert_eq!(size_of::<DiskData>(), 16);
        assert_eq!(align_of::<DiskData>(), 4);
        
        assert_eq!(size_of::<ObjectsBlock>(), 832); // Must match shader expectation
        assert_eq!(align_of::<ObjectsBlock>(), 4);
        
        // Test that structures are Pod and Zeroable
        let _camera_bytes = bytemuck::bytes_of(&CameraData {
            cam_pos: [0.0; 3], _pad0: 0.0,
            cam_right: [1.0, 0.0, 0.0], _pad1: 0.0,
            cam_up: [0.0, 1.0, 0.0], _pad2: 0.0,
            cam_forward: [0.0, 0.0, 1.0], _pad3: 0.0,
            tan_half_fov: 0.5,
            aspect: 1.0,
            moving: 0,
            _pad4: 0,
        });
        
        let _disk_bytes = bytemuck::bytes_of(&DiskData {
            disk_r1: 1.0,
            disk_r2: 2.0,
            disk_num: 1.0,
            thickness: 0.5,
        });
    }

    #[test]
    fn test_math_edge_cases() {
        // Test normalize with zero vector
        let zero_vec = [0.0, 0.0, 0.0];
        let normalized = normalize3(zero_vec);
        assert_eq!(normalized, zero_vec); // Should return zero vector unchanged
        
        // Test normalize with very small vector
        let tiny_vec = [1e-10, 1e-10, 1e-10];
        let normalized = normalize3(tiny_vec);
        assert!(normalized[0].is_finite());
        assert!(normalized[1].is_finite());
        assert!(normalized[2].is_finite());
        
        // Test cross product with parallel vectors
        let parallel1 = [1.0, 0.0, 0.0];
        let parallel2 = [2.0, 0.0, 0.0];
        let cross_result = cross3(parallel1, parallel2);
        assert_eq!(cross_result, [0.0, 0.0, 0.0]);
        
        // Test dot product edge cases
        let dot_zero = dot3([1.0, 2.0, 3.0], [0.0, 0.0, 0.0]);
        assert_eq!(dot_zero, 0.0);
    }

    #[test]
    fn test_physics_stability() {
        let mut app = AppState::default();
        
        // Create a stable orbital configuration
        app.objects = vec![
            ObjectData { 
                pos_radius: [0.0, 0.0, 0.0, 1.269e10], 
                color: [0.0, 0.0, 0.0, 1.0], 
                mass: 8.54e36,
                _pad_align_before_vec3: [0.0; 3], 
                _pad_vec3: [0.0; 3], 
                _pad_end: 0.0 
            },
            ObjectData { 
                pos_radius: [4e11, 0.0, 0.0, 4e10], 
                color: [1.0, 1.0, 0.0, 1.0], 
                mass: 1.98892e30,
                _pad_align_before_vec3: [0.0; 3], 
                _pad_vec3: [0.0; 3], 
                _pad_end: 0.0 
            },
        ];
        app.physics = vec![
            PhysicsBody { velocity: [0.0; 3], _pad: 0.0 },
            PhysicsBody { velocity: [0.0, 0.0, 1e5], _pad: 0.0 }, // Orbital velocity
        ];

        // Run simulation for many steps
        for i in 0..1000 {
            newtonian_gravity_step(&mut app);
            
            // Check that simulation remains stable (no infinities or NaNs)
            for (j, obj) in app.objects.iter().enumerate() {
                assert!(obj.pos_radius[0].is_finite(), "Position infinite at step {} object {}", i, j);
                assert!(obj.pos_radius[1].is_finite(), "Position infinite at step {} object {}", i, j);
                assert!(obj.pos_radius[2].is_finite(), "Position infinite at step {} object {}", i, j);
            }
            
            for (j, phys) in app.physics.iter().enumerate() {
                assert!(phys.velocity[0].is_finite(), "Velocity infinite at step {} object {}", i, j);
                assert!(phys.velocity[1].is_finite(), "Velocity infinite at step {} object {}", i, j);
                assert!(phys.velocity[2].is_finite(), "Velocity infinite at step {} object {}", i, j);
            }
        }
    }

    #[test]
    fn test_view_projection_matrix() {
        let eye = [1.0, 2.0, 3.0];
        let center = [0.0, 0.0, 0.0];
        let up = [0.0, 1.0, 0.0];
        let fovy = 60.0f32.to_radians();
        let aspect = 16.0 / 9.0;
        let znear = 0.1;
        let zfar = 100.0;
        
        let matrix = make_viewproj(eye, center, up, fovy, aspect, znear, zfar);
        
        // Verify matrix elements are finite
        for &element in matrix.iter() {
            assert!(element.is_finite(), "Matrix element is not finite: {}", element);
        }
        
        // Verify matrix is not all zeros (would indicate calculation failure)
        let sum: f32 = matrix.iter().sum();
        assert!(sum.abs() > 1e-6, "Matrix appears to be all zeros");
    }
}
