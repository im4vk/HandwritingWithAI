//! 2D Gravitational Lensing Visualization
//! 
//! This module implements a 2D visualization of light ray trajectories around a black hole,
//! showing gravitational lensing effects using Schwarzschild geodesics in polar coordinates.

use anyhow::Result;
use std::f32::consts::PI;
use wgpu::util::DeviceExt;
use winit::{
    dpi::{PhysicalPosition, PhysicalSize},
    event::*,
    event_loop::EventLoop,
    keyboard::{KeyCode, PhysicalKey},
    window::WindowBuilder,
};

// Physical constants
const C: f64 = 299792458.0;           // Speed of light (m/s)
const G: f64 = 6.67430e-11;          // Gravitational constant (m³/kg/s²)

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Vertex {
    position: [f32; 2],
    color: [f32; 4],
}

impl Vertex {
    const ATTRIBS: [wgpu::VertexAttribute; 2] = wgpu::vertex_attr_array![
        0 => Float32x2,
        1 => Float32x4
    ];

    fn desc() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout {
            array_stride: std::mem::size_of::<Vertex>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &Self::ATTRIBS,
        }
    }
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct ViewUniforms {
    view_matrix: [[f32; 4]; 4],
}

struct LensingApp<'w> {
    surface: wgpu::Surface<'w>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    size: PhysicalSize<u32>,

    // Rendering pipeline
    render_pipeline: wgpu::RenderPipeline,
    view_buffer: wgpu::Buffer,
    view_bind_group: wgpu::BindGroup,

    // Scene data
    black_hole: BlackHole,
    rays: Vec<Ray>,
    
    // Navigation state
    offset_x: f32,
    offset_y: f32,
    zoom: f32,
    middle_mouse_pressed: bool,
    last_mouse_pos: Option<PhysicalPosition<f64>>,

    // Viewport size in meters
    viewport_width: f32,
    viewport_height: f32,
}

struct BlackHole {
    position: [f32; 2],
    mass: f64,
    radius: f64,
    r_s: f64, // Schwarzschild radius
}

impl BlackHole {
    fn new(position: [f32; 2], mass: f64) -> Self {
        let r_s = 2.0 * G * mass / (C * C);
        Self {
            position,
            mass,
            radius: r_s,
            r_s,
        }
    }

    fn generate_vertices(&self) -> Vec<Vertex> {
        let mut vertices = Vec::new();
        let center = Vertex {
            position: self.position,
            color: [1.0, 0.0, 0.0, 1.0], // Red color for black hole
        };
        vertices.push(center);

        // Generate circle vertices for the event horizon
        const SEGMENTS: usize = 100;
        for i in 0..=SEGMENTS {
            let angle = 2.0 * PI * (i as f32) / (SEGMENTS as f32);
            let x = self.position[0] + (self.r_s as f32) * angle.cos();
            let y = self.position[1] + (self.r_s as f32) * angle.sin();
            
            vertices.push(Vertex {
                position: [x, y],
                color: [1.0, 0.0, 0.0, 1.0],
            });
        }
        vertices
    }
}

#[derive(Clone)]
struct Ray {
    // Cartesian coordinates
    x: f64,
    y: f64,
    
    // Polar coordinates
    r: f64,
    phi: f64,
    dr: f64,
    dphi: f64,
    
    // Conserved quantities
    e: f64,  // Energy
    l: f64,  // Angular momentum
    
    // Trail of points for visualization
    trail: Vec<[f32; 2]>,
}

impl Ray {
    fn new(pos: [f64; 2], dir: [f64; 2], black_hole: &BlackHole) -> Self {
        let x = pos[0];
        let y = pos[1];
        
        // Convert to polar coordinates
        let r = (x*x + y*y).sqrt();
        let phi = y.atan2(x);
        
        // Convert velocity to polar coordinates
        let dr = dir[0] * phi.cos() + dir[1] * phi.sin();
        let dphi = (-dir[0] * phi.sin() + dir[1] * phi.cos()) / r;
        
        // Calculate conserved quantities
        let l = r*r * dphi;
        let f = 1.0 - black_hole.r_s / r;
        let dt_dlambda = ((dr*dr)/(f*f) + (r*r*dphi*dphi)/f).sqrt();
        let e = f * dt_dlambda;
        
        let mut trail = Vec::new();
        trail.push([x as f32, y as f32]);
        
        Self {
            x, y, r, phi, dr, dphi, e, l, trail
        }
    }

    fn step(&mut self, dlambda: f64, rs: f64) {
        // Stop if inside event horizon
        if self.r <= rs {
            return;
        }

        // RK4 integration step
        rk4_step(self, dlambda, rs);

        // Convert back to Cartesian coordinates
        self.x = self.r * self.phi.cos();
        self.y = self.r * self.phi.sin();

        // Add to trail
        self.trail.push([self.x as f32, self.y as f32]);
        
        // Limit trail length to prevent excessive memory usage
        if self.trail.len() > 10000 {
            self.trail.remove(0);
        }
    }

    fn generate_vertices(&self) -> Vec<Vertex> {
        let mut vertices = Vec::new();
        
        // Current position as a point
        vertices.push(Vertex {
            position: [self.x as f32, self.y as f32],
            color: [1.0, 0.0, 0.0, 1.0], // Red for current position
        });

        // Trail with fading alpha
        if self.trail.len() >= 2 {
            for i in 0..self.trail.len() {
                let alpha = (i as f32) / (self.trail.len() as f32 - 1.0);
                let alpha = alpha.max(0.05); // Minimum visibility
                
                vertices.push(Vertex {
                    position: self.trail[i],
                    color: [1.0, 1.0, 1.0, alpha], // White with fading alpha
                });
            }
        }
        
        vertices
    }
}

fn geodesic_rhs(ray: &Ray, rs: f64) -> [f64; 4] {
    let r = ray.r;
    let dr = ray.dr;
    let dphi = ray.dphi;
    let e = ray.e;

    let f = 1.0 - rs / r;
    let dt_dlambda = e / f;

    [
        // dr/dλ = dr
        dr,
        // dφ/dλ = dphi  
        dphi,
        // d²r/dλ² from Schwarzschild null geodesic
        -(rs / (2.0 * r * r)) * f * (dt_dlambda * dt_dlambda)
            + (rs / (2.0 * r * r * f)) * (dr * dr)
            + (r - rs) * (dphi * dphi),
        // d²φ/dλ² = -2*(dr * dphi) / r
        -2.0 * dr * dphi / r,
    ]
}

fn add_state(a: &[f64; 4], b: &[f64; 4], factor: f64) -> [f64; 4] {
    [
        a[0] + b[0] * factor,
        a[1] + b[1] * factor,
        a[2] + b[2] * factor,
        a[3] + b[3] * factor,
    ]
}

fn rk4_step(ray: &mut Ray, dlambda: f64, rs: f64) {
    let y0 = [ray.r, ray.phi, ray.dr, ray.dphi];
    
    // k1
    let k1 = geodesic_rhs(ray, rs);
    
    // k2
    let temp = add_state(&y0, &k1, dlambda / 2.0);
    let mut r2 = ray.clone();
    r2.r = temp[0]; r2.phi = temp[1]; r2.dr = temp[2]; r2.dphi = temp[3];
    let k2 = geodesic_rhs(&r2, rs);
    
    // k3
    let temp = add_state(&y0, &k2, dlambda / 2.0);
    let mut r3 = ray.clone();
    r3.r = temp[0]; r3.phi = temp[1]; r3.dr = temp[2]; r3.dphi = temp[3];
    let k3 = geodesic_rhs(&r3, rs);
    
    // k4
    let temp = add_state(&y0, &k3, dlambda);
    let mut r4 = ray.clone();
    r4.r = temp[0]; r4.phi = temp[1]; r4.dr = temp[2]; r4.dphi = temp[3];
    let k4 = geodesic_rhs(&r4, rs);
    
    // Final update
    ray.r += (dlambda / 6.0) * (k1[0] + 2.0*k2[0] + 2.0*k3[0] + k4[0]);
    ray.phi += (dlambda / 6.0) * (k1[1] + 2.0*k2[1] + 2.0*k3[1] + k4[1]);
    ray.dr += (dlambda / 6.0) * (k1[2] + 2.0*k2[2] + 2.0*k3[2] + k4[2]);
    ray.dphi += (dlambda / 6.0) * (k1[3] + 2.0*k2[3] + 2.0*k3[3] + k4[3]);
}

impl<'w> LensingApp<'w> {
    async fn new(window: &'w winit::window::Window) -> Result<Self> {
        let size = window.inner_size();

        // Instance and Surface
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
            backends: wgpu::Backends::all(),
            flags: wgpu::InstanceFlags::empty(),
            dx12_shader_compiler: Default::default(),
            gles_minor_version: wgpu::Gles3MinorVersion::Automatic,
        });

        let surface = instance.create_surface(window)?;

        // Adapter and Device
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .ok_or_else(|| anyhow::anyhow!("No suitable GPU adapters found"))?;

        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("Device"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::default(),
                },
                None,
            )
            .await?;

        // Surface configuration
        let caps = surface.get_capabilities(&adapter);
        let surface_format = caps
            .formats
            .iter()
            .copied()
            .find(|f| f.is_srgb())
            .unwrap_or(caps.formats[0]);

        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format: surface_format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::Fifo,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &config);

        // Shaders
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Lensing Shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("lensing.wgsl").into()),
        });

        // View uniform buffer
        let view_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("View Buffer"),
            size: std::mem::size_of::<ViewUniforms>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let view_bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("View Bind Group Layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });

        let view_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("View Bind Group"),
            layout: &view_bind_group_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: view_buffer.as_entire_binding(),
            }],
        });

        // Render pipeline
        let render_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Render Pipeline Layout"),
            bind_group_layouts: &[&view_bind_group_layout],
            push_constant_ranges: &[],
        });

        let render_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Render Pipeline"),
            layout: Some(&render_pipeline_layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: "vs_main",
                buffers: &[Vertex::desc()],
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState {
                    format: config.format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::PointList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: None,
                unclipped_depth: false,
                polygon_mode: wgpu::PolygonMode::Fill,
                conservative: false,
            },
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
        });

        // Create Sagittarius A* black hole
        let black_hole = BlackHole::new([0.0, 0.0], 8.54e36);

        Ok(Self {
            surface,
            device,
            queue,
            config,
            size,
            render_pipeline,
            view_buffer,
            view_bind_group,
            black_hole,
            rays: Vec::new(),
            offset_x: 0.0,
            offset_y: 0.0,
            zoom: 1.0,
            middle_mouse_pressed: false,
            last_mouse_pos: None,
            viewport_width: 100000000000.0,  // 100 billion meters
            viewport_height: 75000000000.0,  // 75 billion meters
        })
    }

    fn resize(&mut self, new_size: PhysicalSize<u32>) {
        if new_size.width == 0 || new_size.height == 0 {
            return;
        }
        self.size = new_size;
        self.config.width = new_size.width;
        self.config.height = new_size.height;
        self.surface.configure(&self.device, &self.config);
    }

    fn add_ray(&mut self, pos: [f64; 2], dir: [f64; 2]) {
        let ray = Ray::new(pos, dir, &self.black_hole);
        self.rays.push(ray);
    }

    fn update_view_matrix(&mut self) {
        let left = -self.viewport_width / self.zoom + self.offset_x;
        let right = self.viewport_width / self.zoom + self.offset_x;
        let bottom = -self.viewport_height / self.zoom + self.offset_y;
        let top = self.viewport_height / self.zoom + self.offset_y;

        // Orthographic projection matrix
        let view_matrix = [
            [2.0 / (right - left), 0.0, 0.0, 0.0],
            [0.0, 2.0 / (top - bottom), 0.0, 0.0],
            [0.0, 0.0, -1.0, 0.0],
            [-(right + left) / (right - left), -(top + bottom) / (top - bottom), 0.0, 1.0],
        ];

        let uniforms = ViewUniforms { view_matrix };
        self.queue.write_buffer(&self.view_buffer, 0, bytemuck::bytes_of(&uniforms));
    }

    fn update(&mut self) {
        // Update ray positions
        for ray in &mut self.rays {
            ray.step(1.0, self.black_hole.r_s);
        }

        self.update_view_matrix();
    }

    fn render(&mut self) -> Result<()> {
        let output = self.surface.get_current_texture()?;
        let view = output.texture.create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("Render Encoder"),
        });

        // Collect all vertices first to avoid lifetime issues
        let mut all_vertices = Vec::new();
        let mut draw_commands = Vec::new();

        // Black hole vertices
        let bh_vertices = self.black_hole.generate_vertices();
        if !bh_vertices.is_empty() {
            let start = all_vertices.len();
            all_vertices.extend_from_slice(&bh_vertices);
            draw_commands.push((start, bh_vertices.len()));
        }

        // Ray vertices
        for ray in &self.rays {
            let ray_vertices = ray.generate_vertices();
            if !ray_vertices.is_empty() {
                let start = all_vertices.len();
                all_vertices.extend_from_slice(&ray_vertices);
                draw_commands.push((start, ray_vertices.len()));
            }
        }

        // Create one big vertex buffer
        let vertex_buffer = if !all_vertices.is_empty() {
            Some(self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("Combined Vertex Buffer"),
                contents: bytemuck::cast_slice(&all_vertices),
                usage: wgpu::BufferUsages::VERTEX,
            }))
        } else {
            None
        };

        {
            let mut render_pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("Render Pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color {
                            r: 0.0,
                            g: 0.0,
                            b: 0.0,
                            a: 1.0,
                        }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: None,
            });

            render_pass.set_pipeline(&self.render_pipeline);
            render_pass.set_bind_group(0, &self.view_bind_group, &[]);

            if let Some(ref buffer) = vertex_buffer {
                render_pass.set_vertex_buffer(0, buffer.slice(..));
                
                // Draw all objects
                for (start, count) in draw_commands {
                    render_pass.draw(start as u32..(start + count) as u32, 0..1);
                }
            }
        }

        self.queue.submit(std::iter::once(encoder.finish()));
        output.present();

        Ok(())
    }

    fn handle_mouse_input(&mut self, state: ElementState, button: MouseButton) {
        if button == MouseButton::Middle {
            self.middle_mouse_pressed = state == ElementState::Pressed;
            if !self.middle_mouse_pressed {
                self.last_mouse_pos = None;
            }
        }
    }

    fn handle_cursor_moved(&mut self, position: PhysicalPosition<f64>) {
        if self.middle_mouse_pressed {
            if let Some(last_pos) = self.last_mouse_pos {
                let dx = (position.x - last_pos.x) as f32;
                let dy = (position.y - last_pos.y) as f32;
                
                // Convert screen coordinates to world coordinates
                let world_dx = dx * (self.viewport_width * 2.0 / self.zoom) / self.size.width as f32;
                let world_dy = -dy * (self.viewport_height * 2.0 / self.zoom) / self.size.height as f32;
                
                self.offset_x -= world_dx;
                self.offset_y -= world_dy;
            }
            self.last_mouse_pos = Some(position);
        } else {
            self.last_mouse_pos = Some(position);
        }
    }

    fn handle_mouse_wheel(&mut self, delta: MouseScrollDelta) {
        let scroll_amount = match delta {
            MouseScrollDelta::LineDelta(_x, y) => y as f64,
            MouseScrollDelta::PixelDelta(pos) => pos.y / 120.0, // Normalize pixel delta
        };
        
        self.zoom *= (1.0 + scroll_amount * 0.1) as f32;
        self.zoom = self.zoom.clamp(0.1, 10.0);
    }

    fn handle_key_input(&mut self, key: KeyCode) {
        match key {
            KeyCode::Space => {
                // Add a test ray
                self.add_ray([-1e11, 3.27606302719999999e10], [C, 0.0]);
            }
            KeyCode::KeyC => {
                // Clear all rays
                self.rays.clear();
            }
            _ => {}
        }
    }
}

pub async fn run() -> Result<()> {
    env_logger::init();

    let event_loop = EventLoop::new()?;
    let window = std::rc::Rc::new(
        WindowBuilder::new()
            .with_title("Gravitational Lensing 2D")
            .with_inner_size(PhysicalSize::new(800, 600))
            .build(&event_loop)?,
    );

    let mut app = LensingApp::new(window.as_ref()).await?;

    // Add an initial test ray
    app.add_ray([-1e11, 3.27606302719999999e10], [C, 0.0]);

    let window_for_loop = window.clone();

    event_loop.run(move |event, elwt| {
        match event {
            Event::WindowEvent { event, window_id } if window_id == window_for_loop.id() => match event {
                WindowEvent::CloseRequested => elwt.exit(),
                WindowEvent::Resized(size) => app.resize(size),
                WindowEvent::RedrawRequested => {
                    app.update();
                    if let Err(err) = app.render() {
                        if let Some(surface_err) = err.downcast_ref::<wgpu::SurfaceError>() {
                            match surface_err {
                                wgpu::SurfaceError::Lost => app.resize(app.size),
                                wgpu::SurfaceError::OutOfMemory => elwt.exit(),
                                _ => {}
                            }
                        }
                    }
                }
                WindowEvent::MouseInput { state, button, .. } => {
                    app.handle_mouse_input(state, button);
                }
                WindowEvent::CursorMoved { position, .. } => {
                    app.handle_cursor_moved(position);
                }
                WindowEvent::MouseWheel { delta, .. } => {
                    app.handle_mouse_wheel(delta);
                }
                WindowEvent::KeyboardInput { event, .. } => {
                    if event.state == ElementState::Pressed {
                        if let PhysicalKey::Code(key_code) = event.physical_key {
                            app.handle_key_input(key_code);
                        }
                    }
                }
                _ => {}
            },
            Event::AboutToWait => {
                window_for_loop.request_redraw();
            }
            _ => {}
        }
    })?;

    Ok(())
}
