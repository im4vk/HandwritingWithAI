use anyhow::Result;
use std::f32::consts::PI;

#[cfg(test)]
mod tests;

#[cfg(test)]
mod integration_tests;
use std::rc::Rc;
use wgpu::util::DeviceExt;
use winit::{
    dpi::{PhysicalPosition, PhysicalSize},
    event::*,
    event_loop::EventLoop,
    keyboard::{KeyCode, PhysicalKey},
    window::WindowBuilder,
};

struct GpuState<'w> {
    surface: wgpu::Surface<'w>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    size: PhysicalSize<u32>,
    // compute output
    compute_size: (u32, u32),
    compute_texture: wgpu::Texture,
    compute_view: wgpu::TextureView,
    compute_bind_group_layout: wgpu::BindGroupLayout,
    compute_bind_group: wgpu::BindGroup,
    compute_pipeline: wgpu::ComputePipeline,
    // full screen quad
    quad_sampler: wgpu::Sampler,
    quad_bind_group_layout: wgpu::BindGroupLayout,
    quad_bind_group: wgpu::BindGroup,
    quad_pipeline: wgpu::RenderPipeline,
    // grid
    grid_pipeline: wgpu::RenderPipeline,
    grid_bind_group_layout: wgpu::BindGroupLayout,
    grid_bind_group: wgpu::BindGroup,
    grid_vb: wgpu::Buffer,
    grid_ib: wgpu::Buffer,
    grid_index_count: u32,
    grid_viewproj_buffer: wgpu::Buffer,
    grid_vertex_layout: wgpu::VertexBufferLayout<'static>,
    // uniforms
    camera_buffer: wgpu::Buffer,
    disk_buffer: wgpu::Buffer,
    objects_buffer: wgpu::Buffer,
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct CameraData {
    cam_pos: [f32; 3], _pad0: f32,
    cam_right: [f32; 3], _pad1: f32,
    cam_up: [f32; 3], _pad2: f32,
    cam_forward: [f32; 3], _pad3: f32,
    tan_half_fov: f32,
    aspect: f32,
    moving: u32,
    _pad4: u32,
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct DiskData {
    disk_r1: f32,
    disk_r2: f32,
    disk_num: f32,
    thickness: f32,
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct ObjectData {
    // 16 bytes
    pos_radius: [f32; 4],
    // 16 bytes
    color: [f32; 4],
    // 4 bytes
    mass: f32,
    // 12 bytes padding to align next vec3 to 16 boundary (std140)
    _pad_align_before_vec3: [f32; 3],
    // 12 bytes (matches WGSL vec3<f32> _pad)
    _pad_vec3: [f32; 3],
    // 4 bytes padding to make struct size 64 bytes
    _pad_end: f32,
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct ObjectsBlock {
    // 16-byte header
    num_objects: i32,
    _pad0: [i32; 3],
    // pos and color: 16 * 16 bytes each
    pos_radius: [[f32; 4]; 16],
    color: [[f32; 4]; 16],
    // mass needs 16-byte stride in std140: pad each to vec4
    mass: [[f32; 4]; 16],
    // tail padding to satisfy expected size (shader expects 832 bytes)
    pad_tail: [f32; 4],
    pad_tail2: [f32; 4],
    pad_tail3: [f32; 4], // Additional 16 bytes to reach 832 total
}

impl<'w> GpuState<'w> {
    async fn new(window: &'w winit::window::Window) -> Result<Self> {
        let size = window.inner_size();

        // Instance and Surface
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
            backends: wgpu::Backends::all(),
            flags: wgpu::InstanceFlags::empty(),
            dx12_shader_compiler: Default::default(),
            gles_minor_version: wgpu::Gles3MinorVersion::Automatic,
        });

        let surface = instance.create_surface(window)?;

        // Adapter
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .ok_or_else(|| anyhow::anyhow!("No suitable GPU adapters found"))?;

        // Device + Queue
        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("Device"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::default(),
                },
                None,
            )
            .await?;

        // Surface config
        let caps = surface.get_capabilities(&adapter);
        let surface_format = caps
            .formats
            .iter()
            .copied()
            .find(|f| f.is_srgb())
            .unwrap_or(caps.formats[0]);

        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format: surface_format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::Fifo,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &config);

        // Uniform buffers
        let camera_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Camera UBO"),
            size: std::mem::size_of::<CameraData>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let disk_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Disk UBO"),
            size: std::mem::size_of::<DiskData>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let objects_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Objects UBO"),
            size: std::mem::size_of::<ObjectsBlock>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // Compute output texture
        let compute_size = (200u32, 150u32);
        let compute_texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("Compute Output"),
            size: wgpu::Extent3d { width: compute_size.0, height: compute_size.1, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::STORAGE_BINDING | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let compute_view = compute_texture.create_view(&wgpu::TextureViewDescriptor::default());

        // Bind group layouts
        let compute_bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("compute bgl"),
            entries: &[
                // outImage
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::StorageTexture {
                        access: wgpu::StorageTextureAccess::WriteOnly,
                        format: wgpu::TextureFormat::Rgba8Unorm,
                        view_dimension: wgpu::TextureViewDimension::D2,
                    },
                    count: None,
                },
                // camera
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                // disk
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                // objects
                wgpu::BindGroupLayoutEntry {
                    binding: 3,
                    visibility: wgpu::ShaderStages::COMPUTE,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
            ],
        });

        let compute_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("compute bg"),
            layout: &compute_bind_group_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&compute_view) },
                wgpu::BindGroupEntry { binding: 1, resource: camera_buffer.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 2, resource: disk_buffer.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 3, resource: objects_buffer.as_entire_binding() },
            ],
        });

        let quad_bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("quad bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });

        let quad_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("quad sampler"),
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });
        let quad_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("quad bg"),
            layout: &quad_bind_group_layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&compute_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&quad_sampler) },
            ],
        });

        // Pipelines
        let compute_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("geodesic"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/geodesic.wgsl").into()),
        });
        let compute_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("compute layout"),
            bind_group_layouts: &[&compute_bind_group_layout],
            push_constant_ranges: &[],
        });
        let compute_pipeline = device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
            label: Some("compute pipeline"),
            layout: Some(&compute_pipeline_layout),
            module: &compute_module,
            entry_point: "main",
        });

        let quad_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("quad"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/quad.wgsl").into()),
        });
        let quad_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("quad layout"),
            bind_group_layouts: &[&quad_bind_group_layout],
            push_constant_ranges: &[],
        });
        let quad_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("quad pipeline"),
            layout: Some(&quad_pipeline_layout),
            vertex: wgpu::VertexState { module: &quad_module, entry_point: "vs_main", buffers: &[] },
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            fragment: Some(wgpu::FragmentState {
                module: &quad_module,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            multiview: None,
        });

        // Grid pipeline
        let grid_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("grid"),
            source: wgpu::ShaderSource::Wgsl(include_str!("../shaders/grid.wgsl").into()),
        });
        let grid_bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("grid bgl"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
                count: None,
            }],
        });
        let grid_viewproj_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("grid viewproj"),
            size: (16 * std::mem::size_of::<f32>()) as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let grid_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("grid bg"),
            layout: &grid_bind_group_layout,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: grid_viewproj_buffer.as_entire_binding() }],
        });
        let grid_vertex_layout = wgpu::VertexBufferLayout {
            array_stride: (3 * std::mem::size_of::<f32>()) as u64,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &wgpu::vertex_attr_array![0 => Float32x3],
        };
        let grid_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("grid layout"),
            bind_group_layouts: &[&grid_bind_group_layout],
            push_constant_ranges: &[],
        });
        let grid_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("grid pipeline"),
            layout: Some(&grid_pipeline_layout),
            vertex: wgpu::VertexState { module: &grid_module, entry_point: "vs_main", buffers: &[grid_vertex_layout.clone()] },
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::LineList, ..Default::default() },
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            fragment: Some(wgpu::FragmentState {
                module: &grid_module,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState { format: surface_format, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL })],
            }),
            multiview: None,
        });

        // Initial grid buffers (empty)
        let grid_vb = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("grid vb"),
            size: 1,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let grid_ib = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("grid ib"),
            size: 1,
            usage: wgpu::BufferUsages::INDEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let grid_index_count = 0u32;

        Ok(Self {
            surface,
            device,
            queue,
            config,
            size,
            compute_size,
            compute_texture,
            compute_view,
            compute_bind_group_layout,
            compute_bind_group,
            compute_pipeline,
            quad_sampler,
            quad_bind_group_layout,
            quad_bind_group,
            quad_pipeline,
            grid_pipeline,
            grid_bind_group_layout,
            grid_bind_group,
            grid_vb,
            grid_ib,
            grid_index_count,
            grid_viewproj_buffer,
            grid_vertex_layout,
            camera_buffer,
            disk_buffer,
            objects_buffer,
        })
    }

    fn resize(&mut self, new_size: PhysicalSize<u32>) {
        if new_size.width == 0 || new_size.height == 0 { return; }
        self.size = new_size;
        self.config.width = new_size.width;
        self.config.height = new_size.height;
        self.surface.configure(&self.device, &self.config);
    }

    fn update_uniforms(&mut self, app: &AppState) {
        let (right, up, forward) = app.camera.basis();
        let cam = CameraData {
            cam_pos: app.camera.position(), _pad0: 0.0,
            cam_right: right, _pad1: 0.0,
            cam_up: up, _pad2: 0.0,
            cam_forward: forward, _pad3: 0.0,
            tan_half_fov: (60.0f32.to_radians() * 0.5).tan(),
            aspect: self.config.width as f32 / self.config.height as f32,
            moving: (app.camera.dragging as u32),
            _pad4: 0,
        };
        self.queue.write_buffer(&self.camera_buffer, 0, bytemuck::bytes_of(&cam));

        let disk = DiskData { 
            disk_r1: 1.269e10 * 2.2,
            disk_r2: 1.269e10 * 5.2,
            disk_num: 2.0,
            thickness: 1e9,
        };
        self.queue.write_buffer(&self.disk_buffer, 0, bytemuck::bytes_of(&disk));

        let mut objs = ObjectsBlock {
            num_objects: app.objects.len() as i32,
            _pad0: [0; 3],
            pos_radius: [[0.0; 4]; 16],
            color: [[0.0; 4]; 16],
            mass: [[0.0; 4]; 16],
            pad_tail: [0.0; 4],
            pad_tail2: [0.0; 4],
            pad_tail3: [0.0; 4],
        };
        for (i, o) in app.objects.iter().enumerate().take(16) {
            objs.pos_radius[i] = o.pos_radius;
            objs.color[i] = o.color;
            objs.mass[i][0] = o.mass;
        }
        self.queue.write_buffer(&self.objects_buffer, 0, bytemuck::bytes_of(&objs));
    }

    fn render(&mut self, app: &AppState) -> Result<()> {
        // Compute pass
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("Main Encoder") });
        {
            let mut cpass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor { label: Some("Compute Pass"), timestamp_writes: None });
            cpass.set_pipeline(&self.compute_pipeline);
            cpass.set_bind_group(0, &self.compute_bind_group, &[]);
            let gx = (self.compute_size.0 + 15) / 16;
            let gy = (self.compute_size.1 + 15) / 16;
            cpass.dispatch_workgroups(gx, gy, 1);
        }

        // Surface frame
        let frame = self.surface.get_current_texture()?;
        let view = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());

        // Grid view-projection
        let viewproj = make_viewproj(app.camera.position(), app.camera.target, [0.0, 1.0, 0.0], 60.0f32.to_radians(), self.config.width as f32 / self.config.height as f32, 1e9, 1e14);
        self.queue.write_buffer(&self.grid_viewproj_buffer, 0, bytemuck::cast_slice(&viewproj));

        // Render pass
        {
            let mut rpass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("Main Pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment { view: &view, resolve_target: None, ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color { r: 0.02, g: 0.02, b: 0.04, a: 1.0 }), store: wgpu::StoreOp::Store } })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: None,
            });
            // Grid first
            if self.grid_index_count > 0 {
                rpass.set_pipeline(&self.grid_pipeline);
                rpass.set_bind_group(0, &self.grid_bind_group, &[]);
                rpass.set_vertex_buffer(0, self.grid_vb.slice(..));
                rpass.set_index_buffer(self.grid_ib.slice(..), wgpu::IndexFormat::Uint32);
                rpass.draw_indexed(0..self.grid_index_count, 0, 0..1);
            }
            // Fullscreen quad
            rpass.set_pipeline(&self.quad_pipeline);
            rpass.set_bind_group(0, &self.quad_bind_group, &[]);
            rpass.draw(0..6, 0..1);
        }

        self.queue.submit(Some(encoder.finish()));
        frame.present();
        Ok(())
    }

    fn rebuild_grid(&mut self, app: &AppState) {
        // Generate warped grid in x-z plane
        let grid_size = 25i32;
        let spacing = 1e10f32;
        let mut vertices: Vec<f32> = Vec::with_capacity(((grid_size+1)*(grid_size+1)*3) as usize);
        for z in 0..=grid_size {
            for x in 0..=grid_size {
                let world_x = (x - grid_size/2) as f32 * spacing;
                let world_z = (z - grid_size/2) as f32 * spacing;
                let mut y = 0.0f32;
                for i in 0..app.objects.len().min(16) {
                    let obj = app.objects[i];
                    let obj_pos = [obj.pos_radius[0], obj.pos_radius[1], obj.pos_radius[2]];
                    let mass = obj.mass as f64;
                    let rs = 2.0f64 * 6.67430e-11 * mass / (299792458.0 * 299792458.0);
                    let dx = world_x as f64 - obj_pos[0] as f64;
                    let dz = world_z as f64 - obj_pos[2] as f64;
                    let dist = (dx*dx + dz*dz).sqrt();
                    if dist > rs {
                        let delta_y = 2.0 * (rs * (dist - rs)).sqrt();
                        y += (delta_y as f32) - 3e10f32;
                    } else {
                        y += 2.0f32 * (rs * rs).sqrt() as f32 - 3e10f32;
                    }
                }
                vertices.extend_from_slice(&[world_x, y, world_z]);
            }
        }
        // Build indices for line list
        let mut indices: Vec<u32> = Vec::with_capacity((grid_size*grid_size*4) as usize);
        let stride = (grid_size + 1) as u32;
        for z in 0..grid_size {
            for x in 0..grid_size {
                let i = (z as u32) * stride + x as u32;
                indices.push(i);
                indices.push(i + 1);
                indices.push(i);
                indices.push(i + stride);
            }
        }
        // Upload
        if vertices.is_empty() || indices.is_empty() { self.grid_index_count = 0; return; }
        let vb_bytes = bytemuck::cast_slice(&vertices);
        let ib_bytes = bytemuck::cast_slice(&indices);
        self.grid_vb = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("grid vb"), contents: vb_bytes, usage: wgpu::BufferUsages::VERTEX });
        self.grid_ib = self.device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("grid ib"), contents: ib_bytes, usage: wgpu::BufferUsages::INDEX });
        self.grid_index_count = indices.len() as u32;
    }
}

#[derive(Debug, Clone)]
struct Camera {
    target: [f32; 3],
    radius: f32,
    min_radius: f32,
    max_radius: f32,
    azimuth: f32,
    elevation: f32,
    orbit_speed: f32,
    zoom_speed: f32,
    dragging: bool,
    last_cursor: Option<PhysicalPosition<f64>>,
}

impl Default for Camera {
    fn default() -> Self {
        Self {
            target: [0.0, 0.0, 0.0],
            radius: 6.34194e10,
            min_radius: 1e10,
            max_radius: 1e12,
            azimuth: 0.0,
            elevation: PI / 2.0,
            orbit_speed: 0.01,
            zoom_speed: 25e9,
            dragging: false,
            last_cursor: None,
        }
    }
}

impl Camera {
    fn position(&self) -> [f32; 3] {
        let elevation = self.elevation.clamp(0.01, PI - 0.01);
        let x = self.radius * elevation.sin() * self.azimuth.cos();
        let y = self.radius * elevation.cos();
        let z = self.radius * elevation.sin() * self.azimuth.sin();
        [x, y, z]
    }

    fn basis(&self) -> ([f32; 3], [f32; 3], [f32; 3]) {
        let pos = self.position();
        let target = self.target;
        let forward = normalize3(sub3(target, pos));
        let world_up = [0.0, 1.0, 0.0];
        let right = normalize3(cross3(forward, world_up));
        let up = cross3(right, forward);
        (right, up, forward)
    }

    fn on_mouse_button(&mut self, state: ElementState, button: MouseButton) {
        if button == MouseButton::Left {
            self.dragging = state == ElementState::Pressed;
            if !self.dragging {
                self.last_cursor = None;
            }
        }
    }

    fn on_cursor_moved(&mut self, pos: PhysicalPosition<f64>) {
        if self.dragging {
            if let Some(last) = self.last_cursor {
                let dx = (pos.x - last.x) as f32;
                let dy = (pos.y - last.y) as f32;
                self.azimuth += dx * self.orbit_speed;
                self.elevation = (self.elevation - dy * self.orbit_speed).clamp(0.01, PI - 0.01);
            }
            self.last_cursor = Some(pos);
        } else {
            self.last_cursor = Some(pos);
        }
    }

    fn on_mouse_wheel(&mut self, delta: MouseScrollDelta) {
        let lines = match delta {
            MouseScrollDelta::LineDelta(_x, y) => y as f64 * 40.0,
            MouseScrollDelta::PixelDelta(p) => -p.y,
        };
        self.radius = (self.radius - (lines as f32) * self.zoom_speed)
            .clamp(self.min_radius, self.max_radius);
    }
}

#[derive(Debug, Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
#[repr(C)]
struct PhysicsBody {
    velocity: [f32; 3],
    _pad: f32,
}

#[derive(Default)]
struct AppState {
    camera: Camera,
    gravity_enabled: bool,
    objects: Vec<ObjectData>,
    physics: Vec<PhysicsBody>,
}

// math helpers on arrays
fn sub3(a: [f32; 3], b: [f32; 3]) -> [f32; 3] { [a[0]-b[0], a[1]-b[1], a[2]-b[2]] }
fn cross3(a: [f32; 3], b: [f32; 3]) -> [f32; 3] {
    [
        a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0],
    ]
}
fn dot3(a: [f32; 3], b: [f32; 3]) -> f32 { a[0]*b[0] + a[1]*b[1] + a[2]*b[2] }
fn length3(v: [f32; 3]) -> f32 { dot3(v, v).sqrt() }
fn normalize3(v: [f32; 3]) -> [f32; 3] {
    let len = length3(v);
    if len > 0.0 { [v[0]/len, v[1]/len, v[2]/len] } else { v }
}

fn main() -> Result<()> {
    env_logger::init();

    let event_loop = EventLoop::new()?;
    let window = Rc::new(
        WindowBuilder::new()
            .with_title("raymarching-rust-demo")
            .with_inner_size(PhysicalSize::new(1280, 720))
            .build(&event_loop)?,
    );

    let mut gpu = pollster::block_on(GpuState::new(&window))?;
    let mut app = AppState::default();

    // Seed objects (two stars + BH)
    app.objects = vec![
        ObjectData { pos_radius: [4e11, 0.0, 0.0, 4e10], color: [1.0, 1.0, 0.0, 1.0], mass: 1.98892e30, _pad_align_before_vec3: [0.0; 3], _pad_vec3: [0.0; 3], _pad_end: 0.0 },
        ObjectData { pos_radius: [0.0, 0.0, 4e11, 4e10], color: [1.0, 0.0, 0.0, 1.0], mass: 1.98892e30, _pad_align_before_vec3: [0.0; 3], _pad_vec3: [0.0; 3], _pad_end: 0.0 },
        ObjectData { pos_radius: [0.0, 0.0, 0.0, 1.269e10], color: [0.0, 0.0, 0.0, 1.0], mass: 8.54e36, _pad_align_before_vec3: [0.0; 3], _pad_vec3: [0.0; 3], _pad_end: 0.0 },
    ];
    app.physics = vec![
        PhysicsBody { velocity: [0.0, 0.0, 0.0], _pad: 0.0 },
        PhysicsBody { velocity: [0.0, 0.0, 0.0], _pad: 0.0 },
        PhysicsBody { velocity: [0.0, 0.0, 0.0], _pad: 0.0 },
    ];

    // Initial grid
    gpu.rebuild_grid(&app);

    let window_for_loop = window.clone();

    event_loop.run(move |event, elwt| {
        match event {
            Event::WindowEvent { event, window_id } if window_id == window_for_loop.id() => match event {
                WindowEvent::CloseRequested => elwt.exit(),
                WindowEvent::Resized(size) => gpu.resize(size),
                WindowEvent::RedrawRequested => {
                    // Physics update
                    if app.gravity_enabled {
                        newtonian_gravity_step(&mut app);
                        gpu.rebuild_grid(&app);
                    }

                    gpu.update_uniforms(&app);
                    if let Err(err) = gpu.render(&app) {
                        if let Some(surface_err) = err.downcast_ref::<wgpu::SurfaceError>() {
                            match surface_err {
                                wgpu::SurfaceError::Lost => gpu.resize(gpu.size),
                                wgpu::SurfaceError::OutOfMemory => elwt.exit(),
                                _ => {}
                            }
                        }
                    }
                }
                WindowEvent::MouseInput { state, button, .. } => { app.camera.on_mouse_button(state, button); }
                WindowEvent::CursorMoved { position, .. } => { app.camera.on_cursor_moved(position); }
                WindowEvent::MouseWheel { delta, .. } => { app.camera.on_mouse_wheel(delta); }
                WindowEvent::KeyboardInput { event, .. } => {
                    if event.state == ElementState::Pressed {
                        if let PhysicalKey::Code(KeyCode::KeyG) = event.physical_key {
                            app.gravity_enabled = !app.gravity_enabled;
                            log::info!("Gravity: {}", if app.gravity_enabled {"ON"} else {"OFF"});
                        }
                    }
                }
                _ => {}
            },
            Event::AboutToWait => { window_for_loop.request_redraw(); }
            _ => {}
        }
    })?;

    Ok(())
}

fn newtonian_gravity_step(app: &mut AppState) {
    let g_const = 6.67430e-11f64;
    for i in 0..app.objects.len() {
        let mut ax = 0.0f64; let mut ay = 0.0f64; let mut az = 0.0f64;
        let (xi, yi, zi) = (app.objects[i].pos_radius[0] as f64, app.objects[i].pos_radius[1] as f64, app.objects[i].pos_radius[2] as f64);
        for j in 0..app.objects.len() {
            if i == j { continue; }
            let (xj, yj, zj) = (app.objects[j].pos_radius[0] as f64, app.objects[j].pos_radius[1] as f64, app.objects[j].pos_radius[2] as f64);
            let dx = xj - xi; let dy = yj - yi; let dz = zj - zi;
            let dist_sq = dx*dx + dy*dy + dz*dz;
            if dist_sq == 0.0 { continue; }
            let dist = dist_sq.sqrt();
            let force = g_const * (app.objects[i].mass as f64) * (app.objects[j].mass as f64) / dist_sq;
            let acc = force / (app.objects[i].mass as f64);
            ax += acc * dx / dist;
            ay += acc * dy / dist;
            az += acc * dz / dist;
        }
        app.physics[i].velocity[0] += ax as f32;
        app.physics[i].velocity[1] += ay as f32;
        app.physics[i].velocity[2] += az as f32;
    }
    for i in 0..app.objects.len() {
        app.objects[i].pos_radius[0] += app.physics[i].velocity[0];
        app.objects[i].pos_radius[1] += app.physics[i].velocity[1];
        app.objects[i].pos_radius[2] += app.physics[i].velocity[2];
    }
}

fn make_viewproj(eye: [f32;3], center: [f32;3], up: [f32;3], fovy: f32, aspect: f32, znear: f32, zfar: f32) -> [f32; 16] {
    let f = normalize3([center[0]-eye[0], center[1]-eye[1], center[2]-eye[2]]);
    let s = normalize3(cross3(f, up));
    let u = cross3(s, f);
    let mut view = [0.0f32; 16];
    view[0] = s[0]; view[4] = s[1]; view[8] = s[2]; view[12] = -dot3(s, eye);
    view[1] = u[0]; view[5] = u[1]; view[9] = u[2]; view[13] = -dot3(u, eye);
    view[2] = -f[0]; view[6] = -f[1]; view[10] = -f[2]; view[14] = dot3(f, eye);
    view[3] = 0.0; view[7] = 0.0; view[11] = 0.0; view[15] = 1.0;

    let t = 1.0 / (fovy * 0.5).tan();
    let mut proj = [0.0f32; 16];
    proj[0] = t / aspect;
    proj[5] = t;
    proj[10] = (zfar + znear) / (znear - zfar);
    proj[11] = -1.0;
    proj[14] = (2.0 * zfar * znear) / (znear - zfar);

    // mat4 mul
    let mut out = [0.0f32; 16];
    for r in 0..4 {
        for c in 0..4 {
            out[r*4 + c] = view[r*4 + 0]*proj[0*4 + c]
                         + view[r*4 + 1]*proj[1*4 + c]
                         + view[r*4 + 2]*proj[2*4 + c]
                         + view[r*4 + 3]*proj[3*4 + c];
        }
    }
    out
}
