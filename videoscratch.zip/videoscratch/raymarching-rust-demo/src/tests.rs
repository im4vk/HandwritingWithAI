//! Comprehensive functionality tests for the black hole raytracing simulation

#[cfg(test)]
mod tests {
    use crate::*;
    use std::f32::consts::PI;

    #[test]
    fn test_camera_position_calculation() {
        let mut camera = Camera::default();
        
        // Test default position
        let pos = camera.position();
        assert!((pos[0] * pos[0] + pos[1] * pos[1] + pos[2] * pos[2]).sqrt() - camera.radius < 1.0);
        
        // Test azimuth rotation
        camera.azimuth = PI / 2.0;
        let pos2 = camera.position();
        assert!((pos2[2] - camera.radius * (PI/2.0).sin() * (PI/2.0).sin()).abs() < 1e3);
        
        // Test elevation limits
        camera.elevation = 0.0;
        camera.elevation = camera.elevation.clamp(0.01, PI - 0.01);
        assert!(camera.elevation > 0.0);
        
        camera.elevation = PI;
        camera.elevation = camera.elevation.clamp(0.01, PI - 0.01);
        assert!(camera.elevation < PI);
    }

    #[test]
    fn test_camera_basis_vectors() {
        let camera = Camera::default();
        let (right, up, forward) = camera.basis();
        
        // Test orthogonality
        let dot_right_up = dot3(right, up);
        let dot_right_forward = dot3(right, forward);
        let dot_up_forward = dot3(up, forward);
        
        assert!(dot_right_up.abs() < 1e-5);
        assert!(dot_right_forward.abs() < 1e-5);
        assert!(dot_up_forward.abs() < 1e-5);
        
        // Test normalization
        assert!((length3(right) - 1.0).abs() < 1e-5);
        assert!((length3(up) - 1.0).abs() < 1e-5);
        assert!((length3(forward) - 1.0).abs() < 1e-5);
    }

    #[test]
    fn test_gravity_calculation() {
        let mut app = AppState::default();
        // Use closer objects with larger masses for detectable effect
        app.objects = vec![
            ObjectData { 
                pos_radius: [0.0, 0.0, 0.0, 1e10], 
                color: [1.0, 1.0, 1.0, 1.0], 
                mass: 1e36, // Much larger mass
                _pad_align_before_vec3: [0.0; 3], 
                _pad_vec3: [0.0; 3], 
                _pad_end: 0.0 
            },
            ObjectData { 
                pos_radius: [1e11, 0.0, 0.0, 1e10], // Closer distance
                color: [1.0, 0.0, 0.0, 1.0], 
                mass: 1e36, // Much larger mass
                _pad_align_before_vec3: [0.0; 3], 
                _pad_vec3: [0.0; 3], 
                _pad_end: 0.0 
            },
        ];
        app.physics = vec![
            PhysicsBody { velocity: [0.0; 3], _pad: 0.0 },
            PhysicsBody { velocity: [0.0; 3], _pad: 0.0 },
        ];

        // Run multiple steps to accumulate detectable movement
        for _ in 0..100 {
            newtonian_gravity_step(&mut app);
        }

        // Check velocities changed (acceleration occurred)
        assert!(app.physics[0].velocity[0] != 0.0, "Object 0 should have non-zero velocity");
        assert!(app.physics[1].velocity[0] != 0.0, "Object 1 should have non-zero velocity");
        
        // Check velocities point toward each other
        assert!(app.physics[0].velocity[0] > 0.0, "Object 0 should accelerate toward object 1 (+x direction)");
        assert!(app.physics[1].velocity[0] < 0.0, "Object 1 should accelerate toward object 0 (-x direction)");
    }

    #[test]
    fn test_math_helper_functions() {
        let a = [1.0, 2.0, 3.0];
        let b = [4.0, 5.0, 6.0];
        
        // Test subtraction
        let sub_result = sub3(b, a);
        assert_eq!(sub_result, [3.0, 3.0, 3.0]);
        
        // Test dot product
        let dot_result = dot3(a, b);
        assert_eq!(dot_result, 32.0); // 1*4 + 2*5 + 3*6 = 32
        
        // Test length
        let len = length3([3.0, 4.0, 0.0]);
        assert!((len - 5.0).abs() < 1e-5);
        
        // Test normalize
        let normalized = normalize3([3.0, 4.0, 0.0]);
        assert!((normalized[0] - 0.6).abs() < 1e-5);
        assert!((normalized[1] - 0.8).abs() < 1e-5);
        assert!(normalized[2].abs() < 1e-5);
        
        // Test cross product
        let cross_result = cross3([1.0, 0.0, 0.0], [0.0, 1.0, 0.0]);
        assert_eq!(cross_result, [0.0, 0.0, 1.0]);
    }

    #[test]
    fn test_schwarzschild_constants() {
        // Test that Sagittarius A* parameters are correct
        let sag_a_mass = 8.54e36f64; // kg
        let c = 299792458.0f64; // m/s
        let g = 6.67430e-11f64; // m³/kg/s²
        
        let calculated_rs = 2.0f64 * g * sag_a_mass / (c * c);
        let expected_rs = 1.269e10f64; // From shader
        
        // Allow small floating point error
        let relative_error = (calculated_rs - expected_rs).abs() / expected_rs;
        assert!(relative_error < 0.01f64); // Within 1%
    }

    #[test]
    fn test_object_data_layout() {
        // Verify ObjectData struct has correct size alignment
        let obj = ObjectData {
            pos_radius: [1.0, 2.0, 3.0, 4.0],
            color: [0.5, 0.6, 0.7, 0.8],
            mass: 1e30,
            _pad_align_before_vec3: [0.0; 3],
            _pad_vec3: [0.0; 3],
            _pad_end: 0.0,
        };
        
        // Check that mass is accessible
        assert_eq!(obj.mass, 1e30);
        assert_eq!(obj.pos_radius[0], 1.0);
        assert_eq!(obj.color[3], 0.8);
    }

    #[test]
    fn test_objects_block_size() {
        use std::mem::size_of;
        
        // Calculate expected size of ObjectsBlock
        let header_size = size_of::<i32>() + 3 * size_of::<i32>(); // num_objects + _pad0
        let arrays_size = 16 * 4 * size_of::<f32>() * 3; // pos_radius + color + mass arrays
        let tail_padding = 3 * 4 * size_of::<f32>(); // 3 vec4 padding
        
        let expected_size = header_size + arrays_size + tail_padding;
        let actual_size = size_of::<ObjectsBlock>();
        
        println!("Expected ObjectsBlock size: {}", expected_size);
        println!("Actual ObjectsBlock size: {}", actual_size);
        
        // Should be 832 bytes to match shader expectation
        assert_eq!(actual_size, 832);
    }

    #[test]
    fn test_camera_zoom_limits() {
        let mut camera = Camera::default();
        let _initial_radius = camera.radius;
        
        // Test zoom in beyond limit
        camera.radius = camera.min_radius - 1e9;
        camera.radius = camera.radius.clamp(camera.min_radius, camera.max_radius);
        assert!(camera.radius >= camera.min_radius);
        
        // Test zoom out beyond limit
        camera.radius = camera.max_radius + 1e12;
        camera.radius = camera.radius.clamp(camera.min_radius, camera.max_radius);
        assert!(camera.radius <= camera.max_radius);
    }

    #[test]
    fn test_grid_warping_calculation() {
        // Test the grid warping formula from rebuild_grid
        let g = 6.67430e-11f64;
        let c = 299792458.0f64;
        let mass = 8.54e36f64;
        let rs = 2.0 * g * mass / (c * c);
        
        // Test point outside event horizon
        let distance = rs * 2.0; // Safe distance
        let delta_y = 2.0 * (rs * (distance - rs)).sqrt();
        
        assert!(delta_y > 0.0);
        assert!(delta_y.is_finite());
        
        // Test edge case at event horizon
        let _distance_at_horizon = rs;
        let delta_y_horizon = 2.0 * (rs * rs).sqrt();
        assert!(delta_y_horizon > 0.0);
        assert!(delta_y_horizon.is_finite());
    }
}
