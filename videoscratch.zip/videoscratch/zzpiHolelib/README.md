# zzpi_holelib - Pi-hole Implementation from Scratch

A complete Pi-hole implementation built from scratch in Rust, featuring DNS filtering, web administration interface, and statistics tracking.

## Features

🕳️ **Complete Pi-hole Implementation**
- DNS server with query filtering and blocking
- Web admin interface with REST API
- Statistics tracking and logging
- Blocklist/whitelist management
- Gravity list downloading and updates
- Pi-hole v5 API compatibility

🚀 **Built from Scratch**
- No dependencies on existing Pi-hole software
- Pure Rust implementation
- Async/await throughout
- Production-ready architecture

## Quick Start

### 1. Build the project

```bash
cargo build --release
```

### 2. Run the demo server

```bash
# Using the binary
cargo run --bin pihole

# Or using examples
cargo run --example run_pihole
```

### 3. Test the implementation

```bash
cargo run --example test_blocking
```

## Usage

### Configuration

The server uses a JSON configuration file (`pihole.json`):

```json
{
  "dns_bind_address": "0.0.0.0",
  "dns_port": 5353,
  "web_bind_address": "0.0.0.0", 
  "web_port": 8080,
  "upstream_dns": ["1.1.1.1:53", "8.8.8.8:53"],
  "data_dir": "./pihole-data",
  "blocking_enabled": true,
  "gravity_lists": [
    "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
  ]
}
```

### Command Line Options

```bash
# Custom ports (non-root required for port 53)
cargo run --bin pihole -- --dns-port 5353 --web-port 8080

# Custom data directory
cargo run --bin pihole -- --data-dir ./my-pihole-data

# Custom config file
cargo run --bin pihole -- --config my-config.json
```

### API Endpoints

**Pi-hole v5 Compatible API:**
- `GET /admin/api.php?summaryRaw` - Get summary statistics
- `GET /admin/api.php?enable` - Enable blocking
- `GET /admin/api.php?disable[=seconds]` - Disable blocking
- `GET /admin/api.php?list=black` - List blacklisted domains
- `GET /admin/api.php?add=black&domain=example.com` - Add to blacklist
- `GET /admin/api.php?version` - Get version info

**Modern REST API:**
- `GET /api/stats/summary` - Summary statistics (JSON)
- `GET /api/lists/blacklist` - Custom blacklist
- `POST /api/lists/blacklist` - Add to blacklist
- `GET /api/lists/whitelist` - Custom whitelist
- `POST /api/lists/whitelist` - Add to whitelist

### Testing DNS Functionality

```bash
# Test DNS server (when running on port 5353)
dig @127.0.0.1 -p 5353 example.com

# Test with nslookup
nslookup example.com 127.0.0.1:5353
```

### Testing Web Interface

```bash
# Get summary stats
curl "http://localhost:8080/admin/api.php?summaryRaw"

# Modern REST API
curl "http://localhost:8080/api/stats/summary"

# Add domain to blacklist
curl -X POST "http://localhost:8080/api/lists/blacklist" \
  -H "Content-Type: application/json" \
  -d '{"domain": "ads.example.com", "comment": "Test blocking"}'
```

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   DNS Server    │    │   Web Server    │    │ Blocklist Mgr   │
│                 │    │                 │    │                 │
│ • Query Filter  │◄──►│ • REST API      │◄──►│ • Custom Lists  │
│ • Upstream Fwd  │    │ • Pi-hole API   │    │ • Gravity Lists │
│ • Statistics    │    │ • Admin UI      │    │ • Pattern Match │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ Stats Collector │    │ Config Manager  │    │ Gravity Updater │
│                 │    │                 │    │                 │
│ • Query Logs    │    │ • JSON Config   │    │ • HTTP Download │
│ • Metrics       │    │ • Validation    │    │ • Auto Update   │
│ • Persistence   │    │ • Defaults      │    │ • List Parsing  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Components

### DNS Server (`src/dns.rs`)
- UDP-based DNS server
- Query interception and filtering
- Upstream DNS forwarding
- Statistics recording

### Web Server (`src/web.rs`)
- Axum-based HTTP server
- Pi-hole v5 API compatibility
- Modern REST API
- CORS support

### Blocklist Manager (`src/blocklist.rs`)
- Domain blocking/allowing logic
- Custom blacklist/whitelist
- Gravity list integration
- Pattern matching support

### Statistics Collector (`src/stats.rs`)
- Query logging
- Metrics aggregation
- Summary statistics
- Client tracking

### Gravity Updater (`src/gravity.rs`)
- HTTP-based list downloading
- Automatic updates
- Multiple list format support
- Background processing

## Development

### Running Tests

```bash
cargo test
```

### Building Examples

```bash
cargo build --examples
```

### Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This project is a demonstration implementation of Pi-hole functionality.

## Notes

- Uses non-privileged ports (5353, 8080) by default for demo purposes
- For production use with standard DNS port 53, run with appropriate privileges
- Simplified DNS packet handling for demonstration
- In-memory statistics for demo (can be extended with persistent storage)
- Compatible with Pi-hole v5 API endpoints

## Real Pi-hole Comparison

This implementation demonstrates the core concepts of Pi-hole:

| Feature | This Implementation | Real Pi-hole |
|---------|-------------------|--------------|
| DNS Filtering | ✅ Simplified | ✅ Full DNS server |
| Web Interface | ✅ REST API | ✅ Full admin UI |
| Blocklists | ✅ Basic support | ✅ Advanced lists |
| Statistics | ✅ In-memory | ✅ Database-backed |
| DHCP | ❌ Not implemented | ✅ Optional |
| IPv6 | ❌ Not implemented | ✅ Full support |

This is a learning/demo implementation showing how Pi-hole works under the hood!