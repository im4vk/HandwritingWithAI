use zzpi_holelib::{Config, PiHole};
use zzpi_holelib::metrics::MetricsCollector;
use zzpi_holelib::security::RateLimiter;
use zzpi_holelib::cache::DnsCache;
use std::net::IpAddr;
use tokio::time::Duration;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize enhanced logging
    tracing_subscriber::fmt()
        .with_env_filter("zzpi_holelib=debug,advanced_pihole=info")
        .init();

    println!("🚀 Starting Advanced Pi-hole Server with Improvements");

    // Create enhanced configuration
    let mut config = Config::default();
    
    // Enhanced settings
    config.dns_port = 5353;
    config.web_port = 8080;
    config.dns_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    config.web_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    config.data_dir = std::path::PathBuf::from("./advanced-pihole-data");
    
    // Performance settings
    config.cache_size = 50000;
    config.cache_ttl_seconds = 600;
    config.rate_limit_per_minute = 500;
    config.log_retention_days = 30;
    config.enable_query_logging = true;
    
    // Enhanced upstream DNS with multiple providers
    config.upstream_dns = vec![
        "1.1.1.1:53".to_string(),      // Cloudflare
        "8.8.8.8:53".to_string(),      // Google
        "9.9.9.9:53".to_string(),      // Quad9
        "208.67.222.222:53".to_string(), // OpenDNS
    ];
    
    config.ensure_data_dir().await?;

    println!("📋 Enhanced Configuration:");
    println!("   DNS: {}:{} with {} upstream servers", config.dns_bind_address, config.dns_port, config.upstream_dns.len());
    println!("   Web: {}:{}", config.web_bind_address, config.web_port);
    println!("   Cache: {} entries, {} second TTL", config.cache_size, config.cache_ttl_seconds);
    println!("   Rate limit: {} queries/minute per client", config.rate_limit_per_minute);
    println!("   Data: {}", config.data_dir.display());

    // Demonstrate new components
    demonstrate_cache().await;
    demonstrate_security().await;
    demonstrate_metrics().await;

    println!("\n🕳️  Creating Pi-hole instance...");
    let pihole = PiHole::new(config.clone()).await?;

    println!("✅ Pi-hole server created with enhanced features:");
    println!("   • Real DNS packet parsing");
    println!("   • Upstream DNS resolution with fallback");
    println!("   • Database-backed statistics");
    println!("   • DNS response caching");
    println!("   • Rate limiting & security");
    println!("   • Real-time metrics");
    println!();
    println!("🌐 Endpoints available:");
    println!("   • http://{}:{}/admin/api.php?summaryRaw", config.web_bind_address, config.web_port);
    println!("   • http://{}:{}/api/stats/summary", config.web_bind_address, config.web_port);
    println!("   • http://{}:{}/api/metrics", config.web_bind_address, config.web_port);
    println!();
    println!("🧪 Test DNS queries:");
    println!("   dig @{} -p {} example.com", config.dns_bind_address, config.dns_port);
    println!("   nslookup example.com {}:{}", config.dns_bind_address, config.dns_port);
    println!();

    // Start the enhanced server
    println!("🚀 Starting enhanced Pi-hole server...");
    pihole.start().await?;

    Ok(())
}

async fn demonstrate_cache() {
    println!("\n🔄 DNS Cache Demonstration:");
    let cache = DnsCache::new(1000, Duration::from_secs(300));
    
    // This would be integrated into the real DNS server
    println!("   • Cache capacity: 1000 entries");
    println!("   • Default TTL: 300 seconds");
    println!("   • Automatic expiration and LRU eviction");
    
    let stats = cache.get_stats().await;
    println!("   • Current entries: {}/{}", stats.total_entries, stats.max_size);
}

async fn demonstrate_security() {
    println!("\n🔒 Security Features Demonstration:");
    let rate_limiter = RateLimiter::new(100);
    
    println!("   • Rate limiting: 100 queries/minute per client");
    println!("   • Input validation for domain names");
    println!("   • Suspicious domain pattern detection");
    println!("   • Security event logging");
    
    let stats = rate_limiter.get_stats().await;
    println!("   • Currently tracking {} clients", stats.active_clients);
}

async fn demonstrate_metrics() {
    println!("\n📊 Real-time Metrics Demonstration:");
    let metrics = MetricsCollector::new();
    
    // Simulate some metrics
    let client_ip = "192.168.1.100".parse().unwrap();
    metrics.record_query(client_ip, "example.com", false, 50).await;
    metrics.record_query(client_ip, "ads.example.com", true, 30).await;
    metrics.record_cache_hit();
    
    let snapshot = metrics.get_snapshot().await;
    println!("   • Total queries: {}", snapshot.dns_metrics.total_queries);
    println!("   • Blocked queries: {}", snapshot.dns_metrics.blocked_queries);
    println!("   • Block percentage: {:.1}%", snapshot.dns_metrics.block_percentage);
    println!("   • Average response time: {}ms", snapshot.performance_metrics.avg_response_time_ms);
    println!("   • Cache hit rate: {:.1}%", snapshot.cache_metrics.cache_hit_rate);
    println!("   • Unique clients: {}", snapshot.client_metrics.unique_clients);
}
