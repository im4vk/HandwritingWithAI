use zzpi_holelib::{Config, PiHole};
use std::net::IpAddr;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize logging
    tracing_subscriber::fmt::init();

    // Create a demo configuration
    let mut config = Config::default();
    
    // Use non-privileged ports for demo
    config.dns_port = 5353;
    config.web_port = 8080;
    config.dns_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    config.web_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    
    // Set up data directory
    config.data_dir = std::path::PathBuf::from("./demo-pihole-data");
    config.ensure_data_dir().await?;

    println!("🕳️  Starting Pi-hole Demo Server");
    println!("📡 DNS server: {}:{}", config.dns_bind_address, config.dns_port);
    println!("🌐 Web interface: http://{}:{}", config.web_bind_address, config.web_port);
    println!("");
    println!("Try these endpoints:");
    println!("  - http://{}:{}/admin/api.php?summaryRaw", config.web_bind_address, config.web_port);
    println!("  - http://{}:{}/api/stats/summary", config.web_bind_address, config.web_port);
    println!("");

    // Create and start Pi-hole
    let pihole = PiHole::new(config).await?;
    pihole.start().await?;

    Ok(())
}
