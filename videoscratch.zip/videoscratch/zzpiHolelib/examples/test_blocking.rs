use zzpi_holelib::{Config, PiHole};
use std::net::IpAddr;
use tokio::time::{sleep, Duration};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    tracing_subscriber::fmt::init();

    println!("🧪 Testing Pi-hole blocking functionality");

    // Create configuration
    let mut config = Config::default();
    config.dns_port = 5353;
    config.web_port = 8081;
    config.dns_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    config.web_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    config.data_dir = std::path::PathBuf::from("./test-pihole-data");
    config.ensure_data_dir().await?;

    println!("📋 Configuration:");
    println!("   DNS: {}:{}", config.dns_bind_address, config.dns_port);
    println!("   Web: {}:{}", config.web_bind_address, config.web_port);
    println!("   Data: {}", config.data_dir.display());

    // Create Pi-hole instance
    let pihole = PiHole::new(config.clone()).await?;

    // Start servers in background
    let pihole_handle = tokio::spawn(async move {
        if let Err(e) = pihole.start().await {
            eprintln!("Pi-hole server error: {}", e);
        }
    });

    // Wait for servers to start
    sleep(Duration::from_secs(2)).await;

    println!("\n🔍 Testing API endpoints...");

    // Test web API
    let client = reqwest::Client::new();
    
    // Test summary endpoint
    let summary_url = format!("http://{}:{}/admin/api.php?summaryRaw", 
                             config.web_bind_address, config.web_port);
    
    match client.get(&summary_url).send().await {
        Ok(response) => {
            if response.status().is_success() {
                let body = response.text().await?;
                println!("✅ Summary API: {}", body);
            } else {
                println!("❌ Summary API failed with status: {}", response.status());
            }
        }
        Err(e) => {
            println!("❌ Summary API request failed: {}", e);
        }
    }

    // Test modern REST API
    let rest_url = format!("http://{}:{}/api/stats/summary", 
                          config.web_bind_address, config.web_port);
    
    match client.get(&rest_url).send().await {
        Ok(response) => {
            if response.status().is_success() {
                let body = response.text().await?;
                println!("✅ REST API: {}", body);
            } else {
                println!("❌ REST API failed with status: {}", response.status());
            }
        }
        Err(e) => {
            println!("❌ REST API request failed: {}", e);
        }
    }

    println!("\n📊 Pi-hole server is running!");
    println!("   Press Ctrl+C to stop");

    // Wait for interrupt
    tokio::select! {
        _ = tokio::signal::ctrl_c() => {
            println!("\n🛑 Shutting down...");
        }
        _ = pihole_handle => {
            println!("🛑 Pi-hole server stopped");
        }
    }

    Ok(())
}
