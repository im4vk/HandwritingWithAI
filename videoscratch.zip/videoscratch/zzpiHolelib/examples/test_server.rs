use zzpi_holelib::{Config, PiHole};
use std::net::IpAddr;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("🚀 Starting Pi-hole Test Server");

    // Enhanced logging
    tracing_subscriber::fmt::init();

    // Create configuration with custom ports to avoid conflicts
    let mut config = Config::default();
    config.dns_port = 15353; // Use a different port to avoid conflicts
    config.web_port = 18080;
    config.dns_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    config.web_bind_address = "127.0.0.1".parse::<IpAddr>()?;
    config.data_dir = std::path::PathBuf::from("./test-pihole-data");
    
    // Ensure data directory exists
    config.ensure_data_dir().await?;

    println!("📋 Test Configuration:");
    println!("   DNS: {}:{}", config.dns_bind_address, config.dns_port);
    println!("   Web: {}:{}", config.web_bind_address, config.web_port);

    // Create and start Pi-hole
    let pihole = PiHole::new(config.clone()).await?;
    
    println!("✅ Pi-hole server created successfully");
    println!("🌐 Test the server:");
    println!("   Web: http://{}:{}/admin/api.php?summaryRaw", config.web_bind_address, config.web_port);
    println!("   DNS: dig @{} -p {} example.com", config.dns_bind_address, config.dns_port);
    
    // Start the server
    pihole.start().await?;

    Ok(())
}
