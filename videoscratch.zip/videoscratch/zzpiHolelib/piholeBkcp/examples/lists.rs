use std::env;
use zzpi_holelib::PiHoleClient;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let base = env::var("PIHOLE_BASE_URL").unwrap_or_else(|_| "http://pi.hole/".to_string());
    let token = env::var("PIHOLE_TOKEN").ok();

    let client = PiHoleClient::new(&base, token)?;

    let bl = client.list_blacklist().await?;
    println!("blacklist: {:?}", bl);

    let wl = client.list_whitelist().await?;
    println!("whitelist: {:?}", wl);

    let domain = "example.com";
    let _ = client.add_to_blacklist(domain).await?;
    let _ = client.remove_from_blacklist(domain).await?;

    let _ = client.add_to_whitelist(domain).await?;
    let _ = client.remove_from_whitelist(domain).await?;

    Ok(())
}


