use std::env;
use zzpi_holelib::PiHoleClient;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let base = env::var("PIHOLE_BASE_URL").unwrap_or_else(|_| "http://pi.hole/".to_string());
    let token = env::var("PIHOLE_TOKEN").ok();

    let client = PiHoleClient::new(&base, token)?;
    let summary = client.summary_raw().await?;
    println!("summary_raw: {:?}", summary);
    Ok(())
}


