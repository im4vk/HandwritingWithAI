use reqwest::{Client as HttpClient, Url};

use crate::error::{PiHoleError, Result};
use crate::types::{DomainListResponse, EnableDisableResponse, SummaryRaw, Version};

#[derive(Debug, Clone)]
pub struct PiHoleClient {
    base_url: Url,
    auth_token: Option<String>,
    http: HttpClient,
}

impl PiHoleClient {
    pub fn new(base_url: &str, auth_token: Option<String>) -> Result<Self> {
        let mut base = Url::parse(base_url)?;
        if !base.path().ends_with('/') {
            base.set_path(&format!("{}/", base.path()));
        }
        let http = HttpClient::builder().build()?;
        Ok(Self { base_url: base, auth_token, http })
    }

    fn api_url(&self) -> Url {
        self.base_url.join("admin/api.php").expect("base url join admin/api.php")
    }

    async fn get_json<T: serde::de::DeserializeOwned>(&self, mut url: Url) -> Result<T> {
        if let Some(token) = &self.auth_token {
            url.query_pairs_mut().append_pair("auth", token);
        }
        let response = self.http.get(url).send().await?;
        if !response.status().is_success() {
            return Err(PiHoleError::Api(format!("unexpected status: {}", response.status())));
        }
        let data = response.json::<T>().await?;
        Ok(data)
    }

    // GET /admin/api.php?summaryRaw
    pub async fn summary_raw(&self) -> Result<SummaryRaw> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("summaryRaw", "");
        self.get_json(url).await
    }

    // GET /admin/api.php?version
    pub async fn version(&self) -> Result<Version> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("version", "");
        self.get_json(url).await
    }

    // GET /admin/api.php?enable
    pub async fn enable(&self) -> Result<EnableDisableResponse> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("enable", "");
        self.get_json(url).await
    }

    // GET /admin/api.php?disable[=seconds]
    pub async fn disable(&self, seconds: Option<u64>) -> Result<EnableDisableResponse> {
        let mut url = self.api_url();
        match seconds {
            Some(s) => url.query_pairs_mut().append_pair("disable", &s.to_string()),
            None => url.query_pairs_mut().append_pair("disable", ""),
        };
        self.get_json(url).await
    }

    // Blacklist management via list, add, remove
    // GET /admin/api.php?list=black
    pub async fn list_blacklist(&self) -> Result<DomainListResponse> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("list", "black");
        self.get_json(url).await
    }

    // GET /admin/api.php?add=black&domain=example.com
    pub async fn add_to_blacklist(&self, domain: &str) -> Result<DomainListResponse> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("add", "black");
        url.query_pairs_mut().append_pair("domain", domain);
        self.get_json(url).await
    }

    // GET /admin/api.php?sub=black&domain=example.com
    pub async fn remove_from_blacklist(&self, domain: &str) -> Result<DomainListResponse> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("sub", "black");
        url.query_pairs_mut().append_pair("domain", domain);
        self.get_json(url).await
    }

    // Whitelist
    pub async fn list_whitelist(&self) -> Result<DomainListResponse> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("list", "white");
        self.get_json(url).await
    }

    pub async fn add_to_whitelist(&self, domain: &str) -> Result<DomainListResponse> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("add", "white");
        url.query_pairs_mut().append_pair("domain", domain);
        self.get_json(url).await
    }

    pub async fn remove_from_whitelist(&self, domain: &str) -> Result<DomainListResponse> {
        let mut url = self.api_url();
        url.query_pairs_mut().append_pair("sub", "white");
        url.query_pairs_mut().append_pair("domain", domain);
        self.get_json(url).await
    }
}


