use thiserror::Error;

#[derive(Debug, Error)]
pub enum PiHoleError {
    #[error("http error: {0}")]
    Http(#[from] reqwest::Error),

    #[error("url parse error: {0}")]
    UrlParse(#[from] url::ParseError),

    #[error("api error: {0}")]
    Api(String),
}

pub type Result<T> = std::result::Result<T, PiHoleError>;


