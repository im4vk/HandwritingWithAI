pub mod client;
pub mod error;
pub mod types;

pub use client::PiHoleClient;
pub use error::{PiHoleError, Result};
pub use types::*;
