use serde::{Deserialize, Serialize};

// Minimal structures to cover demo endpoints

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SummaryRaw {
    pub domains_being_blocked: Option<u64>,
    pub dns_queries_today: Option<u64>,
    pub ads_blocked_today: Option<u64>,
    pub ads_percentage_today: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Version {
    pub core_current: Option<String>,
    pub core_latest: Option<String>,
    pub web_current: Option<String>,
    pub web_latest: Option<String>,
    pub ftl_current: Option<String>,
    pub ftl_latest: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DomainListResponse {
    pub data: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EnableDisableResponse {
    pub status: Option<String>,
}


