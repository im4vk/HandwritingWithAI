use httpmock::prelude::*;
use zzpi_holelib::{PiHoleClient, PiHoleError};

#[tokio::test]
async fn test_invalid_url() {
    let result = PiHoleClient::new("not-a-url", Some("token".to_string()));
    assert!(result.is_err());
    match result.unwrap_err() {
        PiHoleError::UrlParse(_) => {},
        _ => panic!("Expected UrlParse error"),
    }
}

#[tokio::test]
async fn test_http_error_404() {
    let server = MockServer::start();
    let mock = server.mock(|when, then| {
        when.method(GET).path("/admin/api.php");
        then.status(404);
    });

    let base = format!("{}/", server.base_url());
    let client = PiHoleClient::new(&base, Some("token123".to_string())).unwrap();
    let result = client.summary_raw().await;
    
    assert!(result.is_err());
    match result.unwrap_err() {
        PiHoleError::Api(msg) => assert!(msg.contains("404")),
        _ => panic!("Expected Api error"),
    }
    mock.assert();
}

#[tokio::test]
async fn test_invalid_json_response() {
    let server = MockServer::start();
    let mock = server.mock(|when, then| {
        when.method(GET).path("/admin/api.php");
        then.status(200).body("invalid json");
    });

    let base = format!("{}/", server.base_url());
    let client = PiHoleClient::new(&base, Some("token123".to_string())).unwrap();
    let result = client.summary_raw().await;
    
    assert!(result.is_err());
    match result.unwrap_err() {
        PiHoleError::Http(_) => {},
        _ => panic!("Expected Http error for JSON parsing"),
    }
    mock.assert();
}

#[tokio::test]
async fn test_no_auth_token() {
    let server = MockServer::start();
    let mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("summaryRaw", "");
        then.status(200)
            .json_body(serde_json::json!({
                "domains_being_blocked": 50000
            }));
    });

    let base = format!("{}/", server.base_url());
    let client = PiHoleClient::new(&base, None).unwrap();
    let summary = client.summary_raw().await.unwrap();
    assert_eq!(summary.domains_being_blocked, Some(50000));
    mock.assert();
}

#[tokio::test]
async fn test_url_normalization() {
    let server = MockServer::start();
    let mock = server.mock(|when, then| {
        when.method(GET).path("/admin/api.php");
        then.status(200).json_body(serde_json::json!({}));
    });

    // Test URL without trailing slash gets normalized
    let base_without_slash = server.base_url();
    let client = PiHoleClient::new(&base_without_slash, None).unwrap();
    let _result = client.summary_raw().await;
    mock.assert();
}

#[tokio::test]
async fn test_list_management_endpoints() {
    let server = MockServer::start();
    
    let list_mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("list", "black");
        then.status(200)
            .json_body(serde_json::json!({
                "data": ["example.com", "ads.com"]
            }));
    });

    let add_mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("add", "black")
            .query_param("domain", "test.com");
        then.status(200)
            .json_body(serde_json::json!({
                "data": ["example.com", "ads.com", "test.com"]
            }));
    });

    let remove_mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("sub", "black")
            .query_param("domain", "test.com");
        then.status(200)
            .json_body(serde_json::json!({
                "data": ["example.com", "ads.com"]
            }));
    });

    let base = format!("{}/", server.base_url());
    let client = PiHoleClient::new(&base, None).unwrap();

    let list = client.list_blacklist().await.unwrap();
    assert_eq!(list.data.len(), 2);
    list_mock.assert();

    let add_result = client.add_to_blacklist("test.com").await.unwrap();
    assert_eq!(add_result.data.len(), 3);
    add_mock.assert();

    let remove_result = client.remove_from_blacklist("test.com").await.unwrap();
    assert_eq!(remove_result.data.len(), 2);
    remove_mock.assert();
}

#[tokio::test]
async fn test_version_endpoint() {
    let server = MockServer::start();
    let mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("version", "");
        then.status(200)
            .json_body(serde_json::json!({
                "core_current": "v5.8.1",
                "core_latest": "v5.8.1",
                "web_current": "v5.7",
                "web_latest": "v5.7",
                "ftl_current": "v5.12.2",
                "ftl_latest": "v5.12.2"
            }));
    });

    let base = format!("{}/", server.base_url());
    let client = PiHoleClient::new(&base, None).unwrap();
    let version = client.version().await.unwrap();
    assert_eq!(version.core_current.as_deref(), Some("v5.8.1"));
    assert_eq!(version.ftl_current.as_deref(), Some("v5.12.2"));
    mock.assert();
}
