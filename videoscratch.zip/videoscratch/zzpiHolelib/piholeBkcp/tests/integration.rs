// Integration test to verify all public API surface works correctly
use zzpi_holelib::{PiHoleClient, PiHoleError, Result};

#[test]
fn test_public_exports() {
    // Test that all expected types are publicly accessible
    let _client_type = std::any::type_name::<PiHoleClient>();
    let _error_type = std::any::type_name::<PiHoleError>();
    let _result_type = std::any::type_name::<Result<()>>();
}

#[test]
fn test_error_display() {
    let api_error = PiHoleError::Api("test error".to_string());
    let display = format!("{}", api_error);
    assert_eq!(display, "api error: test error");
}

#[test]
fn test_error_debug() {
    let api_error = PiHoleError::Api("test error".to_string());
    let debug = format!("{:?}", api_error);
    assert!(debug.contains("Api"));
    assert!(debug.contains("test error"));
}

#[tokio::test]
async fn test_client_creation_variants() {
    // Test creation with token
    let client_with_token = PiHoleClient::new("http://example.com", Some("token".to_string()));
    assert!(client_with_token.is_ok());

    // Test creation without token
    let client_without_token = PiHoleClient::new("http://example.com", None);
    assert!(client_without_token.is_ok());

    // Test creation with invalid URL
    let invalid_client = PiHoleClient::new("invalid-url", None);
    assert!(invalid_client.is_err());
}

#[test]
fn test_serde_types() {
    use zzpi_holelib::types::*;
    
    // Test SummaryRaw serialization/deserialization
    let summary = SummaryRaw {
        domains_being_blocked: Some(100000),
        dns_queries_today: Some(1234),
        ads_blocked_today: Some(56),
        ads_percentage_today: Some(4.5),
    };
    
    let json = serde_json::to_string(&summary).unwrap();
    let deserialized: SummaryRaw = serde_json::from_str(&json).unwrap();
    assert_eq!(summary.domains_being_blocked, deserialized.domains_being_blocked);

    // Test Version serialization/deserialization
    let version = Version {
        core_current: Some("v5.8.1".to_string()),
        core_latest: Some("v5.8.1".to_string()),
        web_current: Some("v5.7".to_string()),
        web_latest: Some("v5.7".to_string()),
        ftl_current: Some("v5.12.2".to_string()),
        ftl_latest: Some("v5.12.2".to_string()),
    };
    
    let json = serde_json::to_string(&version).unwrap();
    let deserialized: Version = serde_json::from_str(&json).unwrap();
    assert_eq!(version.core_current, deserialized.core_current);

    // Test DomainListResponse
    let domain_list = DomainListResponse {
        data: vec!["example.com".to_string(), "ads.com".to_string()],
    };
    
    let json = serde_json::to_string(&domain_list).unwrap();
    let deserialized: DomainListResponse = serde_json::from_str(&json).unwrap();
    assert_eq!(domain_list.data, deserialized.data);

    // Test EnableDisableResponse
    let enable_response = EnableDisableResponse {
        status: Some("enabled".to_string()),
    };
    
    let json = serde_json::to_string(&enable_response).unwrap();
    let deserialized: EnableDisableResponse = serde_json::from_str(&json).unwrap();
    assert_eq!(enable_response.status, deserialized.status);
}

#[test]
fn test_types_debug_clone() {
    use zzpi_holelib::types::*;
    
    let summary = SummaryRaw {
        domains_being_blocked: Some(100000),
        dns_queries_today: Some(1234),
        ads_blocked_today: Some(56),
        ads_percentage_today: Some(4.5),
    };
    
    // Test Debug trait
    let debug_str = format!("{:?}", summary);
    assert!(debug_str.contains("SummaryRaw"));
    
    // Test Clone trait
    let cloned = summary.clone();
    assert_eq!(summary.domains_being_blocked, cloned.domains_being_blocked);
}

// Test that we can import and use everything from the crate root
#[test]
fn test_crate_root_imports() {
    use zzpi_holelib::*;
    
    // Should be able to create client using re-exported type
    let _result: Result<PiHoleClient> = PiHoleClient::new("http://example.com", None);
    
    // Should be able to use error type
    let _error = PiHoleError::Api("test".to_string());
}
