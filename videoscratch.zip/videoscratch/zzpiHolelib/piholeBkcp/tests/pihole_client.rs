use httpmock::prelude::*;
use zzpi_holelib::PiHoleClient;

#[tokio::test]
async fn summary_raw_success() {
    let server = MockServer::start();
    let mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("summaryRaw", "")
            .query_param("auth", "token123");
        then.status(200)
            .json_body(serde_json::json!({
                "domains_being_blocked": 100000,
                "dns_queries_today": 1234,
                "ads_blocked_today": 56,
                "ads_percentage_today": 4.5
            }));
    });

    let base = format!("{}/", server.base_url());
    let client = PiHoleClient::new(&base, Some("token123".to_string())).unwrap();
    let summary = client.summary_raw().await.unwrap();
    assert_eq!(summary.domains_being_blocked, Some(100000));
    mock.assert();
}

#[tokio::test]
async fn enable_disable_flow() {
    let server = MockServer::start();

    let enable_mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("enable", "")
            .query_param("auth", "token123");
        then.status(200)
            .json_body(serde_json::json!({ "status": "enabled" }));
    });

    let disable_mock = server.mock(|when, then| {
        when.method(GET)
            .path("/admin/api.php")
            .query_param("disable", "10")
            .query_param("auth", "token123");
        then.status(200)
            .json_body(serde_json::json!({ "status": "disabled" }));
    });

    let base = format!("{}/", server.base_url());
    let client = PiHoleClient::new(&base, Some("token123".to_string())).unwrap();

    let en = client.enable().await.unwrap();
    assert_eq!(en.status.as_deref(), Some("enabled"));
    enable_mock.assert();

    let di = client.disable(Some(10)).await.unwrap();
    assert_eq!(di.status.as_deref(), Some("disabled"));
    disable_mock.assert();
}


