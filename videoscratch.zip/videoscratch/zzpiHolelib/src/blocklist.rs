use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::collections::{HashSet, HashMap};
use std::path::PathBuf;
use regex::Regex;
use tracing::{info, warn, debug};

/// Domain blocking status
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum BlockStatus {
    Allowed,
    Blocked,
    Whitelisted,
}

/// Entry in a blocklist
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlocklistEntry {
    pub domain: String,
    pub comment: Option<String>,
    pub enabled: bool,
    pub added_date: chrono::DateTime<chrono::Utc>,
}

/// Manages domain blocklists and whitelists
pub struct BlocklistManager {
    /// Blocked domains (exact matches)
    blocked_domains: HashSet<String>,
    /// Whitelisted domains (exact matches)  
    whitelisted_domains: HashSet<String>,
    /// Blocked domain patterns (regex)
    blocked_patterns: Vec<Regex>,
    /// Whitelisted domain patterns (regex)
    whitelisted_patterns: Vec<Regex>,
    /// Custom blacklist entries
    custom_blacklist: HashMap<String, BlocklistEntry>,
    /// Custom whitelist entries
    custom_whitelist: HashMap<String, BlocklistEntry>,
    /// Data directory for persistence
    data_dir: PathBuf,
}

impl BlocklistManager {
    /// Create a new blocklist manager
    pub async fn new(data_dir: &PathBuf) -> Result<Self> {
        info!("Initializing blocklist manager...");

        tokio::fs::create_dir_all(data_dir).await?;

        let mut manager = Self {
            blocked_domains: HashSet::new(),
            whitelisted_domains: HashSet::new(),
            blocked_patterns: Vec::new(),
            whitelisted_patterns: Vec::new(),
            custom_blacklist: HashMap::new(),
            custom_whitelist: HashMap::new(),
            data_dir: data_dir.clone(),
        };

        // Load existing lists
        manager.load_custom_lists().await?;

        info!("Blocklist manager initialized");
        Ok(manager)
    }

    /// Check if a domain should be blocked
    pub fn is_blocked(&self, domain: &str) -> bool {
        let domain_clean = domain.trim_end_matches('.').to_lowercase();

        // Check whitelist first (whitelist overrides blacklist)
        if self.is_whitelisted(&domain_clean) {
            return false;
        }

        // Check exact domain match
        if self.blocked_domains.contains(&domain_clean) {
            return true;
        }

        // Check pattern matches
        for pattern in &self.blocked_patterns {
            if pattern.is_match(&domain_clean) {
                return true;
            }
        }

        // Check custom blacklist
        if self.custom_blacklist.contains_key(&domain_clean) {
            if let Some(entry) = self.custom_blacklist.get(&domain_clean) {
                return entry.enabled;
            }
        }

        // Check subdomain blocking
        self.is_subdomain_blocked(&domain_clean)
    }

    /// Check if a domain is whitelisted
    pub fn is_whitelisted(&self, domain: &str) -> bool {
        let domain_clean = domain.trim_end_matches('.').to_lowercase();

        // Check exact domain match
        if self.whitelisted_domains.contains(&domain_clean) {
            return true;
        }

        // Check pattern matches
        for pattern in &self.whitelisted_patterns {
            if pattern.is_match(&domain_clean) {
                return true;
            }
        }

        // Check custom whitelist
        if self.custom_whitelist.contains_key(&domain_clean) {
            if let Some(entry) = self.custom_whitelist.get(&domain_clean) {
                return entry.enabled;
            }
        }

        false
    }

    /// Check if a subdomain of a blocked domain should be blocked
    fn is_subdomain_blocked(&self, domain: &str) -> bool {
        let parts: Vec<&str> = domain.split('.').collect();
        
        // Check if any parent domain is blocked
        for i in 1..parts.len() {
            let parent_domain = parts[i..].join(".");
            if self.blocked_domains.contains(&parent_domain) {
                return true;
            }
        }

        false
    }

    /// Add a domain to the custom blacklist
    pub async fn add_to_blacklist(&mut self, domain: &str, comment: Option<String>) -> Result<()> {
        let domain_clean = domain.trim_end_matches('.').to_lowercase();
        
        let entry = BlocklistEntry {
            domain: domain_clean.clone(),
            comment,
            enabled: true,
            added_date: chrono::Utc::now(),
        };

        self.custom_blacklist.insert(domain_clean, entry);
        self.save_custom_blacklist().await?;
        
        info!("Added domain to blacklist: {}", domain);
        Ok(())
    }

    /// Remove a domain from the custom blacklist
    pub async fn remove_from_blacklist(&mut self, domain: &str) -> Result<()> {
        let domain_clean = domain.trim_end_matches('.').to_lowercase();
        
        if self.custom_blacklist.remove(&domain_clean).is_some() {
            self.save_custom_blacklist().await?;
            info!("Removed domain from blacklist: {}", domain);
        } else {
            warn!("Domain not found in blacklist: {}", domain);
        }
        
        Ok(())
    }

    /// Add a domain to the custom whitelist
    pub async fn add_to_whitelist(&mut self, domain: &str, comment: Option<String>) -> Result<()> {
        let domain_clean = domain.trim_end_matches('.').to_lowercase();
        
        let entry = BlocklistEntry {
            domain: domain_clean.clone(),
            comment,
            enabled: true,
            added_date: chrono::Utc::now(),
        };

        self.custom_whitelist.insert(domain_clean, entry);
        self.save_custom_whitelist().await?;
        
        info!("Added domain to whitelist: {}", domain);
        Ok(())
    }

    /// Remove a domain from the custom whitelist
    pub async fn remove_from_whitelist(&mut self, domain: &str) -> Result<()> {
        let domain_clean = domain.trim_end_matches('.').to_lowercase();
        
        if self.custom_whitelist.remove(&domain_clean).is_some() {
            self.save_custom_whitelist().await?;
            info!("Removed domain from whitelist: {}", domain);
        } else {
            warn!("Domain not found in whitelist: {}", domain);
        }
        
        Ok(())
    }

    /// Get all custom blacklist entries
    pub fn get_custom_blacklist(&self) -> &HashMap<String, BlocklistEntry> {
        &self.custom_blacklist
    }

    /// Get all custom whitelist entries
    pub fn get_custom_whitelist(&self) -> &HashMap<String, BlocklistEntry> {
        &self.custom_whitelist
    }

    /// Load blocklist from a hosts file or domain list
    pub async fn load_gravity_list(&mut self, content: &str) -> Result<usize> {
        let mut added_count = 0;

        for line in content.lines() {
            let line = line.trim();
            
            // Skip empty lines and comments
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            // Parse hosts file format (127.0.0.1 domain.com)
            let domain = if line.starts_with("0.0.0.0") || line.starts_with("127.0.0.1") {
                line.split_whitespace().nth(1)
            } else {
                // Assume it's just a domain
                Some(line)
            };

            if let Some(domain) = domain {
                if self.is_valid_domain(domain) {
                    self.blocked_domains.insert(domain.to_lowercase());
                    added_count += 1;
                }
            }
        }

        info!("Loaded {} domains from gravity list", added_count);
        Ok(added_count)
    }

    /// Validate if a string is a valid domain
    fn is_valid_domain(&self, domain: &str) -> bool {
        // Basic domain validation
        !domain.is_empty() 
            && domain.contains('.') 
            && !domain.starts_with('.') 
            && !domain.ends_with('.') 
            && domain.chars().all(|c| c.is_alphanumeric() || c == '.' || c == '-')
            && domain.len() < 256
    }

    /// Clear gravity lists (but keep custom lists)
    pub fn clear_gravity_lists(&mut self) {
        self.blocked_domains.clear();
        self.blocked_patterns.clear();
        info!("Cleared gravity lists");
    }

    /// Get statistics about loaded domains
    pub fn get_stats(&self) -> HashMap<String, usize> {
        let mut stats = HashMap::new();
        stats.insert("gravity_blocked_domains".to_string(), self.blocked_domains.len());
        stats.insert("custom_blacklist".to_string(), self.custom_blacklist.len());
        stats.insert("custom_whitelist".to_string(), self.custom_whitelist.len());
        stats.insert("blocked_patterns".to_string(), self.blocked_patterns.len());
        stats.insert("whitelisted_patterns".to_string(), self.whitelisted_patterns.len());
        stats
    }

    /// Save custom blacklist to disk
    async fn save_custom_blacklist(&self) -> Result<()> {
        let path = self.data_dir.join("custom_blacklist.json");
        let content = serde_json::to_string_pretty(&self.custom_blacklist)?;
        tokio::fs::write(path, content).await?;
        debug!("Saved custom blacklist");
        Ok(())
    }

    /// Save custom whitelist to disk
    async fn save_custom_whitelist(&self) -> Result<()> {
        let path = self.data_dir.join("custom_whitelist.json");
        let content = serde_json::to_string_pretty(&self.custom_whitelist)?;
        tokio::fs::write(path, content).await?;
        debug!("Saved custom whitelist");
        Ok(())
    }

    /// Load custom lists from disk
    async fn load_custom_lists(&mut self) -> Result<()> {
        // Load custom blacklist
        let blacklist_path = self.data_dir.join("custom_blacklist.json");
        if blacklist_path.exists() {
            let content = tokio::fs::read_to_string(&blacklist_path).await?;
            self.custom_blacklist = serde_json::from_str(&content)?;
            debug!("Loaded {} custom blacklist entries", self.custom_blacklist.len());
        }

        // Load custom whitelist
        let whitelist_path = self.data_dir.join("custom_whitelist.json");
        if whitelist_path.exists() {
            let content = tokio::fs::read_to_string(&whitelist_path).await?;
            self.custom_whitelist = serde_json::from_str(&content)?;
            debug!("Loaded {} custom whitelist entries", self.custom_whitelist.len());
        }

        Ok(())
    }
}
