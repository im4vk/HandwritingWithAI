use crate::dns_parser::DnsPacket;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::time::{Duration, Instant};
use tracing::debug;

/// DNS response cache for improved performance
#[derive(Clone)]
pub struct DnsCache {
    cache: Arc<RwLock<HashMap<String, CacheEntry>>>,
    max_size: usize,
    default_ttl: Duration,
}

#[derive(Clone)]
struct CacheEntry {
    response: DnsPacket,
    expires_at: Instant,
    hits: u64,
}

impl DnsCache {
    /// Create a new DNS cache
    pub fn new(max_size: usize, default_ttl: Duration) -> Self {
        Self {
            cache: Arc::new(RwLock::new(HashMap::new())),
            max_size,
            default_ttl,
        }
    }

    /// Get cache key for a DNS query
    fn cache_key(domain: &str, query_type: u16) -> String {
        format!("{}:{}", domain.to_lowercase(), query_type)
    }

    /// Get cached response
    pub async fn get(&self, domain: &str, query_type: u16) -> Option<DnsPacket> {
        let key = Self::cache_key(domain, query_type);
        let mut cache = self.cache.write().await;
        
        if let Some(entry) = cache.get_mut(&key) {
            if entry.expires_at > Instant::now() {
                entry.hits += 1;
                debug!("Cache hit for {} (type {}), hits: {}", domain, query_type, entry.hits);
                return Some(entry.response.clone());
            } else {
                // Entry expired, remove it
                cache.remove(&key);
                debug!("Cache entry expired for {} (type {})", domain, query_type);
            }
        }

        None
    }

    /// Cache a DNS response
    pub async fn set(&self, domain: &str, query_type: u16, response: DnsPacket, ttl: Option<Duration>) {
        let key = Self::cache_key(domain, query_type);
        let ttl = ttl.unwrap_or(self.default_ttl);
        let expires_at = Instant::now() + ttl;

        let entry = CacheEntry {
            response,
            expires_at,
            hits: 0,
        };

        let mut cache = self.cache.write().await;
        
        // Check if we need to evict entries
        if cache.len() >= self.max_size {
            self.evict_oldest(&mut cache).await;
        }

        cache.insert(key.clone(), entry);
        debug!("Cached response for {} (type {}) with TTL {:?}", domain, query_type, ttl);
    }

    /// Evict oldest entries to make room
    async fn evict_oldest(&self, cache: &mut HashMap<String, CacheEntry>) {
        if cache.is_empty() {
            return;
        }

        // Find entry with earliest expiration time
        let mut oldest_key = None;
        let mut oldest_time = Instant::now() + Duration::from_secs(3600);

        for (key, entry) in cache.iter() {
            if entry.expires_at < oldest_time {
                oldest_time = entry.expires_at;
                oldest_key = Some(key.clone());
            }
        }

        if let Some(key) = oldest_key {
            cache.remove(&key);
            debug!("Evicted cache entry: {}", key);
        }
    }

    /// Clear expired entries
    pub async fn cleanup_expired(&self) {
        let mut cache = self.cache.write().await;
        let now = Instant::now();
        let mut expired_keys = Vec::new();

        for (key, entry) in cache.iter() {
            if entry.expires_at <= now {
                expired_keys.push(key.clone());
            }
        }

        for key in expired_keys {
            cache.remove(&key);
        }

        debug!("Cleaned up expired cache entries");
    }

    /// Get cache statistics
    pub async fn get_stats(&self) -> CacheStats {
        let cache = self.cache.read().await;
        let now = Instant::now();
        let mut total_hits = 0;
        let mut expired_count = 0;

        for entry in cache.values() {
            total_hits += entry.hits;
            if entry.expires_at <= now {
                expired_count += 1;
            }
        }

        CacheStats {
            total_entries: cache.len(),
            expired_entries: expired_count,
            total_hits,
            max_size: self.max_size,
        }
    }

    /// Clear all cache entries
    pub async fn clear(&self) {
        self.cache.write().await.clear();
        debug!("Cache cleared");
    }
}

#[derive(Debug)]
pub struct CacheStats {
    pub total_entries: usize,
    pub expired_entries: usize,
    pub total_hits: u64,
    pub max_size: usize,
}

/// Blocklist cache for fast domain lookups
#[derive(Clone)]
pub struct BlocklistCache {
    blocked_domains: Arc<RwLock<HashMap<String, bool>>>,
    last_updated: Arc<RwLock<Instant>>,
    cache_duration: Duration,
}

impl BlocklistCache {
    pub fn new(cache_duration: Duration) -> Self {
        Self {
            blocked_domains: Arc::new(RwLock::new(HashMap::new())),
            last_updated: Arc::new(RwLock::new(Instant::now())),
            cache_duration,
        }
    }

    /// Check if domain is blocked (with caching)
    pub async fn is_blocked(&self, domain: &str) -> Option<bool> {
        let domain_lower = domain.to_lowercase();
        
        // Check if cache is still valid
        {
            let last_updated = *self.last_updated.read().await;
            if last_updated.elapsed() > self.cache_duration {
                return None; // Cache expired
            }
        }

        // Check cache
        let cache = self.blocked_domains.read().await;
        cache.get(&domain_lower).copied()
    }

    /// Update blocklist cache
    pub async fn update_cache(&self, blocked_domains: HashMap<String, bool>) {
        let mut cache = self.blocked_domains.write().await;
        *cache = blocked_domains;
        
        let mut last_updated = self.last_updated.write().await;
        *last_updated = Instant::now();
        
        debug!("Updated blocklist cache with {} entries", cache.len());
    }

    /// Get cache age
    pub async fn cache_age(&self) -> Duration {
        self.last_updated.read().await.elapsed()
    }
}
