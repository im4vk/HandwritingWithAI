use crate::error::{PiHoleError, Result};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::net::IpAddr;

/// Configuration for the Pi-hole server
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    /// DNS server bind address
    pub dns_bind_address: IpAddr,
    /// DNS server port
    pub dns_port: u16,
    /// Web interface bind address
    pub web_bind_address: IpAddr,
    /// Web interface port
    pub web_port: u16,
    /// Upstream DNS servers
    pub upstream_dns: Vec<String>,
    /// Data directory for storing blocklists, logs, etc.
    pub data_dir: PathBuf,
    /// Default gravity lists to download
    pub gravity_lists: Vec<String>,
    /// Enable/disable blocking
    pub blocking_enabled: bool,
    /// Admin password hash (optional)
    pub admin_password_hash: Option<String>,
    /// Log queries to database
    pub log_queries: bool,
    /// Automatic gravity update interval in hours
    pub gravity_update_interval_hours: u32,
    /// DNS cache settings
    pub cache_size: usize,
    /// DNS cache TTL in seconds
    pub cache_ttl_seconds: u64,
    /// Query log retention in days
    pub log_retention_days: u32,
    /// Enable DNS over HTTPS (DoH)
    pub enable_doh: bool,
    /// DoH endpoint URL
    pub doh_endpoint: Option<String>,
    /// Rate limiting (queries per minute per client)
    pub rate_limit_per_minute: u32,
    /// Enable query logging
    pub enable_query_logging: bool,
    /// Blocklist update check interval in hours
    pub blocklist_update_interval_hours: u32,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            dns_bind_address: "0.0.0.0".parse().unwrap(),
            dns_port: 53,
            web_bind_address: "0.0.0.0".parse().unwrap(),
            web_port: 8080,
            upstream_dns: vec![
                "1.1.1.1:53".to_string(),
                "8.8.8.8:53".to_string(),
            ],
            data_dir: PathBuf::from("./pihole-data"),
            gravity_lists: vec![
                "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts".to_string(),
                "https://someonewhocares.org/hosts/zero/hosts".to_string(),
                "https://raw.githubusercontent.com/AdguardTeam/AdguardFilters/master/BaseFilter/sections/adservers.txt".to_string(),
            ],
            blocking_enabled: true,
            admin_password_hash: None,
            log_queries: true,
            gravity_update_interval_hours: 24,
            cache_size: 10000,
            cache_ttl_seconds: 300,
            log_retention_days: 90,
            enable_doh: false,
            doh_endpoint: None,
            rate_limit_per_minute: 1000,
            enable_query_logging: true,
            blocklist_update_interval_hours: 24,
        }
    }
}

impl Config {
    /// Load configuration from a JSON file
    pub async fn from_file(path: &PathBuf) -> Result<Self> {
        let content = tokio::fs::read_to_string(path).await?;
        let config: Config = serde_json::from_str(&content)?;
        config.validate()?;
        Ok(config)
    }

    /// Save configuration to a JSON file
    pub async fn to_file(&self, path: &PathBuf) -> Result<()> {
        let content = serde_json::to_string_pretty(self)?;
        tokio::fs::write(path, content).await?;
        Ok(())
    }

    /// Validate the configuration
    pub fn validate(&self) -> Result<()> {
        if self.upstream_dns.is_empty() {
            return Err(PiHoleError::Config("At least one upstream DNS server must be configured".to_string()));
        }

        if self.dns_port == 0 || self.web_port == 0 {
            return Err(PiHoleError::Config("Ports must be greater than 0".to_string()));
        }

        if self.dns_port == self.web_port {
            return Err(PiHoleError::Config("DNS and web ports cannot be the same".to_string()));
        }

        Ok(())
    }

    /// Create data directory if it doesn't exist
    pub async fn ensure_data_dir(&self) -> Result<()> {
        tokio::fs::create_dir_all(&self.data_dir).await?;
        Ok(())
    }
}
