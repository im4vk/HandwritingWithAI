use crate::error::Result;
use sqlx::{SqlitePool, Row};
use std::path::PathBuf;
use std::net::IpAddr;
use chrono::{DateTime, Utc};
use tracing::{info, debug};
use serde::{Serialize, Deserialize};

/// Database manager for persistent storage
pub struct Database {
    pool: SqlitePool,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct QueryLogEntry {
    pub id: i64,
    pub timestamp: DateTime<Utc>,
    pub client_ip: IpAddr,
    pub domain: String,
    pub query_type: String,
    pub status: String,
    pub response_time_ms: Option<u32>,
    pub upstream_server: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ClientInfo {
    pub ip: IpAddr,
    pub hostname: Option<String>,
    pub first_seen: DateTime<Utc>,
    pub last_seen: DateTime<Utc>,
    pub total_queries: i64,
    pub blocked_queries: i64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DomainInfo {
    pub domain: String,
    pub first_seen: DateTime<Utc>,
    pub last_seen: DateTime<Utc>,
    pub total_queries: i64,
    pub blocked_queries: i64,
}

impl Database {
    /// Initialize database connection and schema
    pub async fn new(data_dir: &PathBuf) -> Result<Self> {
        info!("Initializing database...");
        
        tokio::fs::create_dir_all(data_dir).await?;
        let db_path = data_dir.join("pihole.db");
        let db_url = format!("sqlite:{}?mode=rwc", db_path.display());

        let pool = SqlitePool::connect(&db_url).await?;

        // Run migrations
        let db = Self { pool };
        db.migrate().await?;

        info!("Database initialized successfully");
        Ok(db)
    }

    /// Run database migrations
    async fn migrate(&self) -> Result<()> {
        debug!("Running database migrations...");

        // Query log table
        sqlx::query(r#"
            CREATE TABLE IF NOT EXISTS query_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                client_ip TEXT NOT NULL,
                domain TEXT NOT NULL,
                query_type TEXT NOT NULL DEFAULT 'A',
                status TEXT NOT NULL,
                response_time_ms INTEGER,
                upstream_server TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        "#).execute(&self.pool).await?;

        // Clients table
        sqlx::query(r#"
            CREATE TABLE IF NOT EXISTS clients (
                ip TEXT PRIMARY KEY,
                hostname TEXT,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                total_queries INTEGER DEFAULT 0,
                blocked_queries INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        "#).execute(&self.pool).await?;

        // Domains table
        sqlx::query(r#"
            CREATE TABLE IF NOT EXISTS domains (
                domain TEXT PRIMARY KEY,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                total_queries INTEGER DEFAULT 0,
                blocked_queries INTEGER DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        "#).execute(&self.pool).await?;

        // Custom lists table
        sqlx::query(r#"
            CREATE TABLE IF NOT EXISTS custom_lists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT NOT NULL,
                list_type TEXT NOT NULL, -- 'blacklist' or 'whitelist'
                comment TEXT,
                enabled INTEGER DEFAULT 1,
                added_by TEXT DEFAULT 'admin',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        "#).execute(&self.pool).await?;

        // Settings table
        sqlx::query(r#"
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        "#).execute(&self.pool).await?;

        // Create indices for better performance
        let indices = [
            "CREATE INDEX IF NOT EXISTS idx_query_log_timestamp ON query_log(timestamp)",
            "CREATE INDEX IF NOT EXISTS idx_query_log_domain ON query_log(domain)",
            "CREATE INDEX IF NOT EXISTS idx_query_log_client_ip ON query_log(client_ip)",
            "CREATE INDEX IF NOT EXISTS idx_query_log_status ON query_log(status)",
            "CREATE INDEX IF NOT EXISTS idx_clients_last_seen ON clients(last_seen)",
            "CREATE INDEX IF NOT EXISTS idx_domains_last_seen ON domains(last_seen)",
            "CREATE INDEX IF NOT EXISTS idx_custom_lists_domain ON custom_lists(domain)",
            "CREATE INDEX IF NOT EXISTS idx_custom_lists_type ON custom_lists(list_type)",
        ];

        for index in &indices {
            sqlx::query(index).execute(&self.pool).await?;
        }

        debug!("Database migrations completed");
        Ok(())
    }

    /// Log a DNS query
    pub async fn log_query(
        &self,
        timestamp: DateTime<Utc>,
        client_ip: IpAddr,
        domain: &str,
        query_type: &str,
        status: &str,
        response_time_ms: Option<u32>,
        upstream_server: Option<&str>,
    ) -> Result<i64> {
        let result = sqlx::query(r#"
            INSERT INTO query_log (timestamp, client_ip, domain, query_type, status, response_time_ms, upstream_server)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        "#)
        .bind(timestamp.to_rfc3339())
        .bind(client_ip.to_string())
        .bind(domain)
        .bind(query_type)
        .bind(status)
        .bind(response_time_ms.map(|t| t as i64))
        .bind(upstream_server)
        .execute(&self.pool)
        .await?;

        let query_id = result.last_insert_rowid();

        // Update client stats
        self.update_client_stats(client_ip, status == "blocked").await?;
        
        // Update domain stats
        self.update_domain_stats(domain, status == "blocked").await?;

        Ok(query_id)
    }

    /// Update client statistics
    async fn update_client_stats(&self, client_ip: IpAddr, was_blocked: bool) -> Result<()> {
        let now = Utc::now().to_rfc3339();
        let blocked_increment = if was_blocked { 1 } else { 0 };

        sqlx::query(r#"
            INSERT INTO clients (ip, first_seen, last_seen, total_queries, blocked_queries)
            VALUES (?, ?, ?, 1, ?)
            ON CONFLICT(ip) DO UPDATE SET
                last_seen = excluded.last_seen,
                total_queries = total_queries + 1,
                blocked_queries = blocked_queries + excluded.blocked_queries,
                updated_at = CURRENT_TIMESTAMP
        "#)
        .bind(client_ip.to_string())
        .bind(&now)
        .bind(&now)
        .bind(blocked_increment)
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    /// Update domain statistics
    async fn update_domain_stats(&self, domain: &str, was_blocked: bool) -> Result<()> {
        let now = Utc::now().to_rfc3339();
        let blocked_increment = if was_blocked { 1 } else { 0 };

        sqlx::query(r#"
            INSERT INTO domains (domain, first_seen, last_seen, total_queries, blocked_queries)
            VALUES (?, ?, ?, 1, ?)
            ON CONFLICT(domain) DO UPDATE SET
                last_seen = excluded.last_seen,
                total_queries = total_queries + 1,
                blocked_queries = blocked_queries + excluded.blocked_queries,
                updated_at = CURRENT_TIMESTAMP
        "#)
        .bind(domain)
        .bind(&now)
        .bind(&now)
        .bind(blocked_increment)
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    /// Get query statistics for a time period
    pub async fn get_query_stats(&self, hours: u32) -> Result<(i64, i64)> {
        let since = Utc::now() - chrono::Duration::hours(hours as i64);
        let since_str = since.to_rfc3339();

        let row = sqlx::query(r#"
            SELECT 
                COUNT(*) as total_queries,
                SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked_queries
            FROM query_log 
            WHERE timestamp >= ?
        "#)
        .bind(&since_str)
        .fetch_one(&self.pool)
        .await?;

        let total: i64 = row.get("total_queries");
        let blocked: i64 = row.get("blocked_queries");

        Ok((total, blocked))
    }

    /// Get top blocked domains
    pub async fn get_top_blocked_domains(&self, limit: i32, hours: Option<u32>) -> Result<Vec<DomainInfo>> {
        let rows = if let Some(h) = hours {
            let since = Utc::now() - chrono::Duration::hours(h as i64);
            let since_str = since.to_rfc3339();
            
            sqlx::query(r#"
                SELECT domain, 
                       MIN(timestamp) as first_seen,
                       MAX(timestamp) as last_seen,
                       COUNT(*) as total_queries,
                       SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked_queries
                FROM query_log 
                WHERE timestamp >= ? AND status = 'blocked'
                GROUP BY domain
                ORDER BY blocked_queries DESC 
                LIMIT ?
            "#)
            .bind(&since_str)
            .bind(limit)
            .fetch_all(&self.pool)
            .await?
        } else {
            sqlx::query(r#"
                SELECT domain, first_seen, last_seen, total_queries, blocked_queries
                FROM domains 
                WHERE blocked_queries > 0
                ORDER BY blocked_queries DESC 
                LIMIT ?
            "#)
            .bind(limit)
            .fetch_all(&self.pool)
            .await?
        };
        let mut domains = Vec::new();

        for row in rows {
            let first_seen_str: String = row.get("first_seen");
            let last_seen_str: String = row.get("last_seen");

            domains.push(DomainInfo {
                domain: row.get("domain"),
                first_seen: DateTime::parse_from_rfc3339(&first_seen_str)?.with_timezone(&Utc),
                last_seen: DateTime::parse_from_rfc3339(&last_seen_str)?.with_timezone(&Utc),
                total_queries: row.get("total_queries"),
                blocked_queries: row.get("blocked_queries"),
            });
        }

        Ok(domains)
    }

    /// Get top clients by query count
    pub async fn get_top_clients(&self, limit: i32) -> Result<Vec<ClientInfo>> {
        let rows = sqlx::query(r#"
            SELECT ip, hostname, first_seen, last_seen, total_queries, blocked_queries
            FROM clients 
            ORDER BY total_queries DESC 
            LIMIT ?
        "#)
        .bind(limit)
        .fetch_all(&self.pool)
        .await?;

        let mut clients = Vec::new();
        for row in rows {
            let ip_str: String = row.get("ip");
            let first_seen_str: String = row.get("first_seen");
            let last_seen_str: String = row.get("last_seen");

            clients.push(ClientInfo {
                ip: ip_str.parse()?,
                hostname: row.get("hostname"),
                first_seen: DateTime::parse_from_rfc3339(&first_seen_str)?.with_timezone(&Utc),
                last_seen: DateTime::parse_from_rfc3339(&last_seen_str)?.with_timezone(&Utc),
                total_queries: row.get("total_queries"),
                blocked_queries: row.get("blocked_queries"),
            });
        }

        Ok(clients)
    }

    /// Get recent query log
    pub async fn get_recent_queries(&self, limit: i32) -> Result<Vec<QueryLogEntry>> {
        let rows = sqlx::query(r#"
            SELECT id, timestamp, client_ip, domain, query_type, status, response_time_ms, upstream_server
            FROM query_log 
            ORDER BY timestamp DESC 
            LIMIT ?
        "#)
        .bind(limit)
        .fetch_all(&self.pool)
        .await?;

        let mut queries = Vec::new();
        for row in rows {
            let timestamp_str: String = row.get("timestamp");
            let client_ip_str: String = row.get("client_ip");

            queries.push(QueryLogEntry {
                id: row.get("id"),
                timestamp: DateTime::parse_from_rfc3339(&timestamp_str)?.with_timezone(&Utc),
                client_ip: client_ip_str.parse()?,
                domain: row.get("domain"),
                query_type: row.get("query_type"),
                status: row.get("status"),
                response_time_ms: row.get::<Option<i64>, _>("response_time_ms").map(|ms| ms as u32),
                upstream_server: row.get("upstream_server"),
            });
        }

        Ok(queries)
    }

    /// Clean up old logs
    pub async fn cleanup_old_logs(&self, days_to_keep: u32) -> Result<u64> {
        let cutoff = Utc::now() - chrono::Duration::days(days_to_keep as i64);
        let cutoff_str = cutoff.to_rfc3339();

        let result = sqlx::query("DELETE FROM query_log WHERE timestamp < ?")
            .bind(&cutoff_str)
            .execute(&self.pool)
            .await?;

        Ok(result.rows_affected())
    }

    /// Add custom list entry
    pub async fn add_custom_list_entry(
        &self,
        domain: &str,
        list_type: &str,
        comment: Option<&str>,
        added_by: &str,
    ) -> Result<i64> {
        let result = sqlx::query(r#"
            INSERT INTO custom_lists (domain, list_type, comment, added_by)
            VALUES (?, ?, ?, ?)
        "#)
        .bind(domain)
        .bind(list_type)
        .bind(comment)
        .bind(added_by)
        .execute(&self.pool)
        .await?;

        Ok(result.last_insert_rowid())
    }

    /// Get custom list entries
    pub async fn get_custom_list_entries(&self, list_type: &str) -> Result<Vec<String>> {
        let rows = sqlx::query("SELECT domain FROM custom_lists WHERE list_type = ? AND enabled = 1")
            .bind(list_type)
            .fetch_all(&self.pool)
            .await?;

        Ok(rows.into_iter().map(|row| row.get("domain")).collect())
    }
}
