use crate::config::Config;
use crate::blocklist::BlocklistManager;
use crate::stats::StatsCollector;
use crate::dns_parser::DnsPacket;
use crate::error::Result;

use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::net::UdpSocket;
use tracing::{info, warn, debug};
use std::net::SocketAddr;

/// Simplified DNS server that demonstrates Pi-hole functionality
pub struct DnsServer {
    config: Config,
    blocklist_manager: Arc<RwLock<BlocklistManager>>,
    stats_collector: Arc<RwLock<StatsCollector>>,
}

impl DnsServer {
    /// Create a new DNS server
    pub async fn new(
        config: Config,
        blocklist_manager: Arc<RwLock<BlocklistManager>>,
        stats_collector: Arc<RwLock<StatsCollector>>,
    ) -> Result<Self> {
        info!("Initializing DNS server...");
        info!("DNS server initialized");

        Ok(Self {
            config,
            blocklist_manager,
            stats_collector,
        })
    }

    /// Start the DNS server
    pub async fn start(&self) -> Result<()> {
        info!("Starting DNS server on {}:{}", self.config.dns_bind_address, self.config.dns_port);

        let bind_addr = SocketAddr::new(self.config.dns_bind_address, self.config.dns_port);
        let socket = UdpSocket::bind(bind_addr).await?;
        
        info!("DNS server listening on {}", bind_addr);

        let mut buf = [0; 512];
        loop {
            match socket.recv_from(&mut buf).await {
                Ok((len, src)) => {
                    debug!("Received {} bytes from {}", len, src);
                    
                    // Simplified DNS packet parsing and response
                    // In a real implementation, this would parse DNS packets properly
                    if let Err(e) = self.handle_dns_packet(&socket, &buf[..len], src).await {
                        warn!("Error handling DNS packet from {}: {}", src, e);
                    }
                }
                Err(e) => {
                    warn!("Error receiving UDP packet: {}", e);
                }
            }
        }
    }

    /// Handle a DNS packet with real DNS parsing
    async fn handle_dns_packet(&self, socket: &UdpSocket, packet: &[u8], src: SocketAddr) -> Result<()> {
        debug!("Handling DNS packet from {}", src);
        
        // Parse the DNS packet
        let query = match DnsPacket::from_bytes(packet) {
            Ok(packet) => packet,
            Err(e) => {
                warn!("Failed to parse DNS packet from {}: {}", src, e);
                return Ok(());
            }
        };

        // Only handle queries
        if !query.is_query() {
            debug!("Ignoring non-query packet from {}", src);
            return Ok(());
        }

        // Get the first question (domain)
        let domain = match query.get_query_domain() {
            Some(domain) => domain,
            None => {
                debug!("No query domain found in packet from {}", src);
                return Ok(());
            }
        };

        info!("DNS query for {} from {}", domain, src.ip());
        
        let is_blocked = {
            let blocklist = self.blocklist_manager.read().await;
            blocklist.is_blocked(domain)
        };

        let response = if is_blocked {
            info!("Blocked query for {} from {}", domain, src.ip());
            {
                let mut stats = self.stats_collector.write().await;
                stats.record_blocked_query(domain, src.ip()).await;
            }
            
            // Create blocked response (NXDOMAIN)
            DnsPacket::create_response(&query, true)
        } else {
            info!("Allowed query for {} from {}", domain, src.ip());
            {
                let mut stats = self.stats_collector.write().await;
                stats.record_allowed_query(domain, src.ip()).await;
            }
            
            // Create allowed response (should forward to upstream in real implementation)
            DnsPacket::create_response(&query, false)
        };

        // Send response
        let response_bytes = response.to_bytes();
        if let Err(e) = socket.send_to(&response_bytes, src).await {
            warn!("Failed to send DNS response to {}: {}", src, e);
        } else {
            debug!("Sent DNS response to {}", src);
        }

        Ok(())
    }
}