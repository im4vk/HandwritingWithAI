use crate::error::{PiHoleError, Result};
use std::net::{Ipv4Addr, Ipv6Addr};

/// DNS packet parser and builder for real DNS functionality
#[derive(Debug, Clone)]
pub struct DnsPacket {
    pub header: DnsHeader,
    pub questions: Vec<DnsQuestion>,
    pub answers: Vec<DnsRecord>,
    pub authorities: Vec<DnsRecord>,
    pub additionals: Vec<DnsRecord>,
}

#[derive(Debug, Clone)]
pub struct DnsHeader {
    pub id: u16,
    pub flags: u16,
    pub question_count: u16,
    pub answer_count: u16,
    pub authority_count: u16,
    pub additional_count: u16,
}

#[derive(Debug, Clone)]
pub struct DnsQuestion {
    pub name: String,
    pub qtype: u16,
    pub qclass: u16,
}

#[derive(Debug, Clone)]
pub struct DnsRecord {
    pub name: String,
    pub rtype: u16,
    pub class: u16,
    pub ttl: u32,
    pub data: DnsRecordData,
}

#[derive(Debug, Clone)]
pub enum DnsRecordData {
    A(Ipv4Addr),
    AAAA(Ipv6Addr),
    CNAME(String),
    NS(String),
    TXT(String),
    Unknown(Vec<u8>),
}

impl DnsPacket {
    /// Parse a DNS packet from bytes
    pub fn from_bytes(data: &[u8]) -> Result<Self> {
        if data.len() < 12 {
            return Err(PiHoleError::Server("DNS packet too short".to_string()));
        }

        let header = DnsHeader {
            id: u16::from_be_bytes([data[0], data[1]]),
            flags: u16::from_be_bytes([data[2], data[3]]),
            question_count: u16::from_be_bytes([data[4], data[5]]),
            answer_count: u16::from_be_bytes([data[6], data[7]]),
            authority_count: u16::from_be_bytes([data[8], data[9]]),
            additional_count: u16::from_be_bytes([data[10], data[11]]),
        };

        let mut questions = Vec::new();
        let mut answers = Vec::new();
        let mut authorities = Vec::new();
        let mut additionals = Vec::new();
        let mut offset = 12;

        // Parse questions
        for _ in 0..header.question_count {
            let (question, new_offset) = Self::parse_question(data, offset)?;
            questions.push(question);
            offset = new_offset;
        }

        // Parse answers
        for _ in 0..header.answer_count {
            let (answer, new_offset) = Self::parse_record(data, offset)?;
            answers.push(answer);
            offset = new_offset;
        }

        // Parse authorities (skipped for now)
        for _ in 0..header.authority_count {
            let (authority, new_offset) = Self::parse_record(data, offset)?;
            authorities.push(authority);
            offset = new_offset;
        }

        // Parse additionals (skipped for now)
        for _ in 0..header.additional_count {
            let (additional, new_offset) = Self::parse_record(data, offset)?;
            additionals.push(additional);
            offset = new_offset;
        }

        Ok(DnsPacket {
            header,
            questions,
            answers,
            authorities,
            additionals,
        })
    }

    /// Parse a DNS question from the packet
    fn parse_question(data: &[u8], mut offset: usize) -> Result<(DnsQuestion, usize)> {
        let name = Self::parse_domain_name(data, &mut offset)?;
        
        if offset + 4 > data.len() {
            return Err(PiHoleError::Server("Invalid question section".to_string()));
        }

        let qtype = u16::from_be_bytes([data[offset], data[offset + 1]]);
        let qclass = u16::from_be_bytes([data[offset + 2], data[offset + 3]]);
        offset += 4;

        Ok((DnsQuestion { name, qtype, qclass }, offset))
    }

    /// Parse a DNS record from the packet
    fn parse_record(data: &[u8], mut offset: usize) -> Result<(DnsRecord, usize)> {
        let name = Self::parse_domain_name(data, &mut offset)?;
        
        if offset + 10 > data.len() {
            return Err(PiHoleError::Server("Invalid record section".to_string()));
        }

        let rtype = u16::from_be_bytes([data[offset], data[offset + 1]]);
        let class = u16::from_be_bytes([data[offset + 2], data[offset + 3]]);
        let ttl = u32::from_be_bytes([data[offset + 4], data[offset + 5], data[offset + 6], data[offset + 7]]);
        let data_len = u16::from_be_bytes([data[offset + 8], data[offset + 9]]) as usize;
        offset += 10;

        if offset + data_len > data.len() {
            return Err(PiHoleError::Server("Invalid record data length".to_string()));
        }

        let record_data = match rtype {
            1 => { // A record
                if data_len == 4 {
                    DnsRecordData::A(std::net::Ipv4Addr::new(
                        data[offset], data[offset + 1], data[offset + 2], data[offset + 3]
                    ))
                } else {
                    DnsRecordData::Unknown(data[offset..offset + data_len].to_vec())
                }
            }
            28 => { // AAAA record
                if data_len == 16 {
                    let mut bytes = [0u8; 16];
                    bytes.copy_from_slice(&data[offset..offset + 16]);
                    DnsRecordData::AAAA(std::net::Ipv6Addr::from(bytes))
                } else {
                    DnsRecordData::Unknown(data[offset..offset + data_len].to_vec())
                }
            }
            5 => { // CNAME record
                let mut cname_offset = offset;
                let cname = Self::parse_domain_name(data, &mut cname_offset)?;
                DnsRecordData::CNAME(cname)
            }
            2 => { // NS record
                let mut ns_offset = offset;
                let ns = Self::parse_domain_name(data, &mut ns_offset)?;
                DnsRecordData::NS(ns)
            }
            16 => { // TXT record
                if data_len > 0 {
                    let txt_len = data[offset] as usize;
                    if offset + 1 + txt_len <= offset + data_len {
                        let txt = String::from_utf8_lossy(&data[offset + 1..offset + 1 + txt_len]).to_string();
                        DnsRecordData::TXT(txt)
                    } else {
                        DnsRecordData::Unknown(data[offset..offset + data_len].to_vec())
                    }
                } else {
                    DnsRecordData::TXT(String::new())
                }
            }
            _ => DnsRecordData::Unknown(data[offset..offset + data_len].to_vec()),
        };

        offset += data_len;

        Ok((DnsRecord {
            name,
            rtype,
            class,
            ttl,
            data: record_data,
        }, offset))
    }

    /// Parse a domain name from DNS packet format
    fn parse_domain_name(data: &[u8], offset: &mut usize) -> Result<String> {
        let mut name = String::new();
        let mut jumped = false;
        let mut original_offset = *offset;

        loop {
            if *offset >= data.len() {
                return Err(PiHoleError::Server("Invalid domain name".to_string()));
            }

            let length = data[*offset] as usize;
            
            if length == 0 {
                *offset += 1;
                break;
            }

            // Check for compression (pointer)
            if length & 0xC0 == 0xC0 {
                if !jumped {
                    original_offset = *offset + 2;
                }
                *offset = (((length & 0x3F) as usize) << 8) | (data[*offset + 1] as usize);
                jumped = true;
                continue;
            }

            *offset += 1;
            
            if *offset + length > data.len() {
                return Err(PiHoleError::Server("Invalid domain name length".to_string()));
            }

            if !name.is_empty() {
                name.push('.');
            }

            name.push_str(&String::from_utf8_lossy(&data[*offset..*offset + length]));
            *offset += length;
        }

        if jumped {
            *offset = original_offset;
        }

        Ok(name)
    }

    /// Convert packet to bytes for transmission
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::new();
        
        // Header
        bytes.extend_from_slice(&self.header.id.to_be_bytes());
        bytes.extend_from_slice(&self.header.flags.to_be_bytes());
        bytes.extend_from_slice(&(self.questions.len() as u16).to_be_bytes());
        bytes.extend_from_slice(&(self.answers.len() as u16).to_be_bytes());
        bytes.extend_from_slice(&(self.authorities.len() as u16).to_be_bytes());
        bytes.extend_from_slice(&(self.additionals.len() as u16).to_be_bytes());

        // Questions
        for question in &self.questions {
            bytes.extend_from_slice(&Self::encode_domain_name(&question.name));
            bytes.extend_from_slice(&question.qtype.to_be_bytes());
            bytes.extend_from_slice(&question.qclass.to_be_bytes());
        }

        // Answers
        for answer in &self.answers {
            bytes.extend_from_slice(&Self::encode_domain_name(&answer.name));
            bytes.extend_from_slice(&answer.rtype.to_be_bytes());
            bytes.extend_from_slice(&answer.class.to_be_bytes());
            bytes.extend_from_slice(&answer.ttl.to_be_bytes());
            
            let data = match &answer.data {
                DnsRecordData::A(ip) => ip.octets().to_vec(),
                DnsRecordData::AAAA(ip) => ip.octets().to_vec(),
                DnsRecordData::CNAME(name) => Self::encode_domain_name(name),
                DnsRecordData::NS(name) => Self::encode_domain_name(name),
                DnsRecordData::TXT(text) => {
                    let mut data = Vec::new();
                    data.push(text.len() as u8);
                    data.extend_from_slice(text.as_bytes());
                    data
                }
                DnsRecordData::Unknown(data) => data.clone(),
            };
            
            bytes.extend_from_slice(&(data.len() as u16).to_be_bytes());
            bytes.extend_from_slice(&data);
        }

        bytes
    }

    /// Encode domain name in DNS format
    pub fn encode_domain_name(name: &str) -> Vec<u8> {
        let mut encoded = Vec::new();
        
        if name.is_empty() || name == "." {
            encoded.push(0);
            return encoded;
        }

        for label in name.split('.') {
            if !label.is_empty() {
                encoded.push(label.len() as u8);
                encoded.extend_from_slice(label.as_bytes());
            }
        }
        encoded.push(0); // Root label
        encoded
    }

    /// Create a response packet from a query
    pub fn create_response(query: &DnsPacket, blocked: bool) -> Self {
        let mut response = query.clone();
        
        // Set response flags
        response.header.flags = 0x8180; // Standard query response, recursion desired/available
        
        if blocked {
            // Return NXDOMAIN for blocked queries
            response.header.flags |= 0x0003; // NXDOMAIN
        } else {
            // Add answer records for allowed queries
            for question in &query.questions {
                if question.qtype == 1 { // A record
                    response.answers.push(DnsRecord {
                        name: question.name.clone(),
                        rtype: 1,
                        class: 1,
                        ttl: 300,
                        data: DnsRecordData::A(Ipv4Addr::new(0, 0, 0, 0)), // Null route for blocked
                    });
                }
            }
        }

        response
    }

    /// Get the first question domain name
    pub fn get_query_domain(&self) -> Option<&str> {
        self.questions.first().map(|q| q.name.as_str())
    }

    /// Check if this is a query packet
    pub fn is_query(&self) -> bool {
        (self.header.flags & 0x8000) == 0
    }
}
