use thiserror::Error;

#[derive(Debug, Error)]
pub enum PiHoleError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("HTTP error: {0}")]
    Http(#[from] reqwest::Error),

    #[error("Database error: {0}")]
    Database(#[from] sqlx::Error),

    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("Regex error: {0}")]
    Regex(#[from] regex::Error),

    #[error("URL parse error: {0}")]
    UrlParse(#[from] url::ParseError),

    #[error("Time parse error: {0}")]
    TimeParse(#[from] chrono::ParseError),

    #[error("Address parse error: {0}")]
    AddrParse(#[from] std::net::AddrParseError),

    #[error("Configuration error: {0}")]
    Config(String),

    #[error("Blocklist error: {0}")]
    Blocklist(String),

    #[error("Server error: {0}")]
    Server(String),

    #[error("API error: {0}")]
    Api(String),
}

pub type Result<T> = std::result::Result<T, PiHoleError>;
