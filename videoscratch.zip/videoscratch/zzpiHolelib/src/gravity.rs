use crate::blocklist::BlocklistManager;
use crate::error::{PiHoleError, Result};
use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::time::{sleep, Duration};
use tracing::{info, warn, error};

/// Manages gravity list downloads and updates
pub struct GravityUpdater {
    blocklist_manager: Arc<RwLock<BlocklistManager>>,
    http_client: reqwest::Client,
}

impl GravityUpdater {
    /// Create a new gravity updater
    pub async fn new(blocklist_manager: Arc<RwLock<BlocklistManager>>) -> Result<Self> {
        info!("Initializing gravity updater...");

        let http_client = reqwest::Client::builder()
            .user_agent("Pi-hole/FTL")
            .timeout(Duration::from_secs(30))
            .build()?;

        info!("Gravity updater initialized");

        Ok(Self {
            blocklist_manager,
            http_client,
        })
    }

    /// Download and update gravity lists
    pub async fn update_gravity(&self, gravity_urls: &[String]) -> Result<()> {
        info!("Starting gravity update with {} lists", gravity_urls.len());

        // Clear existing gravity lists
        {
            let mut blocklist = self.blocklist_manager.write().await;
            blocklist.clear_gravity_lists();
        }

        let mut total_domains = 0;

        for (index, url) in gravity_urls.iter().enumerate() {
            info!("Downloading gravity list {}/{}: {}", index + 1, gravity_urls.len(), url);

            match self.download_and_parse_list(url).await {
                Ok(domains_added) => {
                    total_domains += domains_added;
                    info!("Added {} domains from {}", domains_added, url);
                }
                Err(e) => {
                    warn!("Failed to download gravity list {}: {}", url, e);
                    // Continue with other lists even if one fails
                }
            }
        }

        info!("Gravity update completed. Total domains loaded: {}", total_domains);
        Ok(())
    }

    /// Download and parse a single gravity list
    async fn download_and_parse_list(&self, url: &str) -> Result<usize> {
        // Download the list
        let response = self.http_client.get(url).send().await?;

        if !response.status().is_success() {
            return Err(PiHoleError::Http(response.error_for_status().unwrap_err()));
        }

        let content = response.text().await?;

        // Parse and load into blocklist manager
        let mut blocklist = self.blocklist_manager.write().await;
        let domains_added = blocklist.load_gravity_list(&content).await?;

        Ok(domains_added)
    }

    /// Start periodic gravity updates
    pub async fn start_periodic_updates(&self) -> Result<()> {
        info!("Starting periodic gravity updates");

        // This would normally read from config, but for now use a fixed interval
        let update_interval = Duration::from_secs(24 * 60 * 60); // 24 hours

        loop {
            sleep(update_interval).await;

            info!("Starting periodic gravity update");

            // Default gravity lists (would normally come from config)
            let gravity_lists = vec![
                "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts".to_string(),
            ];

            if let Err(e) = self.update_gravity(&gravity_lists).await {
                error!("Periodic gravity update failed: {}", e);
            }
        }
    }

    /// Update gravity lists immediately
    pub async fn force_update(&self, gravity_urls: &[String]) -> Result<()> {
        info!("Force updating gravity lists");
        self.update_gravity(gravity_urls).await
    }

    /// Get the last update time and statistics
    pub async fn get_update_info(&self) -> Result<GravityUpdateInfo> {
        let blocklist = self.blocklist_manager.read().await;
        let stats = blocklist.get_stats();

        Ok(GravityUpdateInfo {
            last_update: chrono::Utc::now(), // TODO: Store actual last update time
            domains_blocked: stats.get("gravity_blocked_domains").copied().unwrap_or(0),
            lists_processed: 1, // TODO: Track actual number of lists
            update_status: "success".to_string(),
        })
    }
}

/// Information about gravity updates
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct GravityUpdateInfo {
    pub last_update: chrono::DateTime<chrono::Utc>,
    pub domains_blocked: usize,
    pub lists_processed: usize,
    pub update_status: String,
}
