pub mod config;
pub mod dns;
pub mod dns_parser;
pub mod upstream;
pub mod blocklist;
pub mod stats;
pub mod database;
pub mod web;
pub mod gravity;
pub mod cache;
pub mod security;
pub mod metrics;
pub mod error;

pub use config::Config;
pub use error::{PiHoleError, Result};

use crate::dns::DnsServer;
use crate::web::WebServer;
use crate::blocklist::BlocklistManager;
use crate::stats::StatsCollector;
use crate::gravity::GravityUpdater;

use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::{info, error};

/// Main Pi-hole server that coordinates DNS filtering, web interface, and statistics
pub struct PiHole {
    config: Config,
    dns_server: Arc<DnsServer>,
    web_server: Arc<WebServer>,
    blocklist_manager: Arc<RwLock<BlocklistManager>>,
    stats_collector: Arc<RwLock<StatsCollector>>,
    gravity_updater: Arc<GravityUpdater>,
}

impl PiHole {
    /// Create a new Pi-hole instance with the given configuration
    pub async fn new(config: Config) -> Result<Self> {
        info!("Initializing Pi-hole server...");

        // Initialize blocklist manager
        let blocklist_manager = Arc::new(RwLock::new(
            BlocklistManager::new(&config.data_dir).await?
        ));

        // Initialize statistics collector
        let stats_collector = Arc::new(RwLock::new(
            StatsCollector::new(&config.data_dir).await?
        ));

        // Initialize gravity updater
        let gravity_updater = Arc::new(
            GravityUpdater::new(blocklist_manager.clone()).await?
        );

        // Initialize DNS server
        let dns_server = Arc::new(
            DnsServer::new(
                config.clone(),
                blocklist_manager.clone(),
                stats_collector.clone(),
            ).await?
        );

        // Initialize web server
        let web_server = Arc::new(
            WebServer::new(
                config.clone(),
                blocklist_manager.clone(),
                stats_collector.clone(),
                gravity_updater.clone(),
            ).await?
        );

        info!("Pi-hole server initialized successfully");

        Ok(Self {
            config,
            dns_server,
            web_server,
            blocklist_manager,
            stats_collector,
            gravity_updater,
        })
    }

    /// Start the Pi-hole server (DNS and web servers)
    pub async fn start(&self) -> Result<()> {
        info!("Starting Pi-hole server...");

        // Start DNS server
        let dns_handle = {
            let dns_server = self.dns_server.clone();
            tokio::spawn(async move {
                if let Err(e) = dns_server.start().await {
                    error!("DNS server error: {}", e);
                }
            })
        };

        // Start web server
        let web_handle = {
            let web_server = self.web_server.clone();
            tokio::spawn(async move {
                if let Err(e) = web_server.start().await {
                    error!("Web server error: {}", e);
                }
            })
        };

        // Start gravity updater (periodic blocklist updates)
        let gravity_handle = {
            let gravity_updater = self.gravity_updater.clone();
            tokio::spawn(async move {
                if let Err(e) = gravity_updater.start_periodic_updates().await {
                    error!("Gravity updater error: {}", e);
                }
            })
        };

        info!("Pi-hole server started successfully");
        info!("DNS server listening on {}:{}", self.config.dns_bind_address, self.config.dns_port);
        info!("Web interface available at http://{}:{}", self.config.web_bind_address, self.config.web_port);

        // Wait for all services
        let _ = tokio::try_join!(dns_handle, web_handle, gravity_handle);

        Ok(())
    }

    /// Gracefully shutdown the Pi-hole server
    pub async fn shutdown(&self) -> Result<()> {
        info!("Shutting down Pi-hole server...");
        // Graceful shutdown logic would go here
        info!("Pi-hole server shut down successfully");
        Ok(())
    }
}