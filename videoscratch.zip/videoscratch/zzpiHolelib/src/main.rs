use zzpi_holelib::{Config, PiHole};
use clap::Parser;
use tracing_subscriber;
use std::path::PathBuf;

#[derive(Parser)]
#[command(name = "pihole")]
#[command(about = "A Pi-hole implementation in Rust")]
struct Cli {
    /// Configuration file path
    #[arg(short, long, default_value = "pihole.json")]
    config: PathBuf,
    
    /// Data directory
    #[arg(short, long, default_value = "./pihole-data")]
    data_dir: PathBuf,
    
    /// DNS port
    #[arg(long, default_value = "5353")] // Use 5353 instead of 53 for demo (requires root)
    dns_port: u16,
    
    /// Web port
    #[arg(long, default_value = "8080")]
    web_port: u16,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize tracing
    tracing_subscriber::fmt::init();

    let cli = Cli::parse();

    // Create configuration
    let mut config = if cli.config.exists() {
        Config::from_file(&cli.config).await?
    } else {
        Config::default()
    };

    // Override with CLI arguments
    config.data_dir = cli.data_dir;
    config.dns_port = cli.dns_port;
    config.web_port = cli.web_port;

    // Ensure data directory exists
    config.ensure_data_dir().await?;

    // Save config if it was created from defaults
    if !cli.config.exists() {
        config.to_file(&cli.config).await?;
        println!("Created default configuration at {}", cli.config.display());
    }

    println!("Starting Pi-hole server...");
    println!("DNS server will listen on port {}", config.dns_port);
    println!("Web interface will be available on port {}", config.web_port);

    // Create and start Pi-hole server
    let pihole = PiHole::new(config).await?;
    pihole.start().await?;

    Ok(())
}
