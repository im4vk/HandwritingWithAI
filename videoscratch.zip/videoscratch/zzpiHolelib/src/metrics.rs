use std::sync::Arc;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::collections::HashMap;
use tokio::sync::RwLock;
use serde::{Serialize, Deserialize};
use chrono::{DateTime, Utc};

/// Real-time metrics collector
#[derive(Clone)]
pub struct MetricsCollector {
    inner: Arc<MetricsInner>,
}

struct MetricsInner {
    // DNS metrics
    total_queries: AtomicU64,
    blocked_queries: AtomicU64,
    cached_queries: AtomicU64,
    failed_queries: AtomicU64,
    
    // Performance metrics
    avg_response_time_ms: AtomicU64,
    uptime_start: DateTime<Utc>,
    
    // Client metrics
    unique_clients: AtomicUsize,
    active_clients: RwLock<HashMap<std::net::IpAddr, DateTime<Utc>>>,
    
    // Top domains
    top_blocked_domains: RwLock<HashMap<String, u64>>,
    top_allowed_domains: RwLock<HashMap<String, u64>>,
    
    // Error tracking
    dns_errors: AtomicU64,
    upstream_errors: AtomicU64,
    cache_misses: AtomicU64,
    cache_hits: AtomicU64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct MetricsSnapshot {
    pub dns_metrics: DnsMetrics,
    pub performance_metrics: PerformanceMetrics,
    pub client_metrics: ClientMetrics,
    pub error_metrics: ErrorMetrics,
    pub cache_metrics: CacheMetrics,
    pub top_domains: TopDomains,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DnsMetrics {
    pub total_queries: u64,
    pub blocked_queries: u64,
    pub allowed_queries: u64,
    pub block_percentage: f64,
    pub queries_per_second: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PerformanceMetrics {
    pub avg_response_time_ms: u64,
    pub uptime_seconds: u64,
    pub memory_usage_mb: Option<u64>,
    pub cpu_usage_percent: Option<f64>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ClientMetrics {
    pub unique_clients: usize,
    pub active_clients_1h: usize,
    pub active_clients_24h: usize,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ErrorMetrics {
    pub dns_errors: u64,
    pub upstream_errors: u64,
    pub error_rate_percent: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CacheMetrics {
    pub cache_hits: u64,
    pub cache_misses: u64,
    pub cache_hit_rate: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct TopDomains {
    pub blocked: Vec<(String, u64)>,
    pub allowed: Vec<(String, u64)>,
}

impl MetricsCollector {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(MetricsInner {
                total_queries: AtomicU64::new(0),
                blocked_queries: AtomicU64::new(0),
                cached_queries: AtomicU64::new(0),
                failed_queries: AtomicU64::new(0),
                avg_response_time_ms: AtomicU64::new(0),
                uptime_start: Utc::now(),
                unique_clients: AtomicUsize::new(0),
                active_clients: RwLock::new(HashMap::new()),
                top_blocked_domains: RwLock::new(HashMap::new()),
                top_allowed_domains: RwLock::new(HashMap::new()),
                dns_errors: AtomicU64::new(0),
                upstream_errors: AtomicU64::new(0),
                cache_misses: AtomicU64::new(0),
                cache_hits: AtomicU64::new(0),
            }),
        }
    }

    /// Record a DNS query
    pub async fn record_query(&self, client_ip: std::net::IpAddr, domain: &str, blocked: bool, response_time_ms: u64) {
        self.inner.total_queries.fetch_add(1, Ordering::Relaxed);
        
        if blocked {
            self.inner.blocked_queries.fetch_add(1, Ordering::Relaxed);
            self.update_top_blocked_domain(domain).await;
        } else {
            self.update_top_allowed_domain(domain).await;
        }

        self.update_response_time(response_time_ms);
        self.update_client_activity(client_ip).await;
    }

    /// Record a cache hit
    pub fn record_cache_hit(&self) {
        self.inner.cache_hits.fetch_add(1, Ordering::Relaxed);
        self.inner.cached_queries.fetch_add(1, Ordering::Relaxed);
    }

    /// Record a cache miss
    pub fn record_cache_miss(&self) {
        self.inner.cache_misses.fetch_add(1, Ordering::Relaxed);
    }

    /// Record a DNS error
    pub fn record_dns_error(&self) {
        self.inner.dns_errors.fetch_add(1, Ordering::Relaxed);
        self.inner.failed_queries.fetch_add(1, Ordering::Relaxed);
    }

    /// Record an upstream error
    pub fn record_upstream_error(&self) {
        self.inner.upstream_errors.fetch_add(1, Ordering::Relaxed);
        self.inner.failed_queries.fetch_add(1, Ordering::Relaxed);
    }

    /// Update response time (moving average)
    fn update_response_time(&self, response_time_ms: u64) {
        let current_avg = self.inner.avg_response_time_ms.load(Ordering::Relaxed);
        // Simple moving average with weight of 0.1 for new values
        let new_avg = if current_avg == 0 {
            response_time_ms
        } else {
            (current_avg * 9 + response_time_ms) / 10
        };
        self.inner.avg_response_time_ms.store(new_avg, Ordering::Relaxed);
    }

    /// Update client activity
    async fn update_client_activity(&self, client_ip: std::net::IpAddr) {
        let mut clients = self.inner.active_clients.write().await;
        let now = Utc::now();
        
        if !clients.contains_key(&client_ip) {
            self.inner.unique_clients.fetch_add(1, Ordering::Relaxed);
        }
        
        clients.insert(client_ip, now);
    }

    /// Update top blocked domain
    async fn update_top_blocked_domain(&self, domain: &str) {
        let mut top_domains = self.inner.top_blocked_domains.write().await;
        *top_domains.entry(domain.to_string()).or_insert(0) += 1;
        
        // Keep only top 100 domains
        if top_domains.len() > 100 {
            let mut domains_vec: Vec<_> = top_domains.iter().collect();
            domains_vec.sort_by(|a, b| b.1.cmp(a.1));
            domains_vec.truncate(100);
            *top_domains = domains_vec.into_iter().map(|(k, v)| (k.clone(), *v)).collect();
        }
    }

    /// Update top allowed domain
    async fn update_top_allowed_domain(&self, domain: &str) {
        let mut top_domains = self.inner.top_allowed_domains.write().await;
        *top_domains.entry(domain.to_string()).or_insert(0) += 1;
        
        // Keep only top 100 domains
        if top_domains.len() > 100 {
            let mut domains_vec: Vec<_> = top_domains.iter().collect();
            domains_vec.sort_by(|a, b| b.1.cmp(a.1));
            domains_vec.truncate(100);
            *top_domains = domains_vec.into_iter().map(|(k, v)| (k.clone(), *v)).collect();
        }
    }

    /// Get current metrics snapshot
    pub async fn get_snapshot(&self) -> MetricsSnapshot {
        let total_queries = self.inner.total_queries.load(Ordering::Relaxed);
        let blocked_queries = self.inner.blocked_queries.load(Ordering::Relaxed);
        let allowed_queries = total_queries - blocked_queries;
        let failed_queries = self.inner.failed_queries.load(Ordering::Relaxed);
        
        let block_percentage = if total_queries > 0 {
            (blocked_queries as f64 / total_queries as f64) * 100.0
        } else {
            0.0
        };

        let uptime_seconds = Utc::now()
            .signed_duration_since(self.inner.uptime_start)
            .num_seconds() as u64;
        
        let queries_per_second = if uptime_seconds > 0 {
            total_queries as f64 / uptime_seconds as f64
        } else {
            0.0
        };

        let error_rate_percent = if total_queries > 0 {
            (failed_queries as f64 / total_queries as f64) * 100.0
        } else {
            0.0
        };

        let cache_hits = self.inner.cache_hits.load(Ordering::Relaxed);
        let cache_misses = self.inner.cache_misses.load(Ordering::Relaxed);
        let cache_hit_rate = if cache_hits + cache_misses > 0 {
            (cache_hits as f64 / (cache_hits + cache_misses) as f64) * 100.0
        } else {
            0.0
        };

        // Count active clients
        let clients = self.inner.active_clients.read().await;
        let now = Utc::now();
        let active_1h = clients.values()
            .filter(|&&last_seen| now.signed_duration_since(last_seen).num_hours() < 1)
            .count();
        let active_24h = clients.values()
            .filter(|&&last_seen| now.signed_duration_since(last_seen).num_hours() < 24)
            .count();

        // Get top domains
        let blocked_domains = self.inner.top_blocked_domains.read().await;
        let mut top_blocked: Vec<_> = blocked_domains.iter().map(|(k, v)| (k.clone(), *v)).collect();
        top_blocked.sort_by(|a, b| b.1.cmp(&a.1));
        top_blocked.truncate(10);

        let allowed_domains = self.inner.top_allowed_domains.read().await;
        let mut top_allowed: Vec<_> = allowed_domains.iter().map(|(k, v)| (k.clone(), *v)).collect();
        top_allowed.sort_by(|a, b| b.1.cmp(&a.1));
        top_allowed.truncate(10);

        MetricsSnapshot {
            dns_metrics: DnsMetrics {
                total_queries,
                blocked_queries,
                allowed_queries,
                block_percentage,
                queries_per_second,
            },
            performance_metrics: PerformanceMetrics {
                avg_response_time_ms: self.inner.avg_response_time_ms.load(Ordering::Relaxed),
                uptime_seconds,
                memory_usage_mb: self.get_memory_usage(),
                cpu_usage_percent: None, // Would need system monitoring
            },
            client_metrics: ClientMetrics {
                unique_clients: self.inner.unique_clients.load(Ordering::Relaxed),
                active_clients_1h: active_1h,
                active_clients_24h: active_24h,
            },
            error_metrics: ErrorMetrics {
                dns_errors: self.inner.dns_errors.load(Ordering::Relaxed),
                upstream_errors: self.inner.upstream_errors.load(Ordering::Relaxed),
                error_rate_percent,
            },
            cache_metrics: CacheMetrics {
                cache_hits,
                cache_misses,
                cache_hit_rate,
            },
            top_domains: TopDomains {
                blocked: top_blocked,
                allowed: top_allowed,
            },
            timestamp: Utc::now(),
        }
    }

    /// Get memory usage (simplified)
    fn get_memory_usage(&self) -> Option<u64> {
        // This is a simplified implementation
        // In a real implementation, you'd use system APIs
        None
    }

    /// Reset all metrics
    pub async fn reset(&self) {
        self.inner.total_queries.store(0, Ordering::Relaxed);
        self.inner.blocked_queries.store(0, Ordering::Relaxed);
        self.inner.cached_queries.store(0, Ordering::Relaxed);
        self.inner.failed_queries.store(0, Ordering::Relaxed);
        self.inner.avg_response_time_ms.store(0, Ordering::Relaxed);
        self.inner.unique_clients.store(0, Ordering::Relaxed);
        self.inner.dns_errors.store(0, Ordering::Relaxed);
        self.inner.upstream_errors.store(0, Ordering::Relaxed);
        self.inner.cache_hits.store(0, Ordering::Relaxed);
        self.inner.cache_misses.store(0, Ordering::Relaxed);
        
        self.inner.active_clients.write().await.clear();
        self.inner.top_blocked_domains.write().await.clear();
        self.inner.top_allowed_domains.write().await.clear();
    }
}
