use std::collections::HashMap;
use std::net::IpAddr;
use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::time::{Duration, Instant};
use tracing::{warn, debug};

/// Rate limiter for DNS queries
#[derive(Clone)]
pub struct RateLimiter {
    clients: Arc<RwLock<HashMap<IpAddr, ClientRateInfo>>>,
    max_queries_per_minute: u32,
    cleanup_interval: Duration,
    last_cleanup: Arc<RwLock<Instant>>,
}

#[derive(Debug, Clone)]
struct ClientRateInfo {
    query_count: u32,
    window_start: Instant,
    last_query: Instant,
}

impl RateLimiter {
    pub fn new(max_queries_per_minute: u32) -> Self {
        Self {
            clients: Arc::new(RwLock::new(HashMap::new())),
            max_queries_per_minute,
            cleanup_interval: Duration::from_secs(300), // 5 minutes
            last_cleanup: Arc::new(RwLock::new(Instant::now())),
        }
    }

    /// Check if a client is allowed to make a query
    pub async fn is_allowed(&self, client_ip: IpAddr) -> bool {
        // Cleanup old entries periodically
        self.cleanup_if_needed().await;

        let mut clients = self.clients.write().await;
        let now = Instant::now();
        
        let client_info = clients.entry(client_ip).or_insert(ClientRateInfo {
            query_count: 0,
            window_start: now,
            last_query: now,
        });

        // Reset window if more than a minute has passed
        if now.duration_since(client_info.window_start) >= Duration::from_secs(60) {
            client_info.query_count = 0;
            client_info.window_start = now;
        }

        client_info.last_query = now;
        client_info.query_count += 1;

        let allowed = client_info.query_count <= self.max_queries_per_minute;
        
        if !allowed {
            warn!("Rate limit exceeded for client {}: {} queries in current window", 
                  client_ip, client_info.query_count);
        } else {
            debug!("Query allowed for {}: {}/{} queries", 
                   client_ip, client_info.query_count, self.max_queries_per_minute);
        }

        allowed
    }

    /// Clean up old client entries
    async fn cleanup_if_needed(&self) {
        let mut last_cleanup = self.last_cleanup.write().await;
        let now = Instant::now();
        
        if now.duration_since(*last_cleanup) < self.cleanup_interval {
            return;
        }

        *last_cleanup = now;
        drop(last_cleanup);

        let mut clients = self.clients.write().await;
        let cutoff = now - Duration::from_secs(300); // Keep entries for 5 minutes
        
        clients.retain(|ip, info| {
            let keep = info.last_query >= cutoff;
            if !keep {
                debug!("Removed rate limit entry for inactive client: {}", ip);
            }
            keep
        });

        debug!("Rate limiter cleanup completed, {} active clients", clients.len());
    }

    /// Get current rate limit statistics
    pub async fn get_stats(&self) -> RateLimitStats {
        let clients = self.clients.read().await;
        let now = Instant::now();
        let mut active_clients = 0;
        let mut total_queries = 0;
        let mut rate_limited_clients = 0;

        for info in clients.values() {
            if now.duration_since(info.last_query) < Duration::from_secs(300) {
                active_clients += 1;
                total_queries += info.query_count;
                
                if info.query_count > self.max_queries_per_minute {
                    rate_limited_clients += 1;
                }
            }
        }

        RateLimitStats {
            active_clients,
            total_queries,
            rate_limited_clients,
            max_queries_per_minute: self.max_queries_per_minute,
        }
    }
}

#[derive(Debug)]
pub struct RateLimitStats {
    pub active_clients: usize,
    pub total_queries: u32,
    pub rate_limited_clients: usize,
    pub max_queries_per_minute: u32,
}

/// Input validation and sanitization
pub struct InputValidator;

impl InputValidator {
    /// Validate domain name
    pub fn is_valid_domain(domain: &str) -> bool {
        if domain.is_empty() || domain.len() > 253 {
            return false;
        }

        // Check for valid characters and structure
        for part in domain.split('.') {
            if part.is_empty() || part.len() > 63 {
                return false;
            }
            
            // Must start and end with alphanumeric
            if !part.chars().next().unwrap_or(' ').is_alphanumeric() ||
               !part.chars().last().unwrap_or(' ').is_alphanumeric() {
                return false;
            }
            
            // Only alphanumeric and hyphens allowed
            if !part.chars().all(|c| c.is_alphanumeric() || c == '-') {
                return false;
            }
        }

        true
    }

    /// Validate IP address format
    pub fn is_valid_ip(ip_str: &str) -> bool {
        ip_str.parse::<IpAddr>().is_ok()
    }

    /// Sanitize domain name for logging
    pub fn sanitize_domain(domain: &str) -> String {
        domain.chars()
            .filter(|c| c.is_alphanumeric() || *c == '.' || *c == '-')
            .collect::<String>()
            .to_lowercase()
    }

    /// Check for suspicious patterns
    pub fn is_suspicious_domain(domain: &str) -> bool {
        let domain_lower = domain.to_lowercase();
        
        // Check for common malicious patterns
        let suspicious_patterns = [
            "xn--", // Punycode (internationalized domains)
            ".tk", ".ml", ".ga", ".cf", // Free TLDs often used maliciously
            "bit.ly", "tinyurl", "short", // URL shorteners
        ];

        for pattern in &suspicious_patterns {
            if domain_lower.contains(pattern) {
                return true;
            }
        }

        // Check for excessive subdomains
        if domain.split('.').count() > 5 {
            return true;
        }

        // Check for very long domain names
        if domain.len() > 100 {
            return true;
        }

        false
    }
}

/// Security event logger
pub struct SecurityLogger;

impl SecurityLogger {
    pub fn log_rate_limit_exceeded(client_ip: IpAddr, query_count: u32) {
        warn!("SECURITY: Rate limit exceeded - Client: {}, Queries: {}", client_ip, query_count);
    }

    pub fn log_suspicious_domain(client_ip: IpAddr, domain: &str) {
        warn!("SECURITY: Suspicious domain query - Client: {}, Domain: {}", client_ip, domain);
    }

    pub fn log_malformed_packet(client_ip: IpAddr, error: &str) {
        warn!("SECURITY: Malformed DNS packet - Client: {}, Error: {}", client_ip, error);
    }

    pub fn log_blocked_query(client_ip: IpAddr, domain: &str, reason: &str) {
        debug!("SECURITY: Query blocked - Client: {}, Domain: {}, Reason: {}", client_ip, domain, reason);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_domain_validation() {
        assert!(InputValidator::is_valid_domain("example.com"));
        assert!(InputValidator::is_valid_domain("sub.example.com"));
        assert!(InputValidator::is_valid_domain("a.b.c.d.e"));
        
        assert!(!InputValidator::is_valid_domain(""));
        assert!(!InputValidator::is_valid_domain(".example.com"));
        assert!(!InputValidator::is_valid_domain("example.com."));
        assert!(!InputValidator::is_valid_domain("ex ample.com"));
        assert!(!InputValidator::is_valid_domain("example..com"));
    }

    #[test]
    fn test_suspicious_domain_detection() {
        assert!(InputValidator::is_suspicious_domain("xn--fsq.com"));
        assert!(InputValidator::is_suspicious_domain("evil.tk"));
        assert!(InputValidator::is_suspicious_domain("a.b.c.d.e.f.com"));
        
        assert!(!InputValidator::is_suspicious_domain("google.com"));
        assert!(!InputValidator::is_suspicious_domain("sub.example.org"));
    }

    #[tokio::test]
    async fn test_rate_limiter() {
        let limiter = RateLimiter::new(5);
        let client_ip: IpAddr = "192.168.1.1".parse().unwrap();
        
        // Should allow first 5 queries
        for _ in 0..5 {
            assert!(limiter.is_allowed(client_ip).await);
        }
        
        // Should block 6th query
        assert!(!limiter.is_allowed(client_ip).await);
    }
}
