use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::net::IpAddr;
use std::collections::HashMap;
use tracing::{info, debug};
use chrono::{DateTime, Utc};

/// Query log entry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueryLogEntry {
    pub timestamp: DateTime<Utc>,
    pub client_ip: IpAddr,
    pub domain: String,
    pub query_type: String,
    pub status: QueryStatus,
}

/// Query status
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum QueryStatus {
    Allowed,
    Blocked,
}

/// Summary statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SummaryStats {
    pub domains_being_blocked: u64,
    pub dns_queries_today: u64,
    pub ads_blocked_today: u64,
    pub ads_percentage_today: f64,
    pub unique_domains: u64,
    pub queries_forwarded: u64,
    pub unique_clients: u64,
}

/// Simplified statistics collector (in-memory for demo)
pub struct StatsCollector {
    data_dir: PathBuf,
    query_log: Vec<QueryLogEntry>,
    daily_queries: u64,
    daily_blocked: u64,
    unique_clients: HashMap<IpAddr, u64>,
}

impl StatsCollector {
    /// Create a new statistics collector
    pub async fn new(data_dir: &PathBuf) -> Result<Self> {
        info!("Initializing statistics collector...");
        tokio::fs::create_dir_all(data_dir).await?;
        info!("Statistics collector initialized");

        Ok(Self {
            data_dir: data_dir.clone(),
            query_log: Vec::new(),
            daily_queries: 0,
            daily_blocked: 0,
            unique_clients: HashMap::new(),
        })
    }

    /// Record an allowed DNS query
    pub async fn record_allowed_query(&mut self, domain: &str, client_ip: IpAddr) {
        self.record_query(domain, client_ip, QueryStatus::Allowed).await;
    }

    /// Record a blocked DNS query
    pub async fn record_blocked_query(&mut self, domain: &str, client_ip: IpAddr) {
        self.record_query(domain, client_ip, QueryStatus::Blocked).await;
    }

    /// Record a DNS query
    async fn record_query(&mut self, domain: &str, client_ip: IpAddr, status: QueryStatus) {
        let entry = QueryLogEntry {
            timestamp: Utc::now(),
            client_ip,
            domain: domain.to_string(),
            query_type: "A".to_string(),
            status: status.clone(),
        };

        self.query_log.push(entry);
        self.daily_queries += 1;

        match status {
            QueryStatus::Blocked => self.daily_blocked += 1,
            _ => {}
        }

        *self.unique_clients.entry(client_ip).or_insert(0) += 1;

        debug!("Recorded {:?} query for {} from {}", status, domain, client_ip);
    }

    /// Get summary statistics
    pub async fn get_summary_stats(&self, domains_being_blocked: u64) -> Result<SummaryStats> {
        let ads_percentage_today = if self.daily_queries > 0 {
            (self.daily_blocked as f64 / self.daily_queries as f64) * 100.0
        } else {
            0.0
        };

        Ok(SummaryStats {
            domains_being_blocked,
            dns_queries_today: self.daily_queries,
            ads_blocked_today: self.daily_blocked,
            ads_percentage_today,
            unique_domains: self.query_log.len() as u64, // Simplified
            queries_forwarded: self.daily_queries - self.daily_blocked,
            unique_clients: self.unique_clients.len() as u64,
        })
    }

    /// Get recent query log entries
    pub async fn get_recent_queries(&self, limit: usize) -> Result<Vec<QueryLogEntry>> {
        let mut recent = self.query_log.clone();
        recent.sort_by(|a, b| b.timestamp.cmp(&a.timestamp));
        recent.truncate(limit);
        Ok(recent)
    }

    /// Save stats to file (simplified implementation)
    pub async fn save_stats(&self) -> Result<()> {
        let stats_file = self.data_dir.join("stats.json");
        let stats = serde_json::json!({
            "daily_queries": self.daily_queries,
            "daily_blocked": self.daily_blocked,
            "unique_clients": self.unique_clients.len()
        });

        tokio::fs::write(stats_file, serde_json::to_string_pretty(&stats)?).await?;
        debug!("Saved statistics to file");
        Ok(())
    }
}