use crate::error::{PiHoleError, Result};
use crate::dns_parser::DnsPacket;
use tokio::net::UdpSocket;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::time::{timeout, Duration};
use tracing::{debug, warn};

/// Upstream DNS resolver with load balancing and fallback
pub struct UpstreamResolver {
    servers: Vec<SocketAddr>,
    socket: Arc<UdpSocket>,
    timeout_duration: Duration,
}

impl UpstreamResolver {
    /// Create a new upstream resolver
    pub async fn new(servers: Vec<String>) -> Result<Self> {
        let mut parsed_servers = Vec::new();
        
        for server in servers {
            match server.parse::<SocketAddr>() {
                Ok(addr) => parsed_servers.push(addr),
                Err(e) => {
                    warn!("Invalid upstream server address '{}': {}", server, e);
                }
            }
        }

        if parsed_servers.is_empty() {
            return Err(PiHoleError::Config("No valid upstream DNS servers".to_string()));
        }

        // Bind to any available port for outgoing queries
        let socket = Arc::new(UdpSocket::bind("0.0.0.0:0").await?);
        
        Ok(Self {
            servers: parsed_servers,
            socket,
            timeout_duration: Duration::from_secs(5),
        })
    }

    /// Resolve a DNS query using upstream servers
    pub async fn resolve(&self, query: &DnsPacket) -> Result<DnsPacket> {
        let query_bytes = query.to_bytes();
        
        // Try each upstream server
        for (i, &server) in self.servers.iter().enumerate() {
            debug!("Trying upstream server {} ({})", i + 1, server);
            
            match self.query_upstream(server, &query_bytes).await {
                Ok(response) => {
                    debug!("Got response from upstream server {}", server);
                    return Ok(response);
                }
                Err(e) => {
                    warn!("Upstream server {} failed: {}", server, e);
                    // Continue to next server
                }
            }
        }

        Err(PiHoleError::Server("All upstream servers failed".to_string()))
    }

    /// Query a specific upstream server
    async fn query_upstream(&self, server: SocketAddr, query: &[u8]) -> Result<DnsPacket> {
        // Send query
        self.socket.send_to(query, server).await?;
        
        // Wait for response with timeout
        let mut buf = [0u8; 512];
        let (len, _) = timeout(self.timeout_duration, self.socket.recv_from(&mut buf)).await
            .map_err(|_| PiHoleError::Server("Upstream query timeout".to_string()))??;

        // Parse response
        DnsPacket::from_bytes(&buf[..len])
    }

    /// Check if upstream servers are healthy
    pub async fn health_check(&self) -> Vec<(SocketAddr, bool)> {
        let mut results = Vec::new();
        
        // Create a simple health check query (query for ".")
        let health_query = DnsPacket {
            header: crate::dns_parser::DnsHeader {
                id: 1,
                flags: 0x0100, // Standard query
                question_count: 1,
                answer_count: 0,
                authority_count: 0,
                additional_count: 0,
            },
            questions: vec![crate::dns_parser::DnsQuestion {
                name: ".".to_string(),
                qtype: 1, // A record
                qclass: 1, // IN
            }],
            answers: Vec::new(),
            authorities: Vec::new(),
            additionals: Vec::new(),
        };

        let query_bytes = health_query.to_bytes();

        for &server in &self.servers {
            let is_healthy = match timeout(Duration::from_secs(2), 
                self.socket.send_to(&query_bytes, server)).await {
                Ok(Ok(_)) => {
                    // Try to receive response
                    let mut buf = [0u8; 512];
                    timeout(Duration::from_secs(2), self.socket.recv_from(&mut buf)).await.is_ok()
                }
                _ => false,
            };
            
            results.push((server, is_healthy));
        }

        results
    }

    /// Get upstream server statistics
    pub fn get_server_list(&self) -> &[SocketAddr] {
        &self.servers
    }
}
