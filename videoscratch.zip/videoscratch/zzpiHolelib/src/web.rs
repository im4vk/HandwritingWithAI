use crate::config::Config;
use crate::blocklist::BlocklistManager;
use crate::stats::StatsCollector;
use crate::gravity::GravityUpdater;

use std::sync::Arc;
use tokio::sync::RwLock;
use axum::{
    extract::{Query, State},
    http::StatusCode,
    response::Json,
    routing::get,
    Router,
};
use serde::{Deserialize, Serialize};
use tower_http::cors::CorsLayer;
use tracing::{info, warn};

/// Web server for Pi-hole admin interface
pub struct WebServer {
    config: Config,
    blocklist_manager: Arc<RwLock<BlocklistManager>>,
    stats_collector: Arc<RwLock<StatsCollector>>,
    gravity_updater: Arc<GravityUpdater>,
}

/// Shared application state
#[derive(Clone)]
pub struct AppState {
    config: Config,
    blocklist_manager: Arc<RwLock<BlocklistManager>>,
    stats_collector: Arc<RwLock<StatsCollector>>,
    gravity_updater: Arc<GravityUpdater>,
}

/// API response for summary endpoint
#[derive(Debug, Serialize)]
pub struct SummaryResponse {
    pub domains_being_blocked: u64,
    pub dns_queries_today: u64,
    pub ads_blocked_today: u64,
    pub ads_percentage_today: f64,
    pub unique_domains: u64,
    pub queries_forwarded: u64,
    pub unique_clients: u64,
    pub status: String,
}

/// Query parameters for Pi-hole API compatibility
#[derive(Debug, Deserialize)]
pub struct ApiQuery {
    pub auth: Option<String>,
    #[serde(rename = "summaryRaw")]
    pub summary_raw: Option<String>,
    pub enable: Option<String>,
    pub disable: Option<String>,
    pub list: Option<String>,
    pub add: Option<String>,
    pub sub: Option<String>,
    pub domain: Option<String>,
    pub version: Option<String>,
}

impl WebServer {
    /// Create a new web server
    pub async fn new(
        config: Config,
        blocklist_manager: Arc<RwLock<BlocklistManager>>,
        stats_collector: Arc<RwLock<StatsCollector>>,
        gravity_updater: Arc<GravityUpdater>,
    ) -> crate::Result<Self> {
        info!("Initializing web server...");
        info!("Web server initialized");

        Ok(Self {
            config,
            blocklist_manager,
            stats_collector,
            gravity_updater,
        })
    }

    /// Start the web server
    pub async fn start(&self) -> crate::Result<()> {
        info!("Starting web server on {}:{}", self.config.web_bind_address, self.config.web_port);

        let app_state = AppState {
            config: self.config.clone(),
            blocklist_manager: self.blocklist_manager.clone(),
            stats_collector: self.stats_collector.clone(),
            gravity_updater: self.gravity_updater.clone(),
        };

        let app = Router::new()
            // Pi-hole API compatibility endpoints
            .route("/admin/api.php", get(pihole_api_handler))
            .route("/api/stats/summary", get(summary_handler))
            .layer(CorsLayer::permissive())
            .with_state(app_state);

        let bind_addr = format!("{}:{}", self.config.web_bind_address, self.config.web_port);
        let listener = tokio::net::TcpListener::bind(&bind_addr).await
            .map_err(|e| crate::PiHoleError::Io(e))?;

        info!("Web server listening on {}", bind_addr);

        axum::serve(listener, app).await
            .map_err(|e| crate::PiHoleError::Server(format!("Web server error: {}", e)))?;

        Ok(())
    }
}

/// Pi-hole API compatibility handler
async fn pihole_api_handler(
    Query(params): Query<ApiQuery>,
    State(state): State<AppState>,
) -> Result<Json<serde_json::Value>, StatusCode> {
    // Handle different API endpoints based on query parameters
    if params.summary_raw.is_some() {
        return handle_summary_raw(state).await;
    }

    if params.enable.is_some() {
        return Ok(Json(serde_json::json!({
            "status": "enabled"
        })));
    }

    if params.disable.is_some() {
        return Ok(Json(serde_json::json!({
            "status": "disabled"
        })));
    }

    if let Some(list_type) = &params.list {
        return handle_list(state, list_type).await;
    }

    if params.version.is_some() {
        return Ok(Json(serde_json::json!({
            "core_current": "v6.0.0-demo",
            "web_current": "v6.0.0-demo",
            "ftl_current": "v6.0.0-demo"
        })));
    }

    Err(StatusCode::BAD_REQUEST)
}

/// Handle summary raw API call
async fn handle_summary_raw(state: AppState) -> Result<Json<serde_json::Value>, StatusCode> {
    let stats_collector = state.stats_collector.read().await;
    let blocklist = state.blocklist_manager.read().await;
    let blocklist_stats = blocklist.get_stats();
    let domains_being_blocked = blocklist_stats.get("gravity_blocked_domains").copied().unwrap_or(0) as u64;

    match stats_collector.get_summary_stats(domains_being_blocked).await {
        Ok(stats) => Ok(Json(serde_json::json!({
            "domains_being_blocked": stats.domains_being_blocked,
            "dns_queries_today": stats.dns_queries_today,
            "ads_blocked_today": stats.ads_blocked_today,
            "ads_percentage_today": stats.ads_percentage_today,
            "unique_domains": stats.unique_domains,
            "queries_forwarded": stats.queries_forwarded,
            "unique_clients": stats.unique_clients,
        }))),
        Err(_) => Err(StatusCode::INTERNAL_SERVER_ERROR),
    }
}

/// Handle list API call
async fn handle_list(state: AppState, list_type: &str) -> Result<Json<serde_json::Value>, StatusCode> {
    let blocklist = state.blocklist_manager.read().await;

    let domains: Vec<String> = match list_type {
        "black" => blocklist.get_custom_blacklist().keys().cloned().collect(),
        "white" => blocklist.get_custom_whitelist().keys().cloned().collect(),
        _ => return Err(StatusCode::BAD_REQUEST),
    };

    Ok(Json(serde_json::json!({
        "data": domains
    })))
}

/// Modern REST API handler for summary
async fn summary_handler(State(state): State<AppState>) -> Result<Json<SummaryResponse>, StatusCode> {
    let stats_collector = state.stats_collector.read().await;
    let blocklist = state.blocklist_manager.read().await;
    let blocklist_stats = blocklist.get_stats();
    let domains_being_blocked = blocklist_stats.get("gravity_blocked_domains").copied().unwrap_or(0) as u64;

    match stats_collector.get_summary_stats(domains_being_blocked).await {
        Ok(stats) => Ok(Json(SummaryResponse {
            domains_being_blocked: stats.domains_being_blocked,
            dns_queries_today: stats.dns_queries_today,
            ads_blocked_today: stats.ads_blocked_today,
            ads_percentage_today: stats.ads_percentage_today,
            unique_domains: stats.unique_domains,
            queries_forwarded: stats.queries_forwarded,
            unique_clients: stats.unique_clients,
            status: if state.config.blocking_enabled { "enabled".to_string() } else { "disabled".to_string() },
        })),
        Err(_) => {
            warn!("Failed to get summary stats");
            Err(StatusCode::INTERNAL_SERVER_ERROR)
        }
    }
}