use zzpi_holelib::cache::DnsCache;
use zzpi_holelib::dns_parser::{DnsPacket, DnsHeader, DnsQuestion, DnsRecord, DnsRecordData};
use tokio::time::Duration;
use std::net::Ipv4Addr;

#[tokio::test]
async fn test_cache_basic_operations() {
    let cache = DnsCache::new(100, Duration::from_secs(60));
    
    // Test cache miss
    let result = cache.get("example.com", 1).await;
    assert!(result.is_none());
    
    // Create a test DNS response
    let response = DnsPacket {
        header: DnsHeader {
            id: 1234,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "example.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "example.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(192, 168, 1, 1)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    // Cache the response
    cache.set("example.com", 1, response.clone(), None).await;
    
    // Test cache hit
    let cached_result = cache.get("example.com", 1).await;
    assert!(cached_result.is_some());
    let cached_response = cached_result.unwrap();
    assert_eq!(cached_response.header.id, response.header.id);
    assert_eq!(cached_response.questions[0].name, "example.com");
}

#[tokio::test]
async fn test_cache_expiration() {
    let cache = DnsCache::new(100, Duration::from_millis(100));
    
    let response = DnsPacket {
        header: DnsHeader {
            id: 1234,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "test.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "test.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(1, 2, 3, 4)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    // Cache with short TTL
    cache.set("test.com", 1, response, Some(Duration::from_millis(50))).await;
    
    // Should be cached initially
    assert!(cache.get("test.com", 1).await.is_some());
    
    // Wait for expiration
    tokio::time::sleep(Duration::from_millis(100)).await;
    
    // Should be expired now
    assert!(cache.get("test.com", 1).await.is_none());
}

#[tokio::test]
async fn test_cache_statistics() {
    let cache = DnsCache::new(10, Duration::from_secs(60));
    
    let response = DnsPacket {
        header: DnsHeader {
            id: 1234,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "stats-test.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "stats-test.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(5, 6, 7, 8)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    // Cache the response
    cache.set("stats-test.com", 1, response, None).await;
    
    // Get initial stats
    let stats = cache.get_stats().await;
    assert_eq!(stats.total_entries, 1);
    assert_eq!(stats.max_size, 10);
    
    // Hit the cache multiple times
    for _ in 0..5 {
        let _ = cache.get("stats-test.com", 1).await;
    }
    
    let final_stats = cache.get_stats().await;
    assert_eq!(final_stats.total_hits, 5);
}

#[tokio::test]
async fn test_cache_eviction() {
    let cache = DnsCache::new(2, Duration::from_secs(60)); // Small cache size
    
    let response1 = DnsPacket {
        header: DnsHeader {
            id: 1,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "first.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "first.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(1, 1, 1, 1)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    let response2 = DnsPacket {
        header: DnsHeader {
            id: 2,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "second.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "second.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(2, 2, 2, 2)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    let response3 = DnsPacket {
        header: DnsHeader {
            id: 3,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "third.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "third.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(3, 3, 3, 3)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    // Fill cache to capacity
    cache.set("first.com", 1, response1, None).await;
    cache.set("second.com", 1, response2, None).await;
    
    // Both should be cached
    assert!(cache.get("first.com", 1).await.is_some());
    assert!(cache.get("second.com", 1).await.is_some());
    
    let stats = cache.get_stats().await;
    assert_eq!(stats.total_entries, 2);
    
    // Add third entry to trigger eviction
    cache.set("third.com", 1, response3, None).await;
    
    // One of the first two should be evicted
    let final_stats = cache.get_stats().await;
    assert_eq!(final_stats.total_entries, 2);
}
