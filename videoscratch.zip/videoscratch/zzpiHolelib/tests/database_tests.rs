use zzpi_holelib::database::Database;
use chrono::Utc;
use std::net::IpAddr;
use tempfile::TempDir;

#[tokio::test]
async fn test_database_initialization() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await;
    assert!(database.is_ok());
}

#[tokio::test]
async fn test_query_logging() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await.unwrap();
    
    let client_ip: IpAddr = "192.168.1.100".parse().unwrap();
    let timestamp = Utc::now();
    
    let query_id = database.log_query(
        timestamp,
        client_ip,
        "example.com",
        "A",
        "allowed",
        Some(50),
        Some("8.8.8.8:53"),
    ).await;
    
    assert!(query_id.is_ok());
    assert!(query_id.unwrap() > 0);
}

#[tokio::test]
async fn test_statistics_retrieval() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await.unwrap();
    
    let client_ip: IpAddr = "192.168.1.100".parse().unwrap();
    let timestamp = Utc::now();
    
    // Log some queries
    let _ = database.log_query(timestamp, client_ip, "example.com", "A", "allowed", Some(50), None).await;
    let _ = database.log_query(timestamp, client_ip, "ads.example.com", "A", "blocked", Some(30), None).await;
    let _ = database.log_query(timestamp, client_ip, "test.com", "A", "allowed", Some(45), None).await;
    
    // Get statistics
    let stats = database.get_query_stats(24).await.unwrap();
    assert_eq!(stats.0, 3); // total queries
    assert_eq!(stats.1, 1); // blocked queries
}

#[tokio::test]
async fn test_top_blocked_domains() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await.unwrap();
    
    let client_ip: IpAddr = "192.168.1.100".parse().unwrap();
    let timestamp = Utc::now();
    
    // Log blocked queries
    let _ = database.log_query(timestamp, client_ip, "ads1.example.com", "A", "blocked", Some(30), None).await;
    let _ = database.log_query(timestamp, client_ip, "ads2.example.com", "A", "blocked", Some(25), None).await;
    let _ = database.log_query(timestamp, client_ip, "ads1.example.com", "A", "blocked", Some(35), None).await;
    
    let top_domains = database.get_top_blocked_domains(10, Some(24)).await.unwrap();
    assert!(!top_domains.is_empty());
    
    // ads1.example.com should be first (2 queries)
    assert_eq!(top_domains[0].domain, "ads1.example.com");
    assert_eq!(top_domains[0].blocked_queries, 2);
}

#[tokio::test]
async fn test_top_clients() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await.unwrap();
    
    let client1: IpAddr = "192.168.1.100".parse().unwrap();
    let client2: IpAddr = "192.168.1.101".parse().unwrap();
    let timestamp = Utc::now();
    
    // Log queries from different clients
    let _ = database.log_query(timestamp, client1, "example.com", "A", "allowed", Some(50), None).await;
    let _ = database.log_query(timestamp, client1, "test.com", "A", "allowed", Some(45), None).await;
    let _ = database.log_query(timestamp, client2, "google.com", "A", "allowed", Some(40), None).await;
    
    let top_clients = database.get_top_clients(10).await.unwrap();
    assert!(!top_clients.is_empty());
    
    // Client1 should be first (2 queries)
    assert_eq!(top_clients[0].ip, client1);
    assert_eq!(top_clients[0].total_queries, 2);
}

#[tokio::test]
async fn test_recent_queries() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await.unwrap();
    
    let client_ip: IpAddr = "192.168.1.100".parse().unwrap();
    let timestamp = Utc::now();
    
    // Log a query
    let _ = database.log_query(timestamp, client_ip, "example.com", "A", "allowed", Some(50), Some("8.8.8.8:53")).await;
    
    let recent_queries = database.get_recent_queries(10).await.unwrap();
    assert_eq!(recent_queries.len(), 1);
    assert_eq!(recent_queries[0].domain, "example.com");
    assert_eq!(recent_queries[0].client_ip, client_ip);
    assert_eq!(recent_queries[0].status, "allowed");
}

#[tokio::test]
async fn test_custom_lists() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await.unwrap();
    
    // Add entries to blacklist
    let _ = database.add_custom_list_entry("ads.example.com", "blacklist", Some("Test ad domain"), "admin").await;
    let _ = database.add_custom_list_entry("tracker.example.com", "blacklist", Some("Tracking domain"), "admin").await;
    
    // Add entry to whitelist
    let _ = database.add_custom_list_entry("safe.example.com", "whitelist", Some("Safe domain"), "admin").await;
    
    // Get blacklist entries
    let blacklist = database.get_custom_list_entries("blacklist").await.unwrap();
    assert_eq!(blacklist.len(), 2);
    assert!(blacklist.contains(&"ads.example.com".to_string()));
    assert!(blacklist.contains(&"tracker.example.com".to_string()));
    
    // Get whitelist entries
    let whitelist = database.get_custom_list_entries("whitelist").await.unwrap();
    assert_eq!(whitelist.len(), 1);
    assert!(whitelist.contains(&"safe.example.com".to_string()));
}

#[tokio::test]
async fn test_cleanup_old_logs() {
    let temp_dir = TempDir::new().unwrap();
    let database = Database::new(&temp_dir.path().to_path_buf()).await.unwrap();
    
    let client_ip: IpAddr = "192.168.1.100".parse().unwrap();
    let timestamp = Utc::now();
    
    // Log some queries
    let _ = database.log_query(timestamp, client_ip, "example.com", "A", "allowed", Some(50), None).await;
    let _ = database.log_query(timestamp, client_ip, "test.com", "A", "blocked", Some(30), None).await;
    
    // Cleanup logs older than 0 days (should clean everything)
    let cleaned_count = database.cleanup_old_logs(0).await.unwrap();
    assert_eq!(cleaned_count, 2);
    
    // Verify logs are cleaned
    let stats = database.get_query_stats(24).await.unwrap();
    assert_eq!(stats.0, 0); // no queries left
}
