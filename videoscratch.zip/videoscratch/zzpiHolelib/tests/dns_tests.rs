use zzpi_holelib::dns_parser::*;
use std::net::Ipv4Addr;

#[test]
fn test_dns_packet_parsing() {
    // Create a simple DNS query packet
    let mut packet = Vec::new();
    
    // Header
    packet.extend_from_slice(&[0x12, 0x34]); // ID
    packet.extend_from_slice(&[0x01, 0x00]); // Flags (standard query)
    packet.extend_from_slice(&[0x00, 0x01]); // Question count
    packet.extend_from_slice(&[0x00, 0x00]); // Answer count
    packet.extend_from_slice(&[0x00, 0x00]); // Authority count
    packet.extend_from_slice(&[0x00, 0x00]); // Additional count

    // Question: example.com A IN
    packet.extend_from_slice(&[0x07]); // Length of "example"
    packet.extend_from_slice(b"example");
    packet.extend_from_slice(&[0x03]); // Length of "com"
    packet.extend_from_slice(b"com");
    packet.extend_from_slice(&[0x00]); // Root label
    packet.extend_from_slice(&[0x00, 0x01]); // Type A
    packet.extend_from_slice(&[0x00, 0x01]); // Class IN

    let parsed = DnsPacket::from_bytes(&packet).unwrap();
    
    assert_eq!(parsed.header.id, 0x1234);
    assert_eq!(parsed.header.question_count, 1);
    assert_eq!(parsed.questions.len(), 1);
    assert_eq!(parsed.questions[0].name, "example.com");
    assert_eq!(parsed.questions[0].qtype, 1); // A record
    assert_eq!(parsed.questions[0].qclass, 1); // IN
}

#[test]
fn test_dns_response_creation() {
    let query = DnsPacket {
        header: DnsHeader {
            id: 0x1234,
            flags: 0x0100,
            question_count: 1,
            answer_count: 0,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "example.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: Vec::new(),
        authorities: Vec::new(),
        additionals: Vec::new(),
    };

    let response = DnsPacket::create_response(&query, false);
    
    assert_eq!(response.header.id, 0x1234);
    assert!(response.header.flags & 0x8000 != 0); // Response flag set
    assert_eq!(response.questions.len(), 1);
    assert_eq!(response.answers.len(), 1);
    
    if let DnsRecordData::A(ip) = &response.answers[0].data {
        assert_eq!(*ip, Ipv4Addr::new(0, 0, 0, 0));
    } else {
        panic!("Expected A record in response");
    }
}

#[test]
fn test_dns_blocked_response() {
    let query = DnsPacket {
        header: DnsHeader {
            id: 0x5678,
            flags: 0x0100,
            question_count: 1,
            answer_count: 0,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "ads.example.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: Vec::new(),
        authorities: Vec::new(),
        additionals: Vec::new(),
    };

    let response = DnsPacket::create_response(&query, true);
    
    assert_eq!(response.header.id, 0x5678);
    assert!(response.header.flags & 0x8000 != 0); // Response flag set
    assert!(response.header.flags & 0x0003 != 0); // NXDOMAIN flag set
}

#[test]
fn test_domain_name_encoding() {
    let encoded = DnsPacket::encode_domain_name("www.example.com");
    let expected = vec![
        3, b'w', b'w', b'w',
        7, b'e', b'x', b'a', b'm', b'p', b'l', b'e',
        3, b'c', b'o', b'm',
        0
    ];
    assert_eq!(encoded, expected);
}

#[test]
fn test_packet_roundtrip() {
    let original = DnsPacket {
        header: DnsHeader {
            id: 0xABCD,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "test.example.org".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "test.example.org".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(192, 168, 1, 1)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };

    let bytes = original.to_bytes();
    let parsed = DnsPacket::from_bytes(&bytes).unwrap();
    
    assert_eq!(parsed.header.id, original.header.id);
    assert_eq!(parsed.questions[0].name, original.questions[0].name);
    assert_eq!(parsed.answers.len(), 1);
    
    if let DnsRecordData::A(ip) = &parsed.answers[0].data {
        assert_eq!(*ip, Ipv4Addr::new(192, 168, 1, 1));
    } else {
        panic!("Expected A record");
    }
}
