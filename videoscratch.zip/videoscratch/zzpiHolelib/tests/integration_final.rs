use zzpi_holelib::{Config, PiHole};
use std::net::IpAddr;
use tempfile::TempDir;

#[tokio::test]
async fn test_complete_pihole_integration() {
    println!("🧪 Starting Complete Pi-hole Integration Test");

    // Setup logging
    let _ = tracing_subscriber::fmt().try_init();

    // Create test configuration
    let temp_dir = TempDir::new().unwrap();
    let mut config = Config::default();
    config.dns_port = 25353; // Use unique ports for testing
    config.web_port = 28080;
    config.dns_bind_address = "127.0.0.1".parse::<IpAddr>().unwrap();
    config.web_bind_address = "127.0.0.1".parse::<IpAddr>().unwrap();
    config.data_dir = temp_dir.path().to_path_buf();
    config.cache_size = 1000;
    config.cache_ttl_seconds = 300;
    config.rate_limit_per_minute = 100;
    
    println!("✅ Configuration created with ports DNS:{} Web:{}", config.dns_port, config.web_port);

    // Test configuration validation
    assert_eq!(config.dns_port, 25353);
    assert_eq!(config.web_port, 28080);
    assert_eq!(config.cache_size, 1000);
    assert_eq!(config.upstream_dns.len(), 2); // Default upstream servers

    // Create Pi-hole instance
    let pihole_result = PiHole::new(config.clone()).await;
    assert!(pihole_result.is_ok(), "Failed to create Pi-hole instance: {:?}", pihole_result.err());
    
    let _pihole = pihole_result.unwrap();
    println!("✅ Pi-hole instance created successfully");

    // Test that data directory was created
    assert!(config.data_dir.exists());
    println!("✅ Data directory created: {}", config.data_dir.display());

    println!("🎉 Complete Pi-hole Integration Test PASSED");
}

#[tokio::test]
async fn test_configuration_validation() {
    println!("🧪 Testing Configuration Validation");

    // Test default configuration
    let default_config = Config::default();
    assert_eq!(default_config.dns_port, 53);
    assert_eq!(default_config.web_port, 8080);
    assert!(!default_config.upstream_dns.is_empty());
    assert_eq!(default_config.cache_size, 10000);
    assert_eq!(default_config.cache_ttl_seconds, 300);
    assert_eq!(default_config.rate_limit_per_minute, 1000);
    assert_eq!(default_config.log_retention_days, 90);
    
    println!("✅ Default configuration validation passed");

    // Test custom configuration
    let temp_dir = TempDir::new().unwrap();
    let mut custom_config = Config::default();
    custom_config.data_dir = temp_dir.path().to_path_buf();
    custom_config.cache_size = 5000;
    custom_config.upstream_dns = vec!["1.1.1.1:53".to_string(), "8.8.8.8:53".to_string()];
    
    // Validate custom settings
    assert_eq!(custom_config.cache_size, 5000);
    assert_eq!(custom_config.upstream_dns.len(), 2);
    
    println!("✅ Custom configuration validation passed");
    println!("🎉 Configuration Validation Test PASSED");
}

#[tokio::test]
async fn test_error_handling() {
    println!("🧪 Testing Error Handling");

    // Test invalid directory creation (read-only path)
    let mut config = Config::default();
    config.data_dir = std::path::PathBuf::from("/invalid/readonly/path");
    
    // This should fail gracefully
    let result = PiHole::new(config).await;
    assert!(result.is_err(), "Expected error for invalid data directory");
    
    println!("✅ Invalid directory error handling works");

    // Test with valid temporary directory
    let temp_dir = TempDir::new().unwrap();
    let mut valid_config = Config::default();
    valid_config.data_dir = temp_dir.path().to_path_buf();
    valid_config.dns_port = 35353;
    valid_config.web_port = 38080;
    
    let result = PiHole::new(valid_config).await;
    assert!(result.is_ok(), "Valid configuration should work");
    
    println!("✅ Valid configuration works correctly");
    println!("🎉 Error Handling Test PASSED");
}

#[tokio::test]
async fn test_component_initialization() {
    println!("🧪 Testing Component Initialization");

    let temp_dir = TempDir::new().unwrap();
    let mut config = Config::default();
    config.data_dir = temp_dir.path().to_path_buf();
    config.dns_port = 45353;
    config.web_port = 48080;
    
    let pihole = PiHole::new(config.clone()).await.unwrap();
    
    // Test that components are properly initialized
    // (This is mainly testing that no panics occur during initialization)
    
    // Verify data directory structure
    assert!(config.data_dir.exists());
    
    // Check if database file would be created
    let _db_path = config.data_dir.join("pihole.db");
    // The database file might not exist yet as it's created lazily
    
    println!("✅ All components initialized without errors");
    println!("✅ Data directory structure is correct");
    
    drop(pihole); // Clean shutdown
    
    println!("🎉 Component Initialization Test PASSED");
}

#[tokio::test]
async fn test_concurrent_instance_creation() {
    println!("🧪 Testing Concurrent Instance Creation");

    let temp_dir = TempDir::new().unwrap();
    
    // Create multiple instances concurrently (with different ports)
    let mut tasks = Vec::new();
    
    for i in 0..3 {
        let temp_path = temp_dir.path().join(format!("instance_{}", i));
        let task = tokio::spawn(async move {
            let mut config = Config::default();
            config.data_dir = temp_path;
            config.dns_port = 55353 + i as u16;
            config.web_port = 58080 + i as u16;
            
            PiHole::new(config).await
        });
        tasks.push(task);
    }
    
    // Wait for all instances to be created
    let mut success_count = 0;
    for task in tasks {
        match task.await.unwrap() {
            Ok(_) => success_count += 1,
            Err(e) => println!("Instance creation failed: {}", e),
        }
    }
    
    assert!(success_count >= 2, "At least 2 instances should be created successfully");
    println!("✅ Created {} instances concurrently", success_count);
    println!("🎉 Concurrent Instance Creation Test PASSED");
}

#[tokio::test]
async fn test_memory_cleanup() {
    println!("🧪 Testing Memory Cleanup");

    let temp_dir = TempDir::new().unwrap();
    
    // Create and drop multiple instances to test memory cleanup
    for i in 0..5 {
        let instance_dir = temp_dir.path().join(format!("cleanup_test_{}", i));
        let mut config = Config::default();
        config.data_dir = instance_dir;
        config.dns_port = 55353 + i as u16;
        config.web_port = 58080 + i as u16;
        
        let pihole = PiHole::new(config).await.unwrap();
        
        // Use the instance briefly
        drop(pihole);
        
        println!("✅ Instance {} created and cleaned up", i);
    }
    
    println!("✅ All instances cleaned up without memory leaks");
    println!("🎉 Memory Cleanup Test PASSED");
}
