use zzpi_holelib::metrics::MetricsCollector;
use zzpi_holelib::security::RateLimiter;
use zzpi_holelib::cache::DnsCache;
use zzpi_holelib::dns_parser::{DnsPacket, DnsHeader, DnsQuestion, DnsRecord, DnsRecordData};
use std::time::Instant;
use std::net::IpAddr;
use tokio::time::Duration;
use std::net::Ipv4Addr;

#[tokio::test]
async fn test_metrics_performance() {
    let metrics = MetricsCollector::new();
    let client_ip: IpAddr = "192.168.1.100".parse().unwrap();
    
    let start = Instant::now();
    
    // Simulate high-volume query recording
    for i in 0..1000 {
        let domain = format!("test{}.example.com", i % 100);
        let blocked = i % 3 == 0; // Block every 3rd query
        metrics.record_query(client_ip, &domain, blocked, 50).await;
    }
    
    let duration = start.elapsed();
    println!("Recorded 1000 queries in {:?}", duration);
    
    // Should complete in reasonable time (< 100ms)
    assert!(duration.as_millis() < 100);
    
    // Verify metrics are correct
    let snapshot = metrics.get_snapshot().await;
    assert_eq!(snapshot.dns_metrics.total_queries, 1000);
    assert_eq!(snapshot.dns_metrics.blocked_queries, 334); // ~33% blocked
    assert!(snapshot.dns_metrics.block_percentage > 30.0);
    assert!(snapshot.dns_metrics.block_percentage < 35.0);
}

#[tokio::test]
async fn test_rate_limiter_performance() {
    let rate_limiter = RateLimiter::new(1000);
    let client_ip: IpAddr = "192.168.1.200".parse().unwrap();
    
    let start = Instant::now();
    
    // Test rate limiter with many queries
    let mut allowed_count = 0;
    for _ in 0..1500 {
        if rate_limiter.is_allowed(client_ip).await {
            allowed_count += 1;
        }
    }
    
    let duration = start.elapsed();
    println!("Rate limiter processed 1500 queries in {:?}", duration);
    
    // Should complete quickly
    assert!(duration.as_millis() < 50);
    
    // Should allow exactly 1000 queries (rate limit)
    assert_eq!(allowed_count, 1000);
}

#[tokio::test]
async fn test_cache_performance() {
    let cache = DnsCache::new(10000, Duration::from_secs(300));
    
    // Create a test response
    let response = DnsPacket {
        header: DnsHeader {
            id: 1234,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "test.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "test.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(1, 2, 3, 4)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    let start = Instant::now();
    
    // Cache many entries
    for i in 0..1000 {
        let domain = format!("cache-test{}.com", i);
        cache.set(&domain, 1, response.clone(), None).await;
    }
    
    let cache_duration = start.elapsed();
    println!("Cached 1000 entries in {:?}", cache_duration);
    
    let start = Instant::now();
    
    // Retrieve many entries
    let mut hit_count = 0;
    for i in 0..1000 {
        let domain = format!("cache-test{}.com", i);
        if cache.get(&domain, 1).await.is_some() {
            hit_count += 1;
        }
    }
    
    let retrieve_duration = start.elapsed();
    println!("Retrieved 1000 entries in {:?}", retrieve_duration);
    
    // All should be cache hits
    assert_eq!(hit_count, 1000);
    
    // Should be fast
    assert!(cache_duration.as_millis() < 100);
    assert!(retrieve_duration.as_millis() < 50);
}

#[tokio::test]
async fn test_concurrent_operations() {
    let metrics = MetricsCollector::new();
    let client_ip: IpAddr = "192.168.1.30".parse().unwrap();
    
    let start = Instant::now();
    
    // Spawn multiple concurrent tasks
    let mut tasks = Vec::new();
    for task_id in 0..10 {
        let metrics_clone = metrics.clone();
        let task = tokio::spawn(async move {
            for i in 0..100 {
                let domain = format!("concurrent{}-{}.com", task_id, i);
                metrics_clone.record_query(client_ip, &domain, i % 2 == 0, 25).await;
            }
        });
        tasks.push(task);
    }
    
    // Wait for all tasks to complete
    for task in tasks {
        task.await.unwrap();
    }
    
    let duration = start.elapsed();
    println!("Processed 1000 concurrent queries in {:?}", duration);
    
    // Should complete reasonably fast
    assert!(duration.as_millis() < 200);
    
    // Verify all queries were recorded
    let snapshot = metrics.get_snapshot().await;
    assert_eq!(snapshot.dns_metrics.total_queries, 1000);
    assert_eq!(snapshot.dns_metrics.blocked_queries, 500); // 50% blocked
}

#[tokio::test]
async fn test_memory_usage_stability() {
    let cache = DnsCache::new(1000, Duration::from_secs(60));
    
    let response = DnsPacket {
        header: DnsHeader {
            id: 1234,
            flags: 0x8180,
            question_count: 1,
            answer_count: 1,
            authority_count: 0,
            additional_count: 0,
        },
        questions: vec![DnsQuestion {
            name: "memory-test.com".to_string(),
            qtype: 1,
            qclass: 1,
        }],
        answers: vec![DnsRecord {
            name: "memory-test.com".to_string(),
            rtype: 1,
            class: 1,
            ttl: 300,
            data: DnsRecordData::A(Ipv4Addr::new(1, 1, 1, 1)),
        }],
        authorities: Vec::new(),
        additionals: Vec::new(),
    };
    
    // Add more entries than cache capacity to test eviction
    for i in 0..2000 {
        let domain = format!("memory{}.com", i);
        cache.set(&domain, 1, response.clone(), None).await;
    }
    
    let stats = cache.get_stats().await;
    
    // Cache should maintain its size limit
    assert!(stats.total_entries <= 1000);
    
    // Should have evicted older entries
    assert!(stats.total_entries > 900); // Should be close to capacity
}

#[cfg(test)]
mod benchmarks {
    use super::*;
    
    // This would be a benchmark if we had criterion
    #[tokio::test]
    async fn benchmark_dns_packet_parsing() {
        // Create a realistic DNS query packet
        let mut packet = Vec::new();
        
        // Header
        packet.extend_from_slice(&[0x12, 0x34]); // ID
        packet.extend_from_slice(&[0x01, 0x00]); // Flags
        packet.extend_from_slice(&[0x00, 0x01]); // Questions
        packet.extend_from_slice(&[0x00, 0x00]); // Answers
        packet.extend_from_slice(&[0x00, 0x00]); // Authority
        packet.extend_from_slice(&[0x00, 0x00]); // Additional
        
        // Question
        packet.extend_from_slice(&[0x03]); // www
        packet.extend_from_slice(b"www");
        packet.extend_from_slice(&[0x07]); // example
        packet.extend_from_slice(b"example");
        packet.extend_from_slice(&[0x03]); // com
        packet.extend_from_slice(b"com");
        packet.extend_from_slice(&[0x00]); // End
        packet.extend_from_slice(&[0x00, 0x01]); // Type A
        packet.extend_from_slice(&[0x00, 0x01]); // Class IN
        
        let start = Instant::now();
        
        // Parse many packets
        for _ in 0..1000 {
            let _parsed = DnsPacket::from_bytes(&packet).unwrap();
        }
        
        let duration = start.elapsed();
        println!("Parsed 1000 DNS packets in {:?}", duration);
        
        // Should be fast
        assert!(duration.as_millis() < 100);
    }
}
